# AI Tool Selection System - Intelligent Response Generation

## Overview

This system implements an **intelligent AI tool selection approach** where the AI model itself decides which tool to use based on the user's request. This eliminates the need for manual validation and provides more flexible, context-aware responses.

## How It Works

### 1. **AI Intelligence Layer** 🧠

- **Smart Tool Selection**: AI analyzes user input and chooses the appropriate tool
- **Natural Language Understanding**: Handles complex, nuanced queries intelligently
- **Dynamic Schema**: Reads actual database structure in real-time
- **Context Awareness**: Understands intent and responds appropriately

### 2. **Dual Tool System** 🛠️

- **`generate_sql_query`**: For valid queries about available data
- **`explain_available_data`**: For invalid/unclear queries about unavailable data

### 3. **Fallback Safety Layer** 🛡️

- **Graceful Degradation**: Always returns meaningful response
- **Error Handling**: Comprehensive error management
- **User Guidance**: Helpful suggestions when things go wrong

## System Architecture

```
User Query → AI Analysis → Tool Selection → Response Generation
                ↓              ↓              ↓
            Understand    Choose Tool     Generate
            Intent        (generate_sql  Response
                         |explain_data)
```

## Available Tools

### 🔧 **Tool 1: `generate_sql_query`**

**Purpose**: Generate SQL queries for available data
**When to Use**: User asks about bookings, expenses, payments, costs, reservations, purchases
**Output**: SQL query + visualization type + explanation

**Examples**:

- ✅ "ما هي الحجوزات لهذا الأسبوع؟" → Generates SQL for bookings
- ✅ "Total expenses this month" → Generates SQL for expenses
- ✅ "المدفوعات المعلقة" → Generates SQL for payments

### 📚 **Tool 2: `explain_available_data`**

**Purpose**: Explain what data is available when user asks about unavailable data
**When to Use**: User asks about employees, users, customers, halls, or makes unclear requests
**Output**: Helpful explanation + suggestions for available data

**Examples**:

- ❌ "أريد معرفة الموظفين" → Explains what IS available
- ❌ "I want customer data" → Suggests alternative queries
- ❌ "أريد بيانات" → Guides user to available data

## Available Data Tables

✅ **ALLOWED (Will Generate SQL):**

- `bookings` - Hall reservations, dates, amounts, status
- `expenses` - Purchase costs, supplier payments, categories
- `payments` - Payment records for bookings and expenses
- `expenses_payments` - Expense payment details

❌ **BLOCKED (Will Get Explanation):**

- `employees` - Employee information
- `users` - User profiles
- `customers` - Customer details
- `halls` - Hall information
- Any other tables not in schema

## API Endpoints

### 1. **AI Chat** - `POST /analytics/ai-chat`

Processes user queries and AI automatically chooses the right tool.

**Example Request:**

```json
{
  "message": "ما هي الحجوزات لهذا الأسبوع؟",
  "language": "ar"
}
```

**Example Response (Valid Query):**

```json
{
  "sqlQuery": "SELECT * FROM bookings WHERE client_id = 51 AND start_date >= CURRENT_DATE - INTERVAL '7 days'",
  "visualizationType": "table",
  "explanation": "This query shows all bookings from the last 7 days for your client"
}
```

**Example Response (Invalid Query):**

```json
{
  "sqlQuery": "",
  "visualizationType": "table",
  "explanation": "I cannot provide employee data as it's not available in the system. However, I can help you with: Bookings, Expenses, and Payments. Try asking about 'bookings this week' or 'total expenses this month' instead."
}
```

### 2. **Test AI Tools** - `GET /analytics/test-ai-tools`

Tests the AI tool selection system with various query types.

**Response:**

```json
{
  "message": "AI Tool Selection Test - The AI will choose the appropriate tool for each query",
  "description": "This system now uses AI intelligence to decide which tool to use instead of manual validation",
  "availableTools": [
    {
      "name": "generate_sql_query",
      "purpose": "Generate SQL for available data (bookings, expenses, payments)",
      "whenToUse": "User asks about hall reservations, costs, purchases, or payment records"
    },
    {
      "name": "explain_available_data",
      "purpose": "Explain what data is available when user asks about unavailable data",
      "whenToUse": "User asks about employees, users, customers, halls, or makes unclear requests"
    }
  ],
  "testQueries": [...],
  "instructions": [...]
}
```

## Query Examples

### ✅ **Valid Queries (Will Use `generate_sql_query` Tool):**

- Arabic: "ما هي الحجوزات لهذا الأسبوع؟"
- English: "Which bookings this week?"
- Arabic: "إجمالي المصروفات لهذا الشهر"
- English: "Total expenses this month"
- Arabic: "المدفوعات المعلقة للحجوزات"
- English: "Pending payments for bookings"

### ❌ **Invalid Queries (Will Use `explain_available_data` Tool):**

- Arabic: "أريد معرفة الموظفين"
- English: "I want to know about employees"
- Arabic: "أريد بيانات العملاء"
- English: "I want customer data"
- Arabic: "أريد معلومات المستخدمين"
- English: "I want user information"

### 🤔 **Unclear Queries (Will Use `explain_available_data` Tool):**

- Arabic: "أريد بيانات"
- English: "Show me something"

## Benefits of This Approach

### 1. **Intelligence** 🧠

- **AI Decision Making**: Model chooses the right tool automatically
- **Context Understanding**: Better natural language processing
- **Flexible Responses**: More nuanced and helpful explanations

### 2. **Performance** ⚡

- **No Manual Validation**: Eliminates preprocessing overhead
- **Single AI Call**: One intelligent decision instead of multiple steps
- **Scalable**: Handles complex queries efficiently

### 3. **User Experience** 😊

- **Always Helpful**: Never returns null or errors
- **Contextual Guidance**: Explains what IS available when data isn't
- **Natural Responses**: More conversational and helpful

### 4. **Maintainability** 🛠️

- **Cleaner Code**: No complex validation logic
- **AI-Driven**: Model learns and improves over time
- **Easy to Extend**: Add new tools without changing validation

## How AI Makes Decisions

The AI model analyzes the user's request and chooses the appropriate tool based on:

1. **Content Analysis**: What data is the user asking for?
2. **Intent Recognition**: Is this a valid query or a request for unavailable data?
3. **Context Understanding**: Can I generate SQL or should I explain alternatives?
4. **Tool Selection**: Which tool best serves the user's needs?

## Testing the System

### 1. **Test Valid Queries:**

```bash
curl -X POST "http://localhost:3000/analytics/ai-chat" \
  -H "Content-Type: application/json" \
  -d '{"message": "ما هي الحجوزات لهذا الأسبوع؟", "language": "ar"}'
```

### 2. **Test Invalid Queries:**

```bash
curl -X POST "http://localhost:3000/analytics/ai-chat" \
  -H "Content-Type: application/json" \
  -d '{"message": "أريد معرفة الموظفين", "language": "ar"}'
```

### 3. **Test AI Tool Selection:**

```bash
curl "http://localhost:3000/analytics/test-ai-tools"
```

## Configuration

### Environment Variables:

```bash
OPENAI_API_KEY=your_openai_api_key
OPENAI_MODEL=gpt-5
OPENAI_MAX_TOKENS=1000
OPENAI_TEMPERATURE=0.1
```

### Database Tables:

The system automatically reads these tables:

- `bookings`
- `expenses`
- `payments`
- `expenses_payments`

## Future Enhancements

### 1. **Additional Tools**

- **`suggest_queries`**: Suggest related queries based on user input
- **`explain_schema`**: Explain database structure and relationships
- **`optimize_query`**: Suggest query improvements

### 2. **Advanced AI Features**

- **Learning**: Model improves from user interactions
- **Personalization**: Adapts to user preferences
- **Context Memory**: Remembers conversation context

### 3. **Analytics Dashboard**

- **Tool Usage**: Which tools are used most
- **Query Patterns**: Common user request types
- **Performance Metrics**: Response times and accuracy

## Troubleshooting

### Common Issues:

1. **"No function call in OpenAI response"**
   - Check OpenAI API key
   - Verify model configuration
   - Check system prompt clarity

2. **"Wrong tool selected"**
   - Review system prompt instructions
   - Check tool descriptions
   - Verify model training data

3. **"Database schema not found"**
   - Check database connection
   - Verify table existence
   - Check permissions

## Support

For technical support or questions about this system:

- Check the logs for detailed error messages
- Use the test endpoints to validate functionality
- Review the AI tool descriptions and system prompt

---

**This AI tool selection approach provides intelligent, context-aware responses while maintaining security and performance for production AI chat systems.**
