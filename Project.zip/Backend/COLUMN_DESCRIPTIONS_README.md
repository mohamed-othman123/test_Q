# Column Descriptions Configuration

## 📋 Overview

This feature allows you to manually update column descriptions for better SQL generation in your AI agent. The descriptions are stored in a JSON file and automatically regenerate embeddings when updated.

## 🗂️ File Structure

```
src/modules/ai-agent/
├── config/
│   └── column-descriptions.json    # Column descriptions configuration
├── ai-schema.service.ts            # Service with JSON loading logic
├── ai-schema.controller.ts         # API endpoints
└── ai-schema.permissions.ts        # Permissions configuration
```

## 📝 JSON Configuration Format

The `column-descriptions.json` file contains descriptions for each table and its columns:

```json
{
  "bookings": {
    "id": "Unique booking identifier",
    "client_id": "Reference to the client who made the booking",
    "hall_id": "Reference to the hall/venue being booked",
    "start_date": "Booking start date and time",
    "end_date": "Booking end date and time",
    "amount": "Total booking amount in currency",
    "status": "Booking status (confirmed, pending, cancelled)"
  },
  "expenses": {
    "id": "Unique expense identifier",
    "client_id": "Reference to the client this expense belongs to",
    "amount": "Expense amount in currency",
    "description": "Description of the expense",
    "date": "Date when expense occurred"
  }
}
```

## 🚀 API Endpoints

### 1. Get All Column Descriptions

```http
GET /ai-schemas/column-descriptions
```

Returns the current column descriptions from the JSON file.

### 2. Update Column Descriptions (File + Regenerate Embeddings)

```http
PUT /ai-schemas/{tableName}/columns/descriptions/file
Content-Type: application/json

{
  "columnDescriptions": {
    "amount": "Updated description for amount column",
    "status": "Updated description for status column"
  }
}
```

This endpoint:

- ✅ Updates the JSON file
- ✅ Regenerates embeddings for the table
- ✅ Updates the database schema

### 3. Reload Column Descriptions

```http
POST /ai-schemas/reload-column-descriptions
```

Reloads the column descriptions from the JSON file without regenerating embeddings.

### 4. Update Single Column Description

```http
PUT /ai-schemas/{tableName}/columns/{columnName}/description
Content-Type: application/json

{
  "description": "New description for this column"
}
```

### 5. Update Multiple Column Descriptions (Database Only)

```http
PUT /ai-schemas/{tableName}/columns/descriptions
Content-Type: application/json

{
  "columnDescriptions": {
    "amount": "Description for amount",
    "status": "Description for status"
  }
}
```

## 🔧 How to Use

### Step 1: Edit the JSON File

Manually edit `src/modules/ai-agent/config/column-descriptions.json`:

```json
{
  "bookings": {
    "amount": "Total booking amount in USD currency",
    "status": "Booking status: confirmed, pending, or cancelled"
  }
}
```

### Step 2: Update via API

```bash
# Update descriptions and regenerate embeddings
curl -X PUT http://localhost:3000/ai-schemas/bookings/columns/descriptions/file \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "columnDescriptions": {
      "amount": "Total booking amount in USD currency",
      "status": "Booking status: confirmed, pending, or cancelled"
    }
  }'
```

### Step 3: Verify Changes

```bash
# Check the updated descriptions
curl -X GET http://localhost:3000/ai-schemas/column-descriptions \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 🎯 Benefits

### ✅ Better SQL Generation

- More accurate column selection
- Better understanding of data relationships
- Improved query performance

### ✅ Easy Maintenance

- JSON file is easy to edit
- Version control friendly
- No code changes needed

### ✅ Automatic Embedding Updates

- Embeddings regenerate automatically
- Vector search stays accurate
- No manual intervention required

## 📊 Example Workflow

### 1. Initial Setup

```bash
# Initialize schemas with default descriptions
POST /ai-schemas/initialize
```

### 2. Update Descriptions

```bash
# Edit JSON file manually
# Then update via API
PUT /ai-schemas/bookings/columns/descriptions/file
```

### 3. Test AI Agent

```bash
# Ask a question that uses the updated descriptions
POST /ai-agent/chat
{
  "message": "Show me bookings with high amounts"
}
```

## 🔍 Embedding Generation

When you update column descriptions, the system:

1. **Loads** the updated JSON file
2. **Creates** new embedding text with descriptions:
   ```
   Table: bookings. Hall reservations and booking information.
   Columns: id (integer): Unique booking identifier,
   amount (decimal): Total booking amount in USD currency,
   status (varchar): Booking status: confirmed, pending, or cancelled
   ```
3. **Generates** new embedding using OpenAI
4. **Updates** the database with new embedding
5. **Improves** vector search accuracy

## 🛠️ Troubleshooting

### Issue: JSON file not found

```bash
# Check if file exists
ls src/modules/ai-agent/config/column-descriptions.json

# Create if missing
mkdir -p src/modules/ai-agent/config
touch src/modules/ai-agent/config/column-descriptions.json
```

### Issue: Embeddings not updating

```bash
# Force reload descriptions
POST /ai-schemas/reload-column-descriptions

# Refresh specific table
POST /ai-schemas/bookings/refresh
```

### Issue: Permission denied

```bash
# Check if you have the required permissions
# You need: ai-schemas:write permission
```

## 📈 Best Practices

1. **Use Clear Descriptions**: Be specific about what each column contains
2. **Include Data Types**: Mention if it's currency, date, status, etc.
3. **Add Relationships**: Mention foreign keys and their purpose
4. **Keep Updated**: Update descriptions when schema changes
5. **Version Control**: Commit JSON changes to track modifications

## 🎉 Result

With this system, your AI agent will:

- ✅ Generate more accurate SQL queries
- ✅ Better understand your database structure
- ✅ Provide more relevant responses
- ✅ Maintain accuracy as your schema evolves

The column descriptions are now easily manageable through a JSON file and automatically improve your AI agent's performance! 🚀
