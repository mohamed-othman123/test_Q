import { Controller, Post, Body, Patch, Req, Param, Get, Query, Res } from '@nestjs/common';
import { AuthService } from './services/auth.service';
import { CreateAuthDto } from './dto/create-auth.dto';
import { LoginAuthDto } from './dto/login-auth.dto';
import { Public } from './decorator/public.decorator';
import { ApiTags, ApiOperation, ApiResponse, ApiBody, ApiHeader } from '@nestjs/swagger';
import { ForgetPasswordDto, ResetPasswordDto } from './dto/reset-password.dto';
import { Language } from '../common/decorators/languages-headers.decorator';
import { LanguagesEnum } from '../common/enums/lang.enum';
import { RefreshTokenDto } from './dto/refreshTokenDto';
import { RefreshTokenResponse } from './interfaces/auth.interface';
import { SignupDto } from './dto/signup.dto';
import { FastifyReply } from 'fastify';
import { Recaptcha } from '@nestlab/google-recaptcha';
@ApiTags('auth')
@Controller('auth')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Public()
  @Post('register')
  @ApiOperation({ summary: 'Register a client' })
  @ApiResponse({ status: 201, description: 'User registered successfully.' })
  @ApiResponse({ status: 400, description: 'Bad Request.' })
  async create(
    @Body() createAuthDto: CreateAuthDto,
    @Language() lang,
  ): Promise<{ userId: number; clientId: number; message: string }> {
    return this.authService.register(createAuthDto, lang);
  }

  @Recaptcha({ action: 'Signup' })
  @Public()
  @Post('signup')
  @ApiOperation({ summary: 'Signup API for Landing Page' })
  @ApiResponse({ status: 201, description: 'User signed up successfully.' })
  @ApiResponse({ status: 400, description: 'Bad Request.' })
  async signup(@Body() signupDto: SignupDto, @Language() lang: LanguagesEnum) {
    return this.authService.signup(signupDto, lang);
  }

  @Public()
  @Get('verify')
  @ApiOperation({ summary: 'Verify API for Signup users' })
  @ApiResponse({ status: 200, description: 'Account has verified successfully.' })
  @ApiResponse({ status: 400, description: 'Invalid token' })
  async verify(
    @Query('token') token: string,
    @Query('lang') lang: string,
    @Res() reply: FastifyReply,
  ) {
    try {
      const result = await this.authService.verifyEmail(token, lang);

      return reply.redirect(`${result.redirectURL}?verified=true`, 302);
    } catch (error) {
      throw error;
    }
  }

  @Public()
  @Post('login')
  @ApiOperation({ summary: 'Login a user' })
  @ApiBody({ type: LoginAuthDto })
  @ApiResponse({ status: 200, description: 'User logged in successfully.' })
  @ApiResponse({ status: 400, description: 'Bad Request.' })
  async login(
    @Body() loginAuthDto: LoginAuthDto,
    @Req() req,
    @Language() lang,
  ): Promise<{ userId: number; clientId: number; message: string }> {
    return this.authService.login(loginAuthDto, req, lang);
  }

  @Public()
  @Post('verifyOtp')
  @ApiOperation({ summary: 'Verify OTP for login or registration' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        userId: { type: 'number' },
        otp: { type: 'number' },
        channel: { type: 'string', enum: ['login', 'register'] },
        isRememberMe: { type: 'boolean', default: false },
      },
    },
  })
  @ApiResponse({ status: 200, description: 'OTP verified successfully.' })
  @ApiResponse({ status: 400, description: 'Bad Request.' })
  async verifyOtp(
    @Req() req: Request,
    @Body()
    {
      userId,
      otp,
      channel,
      isRememberMe,
    }: { userId: number; otp: number; channel: 'login' | 'register'; isRememberMe: boolean },
    @Language() lang: LanguagesEnum,
  ): Promise<RefreshTokenResponse> {
    return this.authService.verifyOtp(userId, otp, channel, isRememberMe, lang, req);
  }

  @Public()
  @Post('resendOtp')
  @ApiOperation({ summary: 'Resend OTP for login or registration' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        email: { type: 'string' },
      },
    },
  })
  @ApiResponse({ status: 200, description: 'OTP resent successfully.' })
  @ApiResponse({ status: 400, description: 'Bad Request.' })
  async resendOtp(
    @Body() { email }: { email: string },
    @Language() lang,
  ): Promise<{ userId: number }> {
    return this.authService.resendOtp(email, lang);
  }
  @Public()
  @Post('refreshToken')
  async refreshAccessToken(
    @Req() req: Request,
    @Body() refreshTokenDto: RefreshTokenDto,
    @Language() lang: LanguagesEnum,
  ): Promise<RefreshTokenResponse> {
    return this.authService.refreshAccessToken(refreshTokenDto, lang, req);
  }

  @Public()
  @ApiOperation({ summary: 'user enter email to reset passwords' })
  @Patch('forgotpassword')
  public async forgetPassword(
    @Body() forgetPasswordDto: ForgetPasswordDto,
    @Req() req,
    @Language() lang,
  ): Promise<boolean> {
    return this.authService.forgetPassword(forgetPasswordDto, req, lang);
  }

  @Public()
  @ApiOperation({ summary: 'user enter new password to reset password' })
  @Patch('reset-password/:token')
  async resetpassword(
    @Req() req: Request,
    @Body() resetPasswordDto: ResetPasswordDto,
    @Param('token') token: string,
    @Language() lang,
  ): Promise<{ token: string; refresh_token: string }> {
    return this.authService.resetPassword(resetPasswordDto, token, req);
  }
}
