import {
  CallHandler,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { FastifyRequest } from 'fastify';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from '../decorator/public.decorator';
import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

@Injectable()
export class EmployeeHallsInterceptor implements NestInterceptor {
  constructor(
    private readonly hallIdExtractor: HallIdExtractor,
    private readonly reflector: Reflector,
  ) {}

  async intercept(context: ExecutionContext, next: CallHandler): Promise<Observable<any>> {
    const request = context.switchToHttp().getRequest<FastifyRequest & { user: any }>();
    const method = request.method;

    // Check if the route is public
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return next.handle();

    const requiredPermissions = this.reflector.get<
      Array<{
        type: PermissionsTypeEnum;
      }>
    >('permissions', context.getHandler());

    const allowedTypes = [
      PermissionsTypeEnum.CREATE,
      PermissionsTypeEnum.READ,
      PermissionsTypeEnum.UPDATE,
    ];

    // If no permissions or none match allowed types, skip custom logic
    if (
      !requiredPermissions ||
      !requiredPermissions.some((permission) => allowedTypes.includes(permission.type))
    ) {
      return next.handle();
    }

    const user = request.user;

    if (!['POST', 'GET', 'PATCH'].includes(method)) return next.handle();

    const hallIds = await this.hallIdExtractor.extractAll(request);

    if (!hallIds.length && method !== 'PATCH') throw new ForbiddenException(ErrorKeys.forbidden);
    // Check if the user has access to all the extracted hall IDs
    const userHallIds = user.halls || [];

    const isAllowed = hallIds.every((id) => userHallIds.includes(id));

    if (!isAllowed) throw new ForbiddenException(ErrorKeys.forbidden);

    return next.handle();
  }
}
