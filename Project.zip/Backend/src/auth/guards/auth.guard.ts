import {
  BadRequestException,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { CacheService } from '../../providers/cache/cache.service';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { IS_PUBLIC_KEY } from '../decorator/public.decorator';
import { FastifyRequest } from 'fastify';
import { UsersService } from '../../modules/users/users.service';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { getFingerPrint } from 'src/core/helpers/cast.helper';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { HallsService } from '../../modules/halls/halls.service';
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private reflector: Reflector,
    private jwtService: JwtService,
    private configService: ConfigService,
    private readonly cacheService: CacheService,
    private usersService: UsersService,
    private hallsService: HallsService,
  ) {}
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) {
      return true;
    }
    const request = context.switchToHttp().getRequest();
    const token = this.extractTokenFromHeader(request);
    if (!token) {
      throw new UnauthorizedException(ErrorKeys.unauthorized);
    }

    let payload: any;

    try {
      payload = this.jwtService.verify(token, {
        secret: this.configService.get<string>('JWT_SECRET'),
      });
      const fingerprint = payload.fingerprint;
      const req = context.switchToHttp().getRequest();
      const calculatedFingerprint = getFingerPrint(req);
      if (fingerprint !== calculatedFingerprint) {
        throw new UnauthorizedException(ErrorKeys.unauthorized);
      }
    } catch (error) {
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException(ErrorKeys.tokenExpired);
      }
      throw new UnauthorizedException(ErrorKeys.unauthorized);
    }
    const currentHalls = await this.hallsService.getClientHalls({
      clientId: payload.clientId,
      id: payload.userId,
      type: payload.type,
    });
    request.user = {
      id: payload.userId,
      email: payload.email,
      clientId: payload.clientId,
      type: payload.type,
      permissionType: payload.permissionType,
      halls: currentHalls.map((hall) => hall.id),
      name: payload.name,
    } as AuthenticatedUser;

    const requiredPermissions = this.reflector.get<
      {
        en_name: string;
        en_module: string;
        ar_name: string;
        ar_module: string;
        route: string;
      }[]
    >('permissions', context.getHandler());

    if (requiredPermissions && requiredPermissions.length > 0) {
      const hasPermission = await Promise.all(
        requiredPermissions.map((permission) =>
          this.usersService.hasPermission(payload.userId, permission),
        ),
      );

      const permissionGranted = hasPermission.some((permission) => permission);

      if (!permissionGranted) {
        throw new ForbiddenException(ErrorKeys.forbidden);
      }
    }
    const inActiveUser = await this.usersService.checkInActiveUser(payload.userId);
    if (inActiveUser) {
      throw new UnauthorizedException(ErrorKeys.userNotActive);
    }
    this.cacheService.hset('active:users', payload.userId.toString(), Date().toString());

    return true;
  }
  private extractTokenFromHeader(request: FastifyRequest): string | undefined {
    const [type, token] = request.headers.authorization?.split(' ') ?? [];
    return type === 'Bearer' ? token : undefined;
  }
}
