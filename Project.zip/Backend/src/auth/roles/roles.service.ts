import { PermissionsService } from './../permissions/permissions.service';
import { BadRequestException, Injectable, OnModuleInit } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, Not, Repository, In } from 'typeorm';
import { Role } from './entities/role.entity';
import { CreateRoleDto } from './dto/create-role.dto';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { ClientRolesEnum, ClientRolesEnumAr } from './enums/default_roles.enums';
import { UpdateRoleDto } from './dto/update-role.dto';
import { RoleDetails } from './interfaces/role.intreface';
import { FilterRolesDto, SortByOptions } from './dto/filter-role.dto';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { PaginatorService } from '../../common/paginator/paginator.service';
import { HandelTwoName } from '../../core/helpers/cast.helper';

@Injectable()
export class RolesService implements OnModuleInit {
  constructor(
    @InjectRepository(Role)
    private roleRepository: Repository<Role>,
    private readonly paginatorService: PaginatorService,
    private readonly permissionsService: PermissionsService,
  ) { }

  async onModuleInit(): Promise<void> {
    await this.syncOwnersRole();
    await this.syncAdminsRole();
  }

  async create(
    createRoleDto: CreateRoleDto,
    user: { clientId: number; id: number },
  ): Promise<RoleDetails> {
    let { name, name_ar, permissions, notes } = createRoleDto;
    const { clientId, id: userId } = user;
    if (!name && !name_ar) {
      throw new BadRequestException(ErrorKeys.nameIsRequired);
    }
    [name, name_ar] = HandelTwoName(name, name_ar);
    if (
      name === ClientRolesEnum.admin ||
      name === ClientRolesEnumAr.admin ||
      name === ClientRolesEnum.owner ||
      name === ClientRolesEnumAr.owner ||
      name_ar === ClientRolesEnum.admin ||
      name_ar === ClientRolesEnumAr.admin ||
      name_ar === ClientRolesEnum.owner ||
      name_ar === ClientRolesEnumAr.owner
    ) {
      throw new BadRequestException(ErrorKeys.invaildRole);
    }
    const existRole = await this.roleRepository.findOne({
      where: [
        { name, client: { id: clientId }, deleted: false },
        { name: name_ar, client: { id: clientId }, deleted: false },
        { name_ar, client: { id: clientId }, deleted: false },
        { name_ar: name, client: { id: clientId }, deleted: false },
      ],
    });
    if (existRole) {
      throw new BadRequestException(ErrorKeys.roleExist);
    }

    const existingPermissions =
      await this.permissionsService.validateExistingPermissions(permissions);
    const role = this.roleRepository.create({
      name,
      name_ar,
      notes,
      client: { id: clientId },
      created_by: userId,
    });
    if (permissions && permissions.length > 0) {
      role.permissions = existingPermissions;
    }
    const Savedrole = await this.roleRepository.save(role);

    return this.getRole(Savedrole.id, user);
  }
  async findAll(
    filter: FilterRolesDto,
    user: { clientId: number; id: number },
  ): Promise<{
    items: RoleDetails[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    let { sortBy, sortOrder } = filter;
    const take = +filter.limit || 10;
    const skip = ((+filter.page || 1) - 1) * take;
    sortBy = sortBy || SortByOptions.createdAt;
    sortOrder = sortOrder || SortOrderEnum.DESC;
    const queryBuilder = this.roleRepository
      .createQueryBuilder('r')
      .leftJoin('r.users', 'u')
      .select([
        'r.id AS id',
        'r.created_at AS created_at ',
        'r.updated_at AS updated_at ',
        'r.name AS name',
        'r.name_ar AS name_ar',
        'r.notes AS notes ',
        'COUNT(DISTINCT CASE WHEN u.deleted = false AND u.active = true THEN u.id END) AS userCount',
      ])
      .groupBy('r.id');

    const hasFilterKeys =
      filter.name || filter.notes || filter.userCount !== undefined || filter.creationDate;
    if (!hasFilterKeys) {
      queryBuilder
        .where('r.client_id = :clientId', { clientId: user.clientId })
        .andWhere('r.deleted = :deleted', { deleted: false })
        .andWhere('r.name NOT IN (:...names)', {
          names: [ClientRolesEnum.owner, ClientRolesEnum.admin],
        })
        .andWhere('r.name_ar NOT IN (:...names)', {
          names: [ClientRolesEnumAr.owner, ClientRolesEnumAr.admin],
        });
    }
    if (hasFilterKeys) {
      queryBuilder.where(
        new Brackets((qb) => {
          qb.where('r.client_id = :clientId', { clientId: user.clientId })
            .andWhere('r.deleted = :deleted', {
              deleted: false,
            })
            .andWhere('r.name NOT IN (:...names)', {
              names: [ClientRolesEnum.owner, ClientRolesEnum.admin],
            })
            .andWhere('r.name_ar NOT IN (:...names)', {
              names: [ClientRolesEnumAr.owner, ClientRolesEnumAr.admin],
            });
          if (filter.notes) {
            qb.andWhere('r.notes ILIKE :notesFilter', {
              notesFilter: `%${filter.notes}%`,
            });
          }
          if (filter.creationDate) {
            qb.andWhere('DATE(r.created_at) = :creationDate', {
              creationDate: filter.creationDate,
            });
          }
          if (filter.name) {
            qb.andWhere('(r.name ILIKE :nameFilter OR r.name_ar ILIKE :nameFilter)', {
              nameFilter: `%${filter.name}%`,
            });
          }
        }),
      );

      if (filter.userCount !== undefined) {
        queryBuilder.having(
          'COUNT(DISTINCT CASE WHEN u.deleted = false AND u.active = true THEN u.id END) = :userCount',
          { userCount: filter.userCount },
        );
      }
    }
    if (sortBy === SortByOptions.userCount) {
      queryBuilder.orderBy(`userCount`, sortOrder);
    } else if (sortBy === SortByOptions.name) {
      queryBuilder.orderBy(`r.name`, sortOrder).addOrderBy(`r.name_ar`, sortOrder);
    } else {
      queryBuilder.orderBy(`r.${sortBy}`, sortOrder);
    }
    const result = await queryBuilder.getRawMany();
    // Take only the specified amount of results for pagination
    const paginatedResults = result.slice(skip, skip + take);

    const formattedItems = paginatedResults.map((role) => ({
      id: role.id,
      created_at: role.created_at,
      updated_at: role.updated_at,
      name: role.name,
      name_ar: role.name_ar,
      notes: role.notes,
      userCount: +role.usercount,
    }));
    return this.paginatorService.paginate(formattedItems, result.length, +filter?.page || 1, take);
  }

  async findOne(
    id: number,
    clientId: number,
  ): Promise<{
    id: number;
    name: string;
    name_ar: string;
    notes: string | null;
    created_at: Date;
    updated_at: Date;
    permissions: number[];
  }> {
    const role = await this.roleRepository.findOne({
      where: {
        id,
        client: { id: clientId },
        deleted: false,
        name: Not(In([ClientRolesEnum.owner, ClientRolesEnum.admin])),
        name_ar: Not(In([ClientRolesEnumAr.owner, ClientRolesEnumAr.admin])),
      },
      relations: ['permissions'],
    });

    if (!role) {
      throw new BadRequestException(ErrorKeys.roleNotFound);
    }
    const permissions = role.permissions.map((permission) => permission.id);
    return {
      id: role.id,
      created_at: role.created_at,
      updated_at: role.updated_at,
      name: role.name,
      name_ar: role.name_ar,
      notes: role.notes,
      permissions,
    };
  }
  async findRoleByName(
    name: ClientRolesEnum,
    user: { clientId: number; id: number },
  ): Promise<Role> {
    const { clientId, id: userId } = user;
    const role = await this.roleRepository.findOne({
      where: {
        name,
        client: { id: clientId },
        deleted: false,
      },
    });

    if (!role) {
      const permissions = await this.permissionsService.permissionsInRange();
      const adminRole = this.roleRepository.create({
        name: ClientRolesEnum.admin,
        name_ar: ClientRolesEnumAr.admin,
        client: { id: clientId },
        permissions,
        created_by: userId,
      });
      return await this.roleRepository.save(adminRole);
    }
    return role;
  }

  private async getRole(id: number, user: { clientId: number; id: number }): Promise<RoleDetails> {
    const { clientId } = user;
    const role = await this.roleRepository.findOne({
      where: {
        id,
        client: { id: clientId },
        deleted: false,
        name: Not(In([ClientRolesEnum.owner, ClientRolesEnum.admin])),
        name_ar: Not(In([ClientRolesEnumAr.owner, ClientRolesEnumAr.admin])),
      },
      relations: ['permissions'],
    });

    if (!role) {
      throw new BadRequestException(ErrorKeys.roleNotFound);
    }
    return {
      id: role.id,
      created_at: role.created_at,
      updated_at: role.updated_at,
      name: role.name,
      name_ar: role.name_ar,
      notes: role.notes,
      permissions: role.permissions,
    };
  }

  async update(
    id: number,
    updateRoleDto: UpdateRoleDto,
    user: { clientId: number; id: number },
  ): Promise<RoleDetails> {
    const { name, name_ar, permissions, notes } = updateRoleDto;
    const { clientId, id: userId } = user;
    const role = await this.roleRepository.findOne({
      where: {
        id,
        client: { id: clientId },
        deleted: false,
        name: Not(In([ClientRolesEnum.owner, ClientRolesEnum.admin])),
        name_ar: Not(In([ClientRolesEnumAr.owner, ClientRolesEnumAr.admin])),
      },
      relations: ['permissions'],
    });

    if (!role) {
      throw new BadRequestException(ErrorKeys.roleNotFound);
    }
    if (name && name_ar) {
      await this.validateRoleName(id, name, name_ar, clientId);
      role.name = name;
      role.name_ar = name_ar;
    } else if (name) {
      await this.validateRoleName(id, name, null, clientId);
      role.name = name;
    } else if (name_ar) {
      await this.validateRoleName(id, null, name_ar, clientId);
      role.name_ar = name_ar;
    }
    if (permissions) {
      role.permissions = await this.permissionsService.validateExistingPermissions(permissions);
    }
    const savedRole = await this.roleRepository.save({ ...role, notes, updated_by: userId });

    return this.getRole(savedRole.id, user);
  }
  async initRoleWithPermissions(client: { userId: number; clientId: number }): Promise<Role> {
    const { clientId, userId } = client;
    const permissions = await this.permissionsService.permissionsInRange();
    const ownerRole = this.roleRepository.create({
      name: ClientRolesEnum.owner,
      name_ar: ClientRolesEnumAr.owner,
      client: { id: clientId },
      permissions,
      created_by: userId,
    });

    const adminRole = this.roleRepository.create({
      name: ClientRolesEnum.admin,
      name_ar: ClientRolesEnumAr.admin,
      client: { id: clientId },
      permissions,
      created_by: userId,
    });
    const savedRoles = await this.roleRepository.save([ownerRole, adminRole]);

    return savedRoles[0];
  }

  async syncOwnersRole(): Promise<void> {
    const ownersRole = await this.roleRepository.find({
      where: { name: ClientRolesEnum.owner },
      relations: ['permissions'],
    });
    if (ownersRole.length === 0) {
      return;
    }
    const permissions = await this.permissionsService.permissionsInRange();
    for (const role of ownersRole) {
      const rolePermissions = role.permissions.map((permission) => permission.id);
      const missingPermissions = permissions.filter(
        (permission) => !rolePermissions.includes(permission.id),
      );
      if (missingPermissions.length > 0) {
        role.permissions = [...role.permissions, ...missingPermissions];
        await this.roleRepository.save(role);
      }
    }
  }

  async syncAdminsRole(): Promise<void> {
    const adminsRole = await this.roleRepository.find({
      where: { name: ClientRolesEnum.admin },
      relations: ['permissions'],
    });
    if (adminsRole.length === 0) {
      return;
    }
    const permissions = await this.permissionsService.permissionsInRange();
    for (const role of adminsRole) {
      const rolePermissions = role.permissions.map((permission) => permission.id);
      const missingPermissions = permissions.filter(
        (permission) => !rolePermissions.includes(permission.id),
      );
      if (missingPermissions.length > 0) {
        role.permissions = [...role.permissions, ...missingPermissions];
        await this.roleRepository.save(role);
      }
    }
  }
  async remove(id: number, user: { clientId: number; id: number }): Promise<Role> {
    const { clientId, id: userId } = user;

    const role = await this.roleRepository.findOne({
      where: {
        id,
        client: { id: clientId },
        deleted: false,
        name: Not(In([ClientRolesEnum.owner, ClientRolesEnumAr.owner])),
        name_ar: Not(In([ClientRolesEnum.owner, ClientRolesEnumAr.owner])),
      },
      relations: { users: true },
    });

    if (!role) {
      throw new BadRequestException(ErrorKeys.roleNotFound);
    }

    if (role.users.length > 0) {
      throw new BadRequestException(ErrorKeys.roleContainsUsers);
    }

    const softDeleteData = {
      deleted: true,
      deleted_at: new Date(),
      deleted_by: userId,
    };
    await this.roleRepository.update({ id }, softDeleteData);
    return { ...role, ...softDeleteData };
  }

  private async validateRoleName(
    id: number,
    name: string,
    name_ar: string,
    clientId: number,
  ): Promise<void> {
    let existRole = undefined;
    if (name && name_ar) {
      if (
        name === ClientRolesEnum.admin ||
        name === ClientRolesEnumAr.admin ||
        name === ClientRolesEnum.owner ||
        name === ClientRolesEnumAr.owner ||
        name_ar === ClientRolesEnum.admin ||
        name_ar === ClientRolesEnumAr.admin ||
        name_ar === ClientRolesEnum.owner ||
        name_ar === ClientRolesEnumAr.owner
      ) {
        throw new BadRequestException(ErrorKeys.invaildRole);
      }
      existRole = await this.roleRepository.findOne({
        where: [
          { id: Not(id), name, client: { id: clientId }, deleted: false },
          { id: Not(id), name: name_ar, client: { id: clientId }, deleted: false },
          { id: Not(id), name_ar, client: { id: clientId }, deleted: false },
          { id: Not(id), name_ar: name, client: { id: clientId }, deleted: false },
        ],
      });
    } else if (name) {
      if (
        name === ClientRolesEnum.admin ||
        name === ClientRolesEnumAr.admin ||
        name === ClientRolesEnum.owner ||
        name === ClientRolesEnumAr.owner
      ) {
        throw new BadRequestException(ErrorKeys.invaildRole);
      }
      existRole = await this.roleRepository.findOne({
        where: [
          { id: Not(id), name, client: { id: clientId }, deleted: false },
          { id: Not(id), name_ar: name, client: { id: clientId }, deleted: false },
        ],
      });
    } else {
      if (
        name_ar === ClientRolesEnum.admin ||
        name_ar === ClientRolesEnumAr.admin ||
        name_ar === ClientRolesEnum.owner ||
        name_ar === ClientRolesEnumAr.owner
      ) {
        throw new BadRequestException(ErrorKeys.invaildRole);
      }
      existRole = await this.roleRepository.findOne({
        where: [
          { id: Not(id), name: name_ar, client: { id: clientId }, deleted: false },
          { id: Not(id), name_ar, client: { id: clientId }, deleted: false },
        ],
      });
    }
    if (existRole) {
      throw new BadRequestException(ErrorKeys.roleExist);
    }
  }
}
