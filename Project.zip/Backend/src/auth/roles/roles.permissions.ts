import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const rolesPermissions = {
  CREATE_ROLE: {
    ar_name: 'إنشاء:الوظائف',
    en_name: 'create:occupations',
    ar_module: 'الوظائف',
    en_module: 'Occupations',
    order: 15,
    key: 'Roles',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/roles'",
  },
  READ_ROLES: {
    ar_name: 'قراءة:الوظائف',
    en_name: 'read:occupations',
    ar_module: 'الوظائف',
    en_module: 'Occupations',
    order: 15,
    key: 'Roles',
    type: PermissionsTypeEnum.READ,
    route: "GET '/roles'",
  },
  UPDATE_ROLE: {
    ar_name: 'تحديث:الوظائف',
    en_name: 'update:occupations',
    ar_module: 'الوظائف',
    en_module: 'Occupations',
    order: 15,
    key: 'Roles',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/roles/:roleId'",
  },
  DELETE_ROLE: {
    ar_name: 'حذف:الوظائف',
    en_name: 'delete:occupations',
    ar_module: 'الوظائف',
    en_module: 'Occupations',
    order: 15,
    key: 'Roles',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/roles/:id'",
  },
};
