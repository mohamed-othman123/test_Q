import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Delete,
  Patch,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiBody,
  ApiHeader,
} from '@nestjs/swagger';
import { CreateRoleDto } from './dto/create-role.dto';
import { RolesService } from './roles.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { RequirePermissions } from '../decorator/require-permissions.decorator';
import { rolesPermissions } from './roles.permissions';
import { UpdateRoleDto } from './dto/update-role.dto';
import { Role } from './entities/role.entity';
import { RoleDetails } from './interfaces/role.intreface';
import { FilterRolesDto } from './dto/filter-role.dto';
import { UserTypeGuard } from '../../common/guards/user-types.guard';
import { UserTypes } from '../../common/decorators/user-types.decorator';
import { UserTypesEnum } from '../../modules/users/enums/users-type.enum';

@ApiTags('roles')
@UseGuards(UserTypeGuard)
@ApiBearerAuth()
@Controller('roles')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class RolesController {
  constructor(private readonly roleService: RolesService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new role' })
  @ApiResponse({ status: 201, description: 'The role has been successfully created.' })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(rolesPermissions.CREATE_ROLE)
  async create(
    @Body() createRoleDto: CreateRoleDto,
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<RoleDetails> {
    return this.roleService.create(createRoleDto, user);
  }

  @Get()
  @ApiOperation({ summary: 'Retrieve all roles' })
  @ApiResponse({ status: 200, description: 'All roles retrieved successfully.' })
  @ApiResponse({ status: 403, description: 'Forbidden.' })
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(rolesPermissions.READ_ROLES)
  async findAll(
    @Query() filter: FilterRolesDto,
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<{
    items: RoleDetails[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return this.roleService.findAll(filter, user);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Retrieve a role by ID' })
  @ApiResponse({ status: 200, description: 'Role retrieved successfully.' })
  @ApiResponse({ status: 404, description: 'Role not found.' })
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(rolesPermissions.READ_ROLES)
  async findOne(
    @Param('id') id: string,
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<{
    id: number;
    name: string;
    name_ar: string;
    notes: string | null;
    created_at: Date;
    updated_at: Date;
    permissions: number[];
  }> {
    return this.roleService.findOne(+id, user.clientId);
  }

  @Patch(':roleId')
  @ApiOperation({ summary: 'Updated a role' })
  @ApiResponse({ status: 200, description: 'Permission added to role successfully.' })
  @ApiResponse({ status: 404, description: 'Role or permission not found.' })
  @ApiBody({ type: CreateRoleDto })
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(rolesPermissions.UPDATE_ROLE)
  async updated(
    @Param('roleId') roleId: string,
    @CurrentUser() user: { clientId: number; id: number },
    @Body()
    updateRoleDto: UpdateRoleDto,
  ): Promise<RoleDetails> {
    return this.roleService.update(+roleId, updateRoleDto, user);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a role' })
  @ApiResponse({ status: 200, description: 'Role deleted successfully.' })
  @ApiResponse({ status: 404, description: 'Role not found.' })
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(rolesPermissions.DELETE_ROLE)
  async remove(@Param('id') id: string, @CurrentUser() user): Promise<Role> {
    return this.roleService.remove(+id, user);
  }
}
