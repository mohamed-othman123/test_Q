import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { PermissionsService } from './permissions.service';
import {
  ApiBearerAuth,
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiHeader,
} from '@nestjs/swagger';
import { Permission } from './entities/permission.entity';
import { RequirePermissions } from '../decorator/require-permissions.decorator';
import { permissionsPermissions } from './permissions.permissions';
import { PermissionDetails } from './interfaces/permissionType.interface';
import { UserTypeGuard } from '../../common/guards/user-types.guard';
import { UserTypes } from '../../common/decorators/user-types.decorator';
import { UserTypesEnum } from '../../modules/users/enums/users-type.enum';

@ApiTags('permissions')
@UseGuards(UserTypeGuard)
@ApiBearerAuth()
@Controller('permissions')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class PermissionsController {
  constructor(private readonly permissionService: PermissionsService) {}
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(permissionsPermissions.READ_PERMISSIONS)
  @Get()
  @ApiOperation({ summary: 'Get all permissions' })
  @ApiResponse({
    status: 200,
    description: 'Returns all permissions',
    type: Permission,
  })
  async findAll(): Promise<Permission[]> {
    return this.permissionService.findAll();
  }

  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(permissionsPermissions.READ_PERMISSIONS)
  @Get(':id')
  @ApiOperation({ summary: 'Get a specific permission by ID' })
  @ApiParam({ name: 'id', description: 'ID of the permission to retrieve', type: 'string' })
  @ApiResponse({ status: 200, description: 'Returns the permission', type: Permission })
  @ApiResponse({ status: 404, description: 'Permission not found' })
  async findOne(@Param('id') id: string): Promise<PermissionDetails> {
    return await this.permissionService.findOne(+id);
  }
}
