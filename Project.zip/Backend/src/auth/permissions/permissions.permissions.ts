import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const permissionsPermissions = {
  READ_PERMISSIONS: {
    ar_name: 'قراءة:الصلاحيات',
    en_name: 'read:permissions',
    ar_module: 'الصلاحيات',
    en_module: 'Permissions',
    order: 15,
    key: 'Permissions',
    type: PermissionsTypeEnum.READ,
    route: "GET '/permissions'",
  },
};
