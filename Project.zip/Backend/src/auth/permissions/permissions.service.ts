import { bookingDiscountPermissions } from './../../modules/booking/permissions/discounts.permissions';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Permission } from './entities/permission.entity';
import { BadRequestException, Injectable, NotFoundException, OnModuleInit } from '@nestjs/common';
import { usersPermissions } from '../../modules/users/users.permissions';
import { hallsPermissions } from '../../modules/halls/halls.permissions';
import { servicesPermissions } from '../../modules/services/services.permissions';
import { eventsPermissions } from '../../modules/events/events.permissions';
import { paymentMethodsPermissions } from '../../modules/payment-method/payment-method.permissions';
import { hallsClientsPermissions } from '../../modules/hall-clients/halls-clients.permissions';
import { bankPermissions } from '../../modules/bank/bank.permissions';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { contractsPermissions } from '../../modules/contracts/contracts.permissions';
import { bookingsPermissions } from '../../modules/booking/permissions/booking.permissions';
import { paymentsPermissions } from '../../modules/payment/payments.permissions';
import { suppliersPermissions } from '../../modules/suppliers/suppliers.permissions';
import { purchasesPermissions } from '../../modules/expenses/expenses.permissions';
import { rolesPermissions } from '../roles/roles.permissions';
import { permissionsPermissions } from './permissions.permissions';
import { clientsPermissions } from '../../modules/clients/clients.permissions';
import { statisticsPermissions } from '../../modules/statistics/statistics.permissions';
import { landingPagePermissions } from '../../modules/landing-pages/landing-pages.permissions';
import { bookingPriceRequestsPermissions } from '../../modules/booking-price-requests/price-requests.permisssions';
import { PermissionDetails } from './interfaces/permissionType.interface';
import { expensesItemsPermissions } from '../../modules/expenses-items/expenses-items.permissions';
import { expensePaymentsPermissions } from '../../modules/expenses-payments/permissions/expense_payments.permissions';
import { expenseCategoryPermissions } from '../../modules/purchase-categories/purchase-categories.permissions';
import { discountPermissions } from '../../modules/discounts/discount.permissions';
import { refundRequestsPermissions } from '../../modules/refund-requests/refund-requests.permissions';
import { InventoryPermissions } from '../../modules/inventory/permissions/inventory.permissions';

@Injectable()
export class PermissionsService implements OnModuleInit {
  constructor(
    @InjectRepository(Permission)
    private permissionRepository: Repository<Permission>,
  ) {}
  async onModuleInit(): Promise<void> {
    await this.seedPermissions();
  }
  async findAll(): Promise<Permission[]> {
    const permissions = await this.permissionRepository
      .createQueryBuilder('permission')
      .where('permission.key NOT IN (:...modules)', {
        modules: [
          'Halls',
          'Employees',
          'Roles',
          'Organizations',
          'Permissions',
          'Special discounts',
        ],
      })
      .orderBy('permission.order', 'ASC')
      .select([
        'permission.id As id',
        `permission.en_name AS name`,
        `permission.ar_name AS name_ar`,
        `permission.en_module AS module`,
        `permission.ar_module AS module_ar`,
        'permission.type AS type',
        'permission.route AS route',
      ])
      .getRawMany();

    return permissions;
  }

  async validateExistingPermissions(ids: number[]): Promise<Permission[]> {
    const existsPermissions = await this.permissionsInRange(ids);
    const existPermissionIds = existsPermissions.map((per) => per.id);
    const notExistsPermissions = ids.filter((id) => !existPermissionIds.includes(id));

    if (notExistsPermissions.length > 0) {
      throw new BadRequestException(ErrorKeys.permissionNotFound);
    }
    return existsPermissions;
  }

  async permissionsInRange(ids: number[] = null): Promise<Permission[]> {
    let conditions = {};
    if (ids && ids.length > 0) conditions = { id: In(ids) };
    return await this.permissionRepository.find({ where: conditions });
  }

  async findOne(id: number): Promise<PermissionDetails> {
    const permission = await this.permissionRepository
      .createQueryBuilder('permission')
      .where('permission.id = :permissionId', { permissionId: id })
      .andWhere('permission.key NOT IN (:...modules)', {
        modules: [
          'Halls',
          'Employees',
          'Roles',
          'Organizations',
          'Permissions',
          'Special discounts',
        ],
      })
      .select([
        'permission.id',
        'permission.route',
        'permission.type',
        `permission.en_name`,
        `permission.ar_name`,
        `permission.en_module`,
        `permission.ar_module`,
      ])
      .getOne();
    if (!permission) {
      throw new NotFoundException(ErrorKeys.permissionNotFound);
    }
    return {
      id: permission.id,
      name: permission.en_name,
      name_ar: permission.ar_name,
      module: permission.en_module,
      module_ar: permission.ar_module,
      route: permission.route,
      type: permission.type,
    };
  }
  // just try prof of concept will optimize later
  private async seedPermissions(): Promise<void> {
    const permissionGroups = [
      usersPermissions,
      hallsPermissions,
      servicesPermissions,
      eventsPermissions,
      paymentMethodsPermissions,
      bankPermissions,
      hallsClientsPermissions,
      contractsPermissions,
      bookingsPermissions,
      paymentsPermissions,
      suppliersPermissions,
      purchasesPermissions,
      expensePaymentsPermissions,
      rolesPermissions,
      permissionsPermissions,
      clientsPermissions,
      statisticsPermissions,
      landingPagePermissions,
      bookingPriceRequestsPermissions,
      bookingDiscountPermissions,
      expensesItemsPermissions,
      expenseCategoryPermissions,
      discountPermissions,
      refundRequestsPermissions,
      InventoryPermissions,
    ] as Permissions[];

    // Flatten all permissions from all groups
    const allPermissions = permissionGroups.flatMap((group) =>
      Object.values(group).map((permission) => ({
        ...permission,
        uniqueKey: `${permission.key}_${permission.type}`,
      })),
    );

    const existingPermissions = await this.permissionRepository.find();

    const existingMap = new Map(existingPermissions.map((p) => [`${p.key}_${p.type}`, p]));
    const newPermissionsMap = new Map(allPermissions.map((p) => [p.uniqueKey, p]));

    const toCreate: Permission[] = [];
    const toUpdate: Permission[] = [];
    const toDelete: Permission[] = [];

    for (const [uniqueKey, newPermission] of newPermissionsMap) {
      const existing = existingMap.get(uniqueKey);

      if (!existing) {
        toCreate.push(newPermission);
      } else {
        const isChanged =
          existing.en_name !== newPermission.en_name ||
          existing.ar_name !== newPermission.ar_name ||
          existing.en_module !== newPermission.en_module ||
          existing.ar_module !== newPermission.ar_module ||
          existing.route !== newPermission.route ||
          existing.order !== newPermission.order;

        if (isChanged) {
          toUpdate.push({ ...existing, ...newPermission });
        }
      }
    }

    for (const [uniqueKey, existing] of existingMap) {
      if (!newPermissionsMap.has(uniqueKey)) {
        toDelete.push(existing);
      }
    }

    const promises = [];

    if (toCreate.length > 0) {
      promises.push(
        this.permissionRepository
          .save(toCreate)
          .then((created) => console.log(`Created ${created.length} new permissions`)),
      );
    }

    if (toUpdate.length > 0) {
      promises.push(
        this.permissionRepository
          .save(toUpdate)
          .then((updated) => console.log(`Updated ${updated.length} permissions`)),
      );
    }

    if (toDelete.length > 0) {
      promises.push(
        this.permissionRepository
          .createQueryBuilder()
          .delete()
          .where('id IN (:...ids)', { ids: toDelete.map((p) => p.id) })
          .execute()
          .then((result) =>
            console.log(`Deleted ${result.affected} permissions that no longer exist in code`),
          ),
      );
    }

    await Promise.all(promises);
  }
}
