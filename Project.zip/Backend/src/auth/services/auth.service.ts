import {
  BadRequestException,
  ConflictException,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { CreateAuthDto } from './../dto/create-auth.dto';
import { UsersService } from './../../modules/users/users.service';
import { LoginAuthDto } from './../dto/login-auth.dto';
import { JwtService } from '@nestjs/jwt';
import { MailService } from './../../providers/mailer/mail.service';
import { ConfigService } from '@nestjs/config';
import { CacheService } from '../../providers/cache/cache.service';
import { ClientsService } from '../../modules/clients/clients.service';
import { DataSource } from 'typeorm';
import { User } from '../../modules/users/entities/user.entity';
import { Client } from '../../modules/clients/entities/client.entity';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { LanguagesEnum } from '../../common/enums/lang.enum';
import { readEnv } from '../../core/helpers/env.helper';
import { RefreshTokenDto } from './../dto/refreshTokenDto';
import { RefreshTokenResponse } from './../interfaces/auth.interface';
import {
  getFingerPrint,
  verifyPasswordHashV1,
  verifyPasswordHashV2,
} from '../../core/helpers/cast.helper';
import { ForgetPasswordDto, ResetPasswordDto } from '../dto/reset-password.dto';
import { SignupDto } from '../dto/signup.dto';
import { UserProfile } from '../../modules/users/interfaces/user-profile.interface';

@Injectable()
export class AuthService {
  private readonly OTP_DIGITS = 4;
  private readonly OTP_EXPIRATION_TIME = 2 * 60 * 1000;
  private readonly STATIC_OTP = 1234;
  constructor(
    private readonly usersService: UsersService,
    private jwtService: JwtService,
    private mailService: MailService,
    private configService: ConfigService,
    private readonly cacheService: CacheService,
    private readonly clientsService: ClientsService,
    private readonly dataSource: DataSource,
    private readonly eventEmitter: EventEmitter2,
  ) {}

  async register(
    createAuthDto: CreateAuthDto,
    lang: string,
  ): Promise<{ userId: number; clientId: number; message: string }> {
    const { name, email, password } = createAuthDto;
    let registeredUser: User;
    let registeredClient: Client;
    await this.dataSource.transaction(async (manager) => {
      registeredClient = await this.clientsService.create(
        {
          name,
          email,
        },
        manager,
      );
      registeredUser = await this.usersService.register(
        {
          email,
          password,
          name,
        },
        registeredClient,
        manager,
      );
    });
    const { code, expiresAt } = this.GenerateOtp();
    this.mailService.sendOtpMail(registeredUser.email, code, name, lang);
    await this.cacheService.set(this.createOtpKey(registeredUser.id), code, expiresAt);
    return {
      userId: registeredUser.id,
      clientId: registeredClient.id,
      message: 'User registered successfully. OTP sent to email.',
    };
  }

  async signup(signupDto: SignupDto, lang: string) {
    const { organization, user: userDto } = signupDto;

    const existingUser = await this.usersService.checkUserV2(userDto.email);
    if (existingUser) {
      throw new ConflictException(ErrorKeys.emailExists);
    }

    try {
      await this.dataSource.transaction(async (manager) => {
        const client = await this.clientsService.createV2(organization, userDto.email, manager);

        const user = await this.usersService.registerV2(userDto, client, manager);

        // Generate verification token
        const verificationToken = this.jwtService.sign(
          { clientId: client.id },
          {
            expiresIn: '1h',
            subject: user.id.toString(),
            secret: readEnv('JWT_SECRET') as string,
          },
        );

        // Send verification email
        const app_host = this.configService.get('APP_HOST');
        const app_url = process.env.NODE_ENV !== 'local' ? `${app_host}/api` : app_host;
        const verificationUrl = `${app_url}/auth/verify?token=${verificationToken}&lang=${lang}`;

        const subject = lang === 'ar' ? 'تأكيد البريد الإلكتروني' : 'Email Verification';

        this.mailService.sendEmail([user.email], subject, 'email-verify', {
          verificationUrl,
          name: user.name,
          lang,
        });
      });

      // Only return success if transaction completes without errors
      return { message: 'Account has been created, please verify it to login' };
    } catch (error) {
      console.error('Error during signup transaction:', error);

      throw error;
    }
  }

  // Email verification handler
  async verifyEmail(token: string, lang: string) {
    try {
      let decoded: { sub: string; clientId: number };
      try {
        decoded = this.jwtService.verify(token, {
          secret: readEnv('JWT_SECRET') as string,
        });
      } catch (error) {
        throw new BadRequestException(ErrorKeys.invalidToken);
      }

      const userId = +decoded.sub;
      const clientId = decoded.clientId;

      let user: UserProfile;
      try {
        user = await this.usersService.getUserProfile(userId, clientId);
      } catch (userError) {
        throw new NotFoundException(ErrorKeys.userNotFound);
      }

      if (!user) {
        throw new NotFoundException(ErrorKeys.userNotFound);
      }

      try {
        await this.usersService.verifyUser(user.id, clientId);
      } catch (verifyError) {
        throw new InternalServerErrorException(ErrorKeys.failedVerifyUser);
      }

      try {
        this.eventEmitter.emit('client.admin.verified', {
          clientId,
          userId,
          lang: lang || LanguagesEnum.Arabic,
        });
      } catch (eventError) {
        console.error('Error emitting event:', eventError);
      }

      return {
        redirectURL: `${readEnv('APP_HOST')}/auth/login`,
      };
    } catch (error) {
      if (
        error instanceof BadRequestException ||
        error instanceof NotFoundException ||
        error instanceof InternalServerErrorException
      ) {
        throw error;
      }

      throw new BadRequestException(error);
    }
  }

  async login(
    loginAuthDto: LoginAuthDto,
    req,
    lang: string,
  ): Promise<{ userId: number; clientId: number; message: string }> {
    const user = await this.usersService.checkUserV2(loginAuthDto.email);
    if (!user) {
      throw new BadRequestException(ErrorKeys.emailOrPasswordIncorrect);
    }
    if (!user.verified) {
      if (!user.password) {
        this.usersService.forgetPassword({ email: user.email }, req, lang, true);
        throw new BadRequestException(ErrorKeys.passwordNotVerified);
      }
      this.resendOtp(user.email, lang);
      throw new BadRequestException(ErrorKeys.emailNotVerified);
    }

    if (!user.active) {
      throw new UnauthorizedException(ErrorKeys.userNotActive);
    }
    const passwordIsValidHashV1 = await verifyPasswordHashV1(loginAuthDto.password, user.password);
    if (passwordIsValidHashV1) {
      await this.usersService.updateHashPassword(user.id, user.client.id, loginAuthDto.password);
    }
    const passwordIsValidHashV2 = await verifyPasswordHashV2(loginAuthDto.password, user.password);
    if (!passwordIsValidHashV1 && !passwordIsValidHashV2) {
      throw new BadRequestException(ErrorKeys.emailOrPasswordIncorrect);
    }
    const { code, expiresAt } = this.GenerateOtp();
    this.mailService.sendOtpMail(user.email, code, user.name, lang);
    await this.cacheService.set(this.createOtpKey(user.id), code, expiresAt);

    return {
      userId: user.id,
      clientId: user.client.id,
      message: 'OTP sent to email.',
    };
  }

  async verifyOtp(
    userId: number,
    otp: number,
    channel: 'login' | 'register',
    isRememberMe: boolean,
    lang: LanguagesEnum,
    req,
  ): Promise<RefreshTokenResponse> {
    const key = this.createOtpKey(userId);
    const cacheOtp = await this.cacheService.get(key);
    const user = await this.usersService.findOneWithPermissionsandHalls(userId);
    if (!user) {
      throw new BadRequestException(ErrorKeys.userNotFound);
    }

    if (channel === 'register' && user.verified) {
      throw new BadRequestException(ErrorKeys.userAlreadyVerified);
    }

    if (channel === 'login' && !user.verified) {
      throw new BadRequestException(ErrorKeys.userNotVerified);
    }

    if (!cacheOtp) {
      throw new BadRequestException(ErrorKeys.otpExpired);
    }

    if (Number(cacheOtp) !== otp) {
      throw new BadRequestException(ErrorKeys.invalidOtp);
    }

    await this.cacheService.del(key);

    if (channel === 'register') {
      const { ownerRole } = await this.usersService.verifyUser(userId, user.client.id);
      user.role = ownerRole;
      this.eventEmitter.emit('client.admin.verified', {
        clientId: user.client.id,
        userId,
        lang,
      });
    }
    const getPermissionDetails = (perm, lang: LanguagesEnum) => {
      return lang === LanguagesEnum.Arabic
        ? { name: perm.ar_name, module: perm.ar_module, route: perm.route }
        : { name: perm.en_name, module: perm.en_module, route: perm.route };
    };
    const support = {
      email: (readEnv('SUPPORT_EMAIL', 'string') as string) ?? null,
      phone: (readEnv('SUPPORT_PHONE', 'string') as string) ?? null,
    };

    const tokenPayload = {
      userId: user.id,
      clientId: user.client.id,
      email: user.email,
      type: user.type,
      hasAiFeature: user?.client?.hasAiFeature,
      permissionType: user.permissionType,
      halls: user.halls,
      name: user.name,
      role: {
        id: user.role.id,
        name: user.role.name,
        name_ar: user.role.name_ar,
        // ...user.role,
        // permissions: user.role.permissions.map((perm) => getPermissionDetails(perm, lang)),
      },
      subscription: {
        startDate: user.client.created_at,
        endDate: user.client.endDate,
      },
    };
    const token = this.jwtService.sign({
      ...tokenPayload,
      support,
      fingerprint: getFingerPrint(req),
    });
    let refresh_token = undefined;
    if (isRememberMe) refresh_token = this.generateRefreshToken(user.id, req);
    return {
      token,
      refresh_token: refresh_token ? refresh_token : null,
      support,
      user: { ...tokenPayload, role: user.role },
    };
  }

  private generateRefreshToken(userId: number, req): string {
    const tokenPayload = {
      userId,
    };
    const refresh_token = this.jwtService.sign(
      { ...tokenPayload, fingerprint: getFingerPrint(req) },
      {
        expiresIn: readEnv('REFRESH_JWT_EXPIRES_IN') as string,
      },
    );
    return refresh_token;
  }

  async resendOtp(email: string, lang: string): Promise<{ userId: number }> {
    // Check if the user exists
    const user = await this.usersService.checkUser(email);
    if (!user) {
      throw new BadRequestException(ErrorKeys.userNotFound);
    }

    // Check if an OTP is already cached for the user
    const existingOtp = await this.cacheService.get(this.createOtpKey(user.id));
    if (existingOtp) {
      // Resend the existing OTP email
      this.mailService.sendOtpMail(user.email, Number(existingOtp), user.name, lang);

      // Refresh the OTP cache expiration
      await this.cacheService.set(
        this.createOtpKey(user.id),
        Number(existingOtp),
        new Date(Date.now() + this.OTP_EXPIRATION_TIME),
      );

      return { userId: user.id };
    }

    // Generate a new OTP and expiration time
    const { code, expiresAt } = this.GenerateOtp();

    // Send the new OTP email
    this.mailService.sendOtpMail(user.email, code, user.name, lang);

    // Cache the new OTP with its expiration time
    await this.cacheService.set(this.createOtpKey(user.id), code, expiresAt);

    return { userId: user.id };
  }

  private GenerateOtp(): { code: number; expiresAt: Date } {
    const min = Math.pow(10, this.OTP_DIGITS - 1);
    const max = Math.pow(10, this.OTP_DIGITS) - 1;
    const isDevelopment = this.configService.get('NODE_ENV') !== 'production';
    const expiresAt = new Date(Date.now() + this.OTP_EXPIRATION_TIME);
    const code = isDevelopment
      ? this.STATIC_OTP
      : Math.floor(Math.random() * (max - min + 1)) + min;
    return { code, expiresAt };
  }

  private createOtpKey(userId: number): string {
    return `otp:${userId}`;
  }

  async forgetPassword(forgetPasswordDto: ForgetPasswordDto, req, lang: string): Promise<boolean> {
    return this.usersService.forgetPassword(forgetPasswordDto, req, lang);
  }

  async resetPassword(
    resetPasswordDto: ResetPasswordDto,
    resetToken: string,
    req,
  ): Promise<{ token: string; refresh_token: string }> {
    const user = await this.usersService.resetPassword(resetPasswordDto, resetToken);
    const tokenPayload = {
      userId: user.id,
      clientId: user.client.id,
      email: user.email,
      type: user.type,
      name: user.name,
    };

    const token = this.jwtService.sign({ ...tokenPayload, fingerprint: getFingerPrint(req) });
    let refresh_token = undefined;
    if (resetPasswordDto.isRememberMe) refresh_token = this.generateRefreshToken(user.id, req);
    return { token, refresh_token: refresh_token ? refresh_token : null };
  }

  async refreshAccessToken(
    refreshTokenDto: RefreshTokenDto,
    lang: LanguagesEnum,
    req,
  ): Promise<RefreshTokenResponse> {
    const { rToken } = refreshTokenDto;
    let payload: any;
    try {
      payload = this.jwtService.verify(rToken, {
        secret: readEnv('JWT_SECRET') as string,
      });
      const fingerprint = payload.fingerprint;
      const calculatedFingerprint = getFingerPrint(req);
      if (fingerprint !== calculatedFingerprint) {
        throw new UnauthorizedException(ErrorKeys.unauthorized);
      }
    } catch (error) {
      throw new UnauthorizedException(ErrorKeys.tokenExpired);
    }
    const user = await this.usersService.findOneWithPermissionsandHalls(payload.userId);
    if (!user) {
      throw new BadRequestException(ErrorKeys.userNotFound);
    }
    const getPermissionDetails = (perm, lang: LanguagesEnum) => {
      return lang === LanguagesEnum.Arabic
        ? { name: perm.ar_name, module: perm.ar_module, route: perm.route }
        : { name: perm.en_name, module: perm.en_module, route: perm.route };
    };
    const support = {
      email: (readEnv('SUPPORT_EMAIL', 'string') as string) ?? null,
      phone: (readEnv('SUPPORT_PHONE', 'string') as string) ?? null,
    };

    const tokenPayload = {
      userId: user.id,
      clientId: user.client.id,
      email: user.email,
      type: user.type,
      permissionType: user.permissionType,
      halls: user.halls,
      name: user.name,
      role: {
        id: user.role.id,
        name: user.role.name,
        name_ar: user.role.name_ar,
        // ...user.role,
        // permissions: user.role.permissions.map((perm) => getPermissionDetails(perm, lang)),
      },
      subscription: {
        startDate: user.client.created_at,
        endDate: user.client.endDate,
      },
    };
    const token = this.jwtService.sign({
      ...tokenPayload,
      support,
      fingerprint: getFingerPrint(req),
    });
    const refresh_token = this.generateRefreshToken(user.id, req);
    return {
      token,
      refresh_token,
      support,
      user: { ...tokenPayload, role: user.role },
    };
  }
}
