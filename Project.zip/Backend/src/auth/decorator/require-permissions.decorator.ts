import { SetMetadata } from '@nestjs/common';

export interface Permission {
  en_name: string;
  ar_name: string;
  en_module: string;
  ar_module: string;
  route: string;
}

export const RequirePermissions = (...permissions: Permission[]) =>
  SetMetadata('permissions', permissions);
