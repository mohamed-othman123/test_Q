import { Role } from '../roles/entities/role.entity';

export interface RefreshTokenResponse {
  token: string;
  refresh_token: string;
  user: {
    userId: number;
    clientId: number;
    email: string;
    type: string;
    name: string;
    role: Role;
    subscription: {
      startDate: Date,
      endDate: Date
    }
  };
  support: {
    email: string | null,
    phone: string | null
  }
}
