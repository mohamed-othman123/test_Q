import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsEmail, IsNotEmpty, IsOptional, IsString, Matches } from 'class-validator';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { Transform } from 'class-transformer';

export class ForgetPasswordDto {
  @ApiProperty({
    description: 'User email',
    example: 'user@gmail.com',
  })
  @IsNotEmpty({ message: ErrorKeys.emailIsRequired })
  @IsEmail({}, { message: ErrorKeys.emailInvalid })
  @Transform(({ value }) => value?.toLowerCase())
  email: string;
}
export class ResetPasswordDto {
  @ApiProperty({
    description: 'User Password',
    example: 'password',
  })
  @IsNotEmpty({ message: ErrorKeys.passwordIsRequired })
  @IsString({
    message: ErrorKeys.passwordMustBeString,
  })
  @Matches(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)/, { message: ErrorKeys.passwordIsWeak })
  password: string;

  @ApiProperty({
    description: 'User Password confirmed',
    example: 'password',
  })
  @IsNotEmpty({ message: ErrorKeys.passwordIsRequired })
  @IsString({
    message: ErrorKeys.passwordMustBeString,
  })
  @Matches(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)/, { message: ErrorKeys.passwordIsWeak })
  confirmedPassword: string;

  @ApiProperty({ required: false, example: false, description: 'Remember Me' })
  @IsBoolean()
  @IsOptional()
  isRememberMe?: boolean;
}
