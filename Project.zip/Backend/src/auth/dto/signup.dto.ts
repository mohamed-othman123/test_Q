import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsEmail,
  IsNotEmpty,
  IsString,
  Matches,
  ValidateNested,
  IsNumberString,
} from 'class-validator';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';

export class OrganizationDto {
  @ApiProperty({ description: 'Organization name' })
  @IsNotEmpty({ message: ErrorKeys.nameIsRequired })
  @IsString({
    message: ErrorKeys.nameMustBeString,
  })
  @Matches(/^\s*\S+(?:\s+\S+)+\s*$/, {
    message: ErrorKeys.nameMustBeFull,
  })
  name: string;

  // @ApiProperty({ description: 'Organization number' })
  // @IsNotEmpty({ message: ErrorKeys.phoneIsRequired })
  // @IsString({
  //   message: ErrorKeys.phoneMustBeString,
  // })
  // @Matches(/^\+(\d{1,3})\s?(\d{7,15})$/, { message: ErrorKeys.phoneInvaild })
  // @Transform(({ value }) => value?.replace(/ /g, ''))
  // phone_number: string;

  // @ApiProperty({ description: 'Commercial Registration Number' })
  // @IsNotEmpty({ message: ErrorKeys.commercialRegistrationNumberIsRequired })
  // @IsNumberString({}, { message: ErrorKeys.commercialRegistrationNumberMustBeNumber })
  // @Matches(/^[1-9]\d{9}$/, {
  //   message: ErrorKeys.taxRegistrationNumberInvaild,
  // })
  // @Transform(({ value }) => (value === '' ? null : value))
  // cr_number: string;

  // @ApiProperty({ description: 'Tax Registration Number' })
  // @IsNotEmpty({ message: ErrorKeys.taxRegistrationNumberIsRequired })
  // @IsNumberString({}, { message: ErrorKeys.taxRegistrationNumberMustBeNumber })
  // @Matches(/^[1-9]\d{14}$/, {
  //   message: ErrorKeys.taxRegistrationNumberInvaild,
  // })
  // @Transform(({ value }) => (value === '' ? null : value))
  // tax_number: string;

  // @ApiProperty({ description: 'Organization address' })
  // @IsNotEmpty({ message: ErrorKeys.addressIsRequired })
  // @IsString({
  //   message: ErrorKeys.addressMustBeString,
  // })
  // address: string;
}

export class UserDto {
  @ApiProperty({ description: 'Username' })
  @IsNotEmpty({ message: ErrorKeys.nameIsRequired })
  @IsString({
    message: ErrorKeys.nameMustBeString,
  })
  @Matches(/^\s*\S+(?:\s+\S+)+\s*$/, {
    message: ErrorKeys.nameMustBeFull,
  })
  name: string;

  @ApiProperty({ description: 'Phone number' })
  @IsNotEmpty({ message: ErrorKeys.phoneIsRequired })
  @IsString({
    message: ErrorKeys.phoneMustBeString,
  })
  @Matches(/^\+(\d{1,3})\s?(\d{7,15})$/, { message: ErrorKeys.phoneInvaild })
  @Transform(({ value }) => value?.replace(/ /g, ''))
  phone_number: string;

  @ApiProperty({ description: 'Email address' })
  @IsNotEmpty({ message: ErrorKeys.emailIsRequired })
  @IsEmail({}, { message: ErrorKeys.emailInvalid })
  @Transform(({ value }) => value?.toLowerCase())
  email: string;

  @ApiProperty({ description: 'Password' })
  @IsNotEmpty({ message: ErrorKeys.passwordIsRequired })
  @IsString({
    message: ErrorKeys.passwordMustBeString,
  })
  @Matches(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)/, { message: ErrorKeys.passwordIsWeak })
  password: string;
}

export class SignupDto {
  @ApiProperty({ type: () => OrganizationDto })
  @IsNotEmpty({ message: ErrorKeys.orgDataIsRequired })
  @ValidateNested()
  @Type(() => OrganizationDto)
  organization: OrganizationDto;

  @ApiProperty({ type: () => UserDto })
  @IsNotEmpty({ message: ErrorKeys.userDataIsRequired })
  @ValidateNested()
  @Type(() => UserDto)
  user: UserDto;
}
