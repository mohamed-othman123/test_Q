import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateAuthDto } from './create-auth.dto';
import { IsEmail, IsOptional, IsString, Matches } from 'class-validator';
import { ErrorKeys } from 'src/common/enums/errorKeys.enums';
import { Transform } from 'class-transformer';

export class UpdateAuthDto {
  @ApiProperty({
    description: 'User name',
    example: 'John Doe',
    required: true,
  })
  @IsOptional()
  @IsString({
    message: ErrorKeys.nameMustBeString,
  })
  @Matches(/^\s*\S+(?:\s+\S+)+\s*$/, {
    message: ErrorKeys.nameMustBeFull,
  })
  name: string;

  @ApiProperty({
    description: 'User email',
    example: 'user@gmail.com',
    required: true,
  })
  @IsOptional()
  @IsEmail({}, { message: ErrorKeys.emailInvalid })
  @Transform(({ value }) => value?.toLowerCase())
  email: string;

  @ApiProperty({
    description: 'User password',
    example: 'password',
    required: true,
  })
  @IsOptional()
  @IsString({
    message: ErrorKeys.passwordMustBeString,
  })
  @Matches(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)/, { message: ErrorKeys.passwordIsWeak })
  password: string;
}
