import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsEmail } from 'class-validator';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { Transform } from 'class-transformer';

export class LoginAuthDto {
  @ApiProperty({
    description: 'User email',
    example: 'user@gmail.com',
  })
  @IsNotEmpty({ message: ErrorKeys.emailIsRequired })
  @IsEmail({}, { message: ErrorKeys.emailInvalid })
  email: string;

  @ApiProperty({
    description: 'User password',
    example: 'password',
  })
  @IsNotEmpty({ message: ErrorKeys.passwordIsRequired })
  @IsString({
    message: ErrorKeys.passwordMustBeString,
  })
  password: string;
}
