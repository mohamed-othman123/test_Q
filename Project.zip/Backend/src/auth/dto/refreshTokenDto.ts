import { ApiProperty } from '@dataui/crud/lib/crud';
import { IsNotEmpty, IsString } from 'class-validator';
import { ErrorKeys } from 'src/common/enums/errorKeys.enums';

export class RefreshTokenDto {
  @ApiProperty({
    description: 'Refresh token',
    example: 'token',
  })
  @IsNotEmpty({ message: ErrorKeys.refresh_token })
  @IsString({
    message: ErrorKeys.nameMustBeString,
  })
  rToken: string;
}
