import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ConfigService } from '@nestjs/config';
import fastifyMultipart from '@fastify/multipart';
import { FastifyAdapter, NestFastifyApplication } from '@nestjs/platform-fastify';
import { fastifyHelmet } from '@fastify/helmet';
import fastifyView from '@fastify/view';
import { setupSwagger } from './swagger/swagger';
import fastifyCompress from '@fastify/compress';
import rateLimit from '@fastify/rate-limit';
import { apiReference } from '@scalar/nestjs-api-reference';
import { join } from 'path';
import ejs from 'ejs';
import { VERSION_NEUTRAL, VersioningType, Logger } from '@nestjs/common';
import { HyperDXNestLoggerModule } from '@hyperdx/node-logger';

async function bootstrap() {
  const useHyperDXLogger =
    !!process.env.HYPERDX_API_KEY && !!process.env.HYPERDX_URL && !!process.env.SERVICE_NAME;

  const logger = useHyperDXLogger
    ? HyperDXNestLoggerModule.createLogger({
        apiKey: process.env.HYPERDX_API_KEY!,
        service: process.env.SERVICE_NAME!,
        maxLevel: 'info',
        baseUrl: process.env.HYPERDX_URL!,
      })
    : new Logger();

  const app = await NestFactory.create<NestFastifyApplication>(
    AppModule,
    new FastifyAdapter({
      logger: true,
      bodyLimit: 10485760, // 10 MB
    }),
    { logger },
  );

  const configService = app.get<ConfigService>(ConfigService);
  const port: number = configService.get('PORT') || 3000;

  //   Enable CORS for all origins
  app.enableCors({
    origin: '*',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    allowedHeaders: '*',
  });

  // Enable versioning with URI type and v1 as default
  app.enableVersioning({
    type: VersioningType.URI,
    defaultVersion: [VERSION_NEUTRAL, '1'],
  });

  await app.register(fastifyMultipart);
  await app.register(fastifyView, {
    engine: {
      ejs,
    },
    templates: join(__dirname, 'modules/print/templates'),
  });
  await app.register(fastifyCompress, { encodings: ['br', 'gzip', 'deflate'] });
  await app.register(rateLimit, { max: 240, timeWindow: '1 minute' });

  if (process.env.NODE_ENV !== 'production') {
    const document = setupSwagger(app, configService);

    app.use(
      '/reference',
      apiReference({
        withFastify: true,
        spec: {
          content: document,
        },
      }),
    );
  }

  //Register Helmet for security headers
  await app.register(fastifyHelmet, {
    contentSecurityPolicy: {
      directives: {
        defaultSrc: [`'self'`],
        styleSrc: [`'self'`, `'unsafe-inline'`],
        imgSrc: [`'self'`, 'data:', 'validator.swagger.io'],
        scriptSrc: [`'self'`, `https: 'unsafe-inline'`],
      },
    },
  });

  await app.listen(port, '0.0.0.0', async () => {
    console.log(`Server running on ${await app.getUrl()}`);
  });
}
bootstrap();
