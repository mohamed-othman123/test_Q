import { SubscriptionsModule } from '../modules/subscriptions/subscriptions.module';
import { PaymentModule } from './../modules/payment/payment.module';
import { INestApplication } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AuthModule } from '../auth/auth.module';
import { BankModule } from '../modules/bank/bank.module';
import { BookingModule } from '../modules/booking/booking.module';
import { ClientsModule } from '../modules/clients/clients.module';
import { ContractsModule } from '../modules/contracts/contracts.module';
import { EventsModule } from '../modules/events/events.module';
import { HallsClientsModule } from '../modules/hall-clients/halls-clients.module';
import { HallsModule } from '../modules/halls/halls.module';
import { PackagesModule } from '../modules/packages/packages.module';
import { PaymentMethodModule } from '../modules/payment-method/payment-method.module';
import { DiscountsModule } from '../modules/discounts/discount.module';
import { ExpensesModule } from '../modules/expenses/expenses.module';
import { ServicesModule } from '../modules/services/services.module';
import { SuppliersModule } from '../modules/suppliers/suppliers.module';
import { UsersModule } from '../modules/users/users.module';
import { RolesModule } from '../auth/roles/roles.module';
import { PermissionsModule } from '../auth/permissions/permissions.module';
import { LandingPagesModule } from '../modules/landing-pages/landing-pages.module';
import { StatisticsModule } from '../modules/statistics/statistic.module';
import { HallSectionsModule } from '../modules/hall-sections/hall-sections.module';
import { CaptchaModule } from '../common/captcha/captcha.module';
import { BookingPriceRequestsModule } from '../modules/booking-price-requests/booking-price-requests.module';
import { HallTeamMembersModule } from '../modules/hall-team-members/hall-team-member.module';
import { PdfGenerationModule } from '../modules/pdf-generation/pdf-generation.module';
import { HealthModule } from '../modules/health-check/health-check.module';
import { ExpensesItemsModule } from '../modules/expenses-items/expenses-items.module';
import { PurchaseCategoriesModule } from '../modules/purchase-categories/purchase-categories.module';
import { ExpensePaymentsModule } from '../modules/expenses-payments/expense-payments.module';
import { PricingModule } from '../modules/prices/pricing.module';
import { SupplierProductModule } from '../modules/supplier-products/supplier-products.module';
import { VersionModule } from '../modules/version/version.module';
import { RefundRequestsModule } from '../modules/refund-requests/refund-requests.module';
import { AnalyticsModule } from '../modules/analytics/analytics.module';
import { CommentsModule } from '../modules/comments/comments.module';
import { AiAgentModule } from '../modules/ai-agent/ai-agent.module';
import { HallCommunicationConfigurationsModule } from '../modules/hall-communication-configurations/hall-communication-configurations.module';
import { ContactUsModule } from '../contact-us/contact-us.module';
import { InventoryModule } from '../modules/inventory/inventory.module';

export function setupSwagger(app: INestApplication, config: ConfigService): any {
  const operationIdFactory = (controllerKey: string, methodKey: string) => methodKey;
  const options = new DocumentBuilder()
    .addBearerAuth()
    .setTitle('QAATK Api')
    .setDescription('This API provide the needed services to implement QAATK')
    .setVersion('v1')
    .setContact('Contact', 'https://github.com/MustafaElgmal', 'mostafaelgmal36@gmail.com')
    .setLicense('Developed by Mostafa Elgmal', 'https://github.com/MustafaElgmal')
    .addServer(config.get('APP_HOST'))
    .build();

  const document = SwaggerModule.createDocument(app, options, {
    include: [
      AuthModule,
      UsersModule,
      ClientsModule,
      SubscriptionsModule,
      HallsModule,
      HallsClientsModule,
      SuppliersModule,
      ServicesModule,
      ExpensesModule,
      ExpensePaymentsModule,
      PackagesModule,
      DiscountsModule,
      EventsModule,
      BankModule,
      BookingModule,
      ContractsModule,
      PaymentModule,
      PaymentMethodModule,
      RolesModule,
      PermissionsModule,
      PdfGenerationModule,
      LandingPagesModule,
      StatisticsModule,
      HallSectionsModule,
      HallCommunicationConfigurationsModule,
      PricingModule,
      HallTeamMembersModule,
      CaptchaModule,
      BookingPriceRequestsModule,
      HealthModule,
      ExpensesItemsModule,
      PurchaseCategoriesModule,
      SupplierProductModule,
      VersionModule,
      RefundRequestsModule,
      AnalyticsModule,
      CommentsModule,
      AiAgentModule,
      ContactUsModule,
      InventoryModule,
    ],
    operationIdFactory,
  });

  if (process.env.NODE_ENV === 'staging') {
    document.paths = Object.fromEntries(
      Object.entries(document.paths).map(([path, pathObject]) => [`/api${path}`, pathObject]),
    );
  }
  SwaggerModule.setup('docs', app, document);
  return document;
}
