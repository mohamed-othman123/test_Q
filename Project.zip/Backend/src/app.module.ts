import { CronsModule } from './common/crons/crons.module';
import { Module, NestModule, MiddlewareConsumer } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { DatabaseModule } from './databases/database.module';
import { ConfigModule } from './config/config.module';
import { SharedModule } from './common/shared.module';
import { APP_FILTER, APP_INTERCEPTOR, APP_PIPE } from '@nestjs/core';
import { AllExceptionsFilter } from './common/exceptions/all-exceptions.filter';
import { ResponseTransformInterceptor } from './common/Interceptors/response-transform';
import { ValidationPipe } from './common/pipes/ValidationPipe';
import { CacheModule } from './providers/cache/cache.module';
import { join } from 'path';
import { I18nModule, AcceptLanguageResolver, QueryResolver } from 'nestjs-i18n';
import { ClientsModule } from './modules/clients/clients.module';
import { UsersModule } from './modules/users/users.module';
import { HallsModule } from './modules/halls/halls.module';
import { EventsModule } from './modules/events/events.module';
import { PackagesModule } from './modules/packages/packages.module';
import { ServicesModule } from './modules/services/services.module';
import { DiscountsModule } from './modules/discounts/discount.module';
import { SubscriptionsModule } from './modules/subscriptions/subscriptions.module';
import { AuthModule } from './auth/auth.module';
import { MailerAppModule } from './providers/mailer/mailer.module';
import { MailService } from './providers/mailer/mail.service';
import { QueueModule } from './providers/queue/queue.module';
import { PaginatorModule } from './common/paginator/paginator.module';
import { PaymentMethodModule } from './modules/payment-method/payment-method.module';
import { HallsClientsModule } from './modules/hall-clients/halls-clients.module';
import { BankModule } from './modules/bank/bank.module';
import { ContractsModule } from './modules/contracts/contracts.module';
import { BookingModule } from './modules/booking/booking.module';
import { PaymentModule } from './modules/payment/payment.module';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { SuppliersModule } from './modules/suppliers/suppliers.module';
import { ExpensesModule } from './modules/expenses/expenses.module';
import { QrCodeModule } from './modules/qr-code/qr-code.module';
import { LandingPagesModule } from './modules/landing-pages/landing-pages.module';
import { StatisticsModule } from './modules/statistics/statistic.module';
import { HallSectionsModule } from './modules/hall-sections/hall-sections.module';
import { BookingPriceRequestsModule } from './modules/booking-price-requests/booking-price-requests.module';
import { ServeStaticModule } from '@nestjs/serve-static';
import { HallTeamMembersModule } from './modules/hall-team-members/hall-team-member.module';
import { PdfGenerationModule } from './modules/pdf-generation/pdf-generation.module';
import { HealthModule } from './modules/health-check/health-check.module';
import { PurchaseCategoriesModule } from './modules/purchase-categories/purchase-categories.module';
import { ExpensesItemsModule } from './modules/expenses-items/expenses-items.module';
import { ExpensePaymentsModule } from './modules/expenses-payments/expense-payments.module';
import { PricingModule } from './modules/prices/pricing.module';
import { SupplierProductModule } from './modules/supplier-products/supplier-products.module';
import { CommentsModule } from './modules/comments/comments.module';
import { VersionInterceptor } from './common/Interceptors/version.interceptor';
import { VersionModule } from './modules/version/version.module';
import { RefundRequestsModule } from './modules/refund-requests/refund-requests.module';
import { ContactUsModule } from './contact-us/contact-us.module';
import { GoogleRecaptchaModule } from '@nestlab/google-recaptcha';
import { ConfigService } from '@nestjs/config';
import { HyperDXModule } from './providers/observability/hyperdx';
import { TelemetryInterceptor } from './common/Interceptors/telemetry.interceptor';
import { PdfMergeModule } from './common/pdf-merge/pdf-merge.module';
import { AnalyticsModule } from './modules/analytics/analytics.module';
import { OpenAiModule } from './providers/openai';
import { AiAgentModule } from './modules/ai-agent/ai-agent.module';
import { HallCommunicationConfigurationsModule } from './modules/hall-communication-configurations/hall-communication-configurations.module';
import { InventoryModule } from './modules/inventory/inventory.module';

@Module({
  imports: [
    ServeStaticModule.forRoot({
      rootPath: join(__dirname, 'public'),
      serveRoot: '/public/',
      serveStaticOptions: {
        setHeaders: (res, path) => {
          if (path.endsWith('.svg')) {
            res.setHeader('Content-Type', 'image/svg+xml');
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
            res.setHeader('Cross-Origin-Embedder-Policy', 'require-corp');
            res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
          }
        },
      },
    }),
    ConfigModule,
    HyperDXModule,
    DatabaseModule,
    SharedModule,
    CacheModule,
    UsersModule,
    I18nModule.forRoot({
      fallbackLanguage: 'en',
      loaderOptions: {
        path: join(__dirname, '/i18n/'),
        watch: true,
        includeSubfolders: true,
        allowMultiLocales: true,
      },
      resolvers: [{ use: QueryResolver, options: ['lang', 'locale', 'l'] }, AcceptLanguageResolver],
    }),
    GoogleRecaptchaModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        secretKey: configService.get('RECAPTCHA_SECRET_KEY'),
        response: (req) => req.headers.recaptcha,
        score: 0.8,
      }),
    }),
    EventEmitterModule.forRoot(),
    ClientsModule,
    HallsModule,
    EventsModule,
    PackagesModule,
    ServicesModule,
    DiscountsModule,
    SubscriptionsModule,
    AuthModule,
    MailerAppModule,
    QueueModule,
    PaginatorModule,
    PaymentMethodModule,
    BankModule,
    HallsClientsModule,
    ContractsModule,
    BookingModule,
    PaymentModule,
    CommentsModule,
    SuppliersModule,
    ExpensesModule,
    PurchaseCategoriesModule,
    PdfGenerationModule,
    QrCodeModule,
    ExpensePaymentsModule,
    LandingPagesModule,
    StatisticsModule,
    HallSectionsModule,
    HallCommunicationConfigurationsModule,
    PricingModule,
    HallTeamMembersModule,
    BookingPriceRequestsModule,
    CronsModule,
    HealthModule,
    ContactUsModule,
    ExpensesItemsModule,
    SupplierProductModule,
    VersionModule,
    RefundRequestsModule,
    PdfMergeModule,
    OpenAiModule,
    AnalyticsModule,
    AiAgentModule,
    InventoryModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    MailService,
    {
      provide: APP_PIPE,
      useValue: new ValidationPipe(),
    },
    {
      provide: APP_INTERCEPTOR,
      useClass: ResponseTransformInterceptor,
    },
    {
      provide: APP_FILTER,
      useClass: AllExceptionsFilter,
    },
    {
      provide: APP_INTERCEPTOR,
      useClass: VersionInterceptor,
    },
    {
      provide: APP_INTERCEPTOR,
      useClass: TelemetryInterceptor,
    },
  ],
})
export class AppModule {}
