import { Injectable } from '@nestjs/common';
import axios from 'axios';
import { ConfigService } from '@nestjs/config';
import { ProviderSmsParams } from './interfaces/providers-sms.interface';
import { LanguagesEnum } from '../../common/enums/lang.enum';

@Injectable()
export class SmsService {
  private apiKey: string;
  private baseUrl: string;
  private userName: string;
  private userSender: string;
  private isWorking: string;
  constructor(private readonly configService: ConfigService) {
    this.userName = this.configService.get<string>('MSEGAT_USER_NAME');
    this.userSender = this.configService.get<string>('MSEGAT_USER_SENDER');
    this.apiKey = this.configService.get<string>('MSEGAT_API_KEY');
    this.baseUrl = this.configService.get<string>('MSEGAT_BASE_URL');
    this.isWorking = this.configService.get<string>('MSEGAT_IS_WORKING') || 'false';
  }

  async sendSMS(phoneNumbers: string[], msg: string): Promise<void> {
    const url = `${this.baseUrl}`;
    const cleanedPhoneNumbers = phoneNumbers.map((phoneNumber) => phoneNumber.replace(/^\+/, ''));
    const data = {
      userName: this.userName,
      numbers: cleanedPhoneNumbers.join(','),
      userSender: this.userSender,
      apiKey: this.apiKey,
      msg,
    };
    const jsonData = JSON.stringify(data);

    try {
      if (this.isWorking === 'true') {
        const response = await axios.post(url, jsonData, {
          headers: {
            'Content-Type': 'application/json',
          },
        });
        return console.log(`${response.data.message} for sending msg`);
      }
      console.log('MSEGAT feature is currently disabled.');
    } catch (error) {
      console.log(`Failed to send SMS: ${error.message}`);
    }
  }

  generateCreateBookingUserSms(
    language: string,
    venueName: string,
    gregorian: string,
    hijri: string,
    contractLink: string,
  ): string {
    if (language === LanguagesEnum.Arabic) {
      const arabicTemplate = `
      عزيزي المستفيد،
      تم تأكيد حجزك في (اسم المكان) بتاريخ (الهجري)ه‍ , الموافق (الميلادي)م .
      لتفاصيل العقد اضغط على الرابط :
      (contract link)
    `;
      return arabicTemplate
        .replace('(اسم المكان)', venueName)
        .replace('(الهجري)', gregorian)
        .replace('(الميلادي)', gregorian)
        .replace('(contract link)', contractLink);
    } else {
      const englishTemplate = `
      Dear Beneficiary,
      Your reservation for (venue name) has been confirmed for the date (Hijri)H , corresponding to (Gregorian)G .
      Contract details are on the link:
      (contract link)
    `;
      return englishTemplate
        .replace('(venue name)', venueName)
        .replace('(Hijri)', hijri)
        .replace('(Gregorian)', gregorian)
        .replace('(contract link)', contractLink);
    }
  }

  generateCreateBookingProviderSms(params: ProviderSmsParams): string {
    const {
      language,
      serviceName,
      periodName,
      bookingNumber,
      gregorian,
      hijri,
      note,
      contractLink,
    } = params;

    console.log(params);
    if (language === LanguagesEnum.Arabic) {
      const arabicTemplate = `
     تم طلب خدمة (اسم الخدمة) لحجز رقم (رقم الحجز) بتاريخ (الميلادي) م الموافق (الهجري) هـ في الفترة (اسم الفتره)
     ${note}
     تفاصيل العقد: (contract link)
    `;
      return arabicTemplate
        .replace('(اسم الخدمة)', serviceName)
        .replace('(اسم الفتره)', periodName)
        .replace('(رقم الحجز)', bookingNumber)
        .replace('(الهجري)', gregorian)
        .replace('(الميلادي)', gregorian)
        .replace('(contract link)', contractLink);
    } else {
      const englishTemplate = `
     A (service name) service was requested for booking number (bookingNumber) on (Hijri)H , corresponding to (Gregorian)G in the (periodName) period.
     ${note}
     Contract details: (contract link)
    `;
      return englishTemplate
        .replace('(service name)', serviceName)
        .replace('(periodName)', periodName)
        .replace('(bookingNumber)', bookingNumber)
        .replace('(Hijri)', hijri)
        .replace('(Gregorian)', gregorian)
        .replace('(contract link)', contractLink);
    }
  }

  generateCancelBookingProviderSms(
    language: string,
    serviceName: string,
    periodName: string,
    bookingNumber: string,
    gregorian: string,
    hijri: string,
  ): string {
    if (language === 'ar') {
      const arabicTemplate = `
     تم إلغاء خدمة (اسم الخدمة) لحجز رقم (رقم الحجز) بتاريخ (الميلادي) م الموافق (الهجري) هـ في الفترة (اسم الفتره)
    `;
      return arabicTemplate
        .replace('(اسم الخدمة)', serviceName)
        .replace('(اسم الفتره)', periodName)
        .replace('(رقم الحجز)', bookingNumber)
        .replace('(الهجري)', gregorian)
        .replace('(الميلادي)', gregorian);
    } else {
      const englishTemplate = `
     The (service name) service was requested for booking number (bookingNumber) on (Hijri)H , corresponding to (Gregorian)G in the (periodName) period  has been canceled.
    `;
      return englishTemplate
        .replace('(service name)', serviceName)
        .replace('(periodName)', periodName)
        .replace('(bookingNumber)', bookingNumber)
        .replace('(Hijri)', hijri)
        .replace('(Gregorian)', gregorian);
    }
  }

  async sendHealthSMS(): Promise<{ status: boolean; message: string }> {
    const url = `${this.baseUrl}`;
    const cleanedPhoneNumbers = [this.configService.get<string>('HEALTH_CHECK_PHONE')].map(
      (phoneNumber) => phoneNumber.replace(/^\+/, ''),
    );
    const data = {
      userName: this.userName,
      numbers: cleanedPhoneNumbers.join(','),
      userSender: this.userSender,
      apiKey: this.apiKey,
      msg: 'MSEGAT feature is working fine.',
    };
    const jsonData = JSON.stringify(data);

    try {
      if (this.isWorking === 'true') {
        const response = await axios.post(url, jsonData, {
          headers: {
            'Content-Type': 'application/json',
          },
        });
        console.log(`${response.data.message} for sending msg`);
        return { status: true, message: response.data.message };
      }
      console.log('MSEGAT feature is currently disabled.');
      return { status: false, message: 'MSEGAT feature is currently disabled.' };
    } catch (error) {
      console.log(`Failed to send SMS: ${error.message}`);
      return { status: false, message: error.message };
    }
  }
}
