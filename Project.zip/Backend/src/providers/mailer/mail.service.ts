import { Injectable } from '@nestjs/common';
import { MailerService } from '@nestjs-modules/mailer';
import { QueueService } from '../queue/queue.service';
import { ConfigService } from '@nestjs/config';
import { join, resolve } from 'path';
import { LanguagesEnum } from '../../common/enums/lang.enum';
import moment from 'moment-hijri';
import { transformDate } from '../../common/date/date-transform';
import sharp from 'sharp';
import { Booking } from '../../modules/booking/entities/booking.entity';
import { eventTimeTranslations } from '../../modules/booking/translations/contract.translation';
import { GroupedContractsByDay } from '../../modules/booking/types/grouped-contracts.type';

@Injectable()
export class MailService {
  constructor(
    private readonly mailerService: MailerService,
    private readonly queueService: QueueService,
    private readonly configService: ConfigService,
  ) {}

  private async convertToPng(buffer: Buffer): Promise<Buffer> {
    try {
      return await sharp(buffer)
        .resize({
          width: 200,
          fit: 'inside',
          withoutEnlargement: true,
        })
        .png()
        .toBuffer();
    } catch (error) {
      console.error('Error converting image to PNG:', error);
      throw error;
    }
  }

  async sendEmail(
    receivers: string[],
    subject: string,
    template: string,
    context: Record<string, any> | Record<string, any>[],
    files?: any[],
  ) {
    await Promise.all(
      receivers.map((receiver, index) =>
        this.queueService
          .addAsyncQueue(this.sendTemplates.bind(this), receivers.length)
          .push({
            receiver,
            template,
            subject,
            context: Array.isArray(context) ? context[index] : context,
            files,
          })
          .catch((err) => console.error(err)),
      ),
    );
  }

  async sendHallTeamMemberEmail(
    receivers: string[],
    hallName: string,
    primaryColor: string,
    secondaryColor: string,
    logo: string,
    dayLinks: { day: string; link: string }[],
    scheduleDays: number,
  ) {
    const SAUDI_TIMEZONE = 'Asia/Riyadh';
    const saudiNow = moment().tz(SAUDI_TIMEZONE);
    const transformedDate = transformDate(saudiNow.toDate());
    const endDate = saudiNow.clone().add(scheduleDays - 1, 'days');
    const transformedEndDate = transformDate(endDate.toDate());

    await this.sendEmail(
      receivers,
      `جدول العمل لـ ${scheduleDays} أيام - قاعة ${hallName}`,
      'scheduleBooking',
      {
        startHijri: transformedDate.hijri.ar,
        startGregorian: transformedDate.gregorian.ar,
        endHijri: transformedEndDate.hijri.ar,
        endGregorian: transformedEndDate.gregorian.ar,
        dayLinks: dayLinks || [],
        logo,
        scheduleDays,
        dirName: hallName,
        primaryColor,
        secondaryColor,
      },
    );
  }

  async cancelTempBookings(receivers: string[], bookings: Booking[], lang: LanguagesEnum) {
    const bookingDetails = bookings.map((booking) => {
      const { hall, sections, user } = booking;
      const startDate = transformDate(booking.startDate);
      const endDate = transformDate(booking.endDate);

      return {
        placeName:
          lang === LanguagesEnum.English ? hall.name || hall.name_ar : hall.name_ar || hall.name,
        startHijri: startDate.hijri[lang],
        startGregorian: startDate.gregorian[lang],
        endHijri: endDate.hijri[lang],
        endGregorian: endDate.gregorian[lang],
        time: booking.eventTime ? eventTimeTranslations[booking.eventTime][lang] : undefined,
        customerName: user?.name,
        sections: sections
          .map((section) =>
            lang === LanguagesEnum.English
              ? section.name || section.name_ar
              : section.name_ar || section.name,
          )
          .join(', '),
        logo: hall.logo_url,
        dirName:
          lang === LanguagesEnum.English ? hall.name || hall.name_ar : hall.name_ar || hall.name,
        primaryColor: hall.primary_color,
        secondaryColor: hall.secondary_color,
      };
    });

    await this.sendEmail(
      receivers,
      `إلغاء حجز`,
      `temporary-booking-cancellation-${lang}`,
      bookingDetails,
    );
  }

  async tempBookingReminder(receivers: string[], bookings: Booking[], lang: LanguagesEnum) {
    const bookingDetails = bookings.map((booking) => {
      const { hall, sections, user } = booking;
      const startDate = transformDate(booking.startDate);
      const endDate = transformDate(booking.endDate);

      return {
        placeName:
          lang === LanguagesEnum.English ? hall.name || hall.name_ar : hall.name_ar || hall.name,
        startHijri: startDate.hijri[lang],
        startGregorian: startDate.gregorian[lang],
        endHijri: endDate.hijri[lang],
        endGregorian: endDate.gregorian[lang],
        time: booking.eventTime ? eventTimeTranslations[booking.eventTime][lang] : undefined,
        customerName: user?.name,
        sections: sections
          .map((section) =>
            lang === LanguagesEnum.English
              ? section.name || section.name_ar
              : section.name_ar || section.name,
          )
          .join(', '),
        logo: hall.logo_url,
        dirName:
          lang === LanguagesEnum.English ? hall.name || hall.name_ar : hall.name_ar || hall.name,
        primaryColor: hall.primary_color,
        secondaryColor: hall.secondary_color,
      };
    });

    await this.sendEmail(
      receivers,
      `تذكير بتأكيد الحجز`,
      `temporary-booking-reminder-${lang}`,
      bookingDetails,
    );
  }

  private async sendTemplates({
    receiver,
    template,
    context,
    subject,
    files,
  }: {
    receiver: string;
    subject: string;
    template: string;
    context: Record<string, any> | Record<string, any>[];
    files?: { path: string; name: string; type: string }[];
  }) {
    try {
      const defaultLogo = join(__dirname, 'templates', 'logo.png');
      const illustrationPath = join(__dirname, 'templates', 'illustration.png');
      const attachments = [];

      // 🔹 Handle logo logic
      if (context && typeof context === 'object' && 'logo' in context && context.logo) {
        try {
          const response = await fetch(context.logo);
          const arrayBuffer = await response.arrayBuffer();
          const buffer = Buffer.from(arrayBuffer);

          const pngBuffer = await this.convertToPng(buffer);

          attachments.push({
            filename: 'logo.png',
            content: pngBuffer,
            cid: 'logo',
            contentType: 'image/png',
          });
        } catch (error) {
          console.error('Error processing logo:', error);
          attachments.push({
            filename: 'logo.png',
            path: defaultLogo,
            cid: 'logo',
          });
        }
      } else {
        attachments.push({
          filename: 'logo.png',
          path: defaultLogo,
          cid: 'logo',
        });
        if (template !== 'contact-us-notify-ar' && template !== 'contact-us-notify-en') {
          attachments.push({
            filename: 'illustration.png',
            path: illustrationPath,
            cid: 'illustration',
          });
        }
      }

      // 🔹 Attach extra files (optional)
      if (files && files.length !== 0) {
        for (let file of files) {
          attachments.push({
            path: file.path,
          });
        }
      }

      // 🔹 Send email
      const info = await this.mailerService.sendMail({
        from: this.configService.get('MAIL_USER'),
        to: receiver,
        subject,
        template,
        context: {
          ...context,
        },
        attachments,
      });

      console.log('Mail sent: %s', info.messageId);
    } catch (err) {
      console.error('Error in sendTemplates:', err);
    }
  }

  async sendOtpMail(receiver: string, otp: number, name: string, lang: string) {
    const templateName = `otp-${lang}`;
    const templateTitle = lang === LanguagesEnum.Arabic ? 'رمز التحقق' : 'Verification code';
    await this.sendEmail([receiver], templateTitle, templateName, {
      otp,
      fullName: name,
    });
  }

  async sendHealthEmail(): Promise<{ status: boolean; message: string }> {
    try {
      const logo = join(__dirname, 'templates', 'logo.png');
      const info = await this.mailerService.sendMail({
        from: this.configService.get('MAIL_USER'),
        to: this.configService.get('HEALTH_CHECK_MAIL'),
        subject: 'Health check mail',
        template: 'test',
        context: {},
        attachments: [
          {
            filename: 'logo.png',
            path: logo,
            cid: 'logo',
          },
        ],
      });
      console.log('Mail sent: %s', info.messageId);
      return { status: true, message: info.messageId };
    } catch (err) {
      console.error('Error in sendTemplates:', err);
      return { status: false, message: err.message };
    }
  }

  private getPublicAssetUrl(relativePath: string): string {
    const base =
      process.env.NODE_ENV === 'local' ? process.env.APP_HOST : `${process.env.APP_HOST}/api`;
    return `${base}/${relativePath}`;
  }
}
