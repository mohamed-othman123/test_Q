import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { OpenAiConfig } from './types/open-ai.config';

@Injectable()
export class OpenAiService implements OnModuleInit {
  private readonly logger = new Logger(OpenAiService.name);
  private openai: OpenAI;
  private config: OpenAiConfig;

  constructor(private readonly configService: ConfigService) {}

  async onModuleInit() {
    this.config = this.loadConfig();
    this.logger.log('OpenAI service initialized');

    if (!this.config.apiKey) {
      this.logger.warn('OpenAI API key not configured - using mock mode');
    } else {
      this.logger.log('OpenAI API key configured successfully');
      this.initializeOpenAiClient();
    }
  }

  private loadConfig(): OpenAiConfig {
    return {
      apiKey:
        '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',
      //this.configService.get<string>('openai.apiKey') || '',
      apiUrl: this.configService.get<string>('openai.apiUrl'),
      model: this.configService.get<string>('openai.model') || 'gpt-4',
      maxRetries: this.configService.get<number>('openai.maxRetries') || 3,
      timeout: this.configService.get<number>('openai.timeout') || 30000,
      maxTokens: this.configService.get<number>('openai.maxTokens') || 1000,
      temperature: this.configService.get<number>('openai.temperature') || 0.1,
    };
  }

  private initializeOpenAiClient() {
    this.openai = new OpenAI({
      apiKey: this.config.apiKey,
      maxRetries: this.config.maxRetries,
      timeout: Math.max(this.config.timeout, 60000),
    });
  }

  getClient(): OpenAI {
    if (!this.openai) {
      throw new Error('OpenAI client not initialized. Please check your API key configuration.');
    }
    return this.openai;
  }

  getConfig(): OpenAiConfig {
    return { ...this.config };
  }

  isConfigured(): boolean {
    return !!this.config.apiKey;
  }

  getModel(): string {
    return this.config.model;
  }

  getDefaultParams() {
    return {
      temperature: this.config.temperature,
      maxTokens: this.config.maxTokens,
      model: this.config.model,
    };
  }
}
