import { Injectable } from '@nestjs/common';
import fastq from 'fastq';
import type { queueAsPromised, queue, worker, asyncWorker } from 'fastq';
import {cpus} from 'os';

@Injectable()
export class QueueService {
  /**
   * @description add a synchronous queue to memory
   * @example
   * const mailQueue = addQueue(sendMailFn) // concurrency default value = os.cpus.length most power of the cpu
   * const mailQueueWithConcurrency = addQueue(sendMailFn , 1)
   */
  addQueue<Task>(
    workerFn: worker<unknown, Task>,
    concurrency: number =cpus.length,
  ): queue<Task> {
    return fastq(workerFn, concurrency || 1); // for low specs os.cpus.length returns with 0
  }

  /**
   * @description add a asynchronous queue to memory
   * @example
   * const mailQueue = addAsyncQueue(sendMailFn) // concurrency default value = os.cpus.length most power of the cpu
   * const mailQueueWithConcurrency = addAsyncQueue(sendMailFn , 1)
   */
  addAsyncQueue<Task>(
    asyncWorkerFn: asyncWorker<unknown, Task>,
    concurrency: number =cpus.length,
  ): queueAsPromised<Task> {
    return fastq.promise(asyncWorkerFn, concurrency || 1);
  }
}
