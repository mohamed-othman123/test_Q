import { Injectable, OnModuleInit, OnModuleDestroy, Logger, Inject } from '@nestjs/common';
import Redis from 'ioredis';

@Injectable()
export class CacheService implements OnModuleInit, OnModuleDestroy {
  constructor(@Inject('REDIS_CLIENT') private readonly client: Redis) { }

  private readonly logger = new Logger(CacheService.name);

  onModuleInit(): void {
    this.client.on('connect', () => this.logger.log('Connected to CACHE'));
    this.client.on('error', (err) => this.logger.error('CACHE Error', err));
  }

  async onModuleDestroy(): Promise<void> {
    try {
      await this.client.quit();
      this.logger.log('Redis client disconnected');
    } catch (err) {
      this.logger.error('Error disconnecting Redis client', err);
    }
  }

  async get(key: string): Promise<string | null> {
    try {
      return await this.client.get(key);
    } catch (err) {
      this.logger.error(`Failed to get key ${key}`, err);
      return null;
    }
  }

  async set(key: string, value: string | number, exp: Date): Promise<string> {
    try {
      const expiration = exp.getTime() - Date.now();
      if (expiration < 0) {
        this.logger.warn(`Expiration time for key ${key} is in the past. Key will not be set.`);
        return '0'; // Indicate no operation was performed
      }
      return await this.client.set(key, value, 'PX', expiration);
    } catch (err) {
      this.logger.error(`Failed to set key ${key}`, err);
      throw err; // Rethrow to let caller handle the error
    }
  }

  async del(key: string): Promise<number> {
    try {
      return await this.client.del(key);
    } catch (err) {
      this.logger.error(`Failed to delete key ${key}`, err);
      return 0; // Indicate no keys were deleted
    }
  }

  async hset(key: string, field: string, value: string): Promise<number> {
    try {
      return await this.client.hset(key, field, value);
    } catch (err) {
      this.logger.error(`Failed to hset field ${field} in key ${key}`, err);
      return 0; // Indicate no fields were set
    }
  }

  async hget(key: string, field: string): Promise<string | null> {
    try {
      return await this.client.hget(key, field);
    } catch (err) {
      this.logger.error(`Failed to hget field ${field} from key ${key}`, err);
      return null;
    }
  }
}