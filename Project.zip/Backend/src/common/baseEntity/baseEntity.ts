import {
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
} from 'typeorm';
export class BaseEntity {
  @PrimaryGeneratedColumn()
  id: number;
  @Column({ type: 'int', nullable: true }) //null will be removed
  created_by: number;
  @CreateDateColumn({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  created_at: Date;
  @Column({ type: 'int', nullable: true }) //null will be  removed
  updated_by: number;
  @UpdateDateColumn({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  updated_at: Date;
  @DeleteDateColumn({ type: 'timestamp', default: null })
  deleted_at: Date;
  @Column({ type: 'boolean', default: false })
  deleted: boolean;
  @Column({ type: 'int', default: null })
  deleted_by: number;
}
