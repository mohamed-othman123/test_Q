import { DataSource, EntityManager, Repository } from 'typeorm';

export class BaseRepository {
  constructor(private dataSource: DataSource) {}

  getRepository<T>(entityCls: new () => T, connectionKey: EntityManager): Repository<T> {
    const entityManager: EntityManager = connectionKey ?? this.dataSource.manager;
    return entityManager.getRepository(entityCls);
  }
}
