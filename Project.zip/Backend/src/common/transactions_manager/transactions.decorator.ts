import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { EntityManager } from 'typeorm';
import { CONNECTION_MANAGER_KEY } from './transaction.interceptor';

export const Transaction = createParamDecorator(
  (data: unknown, ctx: ExecutionContext): EntityManager => {
    const req = ctx.switchToHttp().getRequest();
    return req[CONNECTION_MANAGER_KEY];
  },
);
