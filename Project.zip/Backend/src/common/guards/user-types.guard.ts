import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { UserTypesEnum } from '../../modules/users/enums/users-type.enum';
import { USER_TYPES_KEY } from '../../common/decorators/user-types.decorator';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';

@Injectable()
export class UserTypeGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const types = this.reflector.get<UserTypesEnum[]>(USER_TYPES_KEY, context.getHandler());
    if (!types) {
      return true; // If no types defined, allow access
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user; // Assume user is set by a JWT strategy

    if (!user || !types.includes(user.type)) {
      throw new ForbiddenException(ErrorKeys.forbidden);
    }

    return true;
  }
}
