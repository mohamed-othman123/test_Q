import { SetMetadata } from '@nestjs/common';
import { UserTypesEnum } from '../../modules/users/enums/users-type.enum';

/**
 * Custom decorator to set user types for route handlers.
 * @param types - Array of user types to be assigned.
 * @returns {CustomDecorator} - The custom decorator function.
 */

export const USER_TYPES_KEY = 'types';
export const UserTypes = (...types: UserTypesEnum[]) => SetMetadata(USER_TYPES_KEY, types);
