import { SetMetadata } from '@nestjs/common';

export const VERSION_METADATA = 'version';

export const CustomVersion = (version: string) => SetMetadata(VERSION_METADATA, version);
