import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { HttpAdapterHost } from '@nestjs/core';
import { I18nService } from 'nestjs-i18n';
import { SpanStatusCode, trace } from '@opentelemetry/api'; // Import OpenTelemetry API
import { v4 as uuidv4 } from 'uuid';
import { ErrorKeys } from '../enums/errorKeys.enums';

@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly logger = new Logger(AllExceptionsFilter.name);

  constructor(
    private readonly httpAdapterHost: HttpAdapterHost,
    private readonly i18n: I18nService,
  ) {}

  catch(exception: any, host: ArgumentsHost): void {
    const { httpAdapter } = this.httpAdapterHost;
    const ctx = host.switchToHttp();
    const request = ctx.getRequest();
    const response = ctx.getResponse();

    const httpStatus =
      exception instanceof HttpException ? exception.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR;

    const lang = request.headers['accept-language'] || 'en';

    let responseMessage: string | undefined;
    let responseErrorCode: string | undefined;
    let responseData: any;
    let responseStatus: string | undefined;
    let entityArg: string | undefined;

    if (httpStatus === HttpStatus.INTERNAL_SERVER_ERROR || httpStatus === HttpStatus.BAD_GATEWAY) {
      const errorKey =
        httpStatus === HttpStatus.INTERNAL_SERVER_ERROR
          ? ErrorKeys.INTERNAL_SERVER_ERROR_WITH_CONTACT
          : ErrorKeys.BAD_GATEWAY_WITH_CONTACT;

      responseMessage = errorKey;
      responseErrorCode = errorKey;
    } else if (exception instanceof HttpException) {
      const exceptionResponse = exception.getResponse();

      if (typeof exceptionResponse === 'object') {
        responseMessage = exceptionResponse['message'];
        responseErrorCode = exceptionResponse['error'];
        responseData = exceptionResponse['data'];
        responseStatus = exceptionResponse['status'];
        entityArg = exceptionResponse['arg'];
      }
    }

    const messages = responseMessage ? responseMessage.split(',') : ['GENERAL_ERROR'];
    const translatedMessages = messages
      .map((msg) => {
        let translatedMessage = this.i18n.translate(`errors.${msg.trim()}`, {
          lang,
          args: {
            entity: entityArg ? this.i18n.translate(`entities.${entityArg}`, { lang }) : '',
            email: process.env?.SUPPORT_EMAIL || '',
            phone: process.env?.SUPPORT_PHONE || '',
          },
        });

        if (translatedMessage === `errors.${msg.trim()}`) {
          translatedMessage = this.i18n.translate('errors.GENERAL_ERROR', { lang });
        }

        if (
          httpStatus === HttpStatus.INTERNAL_SERVER_ERROR ||
          httpStatus === HttpStatus.BAD_GATEWAY
        ) {
          return translatedMessage;
        }

        return translatedMessage.replace(/(?:\r\n|\r|\n)/g, ' ');
      })
      .join('\n');

    responseMessage = translatedMessages;

    const responseBody = {
      statusCode: httpStatus,
      message: responseMessage,
      errorCode: responseErrorCode,
      data: responseData,
      status: responseStatus,
      path: httpAdapter.getRequestUrl(request),
      timestamp: new Date().toISOString(),
      originalMessage: exception instanceof Error ? exception.message : undefined,
      ...(process.env.NODE_ENV === 'local' && {
        stack: exception instanceof Error ? exception.stack : undefined,
      }),
    };

    this.logger.error(responseBody);

    let currentSpan = trace.getActiveSpan();
    if (!currentSpan) {
      const tracer = trace.getTracer('nestjs-exceptions');
      currentSpan = tracer.startSpan('exception.handler', {
        attributes: {
          'http.method': request.method,
          'http.url': request.url,
          'http.status_code': httpStatus,
          'request.user_agent': request.headers['user-agent'],
          'request.ip': request.ip,
          'exception.type': exception.constructor.name,
          'exception.message': responseMessage,
          'error.id': uuidv4(),
        },
      });
    }

    currentSpan.recordException({
      ...(exception as Error),
      message: responseMessage,
    });

    currentSpan.setStatus({
      code: SpanStatusCode.ERROR,
      message: responseMessage,
    });

    currentSpan.setAttributes({
      'http.method': request.method,
      'http.url': request.url,
      'http.status_code': httpStatus,
      'request.user_agent': request.headers['user-agent'],
      'request.ip': request.ip,
      'request.body': JSON.stringify(request.body),
      'exception.type': exception.constructor.name,
      'exception.message': responseMessage,
      'exception.message_keys': responseMessage,
      'exception.original_message':
        exception instanceof Error ? exception.message : 'Unknown error',
      'exception.stack': exception instanceof Error ? exception.stack : undefined,
      'error.id': uuidv4(),
      'error.handled': true,
      'error.severity': httpStatus >= 500 ? 'high' : 'medium',
      'service.name': process.env.SERVICE_NAME || 'qaatk-online-api',
      'service.environment': process.env.NODE_ENV || 'local',
    });

    currentSpan.addEvent('exception.handled', {
      'error.id': uuidv4(),
      'response.status_code': httpStatus,
      'response.message': responseMessage,
      timestamp: new Date().toISOString(),
    });

    if (!trace.getActiveSpan()) {
      currentSpan.end();
    }

    httpAdapter.reply(response, responseBody, httpStatus);
  }
}
