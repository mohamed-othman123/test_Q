import moment from 'moment-hijri';

export const transformDate = (date: Date) => {
  // Initialize moment with Hijri plugin
  const startMoment = moment(date);
  const startHijri = startMoment.clone();

  // Days in English and Arabic
  const daysEn = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const daysAr = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

  // Hijri months in English
  const hijriMonthsEn = [
    'Muharram',
    'Safar',
    'Rabi al-Awwal',
    'Rabi al-Thani',
    'Jumada al-Awwal',
    'Jumada al-Thani',
    'Rajab',
    'Shaban',
    'Ramadan',
    'Shawwal',
    'Dhu al-Qadah',
    'Dhu al-Hijjah',
  ];

  // Get day names
  const dayIndex = startMoment.day();
  const dayEn = daysEn[dayIndex];
  const dayAr = daysAr[dayIndex];

  // Get Gregorian month names
  const monthGregorianEn = startMoment.locale('en').format('MMMM');
  const monthGregorianAr = startMoment.locale('ar-sa').format('MMMM');

  // Get Hijri month names
  const hijriMonthIndex = startHijri.iMonth(); // 0-based index
  const monthHijriEn = hijriMonthsEn[hijriMonthIndex];
  const monthHijriAr = startHijri.locale('ar-sa').format('iMMMM');

  // English format remains DD/MM/YYYY
  const dateGregorianEn = startMoment.locale('en').format('DD/MM/YYYY');
  const dateHijriEn = startHijri.locale('en').format('iDD/iMM/iYYYY');

  // Arabic format changed to YYYY/MM/DD
  const dateGregorianAr = startMoment.locale('ar-sa').format('YYYY/MM/DD');
  const dateHijriAr = startHijri.locale('ar-sa').format('iYYYY/iMM/iDD');

  return {
    day: {
      en: dayEn,
      ar: dayAr,
    },
    monthGregorian: {
      en: monthGregorianEn,
      ar: monthGregorianAr,
    },
    monthHijri: {
      en: monthHijriEn,
      ar: monthHijriAr,
    },
    gregorian: {
      en: dateGregorianEn,
      ar: dateGregorianAr,
    },
    hijri: {
      en: dateHijriEn,
      ar: dateHijriAr,
    },
  };
};
