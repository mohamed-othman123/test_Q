import { Controller, Get } from '@nestjs/common';
import { ApiResponse, ApiTags } from '@nestjs/swagger';
import { Public } from '../../auth/decorator/public.decorator';
import { CaptchaService } from './captcha.service';

@Public()
@ApiTags('captcha')
@Controller('captcha')
export class CaptchaController {
  constructor(private readonly captchaService: CaptchaService) {}

  @Get()
  @ApiResponse({
    description: 'getting captcha at SVG ',
    status: 200,
  })
  async createCaptcha(): Promise<{ captchaId: string; svg: string }> {
    return await this.captchaService.generateCaptcha();
  }
}
