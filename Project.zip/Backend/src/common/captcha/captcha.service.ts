import { CacheService } from './../../providers/cache/cache.service';
import { Injectable } from '@nestjs/common';
import * as svgCaptcha from 'svg-captcha';
import { randomBytes, createHmac } from 'crypto';
import { Readable } from 'stream';

@Injectable()
export class CaptchaService {
  constructor(private readonly cacheService: CacheService) {}
  //generate captcha with hash

  private captchaExpirationTime = 3 * 60 * 1000;
  async generateCaptcha() {
    const captcha = svgCaptcha.create({
      size: 6,
      noise: 2,
      color: true,
      background: '#f7f7f7',
    });
    const secretKey = randomBytes(16).toString('hex');
    const captchaId = randomBytes(8).toString('hex');

    // Step 2: Hash the CAPTCHA text
    const captchaHash = createHmac('sha256', secretKey).update(captcha.text).digest('hex');

    const expirationTime = new Date(Date.now() + this.captchaExpirationTime);

    // Step 3: Store the secret server-side
    await this.cacheService.set(
      captchaId,
      JSON.stringify({
        secretKey,
        captchaHash,
        attempts: 0,
        expirationTime,
      }),
      expirationTime,
    );
    // Step 4: Return the CAPTCHA ID and SVG to the client
    return { captchaId, svg: captcha.data };
  }

  //compared user text with hashed captcha
  async validateCaptcha(captchaId: string, userInput: string): Promise<boolean> {
    // Step 1: Retrieve CAPTCHA metadata from the cache
    const captchaData = await this.cacheService.get(captchaId);
    if (!captchaData) return false;
    const { secretKey, captchaHash, attempts, expirationTime } = JSON.parse(captchaData);

    const expirationTimestamp = new Date(expirationTime).getTime();

    if (Date.now() > expirationTimestamp) {
      await this.cacheService.del(captchaId);
      return false;
    }

    // Step 2: Hash the user input using the stored secret key
    const userInputHash = createHmac('sha256', secretKey).update(userInput).digest('hex');

    // Step 3: Compare the hash of the user input with the stored CAPTCHA hash
    if (userInputHash !== captchaHash) {
      // Increment the attempts counter for invalid inputs
      if (attempts >= 3) {
        await this.cacheService.del(captchaId);
        return false;
      }

      // Update the attempts counter
      await this.cacheService.set(
        captchaId,
        JSON.stringify({ secretKey, captchaHash, expirationTime, attempts: attempts + 1 }),
        new Date(expirationTime),
      );

      return false;
    }

    await this.cacheService.del(captchaId);
    return true;
  }
}
