export const MAX_IMAGE_SIZE = 5 * 1024 * 1024; // 5MB

export const MAX_VIDEO_SIZE = 50 * 1024 * 1024; // 50MB

export const MAX_AUDIO_SIZE = 10 * 1024 * 1024; // 10MB

export const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

export const MAX_FILE_COUNT = 10 as const;

export const FILE_UPLOAD_DESTINATION = 'uploads' as const;

export const FILE_UPLOAD_PATH = 'uploads' as const;

export const FILE_UPLOAD_FIELD_NAME = 'file' as const;

export const FILE_UPLOAD_FIELD_NAME_MULTIPLE = 'files' as const;

export const FILE_UPLOAD_FIELD_NAME_ARRAY = 'files' as const;

export const FILE_UPLOAD_FIELD_NAME_ANY = 'files' as const;
