import { Global, Module } from '@nestjs/common';
import { PdfMergeService } from './pdf-merge.service';

@Global()
@Module({
  providers: [PdfMergeService],
  exports: [PdfMergeService],
})
export class PdfMergeModule {}
