export const NumberTransformer = {
  to: (value: number): number => value,
  from: (value: string): number => Number(value),
};
