export const DecimalTransformer = {
  to: (value: number): number => value,
  from: (value: string): number => parseFloat(parseFloat(value).toFixed(2)),
};
