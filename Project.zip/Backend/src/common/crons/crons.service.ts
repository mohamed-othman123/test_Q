import { BookingService } from './../../modules/booking/services/booking.service';
import { Injectable } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { ExpensesService } from '../../modules/expenses/services/expenses.service';
import { RefundRequestsService } from '../../modules/refund-requests/refund-requests.service';

@Injectable()
export class CronsServices {
  constructor(
    private readonly bookingService: BookingService,
    private readonly expensesService: ExpensesService,
    private readonly refundRequestsService: RefundRequestsService,
  ) {}

  @Cron('0 1 * * *') //at 1 AM
  async handleCron(): Promise<void> {
    this.bookingService.updateLateBookings();
    this.expensesService.updateLatePurchses();
  }

  @Cron('0 1 * * *', {
    timeZone: 'Asia/Riyadh',
  })
  async autoCancelTempBookings(): Promise<void> {
    await this.bookingService.autoCancelTempBookings();
  }

  @Cron('0 0 * * *', {
    timeZone: 'Asia/Riyadh',
  })
  async tempBookingReminder(): Promise<void> {
    await this.bookingService.tempBookingsReminder();
  }

  @Cron(CronExpression.EVERY_HOUR, { timeZone: 'Asia/Riyadh' })
  async scheduleBookings(): Promise<void> {
    await this.bookingService.scheduleBookings();
  }

  @Cron('0 1 * * *', {
    timeZone: 'Asia/Riyadh',
  })
  async autoRejectExceedRefundRequest(): Promise<void> {
    await this.refundRequestsService.autoRejectInvalidRefunds();
  }
}
