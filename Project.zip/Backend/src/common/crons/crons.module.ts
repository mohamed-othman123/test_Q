import { Module } from '@nestjs/common';
import { CronsServices } from './crons.service';
import { ScheduleModule } from '@nestjs/schedule';
import { BookingModule } from '../../modules/booking/booking.module';
import { ExpensesModule } from '../../modules/expenses/expenses.module';
import { RefundRequestsModule } from '../../modules/refund-requests/refund-requests.module';

@Module({
  imports: [ScheduleModule.forRoot(), BookingModule, ExpensesModule, RefundRequestsModule],
  providers: [CronsServices],
  exports: [CronsServices],
})
export class CronsModule {}
