import { Injectable, PipeTransform, ArgumentMetadata, BadRequestException } from '@nestjs/common';
import { validate, ValidationError } from 'class-validator';
import { plainToClass, ClassConstructor } from 'class-transformer';

@Injectable()
export class ValidationPipe implements PipeTransform {
  async transform(value: any, { metatype }: ArgumentMetadata) {
    if (!metatype || !this.toValidate(metatype)) {
      return value;
    }

    const object = plainToClass(metatype, value);
    const errors = await validate(object);

    if (errors.length > 0) {
      throw new BadRequestException(this.formatErrors(errors));
    }

    return object;
  }

  private formatErrors(errors: ValidationError[]) {
    return errors
      .map(err => {
        if (err.constraints) {
          return Object.values(err.constraints);
        } else if (err.children && err.children.length) {
          return err.children.map(childErr => this.formatErrors([childErr]));
        }
        return `Unspecified error in property ${err.property}`;
      })
      .join(', ');
  }

  private toValidate(metatype: ClassConstructor<any>): boolean {
    const types: ClassConstructor<any>[] = [String, Boolean, Number, Array, Object];
    return !types.includes(metatype);
  }
}