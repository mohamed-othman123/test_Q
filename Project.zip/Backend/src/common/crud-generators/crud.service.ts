import { Injectable } from '@nestjs/common';
import { TypeOrmCrudService } from '@dataui/crud-typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class CrudService<T> extends TypeOrmCrudService<T> {
  constructor(repo: Repository<T>) {
    super(repo);
  }
  /*async getTopUsers() {
    return 'test';
  }*/
}
