import { Controller, Get, Type } from '@nestjs/common';
import { CrudService } from './crud.service';
import { Crud, CrudController } from '@dataui/crud';

export function FactoryCrudController<T>(entity: Type<T>): any {
  @Crud({
    model: { type: entity },
  })
  class GenericController implements CrudController<T> {
    constructor(public service: CrudService<T>) {}

    //we can add custom end points here to shared across app
    //ex
    /*  @Get('top-users')
    async getTopUsers() {
      return await this.service.getTopUsers();
    }*/
  }

  return GenericController;
}
