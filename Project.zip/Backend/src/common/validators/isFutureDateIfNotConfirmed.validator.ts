import { registerDecorator, ValidationOptions, ValidationArguments } from 'class-validator';

export function IsFutureDateIfNotConfirmed(validationOptions?: ValidationOptions) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: 'isFutureDateIfNotConfirmed',
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      validator: {
        validate(value: any, args: ValidationArguments) {
          const obj = args.object as any;
          if (obj.isConfirmed === false) {
            const inputDate = new Date(value);
            const today = new Date();
            today.setHours(0, 0, 0, 0); // Set to start of the day
            return inputDate >= today; // Allow today and future dates
          }
          return true;
        },
        defaultMessage(args: ValidationArguments) {
          return `${args.property} must not be less than today if booking is not confirmed.`;
        },
      },
    });
  };
}
