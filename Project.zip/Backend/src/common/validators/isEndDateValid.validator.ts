
import { registerDecorator, ValidationOptions, ValidationArguments } from 'class-validator';

export function IsEndDateValid(startDateProperty: string, validationOptions?: ValidationOptions) {
  return function(object: Object, propertyName: string) {
    registerDecorator({
      name: 'isEndDateValid',
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      constraints: [startDateProperty],
      validator: {
        validate(endDate: string, args: ValidationArguments) {
          const startDate = (args.object as any)[startDateProperty];
          return new Date(endDate) >= new Date(startDate);
        },
        defaultMessage(args: ValidationArguments) {
          return `${args.property} must not be earlier than ${args.constraints[0]}`;
        },
      },
    });
  };
}