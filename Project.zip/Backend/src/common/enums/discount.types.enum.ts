export enum DiscountTypeEnum {
  fixed = 'fixed',
  percent = 'percent',
}
