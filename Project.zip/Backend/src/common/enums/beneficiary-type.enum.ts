export enum BeneficiaryType {
  CUSTOMER = 'customer',
  OTHER = 'other',
}
