export enum ImageMimeTypeEnum {
  'image/png',
  'image/jpg',
  'image/jpeg',
  'image/gif',
  'image/webp',
}
