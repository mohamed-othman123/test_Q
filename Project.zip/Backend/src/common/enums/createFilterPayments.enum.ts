export enum CreateFilterPayment {
  All = 'All',
  Income = 'Income',
  Expense = 'Expense',
}
