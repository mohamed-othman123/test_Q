export enum LanguagesEnum {
  Arabic = 'ar',
  English = 'en',
}
