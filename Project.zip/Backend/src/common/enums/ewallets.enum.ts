export enum EWalletEnum {
  StcEwallet = 'STC Pay',
  UrEwallet = 'UR Pay',
  MobileEwallet = 'Mobile Pay',
  MeemEwallet = 'Meem',
  FriendiEwallet='Friendi Pay',
  AlinmaEwallet = 'Alinma Pay',
  StcEwalletAr = 'إس تي سي باي',
  UrEwalletAr = 'يو آر باي',
  MobileEwalletAr = 'موبايل باي',
  MeemEwalletAr = 'ميم',
  FriendiEwalletAr='فرندي باي',
  AlinmaEwalletAr = 'الإنماء باي',
}
export enum EWalletEn {
  StcEwallet = 'STC Pay',
  UrEwallet = 'UR Pay',
  MobileEwallet = 'Mobile Pay',
  MeemEwallet = 'Meem',
  FriendiEwallet='Friendi Pay',
  AlinmaEwallet = 'Alinma Pay',
}

export enum EWalletAr {
  StcEwallet = 'إس تي سي باي',
  UrEwallet = 'يو آر باي',
  MobileEwallet = 'موبايل باي',
  MeemEwallet = 'ميم',
  FriendiEwallet='فرندي باي',
  AlinmaEwallet = 'الإنماء باي',
}





