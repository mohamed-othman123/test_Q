export enum CreateFilterPaymentType {
  Week = 'week',
  Month = 'month',
}
