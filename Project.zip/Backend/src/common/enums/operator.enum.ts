export enum OperatorEnum {
  LESS = '<',
  MORE = '>',
  LESSOREQUAL = '<=',
  MOREOREQUAL = '>=',
  NOTEQUAL = '!=',
  RIGHTEQUAL = '=:',
  LEFTEQUAL = ':=',
  EQUAL = ':=:',
}
