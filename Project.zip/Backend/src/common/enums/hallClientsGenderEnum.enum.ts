export enum HallClientsGenderEnum {
    MALE = 'male',
    FEMALE = 'female',
    OTHER = 'other',
  }