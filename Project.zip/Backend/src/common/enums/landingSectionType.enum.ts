export enum LandingSectionType {
  SERVICES = 'services',
  FEATURES = 'features',
  BANNERS = 'banners',
  IMAGES = 'images',
  QUESTIONS = 'popularQuestions',
  CUSTOMERS = 'customers',
  LINKS = 'socialLinks',
}
