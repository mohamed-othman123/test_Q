export enum PaymentMethodsEnum {
    BANK_ACCOUNT = 'bankAccount',
    E_WALLET = 'eWallet',
    POS = 'pos',
    CASH = 'cash'
}