export enum TeamMembersTypeEnum {
  employee = 'employee',
  thirdParty = 'thirdParty',
}
