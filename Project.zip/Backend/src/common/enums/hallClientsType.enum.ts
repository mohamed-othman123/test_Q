export enum HallClientsTypeEnum {
  INDIVIDUAL = 'Individual',
  FACILITY = 'Facility',
  GOVERNMENTAL = 'Governmental Facility',
}

export const HallClientsTypeTranslations = {
  [HallClientsTypeEnum.INDIVIDUAL]: {
    en: 'Individual',
    ar:'فرد'
  },
  [HallClientsTypeEnum.FACILITY]: {
    en: 'Facility',
    ar:'منشأة'
  },
  [HallClientsTypeEnum.GOVERNMENTAL]: {
    en: 'Governmental Facility',
    ar:'منشأة حكومية'
  },
};
