export enum TimePeriodEnum {
    MORNING = 'morning',
    EVENING = 'evening',
    FULL_DAY = 'fullDay',
}