export enum PricingCalculationType{
    FIXED_PRICE = 'FIXED_PRICE',
    PER_PERSON = 'PER_PERSON',
    BOOKING_TIME = 'BOOKING_TIME',
}