export enum BookingPricingType {
    BOOKING_TIME = 'BOOKING_TIME',
    FIXED='FIXED',
    EVENT='EVENT'
}