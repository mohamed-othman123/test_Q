export enum SortOrderEnum {
  ASC = 'ASC',
  DESC = 'DESC',
}
