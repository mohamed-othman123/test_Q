import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { trace, metrics, SpanStatusCode } from '@opentelemetry/api';

@Injectable()
export class TelemetryInterceptor implements NestInterceptor {
  private readonly requestCounter = metrics
    .getMeter('nestjs')
    .createCounter('http_requests_total', {
      description: 'Total number of HTTP requests',
    });

  private readonly requestDuration = metrics
    .getMeter('nestjs')
    .createHistogram('http_request_duration_seconds', {
      description: 'HTTP request duration in seconds',
    });

  private readonly errorCounter = metrics.getMeter('nestjs').createCounter('http_errors_total', {
    description: 'Total number of HTTP errors',
  });

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const request = context.switchToHttp().getRequest();
    const response = context.switchToHttp().getResponse();
    const handler = context.getHandler();
    const controller = context.getClass();

    const method = request.method;
    const url = request.url;
    const controllerName = controller.name;
    const handlerName = handler.name;

    const tracer = trace.getTracer('nestjs');
    const span = tracer.startSpan(`${method} ${url}`, {
      attributes: {
        'http.method': method,
        'http.url': url,
        'http.route': `${controllerName}.${handlerName}`,
        'controller.name': controllerName,
        'handler.name': handlerName,
        'user.id': request?.user?.id,
        'user.clientId': request?.user?.clientId,
      },
    });

    const startTime = Date.now();

    this.requestCounter.add(1, {
      method,
      url,
      controller: controllerName,
      handler: handlerName,
    });

    return next.handle().pipe(
      tap((data) => {
        const duration = (Date.now() - startTime) / 1000;

        this.requestDuration.record(duration, {
          method,
          url,
          controller: controllerName,
          handler: handlerName,
          status: response.statusCode,
        });

        span.setAttributes({
          'http.status_code': response.statusCode,
          'http.response_size': JSON.stringify(data)?.length,
          'response.duration_ms': duration * 1000,
        });

        span.setStatus({ code: SpanStatusCode.OK });
        span.end();
      }),
      catchError((error) => {
        const duration = (Date.now() - startTime) / 1000;

        this.errorCounter.add(1, {
          method,
          url,
          controller: controllerName,
          handler: handlerName,
          error_type: error.constructor.name,
        });

        this.requestDuration.record(duration, {
          method,
          url,
          controller: controllerName,
          handler: handlerName,
          status: error.status || 500,
        });

        span.setAttributes({
          'http.status_code': error.status || 500,
          'error.type': error.constructor.name,
          'error.message': error.message,
          'response.duration_ms': duration * 1000,
        });

        span.setStatus({
          code: SpanStatusCode.ERROR,
          message: error.message,
        });

        span.recordException(error);
        span.end();

        throw error;
      }),
    );
  }
}
