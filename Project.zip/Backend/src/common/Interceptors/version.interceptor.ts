import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { Reflector } from '@nestjs/core';
import { FastifyReply } from 'fastify';
import * as fs from 'fs';
import * as path from 'path';

const VERSION_METADATA = 'version';
const DEFAULT_VERSION = '1.0.0';
const DEFAULT_ROUTE_VERSION = '1';

@Injectable()
export class VersionInterceptor implements NestInterceptor {
  private systemVersion: string;

  constructor(private reflector: Reflector) {
    this.loadSystemVersion();
  }

  private loadSystemVersion() {
    try {
      const packageJsonPath = path.join(process.cwd(), 'package.json');
      if (fs.existsSync(packageJsonPath)) {
        const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
        this.systemVersion = packageJson.version;
      }
    } catch (error) {
      console.error('Error loading system version:', error);
      this.systemVersion = '0.0.0';
    }
  }

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const request = context.switchToHttp().getRequest();
    const response = context.switchToHttp().getResponse<FastifyReply>();
    const controller = context.getClass();
    const handler = context.getHandler();

    const handlerVersion = this.reflector.get<string>(VERSION_METADATA, handler);
    const controllerVersion = this.reflector.get<string>(VERSION_METADATA, controller);

    const apiVersion = handlerVersion || controllerVersion || DEFAULT_VERSION;

    const pathSegments = request.url.split('/');
    const routeVersion = pathSegments[1]?.startsWith('v')
      ? pathSegments[1].substring(1) // Remove 'v' prefix
      : DEFAULT_ROUTE_VERSION;

    // Log version information
    console.log(
      `%cAPI Version Info:
      Full Path: ${request.path}
      Method: ${request.method}
      Controller Version: ${apiVersion}
      Handler Version: ${apiVersion}
      Route Version: v${routeVersion}
      System Version: ${this.systemVersion}
      Controller: ${controller.name}
      Handler: ${handler.name}`,
      'background: #222; color: #bada55; padding: 2px 5px; border-radius: 3px;',
    );

    return next.handle().pipe(
      finalize(() => {
        response.header('x-api-version', `${apiVersion}`);
        response.header('x-system-version', this.systemVersion);
      }),
    );
  }
}
