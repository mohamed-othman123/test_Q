import { ForbiddenException, Injectable, Logger } from '@nestjs/common';
import { FastifyRequest } from 'fastify';
import { DataSource } from 'typeorm';
import { ErrorKeys } from '../enums/errorKeys.enums';

/**
 * Service responsible for extracting hall IDs from various sources in a request
 * including body, query parameters, URL parameters, and related entities.
 */
@Injectable()
export class HallIdExtractor {
  private readonly logger = new Logger(HallIdExtractor.name);

  constructor(private readonly dataSource: DataSource) {}

  /**
   * Extracts all hall IDs from a request using various sources
   * @param request The Fastify request object
   * @returns Promise resolving to an array of unique hall IDs
   */
  async extractAll(request: FastifyRequest): Promise<number[]> {
    const hallIds: number[] = [];

    const body = (request.body as Record<string, any>) || {};
    const query = (request.query as Record<string, any>) || {};
    const params = (request.params as Record<string, any>) || {};

    const hasDirectHallIds =
      ('halls' in body && Array.isArray(body.halls) && body.halls.length > 0) ||
      'hallId' in body ||
      'hallId' in query ||
      'hallId' in params;

    if ('halls' in body || 'hallId' in body) {
      this.extractFromRequestBody(body, hallIds);
    }

    if ('hallId' in query) {
      this.extractFromRequestQuery(query, hallIds);
    }

    if ('hallId' in params) {
      this.extractFromRequestParam(params, hallIds);
    }

    if (!hasDirectHallIds) {
      await this.extractFromRelatedEntities(body, query, hallIds);
    }

    // Return unique, valid hall IDs
    return Array.from(new Set(hallIds.filter((id) => this.isValidNumber(id))));
  }

  private async extractFromRelatedEntities(
    body: Record<string, any>,
    query: Record<string, any>,
    hallIds: number[],
  ): Promise<void> {
    const purchaseId = query.purchaseId || body.purchaseId;
    const bookingId = query.bookingId || body.bookingId;
    const landingPageId = query.landingPageId || body.landingPageId;
    const sectionId = query.sectionId || body.sectionId;

    try {
      if (purchaseId) await this.extractFromRelatedEntity(+purchaseId, 'expenses', hallIds);
      if (bookingId) await this.extractFromRelatedEntity(+bookingId, 'booking', hallIds);
      if (sectionId)
        await this.extractFromRelatedEntity(+sectionId, 'hall_landing_page_sections', hallIds);
      if (landingPageId)
        await this.extractFromRelatedEntity(+landingPageId, 'hall_landing_page', hallIds);
    } catch (error) {
      throw new ForbiddenException(ErrorKeys.forbidden);
    }
  }

  private async extractFromRelatedEntity(
    id: number,
    entity: string,
    hallIds: number[],
  ): Promise<void> {
    if (!this.isValidNumber(id)) return;

    try {
      const repo = this.dataSource.getRepository(entity);
      let hallId: number | undefined;

      switch (entity) {
        case 'expenses':
          const expense = await repo.findOne({
            where: { id },
            relations: { hall: true },
            select: { id: true, hall: { id: true } },
          });
          hallId = expense?.hall?.id;
          break;

        case 'booking':
          const booking = await repo.findOne({
            where: { id },
            relations: { hall: true },
            select: { id: true, hall: { id: true } },
          });
          hallId = booking?.hall?.id;
          break;

        case 'hall_landing_page_sections':
          const section = await repo.findOne({
            where: { id },
            relations: { landingPage: { hall: true } },
            select: {
              id: true,
              landingPage: { id: true, hall: { id: true } },
            },
          });
          hallId = section?.landingPage?.hall?.id;
          break;

        case 'hall_landing_page':
          const landingPage = await repo.findOne({
            where: { id },
            relations: { hall: true },
            select: {
              id: true,
              hall: { id: true },
            },
          });
          hallId = landingPage?.hall?.id;
          break;
      }

      if (this.isValidNumber(hallId)) hallIds.push(hallId);
    } catch (error) {
      this.logger.error(
        `Error extracting from ${entity} with ID ${id}: ${error.message}`,
        error.stack,
      );
    }
  }

  private extractFromRequestBody(body: Record<string, any>, hallIds: number[]): void {
    // Array of halls
    if (Array.isArray(body.halls)) {
      body.halls.forEach((item: any) => {
        const hallId = this.extractHallId(item);
        if (this.isValidNumber(hallId)) hallIds.push(hallId);
      });
    }

    // Individual hall or hallId
    if ('hall' in body) this.pushIfValid(body.hall, hallIds);
    if ('hallId' in body) this.pushIfValid(body.hallId, hallIds);
  }

  private extractFromRequestQuery(query: Record<string, any>, hallIds: number[]): void {
    if ('hallId' in query) {
      this.pushIfValid(query.hallId, hallIds);
    }
  }

  private extractFromRequestParam(params: Record<string, any>, hallIds: number[]): void {
    if ('hallId' in params) {
      this.pushIfValid(params.hallId, hallIds);
    }
  }

  private pushIfValid(value: any, hallIds: number[]): void {
    const num = +value;
    if (this.isValidNumber(num)) {
      hallIds.push(num);
    }
  }

  private extractHallId(item: any): number | undefined {
    if (typeof item === 'object' && item !== null && 'id' in item) {
      return +item.id;
    }
    return +item;
  }

  private isValidNumber(value: any): value is number {
    return typeof value === 'number' && !isNaN(value);
  }
}
