import { Module } from '@nestjs/common';
import { FileUploadModule } from './utilities/file-upload/file-upload.module';

@Module({
  imports: [FileUploadModule],
  exports: [],
})
export class SharedModule {}
