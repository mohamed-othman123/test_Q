import { UserTypesEnum } from '../../modules/users/enums/users-type.enum';
import { PermissionTypeEnum } from '../../auth/permissions/enums/permissions-type.Enum';

export interface AuthenticatedUser {
  id: number;
  
  name: string;

  email: string;

  clientId: number;

  type: UserTypesEnum;

  permissionType: PermissionTypeEnum;

  halls: number[];


  
}
