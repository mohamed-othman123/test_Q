import {config} from 'dotenv';
config();
/**
 * 
 * @param key Environment variable key
 * @param type Environment variable type: 'string', 'number', 'boolean'
 * @returns Environment variable value of type TEnvValue: string, number, boolean
 */
// Define the custom types TEnv and TEnvValue
type TEnv = 'string' | 'number' | 'boolean'; // Define the possible types for environment variables
type TEnvValue = string | number | boolean; // Define the possible value types for environment variables
export const readEnv = (key: string, type: TEnv = 'string'): TEnvValue => {
  const value = process.env[key];
 
  switch (type) {
    case 'number':
      return parseInt(value, 10);
    case 'boolean':
      return value === 'true';
    default:
      return value;
  }
}
