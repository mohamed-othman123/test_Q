import Decimal from 'decimal.js';
import { createHash, pbkdf2Sync, randomBytes } from 'crypto';
import { readEnv } from './env.helper';
import { compare } from 'bcrypt';
import { UserTypesEnum } from '../../modules/users/enums/users-type.enum';
import { PermissionTypeEnum } from '../../auth/permissions/enums/permissions-type.Enum';
import { ForbiddenException } from '@nestjs/common';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
interface ToNumberOptions {
  default?: number;
  min?: number;
  max?: number;
}

export function toString(value: any): string {
  return value.toString() || '';
}

export function toLowerCase(value: string): string {
  return value.toLowerCase() || '';
}

export function toUrl(path: string, direct = false): string {
  if (path && path.startsWith('http')) return path;
  let host: string = readEnv('APP_HOST') as string;
  if (host.includes('localhost')) {
    host = 'https://test.qaatk.online';
  }

  if (direct) return `${host}/${path}`;
  return `${path}`;
}

export function trim(value: string): string {
  return value.trim();
}

export function toDate(value: string): Date {
  return new Date(value);
}

export function toBoolean(value: string): boolean {
  value = value.toLowerCase();

  return value === 'true' || value === '1' ? true : false;
}

export function toRightNumber(value: string, opts: ToNumberOptions = {}): number {
  let newValue: number = Number.parseInt(value || String(opts.default));

  if (Number.isNaN(newValue)) {
    newValue = opts.default;
  }

  if (opts.min) {
    if (newValue < opts.min) {
      newValue = opts.min;
    }

    if (newValue > opts.max) {
      newValue = opts.max;
    }
  }

  return newValue;
}

export function decimalToString(value: Decimal, decimals = 2): string {
  return value?.toFixed(decimals);
}

export const randStr = (length: number) => {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
};

export const randNum = (length = 1) => {
  let result = '';
  const characters = '0123456789';
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result.toString();
};

// function to ensure that the value is an array if single value is passed
export function ensureArray<T>(value: T | T[]): T[] {
  return Array.isArray(value) ? value : [value];
}

export function getDate(days: string) {
  return new Date(new Date().getTime() + Number(days) * 60 * 60 * 24 * 1000);
}

export function hourToDate(hour: number, date: string): Date {
  const currentDate = new Date(
    Number(date.split('-')[0]),
    Number(date.split('-')[1]) - 1,
    Number(date.split('-')[2]),
  );
  const options = { timeZone: 'Asia/Riyadh' };
  const ksaDate = new Date(currentDate.toLocaleString('en-US', options));

  ksaDate.setHours(hour - 4);
  const mins = Number(String(hour).split('.')[1]);

  ksaDate.setMinutes(30 + mins);

  return ksaDate;
}
export function getDayName(date: string): string {
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const index = new Date(date).getDay();
  return days[index];
}

export function getSHA512Hash(data) {
  const hash = createHash('sha512');
  hash.update(data);
  return hash.digest('hex');
}
export const getFingerPrint = (req) => {
  const userAgent = req.headers['user-agent'];
  return getSHA512Hash(`${req.ip}${userAgent}`);
};

export const hashPassword = async (password: string): Promise<string> => {
  const salt = randomBytes(16).toString('hex');
  const hash = pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
};

export const verifyPasswordHashV1 = async (
  password: string,
  hashedPassword: string,
): Promise<boolean> => {
  return await compare(password, hashedPassword);
};

export const verifyPasswordHashV2 = async (
  password: string,
  hashedPassword: string,
): Promise<boolean> => {
  const [salt, originalHash] = hashedPassword.split(':');
  const hash = pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return hash === originalHash;
};

export const HandelTwoName = (name: string, name_ar: string): string[] => {
  if (name && name_ar) {
    return [name, name_ar];
  } else if (name) {
    return [name, name];
  } else {
    return [name_ar, name_ar];
  }
};

export const checkUserPermissionType = (user: AuthenticatedUser, createdBy: number): void => {
  const { id: userId, type, permissionType } = user;
  if (
    type === UserTypesEnum.employee &&
    permissionType === PermissionTypeEnum.special &&
    userId !== createdBy
  ) {
    throw new ForbiddenException(ErrorKeys.forbidden);
  }
};
