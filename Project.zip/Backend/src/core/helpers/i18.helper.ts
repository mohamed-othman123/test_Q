import { Inject} from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { FastifyRequest } from 'fastify';


export function i18nEntity(obj: any, lang: string): any {
  if (obj) {
    if (Array.isArray(obj)) {
      return obj.map((item) => i18nEntity(item, lang));
    }
    if (typeof obj === 'object' && obj.constructor.name !== 'Date' && obj !== null) {
      const newObj = {};
      Object.keys(obj).forEach((key) => {
        if (obj[key] !== undefined && obj[key] !== null) {
          // Handle name and name_ar specifically
          if (key === 'name') {
            newObj[key] = lang === 'ar' && obj.name_ar ? obj.name_ar : obj.name;
          } else if (key === 'name_ar') {
            // Skip this key, already handled above
          } else {
            newObj[key] = i18nEntity(obj[key], lang);
          }
        } else {
          newObj[key] = obj[key];
        }
      });
      return newObj;
    } else {
      return obj;
    }
  }
  return null; // Return null if obj is falsy
}

export class I18nResponse {
  private lang = 'en';
  constructor(@Inject(REQUEST) req:FastifyRequest ) {
    this.lang = req.headers['accept-language'];

    if (this.lang === null) this.lang = req.query['lang'] as string;
    if (this.lang === null) this.lang = req.query['local'] as string;
    if (!this.lang || this.lang === null) this.lang = 'en';

    // take first two characters from lang without using substr
    this.lang = this.lang.slice(0, 2);
  }

  public entity(obj: any): any {
    return i18nEntity(obj, this.lang);
  }
}
