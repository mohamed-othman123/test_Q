import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ContactUsService } from './contact-us.service';
import { ContactUsController } from './contact-us.controller';
import { MailerAppModule } from '../providers/mailer/mailer.module';

@Module({
  imports: [ConfigModule, MailerAppModule],
  controllers: [ContactUsController],
  providers: [ContactUsService],
})
export class ContactUsModule {}
