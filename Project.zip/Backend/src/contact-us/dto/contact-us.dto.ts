import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsEmail, IsNotEmpty, IsString, Matches } from 'class-validator';
import { ErrorKeys } from 'src/common/enums/errorKeys.enums';

export class ContactUsDto {
  @ApiProperty({
    description: 'User name',
    example: 'John Doe',
  })
  @IsNotEmpty({ message: ErrorKeys.nameIsRequired })
  @IsString({ message: ErrorKeys.nameMustBeString })
  name: string;

  @ApiProperty({
    description: 'User email',
    example: 'user@gmail.com',
  })
  @IsNotEmpty({ message: ErrorKeys.emailIsRequired })
  @IsEmail({}, { message: ErrorKeys.emailInvalid })
  @Transform(({ value }) => value?.toLowerCase())
  email: string;

  @ApiProperty({
    description: 'User phone number',
    example: '+966 555555555',
  })
  @IsNotEmpty({ message: ErrorKeys.phoneIsRequired })
  @IsString({
    message: ErrorKeys.phoneMustBeString,
  })
  @Matches(/^\+(\d{1,3})\s?(\d{7,15})$/, { message: ErrorKeys.phoneInvaild })
  @Transform(({ value }) => value?.replace(/ /g, ''))
  phoneNumber: string;

  @ApiProperty({
    description: 'User message',
    example: 'I would like to inquire about your services.',
  })
  @IsNotEmpty({ message: ErrorKeys.messageIsRequired })
  @IsString({ message: ErrorKeys.messageMustBeString })
  message: string;
}
