import { Injectable } from '@nestjs/common';
import { ContactUsDto } from './dto/contact-us.dto';
import { MailService } from '../providers/mailer/mail.service';
import { LanguagesEnum } from '../common/enums/lang.enum';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class ContactUsService {
  private readonly adminEmails: string[] = [];
  private readonly defaultEmails: string[] = ['sales@qaatk.online', 'matrix2526@gmail.com'];

  constructor(
    private readonly mailService: MailService,
    private configService: ConfigService,
  ) {
    const emails: string = this.configService.get('CONTACT_US_EMAILS');

    if (emails && emails !== undefined) {
      this.adminEmails = emails?.split(',')?.map((email) => email.trim());
    }

    if (this.adminEmails?.length === 0) {
      this.adminEmails = this.defaultEmails;
    }
  }

  async sendEmail(contactData: ContactUsDto, lang: LanguagesEnum): Promise<void> {
    // Send notification to admin emails
    await this.sendAdminNotification(contactData, lang);

    // Send thank you email to the customer
    await this.sendThankYouEmail(contactData, lang);
  }

  private async sendAdminNotification(contactData: ContactUsDto, lang: string): Promise<void> {
    const subject = lang === 'ar' ? 'استلام نموذج تواصل جديد' : 'New Contact Form Submission';
    this.mailService.sendEmail(this.adminEmails, subject, `contact-us-notify-${lang}`, {
      name: contactData.name,
      email: contactData.email,
      phoneNumber: contactData.phoneNumber,
      message: contactData.message,
    });
  }

  private async sendThankYouEmail(contactData: ContactUsDto, lang: string): Promise<void> {
    const subject = lang === 'ar' ? 'شكرًا لتواصلك معنا' : 'Thank You for Contacting Us';
    this.mailService.sendEmail([contactData.email], subject, `contact-us-thank-you-${lang}`, {
      name: contactData.name,
    });
  }
}
