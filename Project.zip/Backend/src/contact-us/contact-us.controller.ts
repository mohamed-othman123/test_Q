import { Body, Controller, HttpStatus, Post } from '@nestjs/common';
import { ContactUsDto } from './dto/contact-us.dto';
import { ContactUsService } from './contact-us.service';
import { Public } from '../auth/decorator/public.decorator';
import { Language } from '../common/decorators/languages-headers.decorator';
import { LanguagesEnum } from '../common/enums/lang.enum';
import { ApiHeader, ApiTags } from '@nestjs/swagger';

@ApiTags('contact-us')
@Controller('contact-us')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class ContactUsController {
  constructor(private readonly contactUsService: ContactUsService) {}

  @Public()
  @Post()
  async submitContactForm(@Body() contactDto: ContactUsDto, @Language() lang: LanguagesEnum) {
    await this.contactUsService.sendEmail(contactDto, lang);
    return {
      statusCode: HttpStatus.OK,
      message: 'Your message has been sent successfully.',
    };
  }
}
