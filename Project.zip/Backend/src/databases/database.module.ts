// src/database/database.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigService } from '@nestjs/config';
import { TypeOrmModuleOptions } from '@nestjs/typeorm';

@Module({
  imports: [
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService): TypeOrmModuleOptions => ({
        type: 'postgres',
        host: config.get('DATABASE_HOST'),
        port: +config.get('DATABASE_PORT'), // Ensure port is a number
        username: config.get('DATABASE_USERNAME'),
        password: config.get('DATABASE_PASSWORD'),
        database: config.get('DATABASE_NAME'),
        autoLoadEntities: true,
        entities: [
          __dirname + '/../**/*.entity{.ts,.js}', // For standard entities
          __dirname + '/../**/*.view{.ts,.js}',   // For view entities
        ],
        migrations: [__dirname + '/migrations/*{.ts,.js}'],
        poolSize: 30,
        synchronize: false,
        logging: true,
        logNotifications: true,
        useUTC: true,
        migrationsRun: true,
      }),
    }),
  ],
})
export class DatabaseModule {}