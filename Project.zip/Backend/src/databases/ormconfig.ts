import { join } from 'path';
import { config as configEnv } from 'dotenv';
import { DataSource, DataSourceOptions } from 'typeorm';
import { globSync } from 'glob';


// Load environment variables
const envFile = join(process.cwd(), `src/config/environments/.${process.env.NODE_ENV}.env`);
configEnv({ path: envFile });

// Find all entity and view files
const files = globSync('src/**/*.entity{.ts,.js}').concat(globSync('src/**/*.view{.ts,.js}'));

const config: DataSourceOptions = {
  type: 'postgres',
  host: process.env.DATABASE_HOST,
  port: parseInt(process.env.DATABASE_PORT, 10),
  username: process.env.DATABASE_USERNAME,
  password: process.env.DATABASE_PASSWORD,
  database: process.env.DATABASE_NAME,
  entities: files,
  synchronize: false,
  migrationsRun: false,
  logging: true,
  migrations: [__dirname + '/migrations/*{.ts,.js}'],
  migrationsTableName: 'migrations',
};

export default new DataSource(config);