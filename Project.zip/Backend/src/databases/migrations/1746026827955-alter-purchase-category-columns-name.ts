import { MigrationInterface, QueryRunner } from 'typeorm';

export class AlterPurchaseCategoryColumnsName1746026827955 implements MigrationInterface {
  name = 'AlterPurchaseCategoryColumnsName1746026827955';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "purchase_categories" 
            RENAME COLUMN "enName" TO "name"
        `);

    await queryRunner.query(`
            ALTER TABLE "purchase_categories" 
            RENAME COLUMN "arName" TO "name_ar"
        `);

    await queryRunner.query(`
            ALTER TABLE "purchase_categories" 
            RENAME COLUMN "enDescription" TO "description"
        `);

    await queryRunner.query(`
            ALTER TABLE "purchase_categories" 
            DROP COLUMN "arDescription"
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
    ALTER TABLE "purchase_categories" 
    ADD COLUMN "arDescription" character varying
    `);

    await queryRunner.query(`
    ALTER TABLE "purchase_categories" 
    RENAME COLUMN "name" TO "enName"
    `);

    await queryRunner.query(`
    ALTER TABLE "purchase_categories" 
    RENAME COLUMN "name_ar" TO "arName"
    `);

    await queryRunner.query(`
    ALTER TABLE "purchase_categories" 
    RENAME COLUMN "description" TO "enDescription"
    `);
  }
}
