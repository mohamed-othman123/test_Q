import { MigrationInterface, QueryRunner } from 'typeorm';

export class ExpensesItemsDetails1746584778843 implements MigrationInterface {
  name = 'ExpensesItemsDetails1746584778843';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "expenses_details" DROP CONSTRAINT "FK_607211d59b13e705a673a999ab5"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses" DROP CONSTRAINT "FK_090c478af5eec653f0f0ce221d9"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses" DROP CONSTRAINT "FK_b1f12b00beaf809f3e37a9986be"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses" DROP CONSTRAINT "FK_d5fec047f705d5b510c19379b95"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses" DROP CONSTRAINT "FK_f9fcf50d684949f62c2cd07296e"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses" DROP CONSTRAINT "FK_8a4156ba6d7bc8d0ca55f4b2b93"`,
    );
    await queryRunner.query(`ALTER TABLE "expenses_details" Rename  "purchase_id" to "expense_id"`);
    await queryRunner.query(`ALTER TABLE "expenses_details" Rename  "price" to "value"`);
    await queryRunner.query(`ALTER TABLE "expenses_details" ADD "name_ar" character varying `);
    await queryRunner.query(`ALTER TABLE "expenses_details" ADD "type" character varying `);

    await queryRunner.query(`ALTER TABLE "expenses" ADD "expense_item_id" integer`);

    await queryRunner.query(
      `ALTER TABLE "expenses_details" ADD CONSTRAINT "FK_9cc4e7aef02642c631b9340bd8e" FOREIGN KEY ("expense_id") REFERENCES "expenses"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );

    await queryRunner.query(
      `ALTER TABLE "expenses" ADD CONSTRAINT "FK_a30707018a9722e9551db12ea8a" FOREIGN KEY ("supplier_id") REFERENCES "suppliers"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses" ADD CONSTRAINT "FK_9ce602598d4acb703ef2a3914b3" FOREIGN KEY ("expense_item_id") REFERENCES "expense_items"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses" ADD CONSTRAINT "FK_48f8d1f4d8a1b91e7cf6991d7f5" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses" ADD CONSTRAINT "FK_5761adee29a8e328e2aa57ce302" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses" ADD CONSTRAINT "FK_5d1f4be708e0dfe2afa1a3c376c" FOREIGN KEY ("category_id") REFERENCES "purchase_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses" ADD CONSTRAINT "FK_5d7c269fde134f3084604d8fcf9" FOREIGN KEY ("settlement_pdf_id") REFERENCES "document_pdf"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
