import { MigrationInterface, QueryRunner } from "typeorm";

export class RemoveBeneficiaryColumnsFromPaymentEntity1751102780819 implements MigrationInterface {
    name = 'RemoveBeneficiaryColumnsFromPaymentEntity1751102780819'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "beneficiary_name"`);
        await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "beneficiary_mobile"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payments" ADD "beneficiary_mobile" text`);
        await queryRunner.query(`ALTER TABLE "payments" ADD "beneficiary_name" text`);
    }

}
