import { MigrationInterface, QueryRunner } from 'typeorm';

export class VectorStore1756113794948 implements MigrationInterface {
  name = 'VectoreStoe1756113794948';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "ai_schemas" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "tableName" character varying(100) NOT NULL, "description" text NOT NULL, "embedding" text, "isActive" boolean NOT NULL DEFAULT true, "metadata" jsonb, CONSTRAINT "PK_f7b8c6b76db6e1310b5473322ba" PRIMARY KEY ("id"))`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
