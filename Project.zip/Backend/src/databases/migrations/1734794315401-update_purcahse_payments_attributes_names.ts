import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdatePurcahsePaymentsAttributesNames1734794315401 implements MigrationInterface {
  name = 'UpdatePurcahsePaymentsAttributesNames1734794315401';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "paid_amount"`);
    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "type"`);
    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "note"`);
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD "amount" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD "paymentType" character varying NOT NULL DEFAULT 'Income'`,
    );
    await queryRunner.query(`ALTER TABLE "purchase_payments" ADD "notes" character varying`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "notes"`);
    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "paymentType"`);
    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "amount"`);
    await queryRunner.query(`ALTER TABLE "purchase_payments" ADD "note" character varying`);
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD "type" character varying NOT NULL`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD "paid_amount" numeric(10,2) NOT NULL`,
    );
  }
}
