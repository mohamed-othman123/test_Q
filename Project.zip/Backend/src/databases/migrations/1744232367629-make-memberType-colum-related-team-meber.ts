import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeMemberTypeColumRelatedTeamMeber1744232367629 implements MigrationInterface {
    name = 'MakeMemberTypeColumRelatedTeamMeber1744232367629'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "teamMembersType"`);
        await queryRunner.query(`DROP TYPE "public"."halls_teammemberstype_enum"`);
        await queryRunner.query(`CREATE TYPE "public"."hall_team_members_membertype_enum" AS ENUM('employee', 'thirdParty')`);
        await queryRunner.query(`ALTER TABLE "hall_team_members" ADD "memberType" "public"."hall_team_members_membertype_enum" NOT NULL DEFAULT 'thirdParty'`);
        await queryRunner.query(`ALTER TABLE "hall_team_members" ADD "moderatorId" integer`);
        await queryRunner.query(`ALTER TABLE "hall_team_members" ALTER COLUMN "name" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_team_members" ALTER COLUMN "email" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_team_members" ADD CONSTRAINT "FK_e206d3726a21039f65d8fc1e803" FOREIGN KEY ("moderatorId") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_team_members" DROP CONSTRAINT "FK_e206d3726a21039f65d8fc1e803"`);
        await queryRunner.query(`ALTER TABLE "hall_team_members" ALTER COLUMN "email" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_team_members" ALTER COLUMN "name" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_team_members" DROP COLUMN "moderatorId"`);
        await queryRunner.query(`ALTER TABLE "hall_team_members" DROP COLUMN "memberType"`);
        await queryRunner.query(`DROP TYPE "public"."hall_team_members_membertype_enum"`);
        await queryRunner.query(`CREATE TYPE "public"."halls_teammemberstype_enum" AS ENUM('employee', 'thirdParty')`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "teamMembersType" "public"."halls_teammemberstype_enum"`);
    }

}
