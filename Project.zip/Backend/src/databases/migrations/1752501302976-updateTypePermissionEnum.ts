import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateTypePermissionEnum1752501302976 implements MigrationInterface {
  name = 'UpdateTypePermissionEnum1752501302976';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "role_permissions" DROP CONSTRAINT "FK_17022daf3f885f7d35423e9971e"`,
    );
    // Remove references in role_permissions where type is 'READONE'
    await queryRunner.query(`
        DELETE FROM "role_permissions"
        WHERE "permission_id" IN (
          SELECT "id" FROM "permission" WHERE "type" = 'READONE'
        )
      `);

    // Now delete permissions where type is 'READONE'
    await queryRunner.query(`
        DELETE FROM "permission"
        WHERE "type" = 'READONE'
      `);

    await queryRunner.query(
      `ALTER TYPE "public"."permission_type_enum" RENAME TO "permission_type_enum_old"`,
    );
    await queryRunner.query(
      `CREATE TYPE "public"."permission_type_enum" AS ENUM('CREATE', 'READ', 'UPDATE', 'DELETE')`,
    );
    await queryRunner.query(
      `ALTER TABLE "permission" ALTER COLUMN "type" TYPE "public"."permission_type_enum" USING "type"::"text"::"public"."permission_type_enum"`,
    );
    await queryRunner.query(`DROP TYPE "public"."permission_type_enum_old"`);
    await queryRunner.query(
      `ALTER TABLE "role_permissions" ADD CONSTRAINT "FK_17022daf3f885f7d35423e9971e" FOREIGN KEY ("permission_id") REFERENCES "permission"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "role_permissions" DROP CONSTRAINT "FK_17022daf3f885f7d35423e9971e"`,
    );
    await queryRunner.query(
      `CREATE TYPE "public"."permission_type_enum_old" AS ENUM('CREATE', 'READ', 'READONE', 'UPDATE', 'DELETE')`,
    );
    await queryRunner.query(
      `ALTER TABLE "permission" ALTER COLUMN "type" TYPE "public"."permission_type_enum_old" USING "type"::"text"::"public"."permission_type_enum_old"`,
    );
    await queryRunner.query(`DROP TYPE "public"."permission_type_enum"`);
    await queryRunner.query(
      `ALTER TYPE "public"."permission_type_enum_old" RENAME TO "permission_type_enum"`,
    );
    await queryRunner.query(
      `ALTER TABLE "role_permissions" ADD CONSTRAINT "FK_17022daf3f885f7d35423e9971e" FOREIGN KEY ("permission_id") REFERENCES "permission"("id") ON DELETE CASCADE ON UPDATE NO ACTION`,
    );
  }
}
