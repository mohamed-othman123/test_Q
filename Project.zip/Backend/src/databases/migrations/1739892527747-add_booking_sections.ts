import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddBookingSections1739892527747 implements MigrationInterface {
  name = 'AddBookingSections1739892527747';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "booking_hall_sections" ("booking_id" integer NOT NULL, "section_id" integer NOT NULL, CONSTRAINT "PK_74e94e4255a179bea10da0b18f1" PRIMARY KEY ("booking_id", "section_id"))`,
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_327c12804b1f229697d87d1b99" ON "booking_hall_sections" ("booking_id") `,
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_225f35e801f9e55f80dbc30d32" ON "booking_hall_sections" ("section_id") `,
    );

    await queryRunner.query(
      `ALTER TABLE "booking_hall_sections" ADD CONSTRAINT "FK_327c12804b1f229697d87d1b992" FOREIGN KEY ("booking_id") REFERENCES "booking"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "booking_hall_sections" ADD CONSTRAINT "FK_225f35e801f9e55f80dbc30d329" FOREIGN KEY ("section_id") REFERENCES "hall_sections"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking_hall_sections" DROP CONSTRAINT "FK_225f35e801f9e55f80dbc30d329"`,
    );
    await queryRunner.query(
      `ALTER TABLE "booking_hall_sections" DROP CONSTRAINT "FK_327c12804b1f229697d87d1b992"`,
    );
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "end_date" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "start_date" DROP NOT NULL`);
    await queryRunner.query(`DROP INDEX "public"."IDX_225f35e801f9e55f80dbc30d32"`);
    await queryRunner.query(`DROP INDEX "public"."IDX_327c12804b1f229697d87d1b99"`);
    await queryRunner.query(`DROP TABLE "booking_hall_sections"`);
  }
}
