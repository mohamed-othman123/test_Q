import { MigrationInterface, QueryRunner } from 'typeorm';

export class PriceRequestStatus1736977958345 implements MigrationInterface {
  name = 'PriceRequestStatus1736977958345';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking_price_requests" ADD "status" character varying NOT NULL DEFAULT 'New'`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking_price_requests" DROP COLUMN "status"`);
  }
}
