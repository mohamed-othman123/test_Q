import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingInsuranceAmount1732142281659 implements MigrationInterface {
  name = 'BookingInsuranceAmount1732142281659';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" ADD "insurance_amount" integer default 0`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "insurance_amount"`);
  }
}
