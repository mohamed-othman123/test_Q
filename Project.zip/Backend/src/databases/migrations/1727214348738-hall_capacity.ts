import { MigrationInterface, QueryRunner } from 'typeorm';

export class HallCapacity1727214348738 implements MigrationInterface {
  name = 'HallCapacity1727214348738';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "capacity"`);
    await queryRunner.query(`ALTER TABLE "halls" ADD "mensCapacity" integer`);
    await queryRunner.query(`ALTER TABLE "halls" ADD "womensCapacity" integer`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "womensCapacity"`);
    await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "mensCapacity"`);
    await queryRunner.query(`ALTER TABLE "halls" ADD "capacity" integer`);
  }
}
