import { MigrationInterface, QueryRunner } from "typeorm";

export class AddFirstPartyNameInContractTable1743999196585 implements MigrationInterface {
    name = 'AddFirstPartyNameInContractTable1743999196585'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "title_en"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "title_ar"`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "firstPartyName" character varying(255)`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "firstPartyName"`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "title_ar" character varying`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "title_en" character varying`);
    }

}
