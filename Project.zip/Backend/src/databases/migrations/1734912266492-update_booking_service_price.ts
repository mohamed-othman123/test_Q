import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateBookingServicePrice1734912266492 implements MigrationInterface {
  name = 'UpdateBookingServicePrice1734912266492';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking_services" DROP COLUMN "servicePrice"`);
    await queryRunner.query(
      `ALTER TABLE "booking_services" ADD "servicePrice" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking_services" DROP COLUMN "servicePrice"`);
    await queryRunner.query(`ALTER TABLE "booking_services" ADD "servicePrice" integer NOT NULL`);
  }
}
