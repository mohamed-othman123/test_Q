import { MigrationInterface, QueryRunner } from 'typeorm';

export class CalenderView1735175495373 implements MigrationInterface {
  name = 'CalenderView1735175495373';

  public async up(queryRunner: QueryRunner): Promise<void> {
//     await queryRunner.query(`CREATE VIEW "calender_view" AS 
// SELECT
//   b.hall_id,
//   b.booking_date,
//   EXTRACT(
//     YEAR
//     FROM
//       b.booking_date
//   )::INTEGER AS booking_year,
//   EXTRACT(
//     MONTH
//     FROM
//       b.booking_date
//   )::INTEGER AS booking_month,
//    EXTRACT(
//     Day
//     FROM
//       b.booking_date
//   )::INTEGER AS booking_day
// FROM
//   booking b
// WHERE
//   b."bookingProcessStatus" != 'Canceled'
//   `);
//     await queryRunner.query(
//       `INSERT INTO "typeorm_metadata"("database", "schema", "table", "type", "name", "value") VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)`,
//       [
//         'public',
//         'VIEW',
//         'calender_view',
//         'SELECT\n  b.hall_id,\n  b.booking_date,\n  EXTRACT(\n    YEAR\n    FROM\n      b.booking_date\n  )::INTEGER AS booking_year,\n  EXTRACT(\n    MONTH\n    FROM\n      b.booking_date\n  )::INTEGER AS booking_month,\n   EXTRACT(\n    Day\n    FROM\n      b.booking_date\n  )::INTEGER AS booking_day\nFROM\n  booking b\nWHERE\n  b."bookingProcessStatus" != \'Canceled\'',
//       ],
//     );
  }
  public async down(queryRunner: QueryRunner): Promise<void> {
  //   await queryRunner.query(
  //     `DELETE FROM "typeorm_metadata" WHERE "type" = $1 AND "name" = $2 AND "schema" = $3`,
  //     ['VIEW', 'calender_view', 'public'],
  //   );
  //   await queryRunner.query(`DROP VIEW "calender_view"`);
  }
}
