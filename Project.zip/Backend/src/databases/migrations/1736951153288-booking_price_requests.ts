import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingPriceRequests1736951153288 implements MigrationInterface {
  name = 'BookingPriceRequests1736951153288';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "booking_price_requests" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying NOT NULL, "email" character varying, "phone_number" character varying NOT NULL, "event_name" character varying NOT NULL, "event_date" TIMESTAMP NOT NULL, "event_hijri_date" character varying(20), "is_flexible_date" boolean NOT NULL DEFAULT false, "message" text, "hall_id" integer NOT NULL, "client_id" integer NOT NULL, CONSTRAINT "PK_0df86a65fca007d88b203e05a47" PRIMARY KEY ("id"))`,
    );

    await queryRunner.query(
      `ALTER TABLE "booking_price_requests" ADD CONSTRAINT "FK_d0d6341a27c98767ae9a898e61c" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "booking_price_requests" ADD CONSTRAINT "FK_1bd44eed94fcd71ccc2b638daaa" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking_price_requests" DROP CONSTRAINT "FK_1bd44eed94fcd71ccc2b638daaa"`,
    );
    await queryRunner.query(
      `ALTER TABLE "booking_price_requests" DROP CONSTRAINT "FK_d0d6341a27c98767ae9a898e61c"`,
    );

    await queryRunner.query(`DROP TABLE "booking_price_requests"`);
  }
}
