import { MigrationInterface, QueryRunner } from 'typeorm';

export class NameArAtSections1744592028372 implements MigrationInterface {
  name = 'NameArAtSections1744592028372';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "hall_sections" ADD "name_ar" character varying(255)`);
    await queryRunner.query(`ALTER TABLE "hall_sections" ALTER COLUMN "name" DROP NOT NULL`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "hall_sections" ALTER COLUMN "name" SET NOT NULL`);
    await queryRunner.query(`ALTER TABLE "hall_sections" DROP COLUMN "name_ar"`);
  }
}
