import { MigrationInterface, QueryRunner } from 'typeorm';

export class AlterUserTableAddRoleIdcolumn1720468723127 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" ADD "role_id"  integer`);
    await queryRunner.query(
      `ALTER TABLE "users" ADD CONSTRAINT "FK_8e3b9b5b2c2d7b6f3e3e4b3e1b4" FOREIGN KEY ("role_id") REFERENCES "role"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "role_id"`);
    await queryRunner.query(`ALTER TABLE "users" DROP CONSTRAINT "FK_8e3b9b5b2c2d7b6f3e3e4b3e1b4"`);
  }
}
