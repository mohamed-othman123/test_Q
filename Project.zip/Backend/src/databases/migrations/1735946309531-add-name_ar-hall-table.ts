import { MigrationInterface, QueryRunner } from "typeorm";

export class AddNameArHallTable1735946309531 implements MigrationInterface {
    name = 'AddNameArHallTable1735946309531'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" ADD "name_ar" character varying(255) NOT NULL DEFAULT ''`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "name_ar"`);
    }

}
