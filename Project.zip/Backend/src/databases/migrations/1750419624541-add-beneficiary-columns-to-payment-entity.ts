import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddBeneficiaryColumnsToPaymentEntity1750419624541 implements MigrationInterface {
  name = 'AddBeneficiaryColumnsToPaymentEntity1750419624541';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TYPE "public"."beneficiary_type_enum" AS ENUM('customer', 'other')`,
    );
    await queryRunner.query(
      `ALTER TABLE "payments" ADD "beneficiary_type" "public"."beneficiary_type_enum" NOT NULL DEFAULT 'customer'`,
    );
    await queryRunner.query(`ALTER TABLE "payments" ADD "beneficiary_name" text`);
    await queryRunner.query(`ALTER TABLE "payments" ADD "beneficiary_mobile" text`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "beneficiary_mobile"`);
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "beneficiary_name"`);
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "beneficiary_type"`);
  }
}
