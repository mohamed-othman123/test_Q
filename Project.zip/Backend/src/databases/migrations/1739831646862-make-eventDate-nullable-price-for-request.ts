import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeEventDateNullablePriceForRequest1739831646862 implements MigrationInterface {
    name = 'MakeEventDateNullablePriceForRequest1739831646862'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "booking_price_requests" ALTER COLUMN "event_date" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "booking_price_requests" ALTER COLUMN "event_date" SET NOT NULL`);
    }

}
