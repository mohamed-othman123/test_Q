import { MigrationInterface, QueryRunner } from "typeorm";

export class RemoveBeneficiaryColumnsFromRefundRequests1751101796686 implements MigrationInterface {
    name = 'RemoveBeneficiaryColumnsFromRefundRequests1751101796686'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "refund_requests" DROP COLUMN "beneficiary_name"`);
        await queryRunner.query(`ALTER TABLE "refund_requests" DROP COLUMN "beneficiary_mobile"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "refund_requests" ADD "beneficiary_mobile" text`);
        await queryRunner.query(`ALTER TABLE "refund_requests" ADD "beneficiary_name" text`);
    }

}
