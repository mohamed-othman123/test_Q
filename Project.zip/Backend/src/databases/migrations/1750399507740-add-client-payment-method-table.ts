import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddClientPaymentMethodTable1750399507740 implements MigrationInterface {
  name = 'AddClientPaymentMethodTable1750399507740';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TYPE "public"."client_payment_methods_type_enum" AS ENUM('bankAccount', 'eWallet', 'pos', 'cash')`,
    );
    await queryRunner.query(
      `CREATE TABLE "client_payment_methods" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "type" "public"."client_payment_methods_type_enum" NOT NULL, "receiver_name" character varying, "bank_name" character varying, "account_number" character varying, "iban" character varying, "ewallet_name" character varying, "ewallet_mobile" character varying, CONSTRAINT "PK_b131aaf0097a3b931485c3a9c00" PRIMARY KEY ("id"))`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "client_payment_methods"`);
    await queryRunner.query(`DROP TYPE "public"."client_payment_methods_type_enum"`);
  }
}
