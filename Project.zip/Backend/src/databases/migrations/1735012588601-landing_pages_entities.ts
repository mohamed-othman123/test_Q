import { MigrationInterface, QueryRunner } from 'typeorm';

export class LandingPagesEntities1735012588601 implements MigrationInterface {
  name = 'LandingPagesEntities1735012588601';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "landing_popular_questions" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "question" text NOT NULL, "answer" text NOT NULL, "order" integer, "landing_page_id" integer NOT NULL, CONSTRAINT "PK_0f4926766098422f327a78a0fb7" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "landing_features" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "icon" text, "title" character varying NOT NULL, "description" text NOT NULL, "order" integer, "landing_page_id" integer NOT NULL, CONSTRAINT "PK_e47bb6bd2cb13467b1ab5498c76" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "landing_banners" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "path" text NOT NULL, "order" integer, "mimetype" character varying NOT NULL, "landing_page_id" integer NOT NULL, CONSTRAINT "PK_c55235e52c184a11939221592cc" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "landing_images" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "path" text NOT NULL, "mimetype" character varying NOT NULL, "order" integer, "landing_page_id" integer NOT NULL, CONSTRAINT "PK_9bc7c003446ebe33c76b227bda4" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "hall_landing_pages" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "hall_name" character varying NOT NULL, "email" character varying NOT NULL, "phone" character varying NOT NULL, "about" text, "location" character varying, "mapLocation" jsonb, "services" text, "client_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "PK_4067cdc2fab92c31793b5efa56c" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "landing_social_Links" ("landing_page_id" integer NOT NULL, "facebook" character varying, "instagram" character varying, "x" character varying, "snapChat" character varying, "tiktok" character varying, "whatsApp" character varying, "websiteLink" character varying, CONSTRAINT "PK_ca36df0526daec4a0706c93e557" PRIMARY KEY ("landing_page_id"))`,
    );

    await queryRunner.query(
      `ALTER TABLE "landing_popular_questions" ADD CONSTRAINT "FK_67dd08426f9104167001f37b193" FOREIGN KEY ("landing_page_id") REFERENCES "hall_landing_pages"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "landing_features" ADD CONSTRAINT "FK_180140b4daeba254a869b4d3f7b" FOREIGN KEY ("landing_page_id") REFERENCES "hall_landing_pages"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "landing_banners" ADD CONSTRAINT "FK_b020fb4c4d5424b74fed68f9e4f" FOREIGN KEY ("landing_page_id") REFERENCES "hall_landing_pages"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "landing_images" ADD CONSTRAINT "FK_908a1511da280bd0e7de4933f1a" FOREIGN KEY ("landing_page_id") REFERENCES "hall_landing_pages"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "hall_landing_pages" ADD CONSTRAINT "FK_f870ba265b1e512263966174466" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "hall_landing_pages" ADD CONSTRAINT "FK_42300935e46a635b87b7be531c1" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "landing_social_Links" ADD CONSTRAINT "FK_ca36df0526daec4a0706c93e557" FOREIGN KEY ("landing_page_id") REFERENCES "hall_landing_pages"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "landing_social_Links" DROP CONSTRAINT "FK_ca36df0526daec4a0706c93e557"`,
    );
    await queryRunner.query(
      `ALTER TABLE "hall_landing_pages" DROP CONSTRAINT "FK_42300935e46a635b87b7be531c1"`,
    );
    await queryRunner.query(
      `ALTER TABLE "hall_landing_pages" DROP CONSTRAINT "FK_f870ba265b1e512263966174466"`,
    );
    await queryRunner.query(
      `ALTER TABLE "landing_images" DROP CONSTRAINT "FK_908a1511da280bd0e7de4933f1a"`,
    );
    await queryRunner.query(
      `ALTER TABLE "landing_banners" DROP CONSTRAINT "FK_b020fb4c4d5424b74fed68f9e4f"`,
    );
    await queryRunner.query(
      `ALTER TABLE "landing_features" DROP CONSTRAINT "FK_180140b4daeba254a869b4d3f7b"`,
    );
    await queryRunner.query(
      `ALTER TABLE "landing_popular_questions" DROP CONSTRAINT "FK_67dd08426f9104167001f37b193"`,
    );
    await queryRunner.query(`DROP TABLE "landing_social_Links"`);
    await queryRunner.query(`DROP TABLE "hall_landing_pages"`);
    await queryRunner.query(`DROP TABLE "landing_images"`);
    await queryRunner.query(`DROP TABLE "landing_banners"`);
    await queryRunner.query(`DROP TABLE "landing_features"`);
    await queryRunner.query(`DROP TABLE "landing_popular_questions"`);
  }
}
