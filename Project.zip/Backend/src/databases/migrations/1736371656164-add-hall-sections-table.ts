import { MigrationInterface, QueryRunner } from "typeorm";

export class AddHallSectionsTable1736371656164 implements MigrationInterface {
    name = 'AddHallSectionsTable1736371656164'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "hall_sections" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying(255) NOT NULL, "capacity" integer NOT NULL, "hallId" integer, CONSTRAINT "PK_aee4b958b6bf5935cf0081214e4" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "hall_sections" ADD CONSTRAINT "FK_9d8751e3bb8e6a88dbcc58dd4f7" FOREIGN KEY ("hallId") REFERENCES "halls"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_sections" DROP CONSTRAINT "FK_9d8751e3bb8e6a88dbcc58dd4f7"`);
        await queryRunner.query(`DROP TABLE "hall_sections"`);
    }

}
