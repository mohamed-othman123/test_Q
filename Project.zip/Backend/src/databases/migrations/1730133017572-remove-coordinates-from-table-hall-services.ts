import { MigrationInterface, QueryRunner } from "typeorm";

export class RemoveCoordinatesFromTableHallServices1730133017572 implements MigrationInterface {
    name = 'RemoveCoordinatesFromTableHallServices1730133017572'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "maleCoordinatorsNo"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "femaleCoordinatorsNo"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "femaleCoordinatorsNo" integer`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "maleCoordinatorsNo" integer`);
    }

}
