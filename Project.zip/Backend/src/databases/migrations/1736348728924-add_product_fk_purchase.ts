import { MigrationInterface, QueryRunner } from "typeorm";

export class AddProductFkPurchase1736348728924 implements MigrationInterface {
    name = 'AddProductFkPurchase1736348728924'

    public async up(queryRunner: QueryRunner): Promise<void> {
      
        await queryRunner.query(`ALTER TABLE "purchase_items" ADD "product_id" integer`);
        await queryRunner.query(`ALTER TABLE "purchase_items" ADD CONSTRAINT "FK_43694b2fa800ce38d2da9ce74d6" FOREIGN KEY ("product_id") REFERENCES "supplier_products"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "purchase_items" DROP CONSTRAINT "FK_43694b2fa800ce38d2da9ce74d6"`);
        await queryRunner.query(`ALTER TABLE "purchase_items" DROP COLUMN "product_id"`);
       
    }

}
