import { MigrationInterface, QueryRunner } from "typeorm";

export class AddHallEmployeeTeamMemberTable1744127499232 implements MigrationInterface {
    name = 'AddHallEmployeeTeamMemberTable1744127499232'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "halls_employee_team_member" ("id" SERIAL NOT NULL, "employee_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "PK_1c41f780acbac40ef52195a85e0" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "hall_team_members" ADD "phone" character varying(255)`);
        await queryRunner.query(`CREATE TYPE "public"."halls_teammemberstype_enum" AS ENUM('employee', 'thirdParty')`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "teamMembersType" "public"."halls_teammemberstype_enum"`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "sendingTime" character varying DEFAULT '12:00 AM'`);
        await queryRunner.query(`ALTER TABLE "halls_employee_team_member" ADD CONSTRAINT "FK_aa6d37baa119bb5d63fd48003d1" FOREIGN KEY ("employee_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "halls_employee_team_member" ADD CONSTRAINT "FK_f051e525e72d08343861668376d" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_employee_team_member" DROP CONSTRAINT "FK_f051e525e72d08343861668376d"`);
        await queryRunner.query(`ALTER TABLE "halls_employee_team_member" DROP CONSTRAINT "FK_aa6d37baa119bb5d63fd48003d1"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "sendingTime"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "teamMembersType"`);
        await queryRunner.query(`DROP TYPE "public"."halls_teammemberstype_enum"`);
        await queryRunner.query(`ALTER TABLE "hall_team_members" DROP COLUMN "phone"`);
        await queryRunner.query(`DROP TABLE "halls_employee_team_member"`);
    }

}
