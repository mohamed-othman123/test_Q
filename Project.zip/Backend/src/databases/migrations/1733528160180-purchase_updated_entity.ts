import { MigrationInterface, QueryRunner } from 'typeorm';

export class PurchaseUpdatedEntity1733528160180 implements MigrationInterface {
  name = 'PurchaseUpdatedEntity1733528160180';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "paidAmount"`);
    await queryRunner.query(
      `ALTER TABLE "purchases" ADD "invoiceType" character varying NOT NULL DEFAULT 'Tax Invoice'`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchases" ADD "subtotal" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchases" ADD "discount_type" character varying NOT NULL DEFAULT 'fixed'`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchases" ADD "discount_value" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchases" ADD "subtotal_after_disc" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "purchases" ADD "vat" numeric(10,2) NOT NULL DEFAULT '0'`);
    await queryRunner.query(
      `ALTER TABLE "purchases" ADD "totalPayable" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "purchases" ADD "hall_id" integer NOT NULL`);
    await queryRunner.query(
      `ALTER TABLE "purchases" ALTER COLUMN "invoiceReference" DROP NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "purchases" ALTER COLUMN "status" SET DEFAULT 'New'`);
    await queryRunner.query(`ALTER TABLE "purchases" ALTER COLUMN "delivery_date" DROP NOT NULL`);
    await queryRunner.query(
      `ALTER TABLE "purchases" ADD CONSTRAINT "FK_b1f12b00beaf809f3e37a9986be" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchases" DROP CONSTRAINT "FK_b1f12b00beaf809f3e37a9986be"`,
    );
    await queryRunner.query(`ALTER TABLE "purchases" ALTER COLUMN "delivery_date" SET NOT NULL`);
    await queryRunner.query(
      `ALTER TABLE "purchases" ALTER COLUMN "status" SET DEFAULT 'Partially Paid'`,
    );
    await queryRunner.query(`ALTER TABLE "purchases" ALTER COLUMN "invoiceReference" SET NOT NULL`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "hall_id"`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "totalPayable"`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "vat"`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "subtotal_after_disc"`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "discount_value"`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "discount_type"`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "subtotal"`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "invoiceType"`);
    await queryRunner.query(`ALTER TABLE "purchases" ADD "paidAmount" integer NOT NULL`);
  }
}
