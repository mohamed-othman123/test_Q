import { MigrationInterface, QueryRunner } from "typeorm";

export class AddTableHallsPaymentMethod1732204218917 implements MigrationInterface {
    name = 'AddTableHallsPaymentMethod1732204218917'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "halls_payment_methods" ("id" SERIAL NOT NULL, "paymentMethod_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "PK_a9d360b07a5f6a2b2df5a91b4c9" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "halls_payment_methods" ADD CONSTRAINT "FK_b4ff06183865844edb6daeff046" FOREIGN KEY ("paymentMethod_id") REFERENCES "payment_method"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "halls_payment_methods" ADD CONSTRAINT "FK_f68052948446d5dfb3fdccaf75d" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_payment_methods" DROP CONSTRAINT "FK_f68052948446d5dfb3fdccaf75d"`);
        await queryRunner.query(`ALTER TABLE "halls_payment_methods" DROP CONSTRAINT "FK_b4ff06183865844edb6daeff046"`);
        await queryRunner.query(`DROP TABLE "halls_payment_methods"`);
    }

}
