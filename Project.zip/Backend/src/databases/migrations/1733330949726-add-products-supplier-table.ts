import { MigrationInterface, QueryRunner } from "typeorm";

export class AddProductsSupplierTable1733330949726 implements MigrationInterface {
    name = 'AddProductsSupplierTable1733330949726'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "supplier_products" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying NOT NULL, "price" numeric(10,2) NOT NULL, "note" text, "supplierId" integer, CONSTRAINT "PK_651e91706e362ef7393457c347e" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "supplier_products" ADD CONSTRAINT "FK_1a3ae86a8f5e4d73e016c84b7b5" FOREIGN KEY ("supplierId") REFERENCES "suppliers"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "supplier_products" DROP CONSTRAINT "FK_1a3ae86a8f5e4d73e016c84b7b5"`);
        await queryRunner.query(`DROP TABLE "supplier_products"`);
    }

}
