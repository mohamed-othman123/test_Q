import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeDescriptionNotHaveLength1746842848606 implements MigrationInterface {
    name = 'MakeDescriptionNotHaveLength1746842848606'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE SEQUENCE IF NOT EXISTS "special_days_pricing_id_seq" OWNED BY "special_days_pricing"."id"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ALTER COLUMN "id" SET DEFAULT nextval('"special_days_pricing_id_seq"')`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ALTER COLUMN "id" DROP DEFAULT`);
        await queryRunner.query(`CREATE SEQUENCE IF NOT EXISTS "regular_pricing_id_seq" OWNED BY "regular_pricing"."id"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ALTER COLUMN "id" SET DEFAULT nextval('"regular_pricing_id_seq"')`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ALTER COLUMN "id" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "description"`);
        await queryRunner.query(`ALTER TABLE "events" ADD "description" text`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "description"`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "description" text`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "description"`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "description" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "description"`);
        await queryRunner.query(`ALTER TABLE "events" ADD "description" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ALTER COLUMN "id" SET DEFAULT nextval('hall_pricing_id_seq')`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ALTER COLUMN "id" DROP DEFAULT`);
        await queryRunner.query(`DROP SEQUENCE "regular_pricing_id_seq"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ALTER COLUMN "id" SET DEFAULT nextval('hall_special_days_pricing_id_seq')`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ALTER COLUMN "id" DROP DEFAULT`);
        await queryRunner.query(`DROP SEQUENCE "special_days_pricing_id_seq"`);
    }

}
