import { MigrationInterface, QueryRunner } from 'typeorm';

export class RemoveReceiverAndMobileFromClientMethod1752077327829 implements MigrationInterface {
  name = 'RemoveReceiverAndMobileFromClientMethod1752077327829';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "client_payment_methods" DROP COLUMN "receiver_name"`);
    await queryRunner.query(`ALTER TABLE "client_payment_methods" DROP COLUMN "receiver_mobile"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "client_payment_methods" ADD "receiver_mobile" character varying`,
    );
    await queryRunner.query(
      `ALTER TABLE "client_payment_methods" ADD "receiver_name" character varying`,
    );
  }
}
