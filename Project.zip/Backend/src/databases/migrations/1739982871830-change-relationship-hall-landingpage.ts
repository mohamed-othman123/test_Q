import { MigrationInterface, QueryRunner } from "typeorm";

export class ChangeRelationshipHallLandingpage1739982871830 implements MigrationInterface {
    name = 'ChangeRelationshipHallLandingpage1739982871830'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_landing_pages" DROP CONSTRAINT "FK_42300935e46a635b87b7be531c1"`);
        await queryRunner.query(`ALTER TABLE "hall_landing_pages" ADD CONSTRAINT "UQ_42300935e46a635b87b7be531c1" UNIQUE ("hall_id")`);
        await queryRunner.query(`ALTER TABLE "hall_landing_pages" ADD CONSTRAINT "FK_42300935e46a635b87b7be531c1" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_landing_pages" DROP CONSTRAINT "FK_42300935e46a635b87b7be531c1"`);
        await queryRunner.query(`ALTER TABLE "hall_landing_pages" DROP CONSTRAINT "UQ_42300935e46a635b87b7be531c1"`);
        await queryRunner.query(`ALTER TABLE "hall_landing_pages" ADD CONSTRAINT "FK_42300935e46a635b87b7be531c1" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

}
