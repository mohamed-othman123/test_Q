import { MigrationInterface, QueryRunner } from 'typeorm';

export class PurcahsesCategoryTypes1741873022079 implements MigrationInterface {
  name = 'PurcahsesCategoryTypes1741873022079';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchase_categories" ADD "type" character varying NOT NULL DEFAULT 'Purchases'`,
    );
    await queryRunner.query(`ALTER TABLE "purchase_categories" ADD "key" character varying`);
    await queryRunner.query(
      `ALTER TABLE "purchase_categories" ADD "arDescription" character varying`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_categories" ADD "enDescription" character varying`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchase_categories" DROP COLUMN "enDescription"`);
    await queryRunner.query(`ALTER TABLE "purchase_categories" DROP COLUMN "arDescription"`);
    await queryRunner.query(`ALTER TABLE "purchase_categories" DROP COLUMN "key"`);
    await queryRunner.query(`ALTER TABLE "purchase_categories" DROP COLUMN "type"`);
  }
}
