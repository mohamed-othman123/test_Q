import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddRejecrReasonInRefundEntity1755472268092 implements MigrationInterface {
  name = 'AddRejecrReasonInRefundEntity1755472268092';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "refund_requests" ADD "reject_reason" text`);
    // Update reject_reason based on the condition
    await queryRunner.query(`
      UPDATE "refund_requests"
      SET "reject_reason" = "notes"
      WHERE "type" = 'rejected'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "refund_requests" DROP COLUMN "reject_reason"`);
  }
}
