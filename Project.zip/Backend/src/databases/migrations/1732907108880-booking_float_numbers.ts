import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingFloatNumbers1732907108880 implements MigrationInterface {
  name = 'BookingFloatNumbers1732907108880';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "discount_value"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "discount_value" double precision NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "subtotal_after_disc"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "subtotal_after_disc" double precision NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "vat"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "vat" double precision NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "totalPayable"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "totalPayable" double precision NOT NULL DEFAULT '0'`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "totalPayable"`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "totalPayable" integer NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "vat"`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "vat" integer NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "subtotal_after_disc"`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "subtotal_after_disc" integer`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "discount_value"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "discount_value" integer NOT NULL DEFAULT '0'`,
    );
  }
}
