import { MigrationInterface, QueryRunner } from "typeorm";

export class EditUserTable1728943008973 implements MigrationInterface {
    name = 'EditUserTable1728943008973'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "type"`);
        await queryRunner.query(`CREATE TYPE "public"."users_type_enum" AS ENUM('Super Admin', 'Admin', 'Client Admin', 'Client Moderator', 'Customer')`);
        await queryRunner.query(`ALTER TABLE "users" ADD "type" "public"."users_type_enum" NOT NULL DEFAULT 'Client Admin'`);
        // await queryRunner.query(`ALTER TABLE "services" ADD CONSTRAINT "FK_458874e221f4ed82fa478b755d8" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "services" DROP CONSTRAINT "FK_458874e221f4ed82fa478b755d8"`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "type"`);
        await queryRunner.query(`DROP TYPE "public"."users_type_enum"`);
        await queryRunner.query(`ALTER TABLE "users" ADD "type" character varying(255) NOT NULL`);
    }

}
