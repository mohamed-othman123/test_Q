import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingCustomerSignatureName1754487610219 implements MigrationInterface {
  name = 'BookingCustomerSignatureName1754487610219';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "customer_signature_name" character varying`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "customer_signature_name"`);
  }
}
