import { MigrationInterface, QueryRunner } from 'typeorm';

export class ContractPfdDetails1734609990253 implements MigrationInterface {
  name = 'ContractPfdDetails1734609990253';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "booking_contract"`);

    await queryRunner.query(
      `CREATE TABLE "contract_pdf" ("id" SERIAL NOT NULL, "ar_version" text, "en_version" text, "contract_secret" character varying, "hash" character varying, "access_count" integer NOT NULL DEFAULT '0', "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_83930aa53c4b6e31cb6be4a945e" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(`ALTER TABLE "booking" ADD "contract_id" integer`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD CONSTRAINT "UQ_15d7246105f04ade14de03f8f18" UNIQUE ("contract_id")`,
    );
    await queryRunner.query(
      `ALTER TABLE "booking" ADD CONSTRAINT "FK_15d7246105f04ade14de03f8f18" FOREIGN KEY ("contract_id") REFERENCES "contract_pdf"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking" DROP CONSTRAINT "FK_15d7246105f04ade14de03f8f18"`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "contract_id"`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "booking_contract" text`);
    await queryRunner.query(`DROP TABLE "contract_pdf"`);
  }
}
