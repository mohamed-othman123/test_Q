import { MigrationInterface, QueryRunner } from "typeorm";

export class AddInsuranceAmountEventTable1746595734291 implements MigrationInterface {
    name = 'AddInsuranceAmountEventTable1746595734291'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "events" ADD "insurance_amount" numeric(10,2) NOT NULL DEFAULT '0'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "insurance_amount"`);
    }

}
