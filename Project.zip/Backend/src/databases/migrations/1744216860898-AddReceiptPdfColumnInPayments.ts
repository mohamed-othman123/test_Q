import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddReceiptPdfColumnInPayments1744216860898 implements MigrationInterface {
  name = 'AddReceiptPdfColumnInPayments1744216860898';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "payments" ADD "receipt_pdf_id" integer`);
    await queryRunner.query(
      `ALTER TABLE "payments" ADD CONSTRAINT "UQ_0138c4846174a175827bf5e4ea8" UNIQUE ("receipt_pdf_id")`,
    );
    await queryRunner.query(
      `ALTER TABLE "payments" ADD CONSTRAINT "FK_0138c4846174a175827bf5e4ea8" FOREIGN KEY ("receipt_pdf_id") REFERENCES "document_pdf"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "receipt_pdf_id"`);
  }
}
