import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateHallClientsTables1739380036005 implements MigrationInterface {
    name = 'UpdateHallClientsTables1739380036005'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_clients" RENAME COLUMN "isCompany" TO "type"`);
        await queryRunner.query(`CREATE TABLE "hall_clients_contacts" ("id" SERIAL NOT NULL, "name" character varying(255) NOT NULL, "email" character varying(255), "phone" character varying(255) NOT NULL, "customerId" integer NOT NULL, CONSTRAINT "PK_efa787d96e009423d8c4b2b8bd6" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "halls_clients" DROP COLUMN "type"`);
        await queryRunner.query(`CREATE TYPE "public"."halls_clients_type_enum" AS ENUM('Individual', 'Facility', 'Governmental Facility')`);
        await queryRunner.query(`ALTER TABLE "halls_clients" ADD "type" "public"."halls_clients_type_enum" NOT NULL DEFAULT 'Individual'`);
        await queryRunner.query(`ALTER TABLE "hall_clients_contacts" ADD CONSTRAINT "FK_2edc4f6b37dfc2d7ebc6c0e4eb7" FOREIGN KEY ("customerId") REFERENCES "halls_clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_clients_contacts" DROP CONSTRAINT "FK_2edc4f6b37dfc2d7ebc6c0e4eb7"`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "end_date" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "start_date" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls_clients" DROP COLUMN "type"`);
        await queryRunner.query(`DROP TYPE "public"."halls_clients_type_enum"`);
        await queryRunner.query(`ALTER TABLE "halls_clients" RENAME COLUMN "type" TO "isCompany"`);
    }

}
