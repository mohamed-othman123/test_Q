import { MigrationInterface, QueryRunner } from 'typeorm';

export class PurcahsesCategoryOrders1741884443212 implements MigrationInterface {
  name = 'PurcahsesCategoryOrders1741884443212';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchase_categories" ADD "order" integer`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchase_categories" DROP COLUMN "order"`);
  }
}
