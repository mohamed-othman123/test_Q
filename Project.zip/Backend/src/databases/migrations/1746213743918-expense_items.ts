import { MigrationInterface, QueryRunner } from 'typeorm';

export class ExpenseItems1746213743918 implements MigrationInterface {
  name = 'ExpenseItems1746213743918';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "expense_items" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying NOT NULL, "name_ar" character varying NOT NULL, "description" text, "category_id" integer, "client_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "PK_6fd381fa4fa54678572a7aa534d" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "expense_elements" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying NOT NULL, "name_ar" character varying NOT NULL, "value" numeric(10,2) NOT NULL DEFAULT '0', "item_id" integer NOT NULL, CONSTRAINT "PK_eaeb5eb35767f43463e6c039f1e" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_categories" ALTER COLUMN "name_ar" SET DEFAULT ''`,
    );
    await queryRunner.query(
      `ALTER TABLE "expense_items" ADD CONSTRAINT "FK_b2076dd9890a2a3a65ee52494b6" FOREIGN KEY ("category_id") REFERENCES "purchase_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expense_items" ADD CONSTRAINT "FK_b9a0b53058b88071ab5203bca37" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expense_items" ADD CONSTRAINT "FK_f15d1a2a3ad68ecf42ff5a3186e" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expense_elements" ADD CONSTRAINT "FK_bfe3ccddb9ddf93b4eebd795bbd" FOREIGN KEY ("item_id") REFERENCES "expense_items"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "expense_elements" DROP CONSTRAINT "FK_bfe3ccddb9ddf93b4eebd795bbd"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expense_items" DROP CONSTRAINT "FK_f15d1a2a3ad68ecf42ff5a3186e"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expense_items" DROP CONSTRAINT "FK_b9a0b53058b88071ab5203bca37"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expense_items" DROP CONSTRAINT "FK_b2076dd9890a2a3a65ee52494b6"`,
    );

    await queryRunner.query(
      `ALTER TABLE "purchase_categories" ALTER COLUMN "name_ar" DROP DEFAULT`,
    );
    await queryRunner.query(`DROP TABLE "expense_elements"`);
    await queryRunner.query(`DROP TABLE "expense_items"`);
  }
}
