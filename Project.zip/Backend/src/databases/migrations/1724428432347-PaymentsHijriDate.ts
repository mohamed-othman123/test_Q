import { MigrationInterface, QueryRunner } from 'typeorm';

export class PaymentsHijriDate1724428432347 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER TABLE "payments" ADD COLUMN "hijri_date" VARCHAR(20) DEFAULT NULL',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('ALTER TABLE "payments" DROP COLUMN "hijri_date"');
  }
}
