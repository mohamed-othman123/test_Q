import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateUserTable1744337132153 implements MigrationInterface {
    name = 'UpdateUserTable1744337132153'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_moderator" DROP COLUMN "isAdmin"`);
        await queryRunner.query(`CREATE TYPE "public"."users_permissiontype_enum" AS ENUM('general permission', 'special permission')`);
        await queryRunner.query(`ALTER TABLE "users" ADD "permissionType" "public"."users_permissiontype_enum" NOT NULL DEFAULT 'general permission'`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "password" DROP NOT NULL`);
        await queryRunner.query(`ALTER TYPE "public"."users_type_enum" RENAME TO "users_type_enum_old"`);
        await queryRunner.query(`CREATE TYPE "public"."users_type_enum" AS ENUM('hall owner', 'system manager', 'employee')`);
        // Change the enum type to text to accept all existing values
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "type" TYPE text`);
        // Update existing values to match new enum types
        await queryRunner.query(`
        UPDATE "users"
        SET "type" = CASE 
            WHEN "type" = 'Client Admin' THEN 'hall owner'
            WHEN "type" = 'Client Moderator' THEN 'system manager'
            ELSE "type"
        END
        `);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "type" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "type" TYPE "public"."users_type_enum" USING "type"::"text"::"public"."users_type_enum"`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "type" SET DEFAULT 'hall owner'`);
        await queryRunner.query(`DROP TYPE "public"."users_type_enum_old"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."users_type_enum_old" AS ENUM('Admin', 'Client Admin', 'Client Moderator', 'Customer', 'Super Admin')`);
         // Change the enum type to text to accept all existing values
         await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "type" TYPE text`);
         // Update existing values to match new enum types
         await queryRunner.query(`
         UPDATE "users"
         SET "type" = CASE 
             WHEN "type" = 'hall owner' THEN 'Client Admin'
             WHEN "type" = 'system manager' THEN 'Client Moderator'
             ELSE "type"
         END
         `);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "type" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "type" TYPE "public"."users_type_enum_old" USING "type"::"text"::"public"."users_type_enum_old"`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "type" SET DEFAULT 'Client Admin'`);
        await queryRunner.query(`DROP TYPE "public"."users_type_enum"`);
        await queryRunner.query(`ALTER TYPE "public"."users_type_enum_old" RENAME TO "users_type_enum"`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "password" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "permissionType"`);
        await queryRunner.query(`DROP TYPE "public"."users_permissiontype_enum"`);
        await queryRunner.query(`ALTER TABLE "halls_moderator" ADD "isAdmin" boolean NOT NULL DEFAULT false`);
    }

}
