import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddSettlementPdfIdColumnToPurchase1744213777692 implements MigrationInterface {
  name = 'AddSettlementPdfIdColumnToPurchase1744213777692';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchases" ADD "settlement_pdf_id" integer`);
    await queryRunner.query(
      `ALTER TABLE "purchases" ADD CONSTRAINT "UQ_090c478af5eec653f0f0ce221d9" UNIQUE ("settlement_pdf_id")`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchases" ADD CONSTRAINT "FK_090c478af5eec653f0f0ce221d9" FOREIGN KEY ("settlement_pdf_id") REFERENCES "document_pdf"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "settlement_pdf_id"`);
  }
}
