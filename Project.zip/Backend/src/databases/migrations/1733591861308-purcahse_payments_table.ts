import { MigrationInterface, QueryRunner } from 'typeorm';

export class PurcahsePaymentsTable1733591861308 implements MigrationInterface {
  name = 'PurcahsePaymentsTable1733591861308';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "purchase_payments" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "paid_amount" numeric(10,2) NOT NULL, "payment_date" TIMESTAMP NOT NULL, "type" character varying NOT NULL, "bank_name" character varying, "bank_account_number" character varying, "note" character varying, "paymentMethod_id" integer NOT NULL, "purchase_id" integer NOT NULL, "client_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "PK_9765d702e073d3cdf9b1600792d" PRIMARY KEY ("id"))`,
    );

    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD CONSTRAINT "FK_fed90c8deca69fde22b4d01a2f1" FOREIGN KEY ("paymentMethod_id") REFERENCES "payment_method"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD CONSTRAINT "FK_b0089820b7452d8e84b5d1fda65" FOREIGN KEY ("purchase_id") REFERENCES "purchases"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD CONSTRAINT "FK_add42ca533896795ed320136619" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD CONSTRAINT "FK_237d1076afe4dfadaaaea785bfc" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" DROP CONSTRAINT "FK_237d1076afe4dfadaaaea785bfc"`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" DROP CONSTRAINT "FK_add42ca533896795ed320136619"`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" DROP CONSTRAINT "FK_b0089820b7452d8e84b5d1fda65"`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" DROP CONSTRAINT "FK_fed90c8deca69fde22b4d01a2f1"`,
    );
    
    await queryRunner.query(`DROP TABLE "purchase_payments"`);
  }
}
