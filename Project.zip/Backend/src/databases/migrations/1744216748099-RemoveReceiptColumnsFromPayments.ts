import { MigrationInterface, QueryRunner } from 'typeorm';

export class RemoveReceiptColumnsFromPayments1744216748099 implements MigrationInterface {
  name = 'RemoveReceiptColumnsFromPayments1744216748099';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "receipt_ar"`);
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "receipt_en"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "payments" ADD "receipt_en" text`);
    await queryRunner.query(`ALTER TABLE "payments" ADD "receipt_ar" text`);
  }
}
