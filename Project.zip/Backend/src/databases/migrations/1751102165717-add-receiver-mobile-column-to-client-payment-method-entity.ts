import { MigrationInterface, QueryRunner } from "typeorm";

export class AddReceiverMobileColumnToClientPaymentMethodEntity1751102165717 implements MigrationInterface {
    name = 'AddReceiverMobileColumnToClientPaymentMethodEntity1751102165717'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "client_payment_methods" ADD "receiver_mobile" character varying`);
        await queryRunner.query(`ALTER TABLE "client_payment_methods" ALTER COLUMN "type" SET DEFAULT 'cash'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "client_payment_methods" ALTER COLUMN "type" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "client_payment_methods" DROP COLUMN "receiver_mobile"`);
    }

}
