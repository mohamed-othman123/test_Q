import { MigrationInterface, QueryRunner } from "typeorm";

export class AddProvidersTable1738783966415 implements MigrationInterface {
    name = 'AddProvidersTable1738783966415'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "halls_services_providers" ("id" SERIAL NOT NULL, "name" character varying(255), "email" character varying(255), "phone" character varying(255), "hall_service_id" integer NOT NULL, CONSTRAINT "PK_561976c40b76aafd81305908ad7" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "providerName"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "providerEmail"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "providerPhone"`);
        await queryRunner.query(`ALTER TABLE "halls_services_providers" ADD CONSTRAINT "FK_39a741e475b13bd3f5ccb737d0c" FOREIGN KEY ("hall_service_id") REFERENCES "halls_services"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services_providers" DROP CONSTRAINT "FK_39a741e475b13bd3f5ccb737d0c"`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "providerPhone" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "providerEmail" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "providerName" character varying(255)`);
        await queryRunner.query(`DROP TABLE "halls_services_providers"`);
    }

}
