import { MigrationInterface, QueryRunner } from 'typeorm';

export class AlterHallPurchaseCategoryAddHallId1746021403338 implements MigrationInterface {
  name = 'AlterHallPurchaseCategoryAddHallId1746021403338';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "halls_purchase_categories" ADD "hall_id" integer NOT NULL`,
    );
    await queryRunner.query(
      `ALTER TABLE "halls_purchase_categories" ADD CONSTRAINT "FK_214a5d7161f3522c204ec4f52ad" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "halls_purchase_categories" DROP CONSTRAINT "FK_214a5d7161f3522c204ec4f52ad"`,
    );
    await queryRunner.query(`ALTER TABLE "halls_purchase_categories" DROP COLUMN "hall_id"`);
  }
}
