import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddInventoryTable1756267260676 implements MigrationInterface {
  name = 'AddInventoryTable1756267260676';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "hall-inventory" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "inventory_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "PK_226cb7b20c85bd9f3c337dca25b" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "inventory" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying(255) NOT NULL, "name_ar" character varying(255) NOT NULL, "description" text, "note" text, "unit_price" numeric(10,2) NOT NULL, "quantity" integer NOT NULL, "reorder_level" integer NOT NULL, "client_id" integer NOT NULL, CONSTRAINT "PK_82aa5da437c5bbfb80703b08309" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `ALTER TABLE "hall-inventory" ADD CONSTRAINT "FK_3fb421115e836edb378072424e6" FOREIGN KEY ("inventory_id") REFERENCES "inventory"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "hall-inventory" ADD CONSTRAINT "FK_408551a596aa46be25790d66426" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "inventory" ADD CONSTRAINT "FK_1563c6045119884089e33aebb60" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "inventory" DROP CONSTRAINT "FK_1563c6045119884089e33aebb60"`,
    );
    await queryRunner.query(
      `ALTER TABLE "hall-inventory" DROP CONSTRAINT "FK_408551a596aa46be25790d66426"`,
    );
    await queryRunner.query(
      `ALTER TABLE "hall-inventory" DROP CONSTRAINT "FK_3fb421115e836edb378072424e6"`,
    );
    await queryRunner.query(`DROP TABLE "inventory"`);
    await queryRunner.query(`DROP TABLE "hall-inventory"`);
  }
}
