import { MigrationInterface, QueryRunner } from 'typeorm';

export class LandingPagesSocialUpdates1735253741351 implements MigrationInterface {
  name = 'LandingPagesSocialUpdates1735253741351';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "landing_social_Links" DROP COLUMN "whatsApp"`);
    await queryRunner.query(`ALTER TABLE "landing_social_Links" DROP COLUMN "websiteLink"`);
    await queryRunner.query(`ALTER TABLE "landing_social_Links" ADD "linkedin" character varying`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "landing_social_Links" DROP COLUMN "linkedin"`);
    await queryRunner.query(
      `ALTER TABLE "landing_social_Links" ADD "websiteLink" character varying`,
    );
    await queryRunner.query(`ALTER TABLE "landing_social_Links" ADD "whatsApp" character varying`);
  }
}
