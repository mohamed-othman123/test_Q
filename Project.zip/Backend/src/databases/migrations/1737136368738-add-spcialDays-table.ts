import { MigrationInterface, QueryRunner } from "typeorm";

export class AddSpcialDaysTable1737136368738 implements MigrationInterface {
    name = 'AddSpcialDaysTable1737136368738'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "hall_pricing" ("id" SERIAL NOT NULL, "mondayMorningPrice" numeric(10,2) NOT NULL, "mondayEveningPrice" numeric(10,2) NOT NULL, "mondayFullDayPrice" numeric(10,2) NOT NULL, "tuesdayMorningPrice" numeric(10,2) NOT NULL, "tuesdayEveningPrice" numeric(10,2) NOT NULL, "tuesdayFullDayPrice" numeric(10,2) NOT NULL, "wednesdayMorningPrice" numeric(10,2) NOT NULL, "wednesdayEveningPrice" numeric(10,2) NOT NULL, "wednesdayFullDayPrice" numeric(10,2) NOT NULL, "thursdayMorningPrice" numeric(10,2) NOT NULL, "thursdayEveningPrice" numeric(10,2) NOT NULL, "thursdayFullDayPrice" numeric(10,2) NOT NULL, "fridayMorningPrice" numeric(10,2) NOT NULL, "fridayEveningPrice" numeric(10,2) NOT NULL, "fridayFullDayPrice" numeric(10,2) NOT NULL, "saturdayMorningPrice" numeric(10,2) NOT NULL, "saturdayEveningPrice" numeric(10,2) NOT NULL, "saturdayFullDayPrice" numeric(10,2) NOT NULL, "sundayMorningPrice" numeric(10,2) NOT NULL, "sundayEveningPrice" numeric(10,2) NOT NULL, "sundayFullDayPrice" numeric(10,2) NOT NULL, "hall_id" integer, CONSTRAINT "REL_d9abaf324b0de7f72e796a843b" UNIQUE ("hall_id"), CONSTRAINT "PK_98bd05bf38adc23a6a85f229c47" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "hall_special_days_pricing" ("id" SERIAL NOT NULL, "startDate" date, "endDate" date, "morningPrice" numeric(10,2), "eveningPrice" numeric(10,2), "fullDayPrice" numeric(10,2), "hallId" integer, CONSTRAINT "PK_a84c06c5ce06dca1c8d0ac0ef8f" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "pricingOnBooking"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "fixedPrice"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "specialDays"`);
        await queryRunner.query(`CREATE TYPE "public"."halls_pricingtype_enum" AS ENUM('BOOKING_TIME', 'FIXED')`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "pricingType" "public"."halls_pricingtype_enum" NOT NULL DEFAULT 'BOOKING_TIME'`);
        await queryRunner.query(`CREATE TYPE "public"."halls_pricecalculationtype_enum" AS ENUM('FIXED_PRICE', 'PER_PERSON')`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "priceCalculationType" "public"."halls_pricecalculationtype_enum"`);
        await queryRunner.query(`ALTER TABLE "hall_pricing" ADD CONSTRAINT "FK_d9abaf324b0de7f72e796a843b6" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ADD CONSTRAINT "FK_8902a66d56af2e5266dfc55f656" FOREIGN KEY ("hallId") REFERENCES "halls"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" DROP CONSTRAINT "FK_8902a66d56af2e5266dfc55f656"`);
        await queryRunner.query(`ALTER TABLE "hall_pricing" DROP CONSTRAINT "FK_d9abaf324b0de7f72e796a843b6"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "priceCalculationType"`);
        await queryRunner.query(`DROP TYPE "public"."halls_pricecalculationtype_enum"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "pricingType"`);
        await queryRunner.query(`DROP TYPE "public"."halls_pricingtype_enum"`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "specialDays" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "fixedPrice" boolean`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "pricingOnBooking" boolean NOT NULL DEFAULT true`);
        await queryRunner.query(`DROP TABLE "hall_special_days_pricing"`);
        await queryRunner.query(`DROP TABLE "hall_pricing"`);
    }

}
