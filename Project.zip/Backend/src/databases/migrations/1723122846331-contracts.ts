import { MigrationInterface, QueryRunner } from 'typeorm';

export class Contracts1723122846331 implements MigrationInterface {
  name = 'Contracts1723122846331';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "contracts" ("id" SERIAL NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted" boolean NOT NULL DEFAULT false, "deleted_at" TIMESTAMP, "deleted_by" integer, "name" character varying(255) NOT NULL, "terms_and_conditions" text NOT NULL, "privacy_policy" text NOT NULL, "active" boolean NOT NULL DEFAULT true, "logo_url" text, "primary_color" character varying(255), "secondary_color" character varying(255), "client_id" integer, CONSTRAINT "PK_2c7b8f3a7b1acdd49497d83d0fb" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `ALTER TABLE "contracts" ADD CONSTRAINT "FK_9945462ca96b2c7d0a97e012cdc" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contracts" DROP CONSTRAINT "FK_9945462ca96b2c7d0a97e012cdc"`,
    );

    await queryRunner.query(`DROP TABLE "contracts"`);
  }
}
