import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeSupplierPaymentMethodsTable1747685390749 implements MigrationInterface {
    name = 'MakeSupplierPaymentMethodsTable1747685390749'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."supplier_payment_methods_payment_method_type_enum" AS ENUM('bankAccount', 'eWallet', 'pos', 'cash')`);
        await queryRunner.query(`CREATE TABLE "supplier_payment_methods" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying NOT NULL, "payment_method_type" "public"."supplier_payment_methods_payment_method_type_enum" NOT NULL DEFAULT 'cash', "bank_name" character varying, "iban" character varying, "account_number" character varying, "ewallet_name" character varying, "ewallet_phone" character varying, "payment_method_notes" character varying, "supplierId" integer, CONSTRAINT "PK_31d9a0ad85e9431632f77caaebf" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "payment_method_type"`);
        await queryRunner.query(`DROP TYPE "public"."suppliers_payment_method_type_enum"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "bank_name"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "iban"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "account_number"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "ewallet_name"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "ewallet_phone"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "payment_method_notes"`);
        await queryRunner.query(`ALTER TABLE "supplier_payment_methods" ADD CONSTRAINT "FK_bf144ced8bddd79371c19a9753e" FOREIGN KEY ("supplierId") REFERENCES "suppliers"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "supplier_payment_methods" DROP CONSTRAINT "FK_bf144ced8bddd79371c19a9753e"`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "payment_method_notes" character varying`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "ewallet_phone" character varying`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "ewallet_name" character varying`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "account_number" character varying`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "iban" character varying`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "bank_name" character varying`);
        await queryRunner.query(`CREATE TYPE "public"."suppliers_payment_method_type_enum" AS ENUM('bankAccount', 'eWallet', 'pos', 'cash')`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "payment_method_type" "public"."suppliers_payment_method_type_enum" NOT NULL DEFAULT 'cash'`);
        await queryRunner.query(`DROP TABLE "supplier_payment_methods"`);
        await queryRunner.query(`DROP TYPE "public"."supplier_payment_methods_payment_method_type_enum"`);
    }

}
