import { MigrationInterface, QueryRunner } from 'typeorm';

export class ExpensePaymentCashPosNames1748087087165 implements MigrationInterface {
  name = 'ExpensePaymentCashPosNames1748087087165';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD "cash_receiver_name" character varying`,
    );
    await queryRunner.query(`ALTER TABLE "expenses_payments" ADD "pos_name" character varying`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "expenses_payments" DROP COLUMN "pos_name"`);
    await queryRunner.query(`ALTER TABLE "expenses_payments" DROP COLUMN "cash_receiver_name"`);
  }
}
