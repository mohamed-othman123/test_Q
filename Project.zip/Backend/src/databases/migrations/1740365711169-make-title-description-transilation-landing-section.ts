import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeTitleDescriptionTransilationLandingSection1740365711169 implements MigrationInterface {
    name = 'MakeTitleDescriptionTransilationLandingSection1740365711169'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" DROP COLUMN "title"`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" DROP COLUMN "description"`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" ADD "title_en" character varying`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" ADD "title_ar" character varying`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" ADD "description_en" text`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" ADD "description_ar" text`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" DROP COLUMN "description_ar"`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" DROP COLUMN "description_en"`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" DROP COLUMN "title_ar"`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" DROP COLUMN "title_en"`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" ADD "description" text`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" ADD "title" character varying`);
    }

}
