import { MigrationInterface, QueryRunner } from 'typeorm';

export class DropLogColorsContracts1740252375043 implements MigrationInterface {
  name = 'DropLogColorsContracts1740252375043';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "logo_url"`);
    await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "primary_color"`);
    await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "secondary_color"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "secondary_color"`);
    await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "primary_color"`);
    await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "logo_url"`);
    await queryRunner.query(`ALTER TABLE "contracts" ADD "secondary_color" character varying(255)`);
    await queryRunner.query(`ALTER TABLE "contracts" ADD "primary_color" character varying(255)`);
    await queryRunner.query(`ALTER TABLE "contracts" ADD "logo_url" text`);
  }
}
