import { MigrationInterface, QueryRunner } from "typeorm";

export class AddDiscountEntity1750368404192 implements MigrationInterface {
    name = 'AddDiscountEntity1750368404192'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."discounts_type_enum" AS ENUM('fixed', 'percent')`);
        await queryRunner.query(`CREATE TABLE "discounts" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying NOT NULL, "type" "public"."discounts_type_enum" NOT NULL DEFAULT 'percent', "discount" numeric(10,2) NOT NULL DEFAULT '0', "note" character varying, "client_id" integer NOT NULL, CONSTRAINT "PK_66c522004212dc814d6e2f14ecc" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "discounts" ADD CONSTRAINT "FK_1100695c054931e5ffef4bccc4f" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "discounts" DROP CONSTRAINT "FK_1100695c054931e5ffef4bccc4f"`);
        await queryRunner.query(`DROP TABLE "discounts"`);
        await queryRunner.query(`DROP TYPE "public"."discounts_type_enum"`);
    }

}
