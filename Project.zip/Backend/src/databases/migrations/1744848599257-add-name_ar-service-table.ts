import { MigrationInterface, QueryRunner } from "typeorm";

export class AddNameArServiceTable1744848599257 implements MigrationInterface {
    name = 'AddNameArServiceTable1744848599257'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "services" ADD "name_ar" character varying(255) NOT NULL DEFAULT ''`);
        // Step 2: Update the new column to match the 'name' column where 'name_ar' is ''
  await queryRunner.query(`
    UPDATE "services"
    SET "name_ar" = "name"
    WHERE "name_ar" = ''
  `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "services" DROP COLUMN "name_ar"`);
    }

}
