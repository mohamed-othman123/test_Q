import { MigrationInterface, QueryRunner } from 'typeorm';

export class RemoveContractIdColumnFromBooking1744286165997 implements MigrationInterface {
  name = 'RemoveContractIdColumnFromBooking1744286165997';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "contract_id"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" ADD "contract_id" integer`);
  }
}
