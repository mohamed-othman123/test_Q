import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateHallSupplierTable1728951746340 implements MigrationInterface {
    name = 'CreateHallSupplierTable1728951746340'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "halls_supplier" ("id" SERIAL NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "supplier_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "PK_7e8cf3edff8fae06b8b72a9f4c8" PRIMARY KEY ("id"))`);
        // await queryRunner.query(`ALTER TABLE "services" ADD CONSTRAINT "FK_458874e221f4ed82fa478b755d8" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "halls_supplier" ADD CONSTRAINT "FK_77c028eb9444a90ed2119b67e88" FOREIGN KEY ("supplier_id") REFERENCES "suppliers"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "halls_supplier" ADD CONSTRAINT "FK_ddef2a92b9b74e2e208dc5d40a1" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_supplier" DROP CONSTRAINT "FK_ddef2a92b9b74e2e208dc5d40a1"`);
        await queryRunner.query(`ALTER TABLE "halls_supplier" DROP CONSTRAINT "FK_77c028eb9444a90ed2119b67e88"`);
        await queryRunner.query(`ALTER TABLE "services" DROP CONSTRAINT "FK_458874e221f4ed82fa478b755d8"`);
        await queryRunner.query(`DROP TABLE "halls_supplier"`);
    }

}
