import { MigrationInterface, QueryRunner } from "typeorm";

export class TranslateSupplierProduct1747106369081 implements MigrationInterface {
    name = 'TranslateSupplierProduct1747106369081'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "supplier_products" ADD "name_ar" character varying NOT NULL DEFAULT ''`);
        await queryRunner.query(`
            UPDATE "supplier_products"
            SET "name_ar" = "name"
            WHERE "name_ar" = ''
          `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "supplier_products" DROP COLUMN "name_ar"`);
    }

}
