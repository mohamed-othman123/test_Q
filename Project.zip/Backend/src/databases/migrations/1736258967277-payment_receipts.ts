import { MigrationInterface, QueryRunner } from 'typeorm';

export class PaymentReceipts1736258967277 implements MigrationInterface {
  name = 'PaymentReceipts1736258967277';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "payments" ADD "receipt_ar" text`);
    await queryRunner.query(`ALTER TABLE "payments" ADD "receipt_en" text`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "receipt_en"`);
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "receipt_ar"`);
  }
}
