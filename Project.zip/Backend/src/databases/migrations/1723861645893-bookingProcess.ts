import { MigrationInterface, QueryRunner } from 'typeorm';

export class $npmConfigName1723861645893 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "booking"
            ADD COLUMN "bookingProcessStatus" varchar NOT NULL DEFAULT 'New';
          `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
