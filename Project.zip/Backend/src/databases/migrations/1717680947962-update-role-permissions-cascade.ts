import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateRolePermissionsCascade1717680947962 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "role_permissions" 
      DROP CONSTRAINT IF EXISTS "FK_17022daf3f885f7d35423e9971e";
    `);

    await queryRunner.query(`
      ALTER TABLE "role_permissions" 
      ADD CONSTRAINT "FK_17022daf3f885f7d35423e9971e" 
      FOREIGN KEY ("permission_id") 
      REFERENCES "permission"("id") 
      ON DELETE CASCADE;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "role_permissions" 
      DROP CONSTRAINT IF EXISTS "FK_17022daf3f885f7d35423e9971e";
    `);

    // Add back original foreign key constraints
    await queryRunner.query(`
      ALTER TABLE "role_permissions" 
      ADD CONSTRAINT "FK_17022daf3f885f7d35423e9971e" 
      FOREIGN KEY ("permission_id") 
      REFERENCES "permission"("id");
    `);
  }
}
