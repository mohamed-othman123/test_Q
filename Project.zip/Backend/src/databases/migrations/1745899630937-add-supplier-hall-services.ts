import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddSupplierHallServices1745899630937 implements MigrationInterface {
  name = 'AddSupplierHallServices1745899630937';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TYPE "public"."halls_services_provider_type_enum" AS ENUM('hall', 'supplier', 'thirdParty')`,
    );
    await queryRunner.query(
      `ALTER TABLE "halls_services" ADD "provider_type" "public"."halls_services_provider_type_enum" NOT NULL DEFAULT 'hall'`,
    );
    await queryRunner.query(
      `UPDATE "halls_services" SET "provider_type" = 'thirdParty' WHERE "thirdParty" = TRUE`,
    );
    await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "thirdParty"`);
    await queryRunner.query(`ALTER TABLE "halls_services" ADD "supplier_id" integer`);
    await queryRunner.query(
      `ALTER TABLE "halls_services" ADD CONSTRAINT "FK_b95f03c7c4703642bea99c2e6e8" FOREIGN KEY ("supplier_id") REFERENCES "suppliers"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "halls_services" DROP CONSTRAINT "FK_b95f03c7c4703642bea99c2e6e8"`,
    );
    await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "supplier_id"`);
    await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "provider_type"`);
    await queryRunner.query(`DROP TYPE "public"."halls_services_provider_type_enum"`);
    await queryRunner.query(
      `ALTER TABLE "halls_services" ADD "thirdParty" boolean NOT NULL DEFAULT false`,
    );
  }
}
