import { MigrationInterface, QueryRunner } from "typeorm";

export class AddEventPricingLogic1746026400068 implements MigrationInterface {
    name = 'AddEventPricingLogic1746026400068'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TYPE "public"."halls_pricingtype_enum" RENAME TO "halls_pricingtype_enum_old"`);
        await queryRunner.query(`CREATE TYPE "public"."halls_pricingtype_enum" AS ENUM('BOOKING_TIME', 'FIXED', 'EVENT')`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "pricingType" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "pricingType" TYPE "public"."halls_pricingtype_enum" USING "pricingType"::"text"::"public"."halls_pricingtype_enum"`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "pricingType" SET DEFAULT 'BOOKING_TIME'`);
        await queryRunner.query(`DROP TYPE "public"."halls_pricingtype_enum_old"`);
        await queryRunner.query(`ALTER TYPE "public"."halls_pricecalculationtype_enum" RENAME TO "halls_pricecalculationtype_enum_old"`);
        await queryRunner.query(`CREATE TYPE "public"."halls_pricecalculationtype_enum" AS ENUM('FIXED_PRICE', 'PER_PERSON', 'BOOKING_TIME')`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "priceCalculationType" TYPE "public"."halls_pricecalculationtype_enum" USING "priceCalculationType"::"text"::"public"."halls_pricecalculationtype_enum"`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "priceCalculationType" SET DEFAULT 'BOOKING_TIME'`);
        await queryRunner.query(`DROP TYPE "public"."halls_pricecalculationtype_enum_old"`);
        await queryRunner.query(`
            UPDATE "halls"
            SET "priceCalculationType" = 'BOOKING_TIME'
            WHERE "priceCalculationType" IS NULL
        `);
        await queryRunner.query(`
            UPDATE "halls"
            SET "insurance_amount" = 0.00
            WHERE "insurance_amount" IS NULL
        `);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "priceCalculationType" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "priceCalculationType" SET DEFAULT 'BOOKING_TIME'`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "insurance_amount" SET NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "insurance_amount" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "priceCalculationType" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "priceCalculationType" DROP NOT NULL`);
        await queryRunner.query(`CREATE TYPE "public"."halls_pricecalculationtype_enum_old" AS ENUM('FIXED_PRICE', 'PER_PERSON')`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "priceCalculationType" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "priceCalculationType" TYPE "public"."halls_pricecalculationtype_enum_old" USING "priceCalculationType"::"text"::"public"."halls_pricecalculationtype_enum_old"`);
        await queryRunner.query(`DROP TYPE "public"."halls_pricecalculationtype_enum"`);
        await queryRunner.query(`ALTER TYPE "public"."halls_pricecalculationtype_enum_old" RENAME TO "halls_pricecalculationtype_enum"`);
        await queryRunner.query(`CREATE TYPE "public"."halls_pricingtype_enum_old" AS ENUM('BOOKING_TIME', 'FIXED')`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "pricingType" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "pricingType" TYPE "public"."halls_pricingtype_enum_old" USING "pricingType"::"text"::"public"."halls_pricingtype_enum_old"`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "pricingType" SET DEFAULT 'BOOKING_TIME'`);
        await queryRunner.query(`DROP TYPE "public"."halls_pricingtype_enum"`);
        await queryRunner.query(`ALTER TYPE "public"."halls_pricingtype_enum_old" RENAME TO "halls_pricingtype_enum"`);
    }

}
