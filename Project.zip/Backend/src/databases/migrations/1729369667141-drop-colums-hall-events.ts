import { MigrationInterface, QueryRunner } from "typeorm";

export class DropColumsHallEvents1729369667141 implements MigrationInterface {
    name = 'DropColumsHallEvents1729369667141'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_event" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "halls_event" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "halls_event" DROP COLUMN "deleted_at"`);
        await queryRunner.query(`ALTER TABLE "halls_event" DROP COLUMN "deleted"`);
        await queryRunner.query(`ALTER TABLE "halls_event" DROP COLUMN "deleted_by"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "created_by"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "updated_by"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "updated_by" integer`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "created_by" integer`);
        await queryRunner.query(`ALTER TABLE "halls_event" ADD "deleted_by" integer`);
        await queryRunner.query(`ALTER TABLE "halls_event" ADD "deleted" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "halls_event" ADD "deleted_at" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "halls_event" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "halls_event" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
    }

}
