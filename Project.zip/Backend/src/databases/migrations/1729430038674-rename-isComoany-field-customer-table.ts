import { MigrationInterface, QueryRunner } from "typeorm";

export class RenameIsComoanyFieldCustomerTable1729430038674 implements MigrationInterface {
    name = 'RenameIsComoanyFieldCustomerTable1729430038674'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_clients" RENAME COLUMN "Iscompany" TO "isCompany"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_clients" RENAME COLUMN "isCompany" TO "Iscompany"`);
    }

}
