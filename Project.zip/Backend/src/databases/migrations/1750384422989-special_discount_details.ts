import { MigrationInterface, QueryRunner } from 'typeorm';

export class SpecialDiscountDetails1750384422989 implements MigrationInterface {
  name = 'SpecialDiscountDetails1750384422989';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" ADD "discount_details" text`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "special_discount_id" integer`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD CONSTRAINT "FK_b2029cc7756ee78d2ae008817c0" FOREIGN KEY ("special_discount_id") REFERENCES "discounts"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking" DROP CONSTRAINT "FK_b2029cc7756ee78d2ae008817c0"`,
    );

    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "special_discount_id"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "discount_details"`);
  }
}
