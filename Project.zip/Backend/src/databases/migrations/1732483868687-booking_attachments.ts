import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingAttachments1732483868687 implements MigrationInterface {
  name = 'BookingAttachments1732483868687';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "booking_attachments" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying NOT NULL, "path" text NOT NULL, "type" character varying NOT NULL, "booking_id" integer NOT NULL, CONSTRAINT "PK_946b9b0b0e0e74b48a57395b540" PRIMARY KEY ("id"))`,
    );

    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "attachment"`);
    await queryRunner.query(`ALTER TABLE "booking_services" ADD "note" text`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "insurance_amount" SET NOT NULL`);
    await queryRunner.query(
      `ALTER TABLE "booking_attachments" ADD CONSTRAINT "FK_aaeda565a03e473f92e8d66f216" FOREIGN KEY ("booking_id") REFERENCES "booking"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking_attachments" DROP CONSTRAINT "FK_aaeda565a03e473f92e8d66f216"`,
    );
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "insurance_amount" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking_services" DROP COLUMN "note"`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "attachment" text`);

    await queryRunner.query(`DROP TABLE "booking_attachments"`);
  }
}
