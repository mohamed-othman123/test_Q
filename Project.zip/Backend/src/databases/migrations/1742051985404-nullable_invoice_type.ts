import { MigrationInterface, QueryRunner } from 'typeorm';

export class NullableInvoiceType1742051985404 implements MigrationInterface {
  name = 'NullableInvoiceType1742051985404';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchases" ALTER COLUMN "invoiceType" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "purchases" ALTER COLUMN "invoiceType" DROP DEFAULT`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchases" ALTER COLUMN "invoiceType" SET DEFAULT 'Tax Invoice'`,
    );
    await queryRunner.query(`ALTER TABLE "purchases" ALTER COLUMN "invoiceType" SET NOT NULL`);
  }
}
