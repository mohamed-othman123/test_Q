import { MigrationInterface, QueryRunner } from 'typeorm';

export class TeamMembersContract1748469828013 implements MigrationInterface {
  name = 'TeamMembersContract1748469828013';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" ADD "team_members_contract_pdf_id" integer`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD CONSTRAINT "UQ_5817471e61c10f3ad752e91cbbc" UNIQUE ("team_members_contract_pdf_id")`,
    );
    await queryRunner.query(
      `ALTER TABLE "booking" ADD CONSTRAINT "FK_5817471e61c10f3ad752e91cbbc" FOREIGN KEY ("team_members_contract_pdf_id") REFERENCES "document_pdf"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking" DROP CONSTRAINT "FK_5817471e61c10f3ad752e91cbbc"`,
    );
    await queryRunner.query(
      `ALTER TABLE "booking" DROP CONSTRAINT "UQ_5817471e61c10f3ad752e91cbbc"`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "team_members_contract_pdf_id"`);
  }
}
