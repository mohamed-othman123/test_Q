import { MigrationInterface, QueryRunner } from "typeorm";

export class SyncMigrations1728072655553 implements MigrationInterface {
    name = 'SyncMigrations1728072655553'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "role" DROP CONSTRAINT "FK_8e3b9b5b2c2d7b6f3e3e4b3e1b4"`);
        await queryRunner.query(`ALTER TABLE "users" DROP CONSTRAINT "FK_8e3b9b5b2c2d7b6f3e3e4b3e1b4"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP CONSTRAINT "halls_services_hall_id_fkey"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP CONSTRAINT "halls_services_service_id_fkey"`);
        await queryRunner.query(`ALTER TABLE "bank" DROP CONSTRAINT "fk_client_id"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "booking_client_id_fkey"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "booking_event_type_fkey"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "booking_hall_id_fkey"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "booking_user_id_fkey"`);
        await queryRunner.query(`ALTER TABLE "role_permissions" DROP CONSTRAINT "FK_17022daf3f885f7d35423e9971e"`);
        await queryRunner.query(`ALTER TABLE "role_permissions" DROP CONSTRAINT "FK_178199805b901ccd220ab7740ec"`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "deleted" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "deleted_at" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "deleted_by" integer`);
        await queryRunner.query(`ALTER TABLE "permission" ALTER COLUMN "ar_name" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "permission" ALTER COLUMN "en_name" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "permission" ALTER COLUMN "ar_module" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "permission" ALTER COLUMN "en_module" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "verified" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "active" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls_services" ALTER COLUMN "created_at" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls_services" ALTER COLUMN "created_at" SET DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "halls_services" ALTER COLUMN "updated_at" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls_services" ALTER COLUMN "updated_at" SET DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "bank" DROP CONSTRAINT "UQ_11f196da2e68cef1c7e84b4fe94"`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "created_at" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "created_at" SET DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "updated_at" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "updated_at" SET DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "deleted" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "hijri_date" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "payments" ALTER COLUMN "hijri_date" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "services" ALTER COLUMN "created_at" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "services" ALTER COLUMN "created_at" SET DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "services" ALTER COLUMN "updated_at" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "services" ALTER COLUMN "updated_at" SET DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "services" ALTER COLUMN "deleted" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "suppliers" ALTER COLUMN "active" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "file_upload_constants" DROP CONSTRAINT "UQ_d9822ddb0ca45d310ccd5d28b16"`);
        await queryRunner.query(`CREATE INDEX "IDX_178199805b901ccd220ab7740e" ON "role_permissions" ("role_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_17022daf3f885f7d35423e9971" ON "role_permissions" ("permission_id") `);
        await queryRunner.query(`ALTER TABLE "role" ADD CONSTRAINT "FK_7ec8b66943c6444ee369282c922" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "users" ADD CONSTRAINT "FK_a2cecd1a3531c0b041e29ba46e1" FOREIGN KEY ("role_id") REFERENCES "role"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD CONSTRAINT "FK_8bd1e59c6d787c231d6ad7ff2bc" FOREIGN KEY ("service_id") REFERENCES "services"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD CONSTRAINT "FK_ae436a243d71f744b8acb6c8e0f" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "bank" ADD CONSTRAINT "FK_60b5043586a71fb991b6e536475" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "FK_65f5f7fdebd59a3289ee2f77b73" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "FK_276896d1a1a30be6de9d7d43f53" FOREIGN KEY ("user_id") REFERENCES "halls_clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "FK_9cb7c87febae09510d0f4ff5c91" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "FK_bb6c39530593926e12d7616cb15" FOREIGN KEY ("event_type") REFERENCES "events"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "services" ADD CONSTRAINT "FK_458874e221f4ed82fa478b755d8" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "role_permissions" ADD CONSTRAINT "FK_178199805b901ccd220ab7740ec" FOREIGN KEY ("role_id") REFERENCES "role"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "role_permissions" ADD CONSTRAINT "FK_17022daf3f885f7d35423e9971e" FOREIGN KEY ("permission_id") REFERENCES "permission"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "role_permissions" DROP CONSTRAINT "FK_17022daf3f885f7d35423e9971e"`);
        await queryRunner.query(`ALTER TABLE "role_permissions" DROP CONSTRAINT "FK_178199805b901ccd220ab7740ec"`);
        await queryRunner.query(`ALTER TABLE "services" DROP CONSTRAINT "FK_458874e221f4ed82fa478b755d8"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "FK_bb6c39530593926e12d7616cb15"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "FK_9cb7c87febae09510d0f4ff5c91"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "FK_276896d1a1a30be6de9d7d43f53"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "FK_65f5f7fdebd59a3289ee2f77b73"`);
        await queryRunner.query(`ALTER TABLE "bank" DROP CONSTRAINT "FK_60b5043586a71fb991b6e536475"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP CONSTRAINT "FK_ae436a243d71f744b8acb6c8e0f"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP CONSTRAINT "FK_8bd1e59c6d787c231d6ad7ff2bc"`);
        await queryRunner.query(`ALTER TABLE "users" DROP CONSTRAINT "FK_a2cecd1a3531c0b041e29ba46e1"`);
        await queryRunner.query(`ALTER TABLE "role" DROP CONSTRAINT "FK_7ec8b66943c6444ee369282c922"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_17022daf3f885f7d35423e9971"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_178199805b901ccd220ab7740e"`);
        await queryRunner.query(`ALTER TABLE "file_upload_constants" ADD CONSTRAINT "UQ_d9822ddb0ca45d310ccd5d28b16" UNIQUE ("key")`);
        await queryRunner.query(`ALTER TABLE "suppliers" ALTER COLUMN "active" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "services" ALTER COLUMN "deleted" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "services" ALTER COLUMN "updated_at" SET DEFAULT CURRENT_TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "services" ALTER COLUMN "updated_at" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "services" ALTER COLUMN "created_at" SET DEFAULT CURRENT_TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "services" ALTER COLUMN "created_at" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "payments" ALTER COLUMN "hijri_date" SET DEFAULT NULL`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "hijri_date" SET DEFAULT NULL`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "deleted" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "updated_at" SET DEFAULT CURRENT_TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "updated_at" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "created_at" SET DEFAULT CURRENT_TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "created_at" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "bank" ADD CONSTRAINT "UQ_11f196da2e68cef1c7e84b4fe94" UNIQUE ("name")`);
        await queryRunner.query(`ALTER TABLE "halls_services" ALTER COLUMN "updated_at" SET DEFAULT CURRENT_TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "halls_services" ALTER COLUMN "updated_at" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls_services" ALTER COLUMN "created_at" SET DEFAULT CURRENT_TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "halls_services" ALTER COLUMN "created_at" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "active" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "verified" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "permission" ALTER COLUMN "en_module" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "permission" ALTER COLUMN "ar_module" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "permission" ALTER COLUMN "en_name" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "permission" ALTER COLUMN "ar_name" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "deleted_by"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "deleted_at"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "deleted"`);
        await queryRunner.query(`ALTER TABLE "role_permissions" ADD CONSTRAINT "FK_178199805b901ccd220ab7740ec" FOREIGN KEY ("role_id") REFERENCES "role"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "role_permissions" ADD CONSTRAINT "FK_17022daf3f885f7d35423e9971e" FOREIGN KEY ("permission_id") REFERENCES "permission"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "booking_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "halls_clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "booking_hall_id_fkey" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "booking_event_type_fkey" FOREIGN KEY ("event_type") REFERENCES "events"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "booking_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "bank" ADD CONSTRAINT "fk_client_id" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD CONSTRAINT "halls_services_service_id_fkey" FOREIGN KEY ("service_id") REFERENCES "services"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD CONSTRAINT "halls_services_hall_id_fkey" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "users" ADD CONSTRAINT "FK_8e3b9b5b2c2d7b6f3e3e4b3e1b4" FOREIGN KEY ("role_id", "client_id") REFERENCES "role"("id","id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "role" ADD CONSTRAINT "FK_8e3b9b5b2c2d7b6f3e3e4b3e1b4" FOREIGN KEY ("role_id", "client_id") REFERENCES "clients"("id","id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}
