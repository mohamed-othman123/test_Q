import { MigrationInterface, QueryRunner } from "typeorm";

export class DropColumsHallCustomer1729290466105 implements MigrationInterface {
    name = 'DropColumsHallCustomer1729290466105'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_customer" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "hall_customer" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "hall_customer" DROP COLUMN "deleted_at"`);
        await queryRunner.query(`ALTER TABLE "hall_customer" DROP COLUMN "deleted"`);
        await queryRunner.query(`ALTER TABLE "hall_customer" DROP COLUMN "deleted_by"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_customer" ADD "deleted_by" integer`);
        await queryRunner.query(`ALTER TABLE "hall_customer" ADD "deleted" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "hall_customer" ADD "deleted_at" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "hall_customer" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "hall_customer" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
    }

}
