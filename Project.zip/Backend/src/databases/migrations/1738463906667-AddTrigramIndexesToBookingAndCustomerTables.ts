import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddTrigramIndexesToBookingAndCustomerTables1738463906667
  implements MigrationInterface
{
  name = 'AddTrigramIndexesToBookingAndCustomerTables1738463906667';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking" DROP CONSTRAINT "UQ_1b26cef9409d01141c96c86cfa8"`,
    );
    await queryRunner.query(`CREATE EXTENSION IF NOT EXISTS pg_trgm;`);

    await queryRunner.query(`
                    CREATE INDEX idx_booking_reference_trgm 
                    ON booking USING GIN (booking_reference gin_trgm_ops);
                `);

    await queryRunner.query(`
                    CREATE INDEX idx_customer_phone_trgm 
                    ON halls_clients USING GIN (phone gin_trgm_ops);
                `);

    await queryRunner.query(`
                    CREATE INDEX idx_customer_email_trgm 
                    ON halls_clients USING GIN (email gin_trgm_ops);
                `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking" ADD CONSTRAINT "UQ_1b26cef9409d01141c96c86cfa8" UNIQUE ("booking_reference")`,
    );

    await queryRunner.query(`DROP INDEX IF EXISTS idx_booking_reference_trgm;`);
    await queryRunner.query(`DROP INDEX IF EXISTS idx_customer_phone_trgm;`);
    await queryRunner.query(`DROP INDEX IF EXISTS idx_customer_email_trgm;`);
  }
}
