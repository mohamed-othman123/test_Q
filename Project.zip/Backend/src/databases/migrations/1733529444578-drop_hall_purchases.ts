import { MigrationInterface, QueryRunner } from 'typeorm';

export class drop_hall_purchases1733529444578 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('hall_purchases');
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
