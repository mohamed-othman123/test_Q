import { MigrationInterface, QueryRunner } from 'typeorm';

export class DropBookingDate1741461483425 implements MigrationInterface {
  name = 'DropBookingDate1741461483425';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "booking_date"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "hijri_date"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" ADD "hijri_date" character varying(20)`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "booking_date" TIMESTAMP NOT NULL`);
  }
}
