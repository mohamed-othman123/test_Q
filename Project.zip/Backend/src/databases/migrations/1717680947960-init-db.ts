import { MigrationInterface, QueryRunner } from 'typeorm';

export class InitDb1717680947960 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    // create clients table
    await queryRunner.query(`
      CREATE TABLE clients (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        address VARCHAR(255) NOT NULL,
        cr_number VARCHAR(255) NOT NULL,
        vat_number VARCHAR(255) NOT NULL,
        phone VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        website VARCHAR(255) DEFAULT NULL,
        note TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
        deleted_at TIMESTAMP DEFAULT NULL,
        deleted BOOLEAN DEFAULT FALSE,
        deleted_by INT DEFAULT NULL
      );
    `);

    // drop users table
    await queryRunner.query(`
          DROP TABLE IF EXISTS users;
        `);
    // create users table
    await queryRunner.query(`
      CREATE TABLE users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        phone VARCHAR(255) NOT NULL,
        type VARCHAR(255) NOT NULL,
        notification_token VARCHAR(255) DEFAULT NULL,
        note TEXT DEFAULT NULL,
        client_id INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
        deleted_at TIMESTAMP DEFAULT NULL,
        deleted BOOLEAN DEFAULT FALSE,
        deleted_by INT DEFAULT NULL,
        FOREIGN KEY (client_id) REFERENCES clients(id)
      );
    `);

    // create halls table
    await queryRunner.query(`
      CREATE TABLE halls (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        location VARCHAR(255) NOT NULL,
        capacity INT NOT NULL,
        client_id INT NOT NULL,
        note TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
        deleted_at TIMESTAMP DEFAULT NULL,
        deleted BOOLEAN DEFAULT FALSE,
        deleted_by INT DEFAULT NULL,
        FOREIGN KEY (client_id) REFERENCES clients(id)
      );
    `);

    // create events table
    await queryRunner.query(`
      CREATE TABLE events (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        date DATE NOT NULL,
        start_time TIME NOT NULL,
        end_time TIME NOT NULL,
        hall_id INT NOT NULL,
        client_id INT NOT NULL,
        note TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
        deleted_at TIMESTAMP DEFAULT NULL,
        deleted BOOLEAN DEFAULT FALSE,
        deleted_by INT DEFAULT NULL,
        FOREIGN KEY (hall_id) REFERENCES halls(id),
        FOREIGN KEY (client_id) REFERENCES clients(id)
      );
    `);

    // create event_histories table
    await queryRunner.query(`
      CREATE TABLE event_histories (
        id SERIAL PRIMARY KEY,
        event_id INT NOT NULL,
        user_id INT NOT NULL,
        action VARCHAR(255) NOT NULL,
        note TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
        deleted_at TIMESTAMP DEFAULT NULL,
        deleted BOOLEAN DEFAULT FALSE,
        deleted_by INT DEFAULT NULL,
        FOREIGN KEY (event_id) REFERENCES events(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
      );
    `);

    // create packages table
    await queryRunner.query(`
      CREATE TABLE packages (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        period_ratio INT NOT NULL,
        note TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
        deleted_at TIMESTAMP DEFAULT NULL,
        deleted BOOLEAN DEFAULT FALSE,
        deleted_by INT DEFAULT NULL
      );
    `);

    // create services table
    await queryRunner.query(`
      CREATE TABLE services (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT DEFAULT NULL,
        type VARCHAR(255) NOT NULL,
        config JSON DEFAULT NULL,
        note TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
        deleted_at TIMESTAMP DEFAULT NULL,
        deleted BOOLEAN DEFAULT FALSE,
        deleted_by INT DEFAULT NULL
      );
    `);

    // create packages_services table
    await queryRunner.query(`
      CREATE TABLE packages_services (
        id SERIAL PRIMARY KEY,
        package_id INT NOT NULL,
        service_id INT NOT NULL,
        note TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
        deleted_at TIMESTAMP DEFAULT NULL,
        deleted BOOLEAN DEFAULT FALSE,
        deleted_by INT DEFAULT NULL,
        FOREIGN KEY (package_id) REFERENCES packages(id),
        FOREIGN KEY (service_id) REFERENCES services(id)
      );
    `);
    // create promo_codes table
    await queryRunner.query(`
      CREATE TABLE promo_codes (
        id SERIAL PRIMARY KEY,
        code VARCHAR(255) NOT NULL,
        type VARCHAR(255) NOT NULL,
        usage_limit INT NOT NULL,
        discount DECIMAL(10, 2) NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        note TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
        deleted_at TIMESTAMP DEFAULT NULL,
        deleted BOOLEAN DEFAULT FALSE,
        deleted_by INT DEFAULT NULL
      );
    `);
    // create subscriptions table
    await queryRunner.query(`
      CREATE TABLE subscriptions (
        id SERIAL PRIMARY KEY,
        client_id INT NOT NULL,
        package_id INT NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        note TEXT DEFAULT NULL,
        payment_status VARCHAR(255) NOT NULL,
        payment_method VARCHAR(255) NOT NULL,
        price DECIMAL(10, 2) NOT NULL,
        promo_code_id INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
        deleted_at TIMESTAMP DEFAULT NULL,
        deleted BOOLEAN DEFAULT FALSE,
        deleted_by INT DEFAULT NULL,
        FOREIGN KEY (client_id) REFERENCES clients(id),
        FOREIGN KEY (package_id) REFERENCES packages(id),
        FOREIGN KEY (promo_code_id) REFERENCES promo_codes(id)
      );
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DROP TABLE subscriptions;
      DROP TABLE promo_codes;
      DROP TABLE packages_services;
      DROP TABLE services;
      DROP TABLE packages;
      DROP TABLE event_histories;
      DROP TABLE events;
      DROP TABLE halls;
      DROP TABLE clients;
      DROP TABLE users;
    `);
  }
}
