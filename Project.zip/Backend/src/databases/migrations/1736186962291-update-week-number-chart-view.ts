import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateWeekNumberChartView1736186962291 implements MigrationInterface {
    name = 'UpdateWeekNumberChartView1736186962291'

    public async up(queryRunner: QueryRunner): Promise<void> {
//         await queryRunner.query(`DELETE FROM "typeorm_metadata" WHERE "type" = $1 AND "name" = $2 AND "schema" = $3`, ["VIEW","chart_view","public"]);
//         await queryRunner.query(`DROP VIEW "chart_view"`);
//         await queryRunner.query(`CREATE VIEW "chart_view" AS 
// WITH
//   weekly_data AS (
//     SELECT
//       b.hall_id,
//       DATE_TRUNC('week', b.booking_date) AS period,
//       COUNT(DISTINCT b.id) FILTER (
//         WHERE
//           b."bookingProcessStatus" != 'Canceled'
//       ) AS number_of_bookings,
//       0 AS total_revenue,
//       0 AS total_expenses
//     FROM
//       booking b
//     WHERE
//       b.booking_date <= NOW()
//       AND b.booking_date > NOW() - INTERVAL '12 weeks'
//     GROUP BY
//       DATE_TRUNC('week', b.booking_date),
//       b.hall_id
//     UNION ALL
//     SELECT
//       b.hall_id,
//       DATE_TRUNC('week', p.payment_date) AS period,
//       0 AS number_of_bookings,
//       SUM(
//         CASE
//           WHEN p."paymentType" = 'Income' THEN p.amount
//           ELSE 0
//         END
//       ) AS total_revenue,
//       SUM(
//         CASE
//           WHEN p."paymentType" = 'Refund' THEN p.amount
//           ELSE 0
//         END
//       ) AS total_expenses
//     FROM
//       payments p
//       LEFT JOIN booking b ON p.booking_id = b.id
//     WHERE
//       p.payment_date <= NOW()
//       AND p.payment_date > NOW() - INTERVAL '12 weeks'
//     GROUP BY
//       DATE_TRUNC('week', p.payment_date),
//       b.hall_id
//     UNION ALL
//     SELECT
//       p.hall_id,
//       DATE_TRUNC('week', pp.created_at) AS period,
//       0 AS number_of_bookings,
//       SUM(
//         CASE
//           WHEN pp."paymentType" = 'Refund' THEN pp.amount
//           ELSE 0
//         END
//       ) AS total_revenue,
//       SUM(
//         CASE
//           WHEN pp."paymentType" = 'Income' THEN pp.amount
//           ELSE 0
//         END
//       ) AS total_expenses
//     FROM
//       purchase_payments pp
//       JOIN purchases p ON pp.purchase_id = p.id
//     WHERE
//       pp.created_at <= NOW()
//       AND pp.created_at > NOW() - INTERVAL '12 weeks'
//     GROUP BY
//       DATE_TRUNC('week', pp.created_at),
//       p.hall_id
//   ),
//   monthly_data AS (
//     SELECT
//       b.hall_id,
//       DATE_TRUNC('month', b.booking_date) AS period,
//       COUNT(DISTINCT b.id) FILTER (
//         WHERE
//           b."bookingProcessStatus" != 'Canceled'
//       ) AS number_of_bookings,
//       0 AS total_revenue,
//       0 AS total_expenses
//     FROM
//       booking b
//     WHERE
//       b.booking_date <= NOW()
//       AND b.booking_date > NOW() - INTERVAL '12 months'
//     GROUP BY
//       DATE_TRUNC('month', b.booking_date),
//       b.hall_id
//     union ALL
//     SELECT
//       b.hall_id,
//       DATE_TRUNC('month', p.payment_date) AS period,
//       0 AS number_of_bookings,
//       SUM(
//         CASE
//           WHEN p."paymentType" = 'Income' THEN p.amount
//           ELSE 0
//         END
//       ) AS total_revenue,
//       SUM(
//         CASE
//           WHEN p."paymentType" = 'Refund' THEN p.amount
//           ELSE 0
//         END
//       ) AS total_expenses
//     FROM
//       payments p
//       LEFT JOIN booking b ON p.booking_id = b.id
//     WHERE
//       p.payment_date <= NOW()
//       AND p.payment_date > NOW() - INTERVAL '12 months'
//     GROUP BY
//       DATE_TRUNC('month', p.payment_date),
//       b.hall_id
//     UNION ALL
//     SELECT
//       p.hall_id,
//       DATE_TRUNC('month', pp.created_at) AS period,
//       0 AS number_of_bookings,
//       SUM(
//         CASE
//           WHEN pp."paymentType" = 'Refund' THEN pp.amount
//           ELSE 0
//         END
//       ) AS total_revenue,
//       SUM(
//         CASE
//           WHEN pp."paymentType" = 'Income' THEN pp.amount
//           ELSE 0
//         END
//       ) AS total_expenses
//     FROM
//       purchase_payments pp
//       JOIN purchases p ON pp.purchase_id = p.id
//     WHERE
//       pp.created_at <= NOW()
//       AND pp.created_at > NOW() - INTERVAL '12 months'
//     GROUP BY
//       DATE_TRUNC('month', pp.created_at),
//       p.hall_id
//   )
// SELECT
//   hall_id,
//   period,
//   0 AS month_number,
//   MOD(ABS(53 - EXTRACT(WEEK FROM period) - 12), 12) AS week_number,
//   SUM(number_of_bookings) AS number_of_bookings,
//   SUM(total_revenue) - (SUM(total_revenue) * 0.15) AS total_revenue,
//   SUM(total_expenses) - (SUM(total_expenses) * 0.15) AS total_expenses,
//   'weekly' AS interval_type
// FROM
//   weekly_data
// GROUP BY
//   period,
//   hall_id
// UNION ALL
// SELECT
//   hall_id,
//   period,
//   EXTRACT(
//     MONTH
//     FROM
//       period
//   ) AS month_number,
//   0 AS week_number,
//   SUM(number_of_bookings) AS number_of_bookings,
//   SUM(total_revenue) - (SUM(total_revenue) * 0.15) AS total_revenue,
//   SUM(total_expenses) - (SUM(total_expenses) * 0.15) AS total_expenses,
//   'monthly' AS interval_type
// FROM
//   monthly_data
// GROUP BY
//   period,
//   hall_id
// ORDER BY
//   period
//   `);
//         await queryRunner.query(`INSERT INTO "typeorm_metadata"("database", "schema", "table", "type", "name", "value") VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)`, ["public","VIEW","chart_view","WITH\n  weekly_data AS (\n    SELECT\n      b.hall_id,\n      DATE_TRUNC('week', b.booking_date) AS period,\n      COUNT(DISTINCT b.id) FILTER (\n        WHERE\n          b.\"bookingProcessStatus\" != 'Canceled'\n      ) AS number_of_bookings,\n      0 AS total_revenue,\n      0 AS total_expenses\n    FROM\n      booking b\n    WHERE\n      b.booking_date <= NOW()\n      AND b.booking_date > NOW() - INTERVAL '12 weeks'\n    GROUP BY\n      DATE_TRUNC('week', b.booking_date),\n      b.hall_id\n    UNION ALL\n    SELECT\n      b.hall_id,\n      DATE_TRUNC('week', p.payment_date) AS period,\n      0 AS number_of_bookings,\n      SUM(\n        CASE\n          WHEN p.\"paymentType\" = 'Income' THEN p.amount\n          ELSE 0\n        END\n      ) AS total_revenue,\n      SUM(\n        CASE\n          WHEN p.\"paymentType\" = 'Refund' THEN p.amount\n          ELSE 0\n        END\n      ) AS total_expenses\n    FROM\n      payments p\n      LEFT JOIN booking b ON p.booking_id = b.id\n    WHERE\n      p.payment_date <= NOW()\n      AND p.payment_date > NOW() - INTERVAL '12 weeks'\n    GROUP BY\n      DATE_TRUNC('week', p.payment_date),\n      b.hall_id\n    UNION ALL\n    SELECT\n      p.hall_id,\n      DATE_TRUNC('week', pp.created_at) AS period,\n      0 AS number_of_bookings,\n      SUM(\n        CASE\n          WHEN pp.\"paymentType\" = 'Refund' THEN pp.amount\n          ELSE 0\n        END\n      ) AS total_revenue,\n      SUM(\n        CASE\n          WHEN pp.\"paymentType\" = 'Income' THEN pp.amount\n          ELSE 0\n        END\n      ) AS total_expenses\n    FROM\n      purchase_payments pp\n      JOIN purchases p ON pp.purchase_id = p.id\n    WHERE\n      pp.created_at <= NOW()\n      AND pp.created_at > NOW() - INTERVAL '12 weeks'\n    GROUP BY\n      DATE_TRUNC('week', pp.created_at),\n      p.hall_id\n  ),\n  monthly_data AS (\n    SELECT\n      b.hall_id,\n      DATE_TRUNC('month', b.booking_date) AS period,\n      COUNT(DISTINCT b.id) FILTER (\n        WHERE\n          b.\"bookingProcessStatus\" != 'Canceled'\n      ) AS number_of_bookings,\n      0 AS total_revenue,\n      0 AS total_expenses\n    FROM\n      booking b\n    WHERE\n      b.booking_date <= NOW()\n      AND b.booking_date > NOW() - INTERVAL '12 months'\n    GROUP BY\n      DATE_TRUNC('month', b.booking_date),\n      b.hall_id\n    union ALL\n    SELECT\n      b.hall_id,\n      DATE_TRUNC('month', p.payment_date) AS period,\n      0 AS number_of_bookings,\n      SUM(\n        CASE\n          WHEN p.\"paymentType\" = 'Income' THEN p.amount\n          ELSE 0\n        END\n      ) AS total_revenue,\n      SUM(\n        CASE\n          WHEN p.\"paymentType\" = 'Refund' THEN p.amount\n          ELSE 0\n        END\n      ) AS total_expenses\n    FROM\n      payments p\n      LEFT JOIN booking b ON p.booking_id = b.id\n    WHERE\n      p.payment_date <= NOW()\n      AND p.payment_date > NOW() - INTERVAL '12 months'\n    GROUP BY\n      DATE_TRUNC('month', p.payment_date),\n      b.hall_id\n    UNION ALL\n    SELECT\n      p.hall_id,\n      DATE_TRUNC('month', pp.created_at) AS period,\n      0 AS number_of_bookings,\n      SUM(\n        CASE\n          WHEN pp.\"paymentType\" = 'Refund' THEN pp.amount\n          ELSE 0\n        END\n      ) AS total_revenue,\n      SUM(\n        CASE\n          WHEN pp.\"paymentType\" = 'Income' THEN pp.amount\n          ELSE 0\n        END\n      ) AS total_expenses\n    FROM\n      purchase_payments pp\n      JOIN purchases p ON pp.purchase_id = p.id\n    WHERE\n      pp.created_at <= NOW()\n      AND pp.created_at > NOW() - INTERVAL '12 months'\n    GROUP BY\n      DATE_TRUNC('month', pp.created_at),\n      p.hall_id\n  )\nSELECT\n  hall_id,\n  period,\n  0 AS month_number,\n  MOD(ABS(53 - EXTRACT(WEEK FROM period) - 12), 12) AS week_number,\n  SUM(number_of_bookings) AS number_of_bookings,\n  SUM(total_revenue) - (SUM(total_revenue) * 0.15) AS total_revenue,\n  SUM(total_expenses) - (SUM(total_expenses) * 0.15) AS total_expenses,\n  'weekly' AS interval_type\nFROM\n  weekly_data\nGROUP BY\n  period,\n  hall_id\nUNION ALL\nSELECT\n  hall_id,\n  period,\n  EXTRACT(\n    MONTH\n    FROM\n      period\n  ) AS month_number,\n  0 AS week_number,\n  SUM(number_of_bookings) AS number_of_bookings,\n  SUM(total_revenue) - (SUM(total_revenue) * 0.15) AS total_revenue,\n  SUM(total_expenses) - (SUM(total_expenses) * 0.15) AS total_expenses,\n  'monthly' AS interval_type\nFROM\n  monthly_data\nGROUP BY\n  period,\n  hall_id\nORDER BY\n  period"]);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
//         await queryRunner.query(`DELETE FROM "typeorm_metadata" WHERE "type" = $1 AND "name" = $2 AND "schema" = $3`, ["VIEW","chart_view","public"]);
//         await queryRunner.query(`DROP VIEW "chart_view"`);
//         await queryRunner.query(`CREATE VIEW "chart_view" AS WITH
//   weekly_data AS (
//     SELECT
//       b.hall_id,
//       DATE_TRUNC('week', b.booking_date) AS period,
//       COUNT(DISTINCT b.id) FILTER (
//         WHERE
//           b."bookingProcessStatus" != 'Canceled'
//       ) AS number_of_bookings,
//       0 AS total_revenue,
//       0 AS total_expenses
//     FROM
//       booking b
//     WHERE
//       b.booking_date <= NOW()
//       AND b.booking_date > NOW() - INTERVAL '12 weeks'
//     GROUP BY
//       DATE_TRUNC('week', b.booking_date),
//       b.hall_id
//     UNION ALL
//     SELECT
//       b.hall_id,
//       DATE_TRUNC('week', p.payment_date) AS period,
//       0 AS number_of_bookings,
//       SUM(
//         CASE
//           WHEN p."paymentType" = 'Income' THEN p.amount
//           ELSE 0
//         END
//       ) AS total_revenue,
//       SUM(
//         CASE
//           WHEN p."paymentType" = 'Refund' THEN p.amount
//           ELSE 0
//         END
//       ) AS total_expenses
//     FROM
//       payments p
//       LEFT JOIN booking b ON p.booking_id = b.id
//     WHERE
//       p.payment_date <= NOW()
//       AND p.payment_date >NOW() - INTERVAL '12 weeks'
//     GROUP BY
//       DATE_TRUNC('week', p.payment_date),
//       b.hall_id
//     UNION ALL
//     SELECT
//       p.hall_id,
//       DATE_TRUNC('week', pp.created_at) AS period,
//       0 AS number_of_bookings,
//       SUM(
//         CASE
//           WHEN pp."paymentType" = 'Refund' THEN pp.amount
//           ELSE 0
//         END
//       ) AS total_revenue,
//       SUM(
//         CASE
//           WHEN pp."paymentType" = 'Income' THEN pp.amount
//           ELSE 0
//         END
//       ) AS total_expenses
//     FROM
//       purchase_payments pp
//       JOIN purchases p ON pp.purchase_id = p.id
//     WHERE
//       pp.created_at <= NOW()
//       AND pp.created_at > NOW() - INTERVAL '12 weeks'
//     GROUP BY
//       DATE_TRUNC('week', pp.created_at),
//       p.hall_id
//   ),
//   monthly_data AS (
//     SELECT
//       b.hall_id,
//       DATE_TRUNC('month', b.booking_date) AS period,
//       COUNT(DISTINCT b.id) FILTER (
//         WHERE
//           b."bookingProcessStatus" != 'Canceled'
//       ) AS number_of_bookings,
//       0 AS total_revenue,
//       0 AS total_expenses
//     FROM
//       booking b
//     WHERE
//       b.booking_date <= NOW()
//       AND b.booking_date >NOW() - INTERVAL '12 months'
//     GROUP BY
//       DATE_TRUNC('month', b.booking_date),
//       b.hall_id
//     union ALL
//     SELECT
//       b.hall_id,
//       DATE_TRUNC('month', p.payment_date) AS period,
//       0 AS number_of_bookings,
//       SUM(
//         CASE
//           WHEN p."paymentType" = 'Income' THEN p.amount
//           ELSE 0
//         END
//       ) AS total_revenue,
//       SUM(
//         CASE
//           WHEN p."paymentType" = 'Refund' THEN p.amount
//           ELSE 0
//         END
//       ) AS total_expenses
//     FROM
//       payments p
//       LEFT JOIN booking b ON p.booking_id = b.id
//     WHERE
//       p.payment_date <= NOW()
//       AND p.payment_date > NOW() - INTERVAL '12 months'
//     GROUP BY
//       DATE_TRUNC('month', p.payment_date),
//       b.hall_id
//     UNION ALL
//     SELECT
//       p.hall_id,
//       DATE_TRUNC('month', pp.created_at) AS period,
//       0 AS number_of_bookings,
//       SUM(
//         CASE
//           WHEN pp."paymentType" = 'Refund' THEN pp.amount
//           ELSE 0
//         END
//       ) AS total_revenue,
//       SUM(
//         CASE
//           WHEN pp."paymentType" = 'Income' THEN pp.amount
//           ELSE 0
//         END
//       ) AS total_expenses
//     FROM
//       purchase_payments pp
//       JOIN purchases p ON pp.purchase_id = p.id
//     WHERE
//       pp.created_at <= NOW()
//       AND pp.created_at >NOW() - INTERVAL '12 months'
//     GROUP BY
//       DATE_TRUNC('month', pp.created_at),
//       p.hall_id
//   )
// SELECT
//   hall_id,
//   period,
//   0 AS month_number,
//   EXTRACT(
//     WEEK
//     FROM
//       period
//   ) - EXTRACT(
//     WEEK
//     FROM
//       DATE_TRUNC('week', NOW() - INTERVAL '11 weeks')
//   ) + 1 AS week_number,
//   SUM(number_of_bookings) AS number_of_bookings,
//   SUM(total_revenue) - (SUM(total_revenue) * 0.15) AS total_revenue,
//   SUM(total_expenses) - (SUM(total_expenses) * 0.15) AS total_expenses,
//   'weekly' AS interval_type
// FROM
//   weekly_data
// GROUP BY
//   period,
//   hall_id
// UNION ALL
// SELECT
//   hall_id,
//   period,
//   EXTRACT(MONTH FROM period) AS month_number,
//   0 AS week_number,
//   SUM(number_of_bookings) AS number_of_bookings,
//   SUM(total_revenue) - (SUM(total_revenue) * 0.15) AS total_revenue,
//   SUM(total_expenses) - (SUM(total_expenses) * 0.15) AS total_expenses,
//   'monthly' AS interval_type
// FROM
//   monthly_data
// GROUP BY
//   period,
//   hall_id
// ORDER BY
//   period`);
//         await queryRunner.query(`INSERT INTO "typeorm_metadata"("database", "schema", "table", "type", "name", "value") VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)`, ["public","VIEW","chart_view","WITH\n  weekly_data AS (\n    SELECT\n      b.hall_id,\n      DATE_TRUNC('week', b.booking_date) AS period,\n      COUNT(DISTINCT b.id) FILTER (\n        WHERE\n          b.\"bookingProcessStatus\" != 'Canceled'\n      ) AS number_of_bookings,\n      0 AS total_revenue,\n      0 AS total_expenses\n    FROM\n      booking b\n    WHERE\n      b.booking_date <= NOW()\n      AND b.booking_date > NOW() - INTERVAL '12 weeks'\n    GROUP BY\n      DATE_TRUNC('week', b.booking_date),\n      b.hall_id\n    UNION ALL\n    SELECT\n      b.hall_id,\n      DATE_TRUNC('week', p.payment_date) AS period,\n      0 AS number_of_bookings,\n      SUM(\n        CASE\n          WHEN p.\"paymentType\" = 'Income' THEN p.amount\n          ELSE 0\n        END\n      ) AS total_revenue,\n      SUM(\n        CASE\n          WHEN p.\"paymentType\" = 'Refund' THEN p.amount\n          ELSE 0\n        END\n      ) AS total_expenses\n    FROM\n      payments p\n      LEFT JOIN booking b ON p.booking_id = b.id\n    WHERE\n      p.payment_date <= NOW()\n      AND p.payment_date >NOW() - INTERVAL '12 weeks'\n    GROUP BY\n      DATE_TRUNC('week', p.payment_date),\n      b.hall_id\n    UNION ALL\n    SELECT\n      p.hall_id,\n      DATE_TRUNC('week', pp.created_at) AS period,\n      0 AS number_of_bookings,\n      SUM(\n        CASE\n          WHEN pp.\"paymentType\" = 'Refund' THEN pp.amount\n          ELSE 0\n        END\n      ) AS total_revenue,\n      SUM(\n        CASE\n          WHEN pp.\"paymentType\" = 'Income' THEN pp.amount\n          ELSE 0\n        END\n      ) AS total_expenses\n    FROM\n      purchase_payments pp\n      JOIN purchases p ON pp.purchase_id = p.id\n    WHERE\n      pp.created_at <= NOW()\n      AND pp.created_at > NOW() - INTERVAL '12 weeks'\n    GROUP BY\n      DATE_TRUNC('week', pp.created_at),\n      p.hall_id\n  ),\n  monthly_data AS (\n    SELECT\n      b.hall_id,\n      DATE_TRUNC('month', b.booking_date) AS period,\n      COUNT(DISTINCT b.id) FILTER (\n        WHERE\n          b.\"bookingProcessStatus\" != 'Canceled'\n      ) AS number_of_bookings,\n      0 AS total_revenue,\n      0 AS total_expenses\n    FROM\n      booking b\n    WHERE\n      b.booking_date <= NOW()\n      AND b.booking_date >NOW() - INTERVAL '12 months'\n    GROUP BY\n      DATE_TRUNC('month', b.booking_date),\n      b.hall_id\n    union ALL\n    SELECT\n      b.hall_id,\n      DATE_TRUNC('month', p.payment_date) AS period,\n      0 AS number_of_bookings,\n      SUM(\n        CASE\n          WHEN p.\"paymentType\" = 'Income' THEN p.amount\n          ELSE 0\n        END\n      ) AS total_revenue,\n      SUM(\n        CASE\n          WHEN p.\"paymentType\" = 'Refund' THEN p.amount\n          ELSE 0\n        END\n      ) AS total_expenses\n    FROM\n      payments p\n      LEFT JOIN booking b ON p.booking_id = b.id\n    WHERE\n      p.payment_date <= NOW()\n      AND p.payment_date > NOW() - INTERVAL '12 months'\n    GROUP BY\n      DATE_TRUNC('month', p.payment_date),\n      b.hall_id\n    UNION ALL\n    SELECT\n      p.hall_id,\n      DATE_TRUNC('month', pp.created_at) AS period,\n      0 AS number_of_bookings,\n      SUM(\n        CASE\n          WHEN pp.\"paymentType\" = 'Refund' THEN pp.amount\n          ELSE 0\n        END\n      ) AS total_revenue,\n      SUM(\n        CASE\n          WHEN pp.\"paymentType\" = 'Income' THEN pp.amount\n          ELSE 0\n        END\n      ) AS total_expenses\n    FROM\n      purchase_payments pp\n      JOIN purchases p ON pp.purchase_id = p.id\n    WHERE\n      pp.created_at <= NOW()\n      AND pp.created_at >NOW() - INTERVAL '12 months'\n    GROUP BY\n      DATE_TRUNC('month', pp.created_at),\n      p.hall_id\n  )\nSELECT\n  hall_id,\n  period,\n  0 AS month_number,\n  EXTRACT(\n    WEEK\n    FROM\n      period\n  ) - EXTRACT(\n    WEEK\n    FROM\n      DATE_TRUNC('week', NOW() - INTERVAL '11 weeks')\n  ) + 1 AS week_number,\n  SUM(number_of_bookings) AS number_of_bookings,\n  SUM(total_revenue) - (SUM(total_revenue) * 0.15) AS total_revenue,\n  SUM(total_expenses) - (SUM(total_expenses) * 0.15) AS total_expenses,\n  'weekly' AS interval_type\nFROM\n  weekly_data\nGROUP BY\n  period,\n  hall_id\nUNION ALL\nSELECT\n  hall_id,\n  period,\n  EXTRACT(MONTH FROM period) AS month_number,\n  0 AS week_number,\n  SUM(number_of_bookings) AS number_of_bookings,\n  SUM(total_revenue) - (SUM(total_revenue) * 0.15) AS total_revenue,\n  SUM(total_expenses) - (SUM(total_expenses) * 0.15) AS total_expenses,\n  'monthly' AS interval_type\nFROM\n  monthly_data\nGROUP BY\n  period,\n  hall_id\nORDER BY\n  period"]);
 }

}
