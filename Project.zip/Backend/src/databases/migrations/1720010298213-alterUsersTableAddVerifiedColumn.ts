import { MigrationInterface, QueryRunner } from 'typeorm';

export class AlterUsersTableAddVerifiedColumn1720010298213 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE users ADD COLUMN verified BOOLEAN DEFAULT FALSE`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE users DROP COLUMN verified`);
  }
}
