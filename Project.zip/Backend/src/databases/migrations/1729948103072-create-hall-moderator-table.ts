import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateHallModeratorTable1729948103072 implements MigrationInterface {
    name = 'CreateHallModeratorTable1729948103072'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "halls_moderator" ("id" SERIAL NOT NULL, "moderator_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "PK_da9ea40998dc285004195e0f642" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "halls_event" ADD "isAdmin" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "halls_moderator" ADD CONSTRAINT "FK_f90bf870488ff6493449b1ed95d" FOREIGN KEY ("moderator_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "halls_moderator" ADD CONSTRAINT "FK_bf46521b3df7211dc15c1fbc8fa" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_moderator" DROP CONSTRAINT "FK_bf46521b3df7211dc15c1fbc8fa"`);
        await queryRunner.query(`ALTER TABLE "halls_moderator" DROP CONSTRAINT "FK_f90bf870488ff6493449b1ed95d"`);
        await queryRunner.query(`ALTER TABLE "halls_event" DROP COLUMN "isAdmin"`);
        await queryRunner.query(`DROP TABLE "halls_moderator"`);
    }

}
