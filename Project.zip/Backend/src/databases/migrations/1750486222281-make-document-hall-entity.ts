import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeDocumentHallEntity1750486222281 implements MigrationInterface {
    name = 'MakeDocumentHallEntity1750486222281'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."hall_documents_document_type_enum" AS ENUM('General Expense Payment Receipt', 'Booking Payment Receipt', 'Purchase Expense Payment Receipt', 'Booking Refund Receipt', 'Expense Refund Receipt')`);
        await queryRunner.query(`CREATE TABLE "hall_documents" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "document_type" "public"."hall_documents_document_type_enum" NOT NULL, "name" character varying NOT NULL, "name_ar" character varying NOT NULL, "first_party_signature" boolean NOT NULL DEFAULT false, "first_party_stamp" boolean NOT NULL DEFAULT false, "second_party_signature" boolean NOT NULL DEFAULT false, "hallId" integer, CONSTRAINT "PK_be6b2ed04f93d2e937ca0c502ff" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "hall_documents" ADD CONSTRAINT "FK_2743dfa13015bbf1df8f9b265cc" FOREIGN KEY ("hallId") REFERENCES "halls"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_documents" DROP CONSTRAINT "FK_2743dfa13015bbf1df8f9b265cc"`);
        await queryRunner.query(`DROP TABLE "hall_documents"`);
        await queryRunner.query(`DROP TYPE "public"."hall_documents_document_type_enum"`);
    }

}
