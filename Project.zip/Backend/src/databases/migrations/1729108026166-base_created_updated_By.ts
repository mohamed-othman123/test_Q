import { MigrationInterface, QueryRunner } from 'typeorm';

export class BaseCreatedUpdatedBy1729108026166 implements MigrationInterface {
  name = 'BaseCreatedUpdatedBy1729108026166';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "events" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "events" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "halls_clients" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "halls_clients" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "payment_method" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "payment_method" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "bank" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "bank" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "payments" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "payments" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "services" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "services" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "halls_services" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "halls_services" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "halls" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "halls" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "role" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "role" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "contracts" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "contracts" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "clients" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "clients" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "users" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "users" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "purchase_items" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "purchase_items" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "purchases" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "purchases" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "suppliers" ADD "created_by" integer`);
    await queryRunner.query(`ALTER TABLE "suppliers" ADD "updated_by" integer`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "purchase_items" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "purchase_items" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "clients" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "clients" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "role" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "role" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "services" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "services" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "bank" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "bank" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "payment_method" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "payment_method" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "halls_clients" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "halls_clients" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "created_by"`);
  }
}
