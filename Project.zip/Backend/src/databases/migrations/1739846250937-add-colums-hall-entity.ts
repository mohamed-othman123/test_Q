import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumsHallEntity1739846250937 implements MigrationInterface {
    name = 'AddColumsHallEntity1739846250937'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" ADD "logo_url" text`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "primary_color" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "secondary_color" character varying(255)`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "secondary_color"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "primary_color"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "logo_url"`);
    }

}
