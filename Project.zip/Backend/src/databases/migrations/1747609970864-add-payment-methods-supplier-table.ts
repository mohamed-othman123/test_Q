import { MigrationInterface, QueryRunner } from "typeorm";

export class AddPaymentMethodsSupplierTable1747609970864 implements MigrationInterface {
    name = 'AddPaymentMethodsSupplierTable1747609970864'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "bankName"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "IBAN"`);
        await queryRunner.query(`CREATE TYPE "public"."suppliers_payment_method_type_enum" AS ENUM('bankAccount', 'eWallet', 'pos', 'cash')`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "payment_method_type" "public"."suppliers_payment_method_type_enum" NOT NULL DEFAULT 'cash'`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "bank_name" character varying`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "iban" character varying`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "account_number" character varying`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "ewallet_name" character varying`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "ewallet_phone" character varying`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "payment_method_notes" character varying`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "payment_method_notes"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "ewallet_phone"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "ewallet_name"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "account_number"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "iban"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "bank_name"`);
        await queryRunner.query(`ALTER TABLE "suppliers" DROP COLUMN "payment_method_type"`);
        await queryRunner.query(`DROP TYPE "public"."suppliers_payment_method_type_enum"`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "IBAN" character varying`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD "bankName" character varying`);
    }

}
