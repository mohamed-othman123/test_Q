import { MigrationInterface, QueryRunner } from 'typeorm';

export class PriceRequestsEventTime1742413294216 implements MigrationInterface {
  name = 'PriceRequestsEventTime1742413294216';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking_price_requests" ADD "event_time" character varying NOT NULL DEFAULT 'Full Day'`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking_price_requests" DROP COLUMN "event_time"`);
  }
}
