import { MigrationInterface, QueryRunner } from 'typeorm';

export class $npmConfigName1724950174775 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('ALTER TABLE "halls" ALTER COLUMN "capacity" DROP NOT NULL');
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
