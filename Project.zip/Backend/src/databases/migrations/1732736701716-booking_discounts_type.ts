import { MigrationInterface, QueryRunner } from "typeorm";

export class BookingDiscountsType1732736701716 implements MigrationInterface {
    name = 'BookingDiscountsType1732736701716'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "discountPercent"`);
        await queryRunner.query(`ALTER TABLE "booking" ADD "discount_value" integer NOT NULL DEFAULT '0'`);
        await queryRunner.query(`ALTER TABLE "booking" ADD "discount_type" character varying NOT NULL DEFAULT 'fixed'`);
        await queryRunner.query(`ALTER TABLE "booking" ADD "subtotal_after_disc" integer`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "subtotal_after_disc"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "discount_type"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "discount_value"`);
        await queryRunner.query(`ALTER TABLE "booking" ADD "discountPercent" integer NOT NULL`);
    }

}
