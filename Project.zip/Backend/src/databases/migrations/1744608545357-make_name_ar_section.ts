import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeNameArSection1744608545357 implements MigrationInterface {
    name = 'MakeNameArSection1744608545357'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_sections" ALTER COLUMN "name" SET NOT NULL`);
        await queryRunner.query(`UPDATE "hall_sections" SET "name_ar" = '' WHERE "name_ar" IS NULL`);
        await queryRunner.query(`ALTER TABLE "hall_sections" ALTER COLUMN "name_ar" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_sections" ALTER COLUMN "name_ar" SET DEFAULT ''`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_sections" ALTER COLUMN "name_ar" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "hall_sections" ALTER COLUMN "name_ar" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_sections" ALTER COLUMN "name" DROP NOT NULL`);
    }

}
