import { MigrationInterface, QueryRunner } from "typeorm";

export class AddOrderDocumentsEntity1750791007267 implements MigrationInterface {
    name = 'AddOrderDocumentsEntity1750791007267'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_documents" ADD "order" integer`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_documents" DROP COLUMN "order"`);
    }

}
