import { MigrationInterface, QueryRunner } from "typeorm";

export class AddSchedualDaysAutoCancelHallEntity1749833895267 implements MigrationInterface {
    name = 'AddSchedualDaysAutoCancelHallEntity1749833895267'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" ADD "auto_cancel_days_temp_bookings" integer`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "schedule_days" integer NOT NULL DEFAULT '1'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "schedule_days"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "auto_cancel_days_temp_bookings"`);
    }

}
