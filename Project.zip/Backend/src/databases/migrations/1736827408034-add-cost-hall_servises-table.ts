import { MigrationInterface, QueryRunner } from "typeorm";

export class AddCostHallServisesTable1736827408034 implements MigrationInterface {
    name = 'AddCostHallServisesTable1736827408034'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "cost" numeric(10,2) NOT NULL DEFAULT '0'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "cost"`);
    }

}
