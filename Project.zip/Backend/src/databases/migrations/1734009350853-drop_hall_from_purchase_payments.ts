import { MigrationInterface, QueryRunner } from 'typeorm';

export class DropHallFromPurchasePayments1734009350853 implements MigrationInterface {
  name = 'DropHallFromPurchasePayments1734009350853';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" DROP CONSTRAINT "FK_237d1076afe4dfadaaaea785bfc"`,
    );

    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "hall_id"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchase_payments" ADD "hall_id" integer NOT NULL`);

    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD CONSTRAINT "FK_237d1076afe4dfadaaaea785bfc" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }
}
