import { MigrationInterface, QueryRunner } from 'typeorm';

export class ExpensesTablesRename1746581088430 implements MigrationInterface {
  name = 'ExpensesTablesRename1746581088430';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchases" RENAME TO "expenses"`);
    await queryRunner.query(`ALTER TABLE "purchase_payments" RENAME TO "expenses_payments"`);
    await queryRunner.query(`ALTER TABLE "purchase_attachments" RENAME TO "expenses_attachments"`);
    await queryRunner.query(`ALTER TABLE "purchase_items" RENAME TO "expenses_details"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
