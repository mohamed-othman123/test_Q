import { MigrationInterface, QueryRunner } from "typeorm";

export class RemoveSecondSigntureContractSetting1744207444188 implements MigrationInterface {
    name = 'RemoveSecondSigntureContractSetting1744207444188'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "secondPartyName"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "secondPartySignature"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contracts" ADD "secondPartySignature" text`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "secondPartyName" character varying(255)`);
    }

}
