import { MigrationInterface, QueryRunner } from 'typeorm';

export class DropPaymentDatePurchase1734008919743 implements MigrationInterface {
  name = 'DropPaymentDatePurchase1734008919743';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "payment_date"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD "payment_date" TIMESTAMP NOT NULL`,
    );
  }
}
