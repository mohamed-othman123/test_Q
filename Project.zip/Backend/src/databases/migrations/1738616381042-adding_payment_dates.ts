import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddingPaymentDates1738616381042 implements MigrationInterface {
  name = 'AddingPaymentDates1738616381042';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD "hijri_date" character varying(20)`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD "payment_date" TIMESTAMP NOT NULL DEFAULT now()`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD "useGregorian" boolean NOT NULL DEFAULT true`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "useGregorian"`);
    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "payment_date"`);
    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "hijri_date"`);
  }
}
