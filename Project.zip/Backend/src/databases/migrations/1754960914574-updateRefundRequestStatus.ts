import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateRefundRequestStatus1754960914574 implements MigrationInterface {
  name = 'UpdateRefundRequestStatus1754960914574';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TYPE "public"."refund_requests_type_enum" RENAME TO "refund_requests_type_enum_old"`,
    );
    await queryRunner.query(
      `CREATE TYPE "public"."refund_requests_type_enum" AS ENUM('new', 'completed', 'in_progress', 'rejected')`,
    );
    await queryRunner.query(`ALTER TABLE "refund_requests" ALTER COLUMN "type" DROP DEFAULT`);
    // Change the enum type to text to accept all existing values
    await queryRunner.query(`ALTER TABLE "refund_requests" ALTER COLUMN "type" TYPE text`);
    await queryRunner.query(`
        UPDATE "refund_requests"
        SET "type" = CASE 
            WHEN "type" = 'canceled' THEN 'rejected'
            ELSE "type"
        END
        `);
    await queryRunner.query(
      `ALTER TABLE "refund_requests" ALTER COLUMN "type" TYPE "public"."refund_requests_type_enum" USING "type"::"text"::"public"."refund_requests_type_enum"`,
    );
    await queryRunner.query(`ALTER TABLE "refund_requests" ALTER COLUMN "type" SET DEFAULT 'new'`);
    await queryRunner.query(`DROP TYPE "public"."refund_requests_type_enum_old"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TYPE "public"."refund_requests_type_enum_old" AS ENUM('new', 'completed', 'in_progress', 'canceled')`,
    );
    await queryRunner.query(`ALTER TABLE "refund_requests" ALTER COLUMN "type" DROP DEFAULT`);
    await queryRunner.query(
      `ALTER TABLE "refund_requests" ALTER COLUMN "type" TYPE "public"."refund_requests_type_enum_old" USING "type"::"text"::"public"."refund_requests_type_enum_old"`,
    );
    await queryRunner.query(`ALTER TABLE "refund_requests" ALTER COLUMN "type" SET DEFAULT 'new'`);
    await queryRunner.query(`DROP TYPE "public"."refund_requests_type_enum"`);
    await queryRunner.query(
      `ALTER TYPE "public"."refund_requests_type_enum_old" RENAME TO "refund_requests_type_enum"`,
    );
  }
}
