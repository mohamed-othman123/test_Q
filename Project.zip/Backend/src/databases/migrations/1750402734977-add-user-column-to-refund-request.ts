import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddUserColumnToRefundRequest1750402734977 implements MigrationInterface {
  name = 'AddUserColumnToRefundRequest1750402734977';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "refund_requests" ADD "user_id" integer`);
    await queryRunner.query(
      `ALTER TABLE "refund_requests" ADD CONSTRAINT "FK_228d14156b20be394872d6c3aaa" FOREIGN KEY ("user_id") REFERENCES "halls_clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "refund_requests" DROP COLUMN "user_id"`);
  }
}
