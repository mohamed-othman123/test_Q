import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddBeneficiaryColumnsToRefundRequest1750419935116 implements MigrationInterface {
  name = 'AddBeneficiaryColumnsToRefundRequest1750419935116';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "refund_requests" ADD "beneficiary_type" "public"."beneficiary_type_enum" NOT NULL DEFAULT 'customer'`,
    );
    await queryRunner.query(`ALTER TABLE "refund_requests" ADD "beneficiary_name" text`);
    await queryRunner.query(`ALTER TABLE "refund_requests" ADD "beneficiary_mobile" text`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "refund_requests" DROP COLUMN "beneficiary_mobile"`);
    await queryRunner.query(`ALTER TABLE "refund_requests" DROP COLUMN "beneficiary_name"`);
    await queryRunner.query(`ALTER TABLE "refund_requests" DROP COLUMN "beneficiary_type"`);
  }
}
