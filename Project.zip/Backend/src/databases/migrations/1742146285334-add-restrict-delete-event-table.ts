import { MigrationInterface, QueryRunner } from "typeorm";

export class AddRestrictDeleteEventTable1742146285334 implements MigrationInterface {
    name = 'AddRestrictDeleteEventTable1742146285334'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contracts" DROP CONSTRAINT "FK_9ebe35e249c32fa290b0d344bd1"`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD CONSTRAINT "FK_9ebe35e249c32fa290b0d344bd1" FOREIGN KEY ("event_id") REFERENCES "events"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contracts" DROP CONSTRAINT "FK_9ebe35e249c32fa290b0d344bd1"`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD CONSTRAINT "FK_9ebe35e249c32fa290b0d344bd1" FOREIGN KEY ("event_id") REFERENCES "events"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

}
