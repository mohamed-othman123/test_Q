import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddRefundRequestsTable1750399801857 implements MigrationInterface {
  name = 'AddRefundRequestsTable1750399801857';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TYPE "public"."refund_requests_type_enum" AS ENUM('new', 'completed', 'rejected')`,
    );
    await queryRunner.query(
      `CREATE TABLE "refund_requests" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "amount" numeric(10,2) DEFAULT '0', "type" "public"."refund_requests_type_enum" NOT NULL DEFAULT 'new', "request_date" date NOT NULL, "notes" text, "hall_id" integer NOT NULL, "booking_id" integer, "payment_method_id" integer, "client_payment_method_id" integer, "client_id" integer, CONSTRAINT "REL_44c906e760a49973fd6140e9ac" UNIQUE ("client_payment_method_id"), CONSTRAINT "PK_00c88ecd40a63abe92a3dc69897" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `ALTER TABLE "refund_requests" ADD CONSTRAINT "FK_b898181fb67b6efb842b244a5c6" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "refund_requests" ADD CONSTRAINT "FK_066a7fa3eb766591653f587d396" FOREIGN KEY ("booking_id") REFERENCES "booking"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "refund_requests" ADD CONSTRAINT "FK_988d40f38a600daf0f692518262" FOREIGN KEY ("payment_method_id") REFERENCES "payment_method"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "refund_requests" ADD CONSTRAINT "FK_44c906e760a49973fd6140e9aca" FOREIGN KEY ("client_payment_method_id") REFERENCES "client_payment_methods"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
    await queryRunner.query(
      `ALTER TABLE "refund_requests" ADD CONSTRAINT "FK_70d89e3c3f505965e799e9600a7" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "refund_requests" DROP CONSTRAINT "FK_70d89e3c3f505965e799e9600a7"`,
    );
    await queryRunner.query(
      `ALTER TABLE "refund_requests" DROP CONSTRAINT "FK_44c906e760a49973fd6140e9aca"`,
    );
    await queryRunner.query(
      `ALTER TABLE "refund_requests" DROP CONSTRAINT "FK_988d40f38a600daf0f692518262"`,
    );
    await queryRunner.query(
      `ALTER TABLE "refund_requests" DROP CONSTRAINT "FK_066a7fa3eb766591653f587d396"`,
    );
    await queryRunner.query(
      `ALTER TABLE "refund_requests" DROP CONSTRAINT "FK_b898181fb67b6efb842b244a5c6"`,
    );
    await queryRunner.query(`DROP TABLE "refund_requests"`);
    await queryRunner.query(`DROP TYPE "public"."refund_requests_type_enum"`);
  }
}
