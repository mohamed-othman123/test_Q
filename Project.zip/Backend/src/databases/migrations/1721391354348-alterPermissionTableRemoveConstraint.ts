import { MigrationInterface, QueryRunner } from 'typeorm';

export class RemoveUniqueConstraint1721391354348 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const result = await queryRunner.query(`
      SELECT conname
      FROM pg_constraint
      INNER JOIN pg_class ON pg_constraint.conrelid = pg_class.oid
      INNER JOIN pg_attribute ON pg_attribute.attnum = ANY(pg_constraint.conkey) AND pg_attribute.attrelid = pg_class.oid
      WHERE pg_class.relname = 'permission'
      AND pg_constraint.contype = 'u'
      AND pg_attribute.attname = 'name';
    `);

    const constraintName = result[0]?.conname;
    if (constraintName) {
      await queryRunner.query(`ALTER TABLE "permission" DROP CONSTRAINT "${constraintName}"`);
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "permission" ADD CONSTRAINT "UQ_name" UNIQUE ("name")`);
  }
}
