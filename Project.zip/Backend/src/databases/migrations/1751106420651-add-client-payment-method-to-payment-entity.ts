import { MigrationInterface, QueryRunner } from "typeorm";

export class AddClientPaymentMethodToPaymentEntity1751106420651 implements MigrationInterface {
    name = 'AddClientPaymentMethodToPaymentEntity1751106420651'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payments" ADD "client_payment_method_id" integer`);
        await queryRunner.query(`ALTER TABLE "payments" ADD CONSTRAINT "UQ_f19d2309ac8dfc9d50ec68a45bf" UNIQUE ("client_payment_method_id")`);
        await queryRunner.query(`ALTER TABLE "payments" ADD CONSTRAINT "FK_f19d2309ac8dfc9d50ec68a45bf" FOREIGN KEY ("client_payment_method_id") REFERENCES "client_payment_methods"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "client_payment_method_id"`);
    }

}
