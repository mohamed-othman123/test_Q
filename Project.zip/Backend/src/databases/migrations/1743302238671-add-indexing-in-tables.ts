import { MigrationInterface, QueryRunner } from "typeorm";

export class AddIndexingInTables1743302238671 implements MigrationInterface {
    name = 'AddIndexingInTables1743302238671'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE INDEX "idx_payment_booking_id" ON "payments" ("booking_id") `);
        await queryRunner.query(`CREATE INDEX "idx_payment_client_id" ON "payments" ("client_id") `);
        await queryRunner.query(`CREATE INDEX "idx_payment_date" ON "payments" ("payment_date") `);
        await queryRunner.query(`CREATE INDEX "idx_booking_client_id" ON "booking" ("client_id") `);
        await queryRunner.query(`CREATE INDEX "idx_hall_id_booking" ON "booking" ("hall_id") `);
        await queryRunner.query(`CREATE INDEX "idx_booking_start_date" ON "booking" ("start_date") `);
        await queryRunner.query(`CREATE INDEX "idx_booking_end_date" ON "booking" ("end_date") `);
        await queryRunner.query(`CREATE INDEX "idx_purchase_payment_date" ON "purchase_payments" ("payment_date") `);
        await queryRunner.query(`CREATE INDEX "idx_purchase_id" ON "purchase_payments" ("purchase_id") `);
        await queryRunner.query(`CREATE INDEX "idx_purchase_payment_client_id" ON "purchase_payments" ("client_id") `);
        await queryRunner.query(`CREATE INDEX "idx_purchase_supplier_id" ON "purchases" ("supplier_id") `);
        await queryRunner.query(`CREATE INDEX "idx_purchase_hall_id" ON "purchases" ("hall_id") `);
        await queryRunner.query(`CREATE INDEX "idx_purchase_client_id" ON "purchases" ("client_id") `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP INDEX "public"."idx_purchase_client_id"`);
        await queryRunner.query(`DROP INDEX "public"."idx_purchase_hall_id"`);
        await queryRunner.query(`DROP INDEX "public"."idx_purchase_supplier_id"`);
        await queryRunner.query(`DROP INDEX "public"."idx_purchase_payment_client_id"`);
        await queryRunner.query(`DROP INDEX "public"."idx_purchase_id"`);
        await queryRunner.query(`DROP INDEX "public"."idx_purchase_payment_date"`);
        await queryRunner.query(`DROP INDEX "public"."idx_booking_end_date"`);
        await queryRunner.query(`DROP INDEX "public"."idx_booking_start_date"`);
        await queryRunner.query(`DROP INDEX "public"."idx_hall_id_booking"`);
        await queryRunner.query(`DROP INDEX "public"."idx_booking_client_id"`);
        await queryRunner.query(`DROP INDEX "public"."idx_payment_date"`);
        await queryRunner.query(`DROP INDEX "public"."idx_payment_client_id"`);
        await queryRunner.query(`DROP INDEX "public"."idx_payment_booking_id"`);
    }

}
