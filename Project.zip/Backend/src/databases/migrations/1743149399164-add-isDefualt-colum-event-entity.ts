import { MigrationInterface, QueryRunner } from "typeorm";

export class AddIsDefualtColumEventEntity1743149399164 implements MigrationInterface {
    name = 'AddIsDefualtColumEventEntity1743149399164'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "events" ADD "isDefault" boolean NOT NULL DEFAULT false`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "isDefault"`);
    }

}
