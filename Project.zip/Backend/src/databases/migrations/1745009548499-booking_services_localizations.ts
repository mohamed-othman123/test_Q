import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingServicesLocalizations1745009548499 implements MigrationInterface {
  name = 'BookingServicesLocalizations1745009548499';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking_services" ADD "name" character varying(255) NOT NULL DEFAULT ''`,
    );
    await queryRunner.query(
      `ALTER TABLE "booking_services" ADD "name_ar" character varying(255) NOT NULL DEFAULT ''`,
    );
    await queryRunner.query(
      `UPDATE booking_services bs 
       SET name = s.name,
           name_ar = s.name_ar
       FROM services s
       WHERE bs.service_id = s.id`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking_services" DROP COLUMN "name_ar"`);
    await queryRunner.query(`ALTER TABLE "booking_services" DROP COLUMN "name"`);
  }
}
