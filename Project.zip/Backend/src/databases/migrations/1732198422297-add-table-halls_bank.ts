import { MigrationInterface, QueryRunner } from "typeorm";

export class AddTableHallsBank1732198422297 implements MigrationInterface {
    name = 'AddTableHallsBank1732198422297'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "halls_bank" ("id" SERIAL NOT NULL, "bank_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "PK_d87094bfe192ddc179d5f9f1de6" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "halls_bank" ADD CONSTRAINT "FK_53760e1861274521f2fc9fc9a1d" FOREIGN KEY ("bank_id") REFERENCES "bank"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "halls_bank" ADD CONSTRAINT "FK_c424c245da8b098f11a4ed640b8" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_bank" DROP CONSTRAINT "FK_c424c245da8b098f11a4ed640b8"`);
        await queryRunner.query(`ALTER TABLE "halls_bank" DROP CONSTRAINT "FK_53760e1861274521f2fc9fc9a1d"`);
        await queryRunner.query(`DROP TABLE "halls_bank"`);
    }

}
