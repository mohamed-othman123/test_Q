import { MigrationInterface, QueryRunner } from "typeorm";

export class AddPriceCalculationTypeInEvent1746060157133 implements MigrationInterface {
    name = 'AddPriceCalculationTypeInEvent1746060157133'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."events_pricecalculationtype_enum" AS ENUM('FIXED_PRICE', 'PER_PERSON', 'BOOKING_TIME')`);
        await queryRunner.query(`ALTER TABLE "events" ADD "priceCalculationType" "public"."events_pricecalculationtype_enum" NOT NULL DEFAULT 'BOOKING_TIME'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "priceCalculationType"`);
        await queryRunner.query(`DROP TYPE "public"."events_pricecalculationtype_enum"`);
    }

}
