import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddBeneficiaryNameAndMobileToPaymentEntity1752077884288 implements MigrationInterface {
  name = 'AddBeneficiaryNameAndMobileToPaymentEntity1752077884288';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "payments" ADD "beneficiary_name" character varying`);
    await queryRunner.query(`ALTER TABLE "payments" ADD "beneficiary_mobile" character varying`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "beneficiary_mobile"`);
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "beneficiary_name"`);
  }
}
