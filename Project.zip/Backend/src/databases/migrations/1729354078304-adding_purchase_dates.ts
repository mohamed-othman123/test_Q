import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddingPurchaseDates1729354078304 implements MigrationInterface {
  name = 'AddingPurchaseDates1729354078304';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchases" ADD "invoiceReference" character varying NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "purchases" ADD "purchase_date" TIMESTAMP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "purchases" ADD "delivery_date" TIMESTAMP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "purchases" ADD "due_date" TIMESTAMP NOT NULL`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "due_date"`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "delivery_date"`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "purchase_date"`);
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "invoiceReference"`);
    await queryRunner.query(`ALTER TABLE "halls_event" DROP COLUMN "updated_by"`);
    await queryRunner.query(`ALTER TABLE "halls_event" DROP COLUMN "created_by"`);
    await queryRunner.query(`ALTER TABLE "halls_services" ADD "updated_by" integer`);
    await queryRunner.query(`ALTER TABLE "halls_services" ADD "created_by" integer`);
  }
}
