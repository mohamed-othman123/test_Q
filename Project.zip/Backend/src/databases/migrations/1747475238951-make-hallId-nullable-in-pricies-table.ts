import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeHallIdNullableInPriciesTable1747475238951 implements MigrationInterface {
    name = 'MakeHallIdNullableInPriciesTable1747475238951'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "regular_pricing" ALTER COLUMN "hall_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ALTER COLUMN "event_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ALTER COLUMN "hallId" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ALTER COLUMN "eventId" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ALTER COLUMN "id" DROP DEFAULT`);
        await queryRunner.query(`DROP SEQUENCE "regular_pricing_id_seq"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ALTER COLUMN "id" DROP DEFAULT`);
        await queryRunner.query(`DROP SEQUENCE "special_days_pricing_id_seq"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE SEQUENCE IF NOT EXISTS "special_days_pricing_id_seq" OWNED BY "special_days_pricing"."id"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ALTER COLUMN "id" SET DEFAULT nextval('"special_days_pricing_id_seq"')`);
        await queryRunner.query(`CREATE SEQUENCE IF NOT EXISTS "regular_pricing_id_seq" OWNED BY "regular_pricing"."id"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ALTER COLUMN "id" SET DEFAULT nextval('"regular_pricing_id_seq"')`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ALTER COLUMN "eventId" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ALTER COLUMN "hallId" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ALTER COLUMN "event_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ALTER COLUMN "hall_id" SET NOT NULL`);

    }

}
