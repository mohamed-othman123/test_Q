import { MigrationInterface, QueryRunner } from "typeorm";

export class AddProviderInformationHallServicesTable1736918662511 implements MigrationInterface {
    name = 'AddProviderInformationHallServicesTable1736918662511'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "thirdParty" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "providerName" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "providerEmail" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "providerPhone" character varying(255)`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "providerPhone"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "providerEmail"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "providerName"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "thirdParty"`);
    }

}
