import { MigrationInterface, QueryRunner } from "typeorm";

export class AddTotalTaxStatisticsView1735401441741 implements MigrationInterface {
    name = 'AddTotalTaxStatisticsView1735401441741'

    public async up(queryRunner: QueryRunner): Promise<void> {
//         await queryRunner.query(`DELETE FROM "typeorm_metadata" WHERE "type" = $1 AND "name" = $2 AND "schema" = $3`, ["VIEW","statistics_view","public"]);
//         await queryRunner.query(`DROP VIEW "statistics_view"`);
//         await queryRunner.query(`CREATE VIEW "statistics_view" AS 
// SELECT
//   h.id AS hall_id,
//   h.client_id AS client_id,
//   COALESCE(s.total_services, 0) AS total_services,
//   COALESCE(p.total_suppliers, 0) AS total_suppliers,
//   COALESCE(c.total_customers, 0) AS total_customers,
//   COALESCE(b.total_bookings, 0) AS total_bookings,
//   (
//     COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)
//   ) - (
//     COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)
//   ) * 0.15 AS total_income,
//   (
//     COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)
//   ) - (
//     COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)
//   ) * 0.15 AS total_refund,
//   (
//     (
//       COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)
//     ) - (
//       COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)
//     ) * 0.15
//   ) - (
//     (
//       COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)
//     ) - (
//       COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)
//     ) * 0.15
//   ) AS total_net,
//   ABS((
//     (
//       COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)
//     ) * 0.15 - (
//       COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)
//     ) * 0.15
//   )) AS total_tax
// FROM
//   halls h
//   LEFT JOIN (
//     SELECT
//       hall_id,
//       COUNT(*) AS total_services
//     FROM
//       halls_services
//     GROUP BY
//       hall_id
//   ) s ON h.id = s.hall_id
//   LEFT JOIN (
//     SELECT
//       hall_id,
//       COUNT(*) AS total_suppliers
//     FROM
//       halls_supplier
//     GROUP BY
//       hall_id
//   ) p ON h.id = p.hall_id
//   LEFT JOIN (
//     SELECT
//       hall_id,
//       COUNT(*) AS total_customers
//     FROM
//       hall_customer
//     GROUP BY
//       hall_id
//   ) c ON h.id = c.hall_id
//   LEFT JOIN (
//     SELECT
//       hall_id,
//       COUNT(booking.id) FILTER (
//         WHERE
//           booking."bookingProcessStatus" != 'Canceled'
//       ) AS total_bookings
//     FROM
//       booking
//     GROUP BY
//       hall_id
//   ) b ON h.id = b.hall_id
//   LEFT JOIN (
//     SELECT
//       booking.hall_id,
//       SUM(payment.amount) AS total_income
//     FROM
//       payments payment
//       JOIN booking ON payment.booking_id = booking.id
//     WHERE
//       payment."paymentType" = 'Income'
//     GROUP BY
//       booking.hall_id
//   ) income ON h.id = income.hall_id
//   LEFT JOIN (
//     SELECT
//       purchase.hall_id,
//       SUM(paymentPurchase.amount) AS purchase_total_income
//     FROM
//       purchase_payments paymentPurchase
//       JOIN purchases purchase ON paymentPurchase.purchase_id = purchase.id
//     WHERE
//       paymentPurchase."paymentType" = 'Income'
//     GROUP BY
//       purchase.hall_id
//   ) purchase_income ON h.id = purchase_income.hall_id
//   LEFT JOIN (
//     SELECT
//       booking.hall_id,
//       SUM(payment.amount) AS payment_total_refund
//     FROM
//       payments payment
//       JOIN booking ON payment.booking_id = booking.id
//     WHERE
//       payment."paymentType" = 'Refund'
//     GROUP BY
//       booking.hall_id
//   ) refund ON h.id = refund.hall_id
//   LEFT JOIN (
//     SELECT
//       purchase.hall_id,
//       SUM(paymentPurchase.amount) AS purchase_total_refund
//     FROM
//       purchase_payments paymentPurchase
//       JOIN purchases purchase ON paymentPurchase.purchase_id = purchase.id
//     WHERE
//       paymentPurchase."paymentType" = 'Refund'
//     GROUP BY
//       purchase.hall_id
//   ) purchase_refund ON h.id = purchase_refund.hall_id
// ORDER BY
//   hall_id;

//   `);
//         await queryRunner.query(`INSERT INTO "typeorm_metadata"("database", "schema", "table", "type", "name", "value") VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)`, ["public","VIEW","statistics_view","SELECT\n  h.id AS hall_id,\n  h.client_id AS client_id,\n  COALESCE(s.total_services, 0) AS total_services,\n  COALESCE(p.total_suppliers, 0) AS total_suppliers,\n  COALESCE(c.total_customers, 0) AS total_customers,\n  COALESCE(b.total_bookings, 0) AS total_bookings,\n  (\n    COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)\n  ) - (\n    COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)\n  ) * 0.15 AS total_income,\n  (\n    COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)\n  ) - (\n    COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)\n  ) * 0.15 AS total_refund,\n  (\n    (\n      COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)\n    ) - (\n      COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)\n    ) * 0.15\n  ) - (\n    (\n      COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)\n    ) - (\n      COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)\n    ) * 0.15\n  ) AS total_net,\n  ABS((\n    (\n      COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)\n    ) * 0.15 - (\n      COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)\n    ) * 0.15\n  )) AS total_tax\nFROM\n  halls h\n  LEFT JOIN (\n    SELECT\n      hall_id,\n      COUNT(*) AS total_services\n    FROM\n      halls_services\n    GROUP BY\n      hall_id\n  ) s ON h.id = s.hall_id\n  LEFT JOIN (\n    SELECT\n      hall_id,\n      COUNT(*) AS total_suppliers\n    FROM\n      halls_supplier\n    GROUP BY\n      hall_id\n  ) p ON h.id = p.hall_id\n  LEFT JOIN (\n    SELECT\n      hall_id,\n      COUNT(*) AS total_customers\n    FROM\n      hall_customer\n    GROUP BY\n      hall_id\n  ) c ON h.id = c.hall_id\n  LEFT JOIN (\n    SELECT\n      hall_id,\n      COUNT(booking.id) FILTER (\n        WHERE\n          booking.\"bookingProcessStatus\" != 'Canceled'\n      ) AS total_bookings\n    FROM\n      booking\n    GROUP BY\n      hall_id\n  ) b ON h.id = b.hall_id\n  LEFT JOIN (\n    SELECT\n      booking.hall_id,\n      SUM(payment.amount) AS total_income\n    FROM\n      payments payment\n      JOIN booking ON payment.booking_id = booking.id\n    WHERE\n      payment.\"paymentType\" = 'Income'\n    GROUP BY\n      booking.hall_id\n  ) income ON h.id = income.hall_id\n  LEFT JOIN (\n    SELECT\n      purchase.hall_id,\n      SUM(paymentPurchase.amount) AS purchase_total_income\n    FROM\n      purchase_payments paymentPurchase\n      JOIN purchases purchase ON paymentPurchase.purchase_id = purchase.id\n    WHERE\n      paymentPurchase.\"paymentType\" = 'Income'\n    GROUP BY\n      purchase.hall_id\n  ) purchase_income ON h.id = purchase_income.hall_id\n  LEFT JOIN (\n    SELECT\n      booking.hall_id,\n      SUM(payment.amount) AS payment_total_refund\n    FROM\n      payments payment\n      JOIN booking ON payment.booking_id = booking.id\n    WHERE\n      payment.\"paymentType\" = 'Refund'\n    GROUP BY\n      booking.hall_id\n  ) refund ON h.id = refund.hall_id\n  LEFT JOIN (\n    SELECT\n      purchase.hall_id,\n      SUM(paymentPurchase.amount) AS purchase_total_refund\n    FROM\n      purchase_payments paymentPurchase\n      JOIN purchases purchase ON paymentPurchase.purchase_id = purchase.id\n    WHERE\n      paymentPurchase.\"paymentType\" = 'Refund'\n    GROUP BY\n      purchase.hall_id\n  ) purchase_refund ON h.id = purchase_refund.hall_id\nORDER BY\n  hall_id;"]);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
//         await queryRunner.query(`DELETE FROM "typeorm_metadata" WHERE "type" = $1 AND "name" = $2 AND "schema" = $3`, ["VIEW","statistics_view","public"]);
//         await queryRunner.query(`DROP VIEW "statistics_view"`);
//         await queryRunner.query(`CREATE VIEW "statistics_view" AS SELECT
//   h.id AS hall_id,
//   h.client_id AS client_id,
//   COALESCE(s.total_services, 0) AS total_services,
//   COALESCE(p.total_suppliers, 0) AS total_suppliers,
//   COALESCE(c.total_customers, 0) AS total_customers,
//   COALESCE(b.total_bookings, 0) AS total_bookings,
//   (
//     COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)
//   ) - (
//     COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)
//   ) * 0.15 AS total_income,
//   (
//     COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)
//   ) - (
//     COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)
//   ) * 0.15 AS total_refund,
//   (
//     (
//       COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)
//     ) - (
//       COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)
//     ) * 0.15
//   ) - (
//     (
//       COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)
//     ) - (
//       COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)
//     ) * 0.15
//   ) AS total_net
// FROM
//   halls h
//   LEFT JOIN (
//     SELECT
//       hall_id,
//       COUNT(*) AS total_services
//     FROM
//       halls_services
//     GROUP BY
//       hall_id
//   ) s ON h.id = s.hall_id
//   LEFT JOIN (
//     SELECT
//       hall_id,
//       COUNT(*) AS total_suppliers
//     FROM
//       halls_supplier
//     GROUP BY
//       hall_id
//   ) p ON h.id = p.hall_id
//   LEFT JOIN (
//     SELECT
//       hall_id,
//       COUNT(*) AS total_customers
//     FROM
//       hall_customer
//     GROUP BY
//       hall_id
//   ) c ON h.id = c.hall_id
//   LEFT JOIN (
//     SELECT
//       hall_id,
//       COUNT(booking.id) FILTER (
//         WHERE
//           booking."bookingProcessStatus" != 'Canceled'
//       ) AS total_bookings
//     FROM
//       booking
//     GROUP BY
//       hall_id
//   ) b ON h.id = b.hall_id
//   LEFT JOIN (
//     SELECT
//       booking.hall_id,
//       SUM(payment.amount) AS total_income
//     FROM
//       payments payment
//       JOIN booking ON payment.booking_id = booking.id
//     WHERE
//       payment."paymentType" = 'Income'
//     GROUP BY
//       booking.hall_id
//   ) income ON h.id = income.hall_id
//   LEFT JOIN (
//     SELECT
//       purchase.hall_id,
//       SUM(paymentPurchase.amount) AS purchase_total_income
//     FROM
//       purchase_payments paymentPurchase
//       JOIN purchases purchase ON paymentPurchase.purchase_id = purchase.id
//     WHERE
//       paymentPurchase."paymentType" = 'Income'
//     GROUP BY
//       purchase.hall_id
//   ) purchase_income ON h.id = purchase_income.hall_id
//   LEFT JOIN (
//     SELECT
//       booking.hall_id,
//       SUM(payment.amount) AS payment_total_refund
//     FROM
//       payments payment
//       JOIN booking ON payment.booking_id = booking.id
//     WHERE
//       payment."paymentType" = 'Refund'
//     GROUP BY
//       booking.hall_id
//   ) refund ON h.id = refund.hall_id
//   LEFT JOIN (
//     SELECT
//       purchase.hall_id,
//       SUM(paymentPurchase.amount) AS purchase_total_refund
//     FROM
//       purchase_payments paymentPurchase
//       JOIN purchases purchase ON paymentPurchase.purchase_id = purchase.id
//     WHERE
//       paymentPurchase."paymentType" = 'Refund'
//     GROUP BY
//       purchase.hall_id
//   ) purchase_refund ON h.id = purchase_refund.hall_id
// ORDER BY

//   hall_id;`);
//         await queryRunner.query(`INSERT INTO "typeorm_metadata"("database", "schema", "table", "type", "name", "value") VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)`, ["public","VIEW","statistics_view","SELECT\n  h.id AS hall_id,\n  h.client_id AS client_id,\n  COALESCE(s.total_services, 0) AS total_services,\n  COALESCE(p.total_suppliers, 0) AS total_suppliers,\n  COALESCE(c.total_customers, 0) AS total_customers,\n  COALESCE(b.total_bookings, 0) AS total_bookings,\n  (\n    COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)\n  ) - (\n    COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)\n  ) * 0.15 AS total_income,\n  (\n    COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)\n  ) - (\n    COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)\n  ) * 0.15 AS total_refund,\n  (\n    (\n      COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)\n    ) - (\n      COALESCE(income.total_income, 0) + COALESCE(purchase_refund.purchase_total_refund, 0)\n    ) * 0.15\n  ) - (\n    (\n      COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)\n    ) - (\n      COALESCE(purchase_income.purchase_total_income, 0) + COALESCE(refund.payment_total_refund, 0)\n    ) * 0.15\n  ) AS total_net\nFROM\n  halls h\n  LEFT JOIN (\n    SELECT\n      hall_id,\n      COUNT(*) AS total_services\n    FROM\n      halls_services\n    GROUP BY\n      hall_id\n  ) s ON h.id = s.hall_id\n  LEFT JOIN (\n    SELECT\n      hall_id,\n      COUNT(*) AS total_suppliers\n    FROM\n      halls_supplier\n    GROUP BY\n      hall_id\n  ) p ON h.id = p.hall_id\n  LEFT JOIN (\n    SELECT\n      hall_id,\n      COUNT(*) AS total_customers\n    FROM\n      hall_customer\n    GROUP BY\n      hall_id\n  ) c ON h.id = c.hall_id\n  LEFT JOIN (\n    SELECT\n      hall_id,\n      COUNT(booking.id) FILTER (\n        WHERE\n          booking.\"bookingProcessStatus\" != 'Canceled'\n      ) AS total_bookings\n    FROM\n      booking\n    GROUP BY\n      hall_id\n  ) b ON h.id = b.hall_id\n  LEFT JOIN (\n    SELECT\n      booking.hall_id,\n      SUM(payment.amount) AS total_income\n    FROM\n      payments payment\n      JOIN booking ON payment.booking_id = booking.id\n    WHERE\n      payment.\"paymentType\" = 'Income'\n    GROUP BY\n      booking.hall_id\n  ) income ON h.id = income.hall_id\n  LEFT JOIN (\n    SELECT\n      purchase.hall_id,\n      SUM(paymentPurchase.amount) AS purchase_total_income\n    FROM\n      purchase_payments paymentPurchase\n      JOIN purchases purchase ON paymentPurchase.purchase_id = purchase.id\n    WHERE\n      paymentPurchase.\"paymentType\" = 'Income'\n    GROUP BY\n      purchase.hall_id\n  ) purchase_income ON h.id = purchase_income.hall_id\n  LEFT JOIN (\n    SELECT\n      booking.hall_id,\n      SUM(payment.amount) AS payment_total_refund\n    FROM\n      payments payment\n      JOIN booking ON payment.booking_id = booking.id\n    WHERE\n      payment.\"paymentType\" = 'Refund'\n    GROUP BY\n      booking.hall_id\n  ) refund ON h.id = refund.hall_id\n  LEFT JOIN (\n    SELECT\n      purchase.hall_id,\n      SUM(paymentPurchase.amount) AS purchase_total_refund\n    FROM\n      purchase_payments paymentPurchase\n      JOIN purchases purchase ON paymentPurchase.purchase_id = purchase.id\n    WHERE\n      paymentPurchase.\"paymentType\" = 'Refund'\n    GROUP BY\n      purchase.hall_id\n  ) purchase_refund ON h.id = purchase_refund.hall_id\nORDER BY\n\n  hall_id;"]);
 }

}
