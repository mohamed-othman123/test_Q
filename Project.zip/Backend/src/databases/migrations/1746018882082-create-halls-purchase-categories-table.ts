import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateHallsPurchaseCategoriesTable1746018882082 implements MigrationInterface {
  name = 'CreateHallsPurchaseCategoriesTable1746018882082';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "halls_purchase_categories" ("id" SERIAL NOT NULL, "purchase_category_id" integer NOT NULL, CONSTRAINT "PK_2a2296ff299355a43e41934ba50" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `ALTER TABLE "halls_purchase_categories" ADD CONSTRAINT "FK_6fa2777abbd8c1b44c312b0d9f9" FOREIGN KEY ("purchase_category_id") REFERENCES "purchase_categories"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "halls_purchase_categories" DROP CONSTRAINT "FK_6fa2777abbd8c1b44c312b0d9f9"`,
    );
    await queryRunner.query(`DROP TABLE "halls_purchase_categories"`);
  }
}
