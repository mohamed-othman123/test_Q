import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateRoles1727559355512 implements MigrationInterface {
  name = 'UpdateRoles1727559355512';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "role" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
    await queryRunner.query(`ALTER TABLE "role" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
    await queryRunner.query(`ALTER TABLE "role" ADD "deleted" boolean NOT NULL DEFAULT false`);
    await queryRunner.query(`ALTER TABLE "role" ADD "deleted_at" TIMESTAMP`);
    await queryRunner.query(`ALTER TABLE "role" ADD "deleted_by" integer`);
    await queryRunner.query(
      `ALTER TABLE "role" DROP CONSTRAINT IF EXISTS "UQ_ae4578dcaed5adff96595e61660"`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "role" DROP COLUMN "deleted_by"`);
    await queryRunner.query(`ALTER TABLE "role" DROP COLUMN "deleted_at"`);
    await queryRunner.query(`ALTER TABLE "role" DROP COLUMN "deleted"`);
    await queryRunner.query(`ALTER TABLE "role" DROP COLUMN "updated_at"`);
    await queryRunner.query(`ALTER TABLE "role" DROP COLUMN "created_at"`);
  }
}
