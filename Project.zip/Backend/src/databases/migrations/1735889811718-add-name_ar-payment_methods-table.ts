import { MigrationInterface, QueryRunner } from "typeorm";

export class AddNameArPaymentMethodsTable1735889811718 implements MigrationInterface {
    name = 'AddNameArPaymentMethodsTable1735889811718'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payment_method" ADD "name_ar" character varying NOT NULL DEFAULT ''`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payment_method" DROP COLUMN "name_ar"`);
    }

}
