import { MigrationInterface, QueryRunner } from "typeorm";

export class AddNameArRoleEntity1744200149394 implements MigrationInterface {
    name = 'AddNameArRoleEntity1744200149394'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "role" ADD "name_ar" character varying(255) NOT NULL DEFAULT ''`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "role" DROP COLUMN "name_ar"`);
    }

}
