import { MigrationInterface, QueryRunner } from "typeorm";

export class EditClientTable1728943358914 implements MigrationInterface {
    name = 'EditClientTable1728943358914'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "suppliers" DROP CONSTRAINT "FK_1eac3ac38b455af8345adf400c4"`);
        await queryRunner.query(`ALTER TABLE "suppliers" ALTER COLUMN "client_id" SET NOT NULL`);
        // await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "type"`);
        // await queryRunner.query(`CREATE TYPE "public"."users_type_enum" AS ENUM('Super Admin', 'Admin', 'Client Admin', 'Client Moderator', 'Customer')`);
        // await queryRunner.query(`ALTER TABLE "users" ADD "type" "public"."users_type_enum" NOT NULL DEFAULT 'Client Admin'`);
        // await queryRunner.query(`ALTER TABLE "services" ADD CONSTRAINT "FK_458874e221f4ed82fa478b755d8" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD CONSTRAINT "FK_1eac3ac38b455af8345adf400c4" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "suppliers" DROP CONSTRAINT "FK_1eac3ac38b455af8345adf400c4"`);
        await queryRunner.query(`ALTER TABLE "services" DROP CONSTRAINT "FK_458874e221f4ed82fa478b755d8"`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "type"`);
        await queryRunner.query(`DROP TYPE "public"."users_type_enum"`);
        await queryRunner.query(`ALTER TABLE "users" ADD "type" character varying(255) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "suppliers" ALTER COLUMN "client_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD CONSTRAINT "FK_1eac3ac38b455af8345adf400c4" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

}
