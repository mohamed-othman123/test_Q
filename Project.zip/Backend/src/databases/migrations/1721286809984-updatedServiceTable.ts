import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdatedServiceTable1721286809984 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS packages_services;`);
    await queryRunner.query(`
        ALTER TABLE services ADD COLUMN client_id INT NOT NULL;
        ALTER TABLE services DROP COLUMN  IF EXISTS config;
        ALTER TABLE services DROP COLUMN IF EXISTS type;
        `);

  
    await queryRunner.query(`
            CREATE TABLE  IF NOT EXISTS halls_services (
            id SERIAL PRIMARY KEY,
            hall_id INT NOT NULL,
            service_id INT NOT NULL,
            price INT NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ,
            FOREIGN KEY (hall_id) REFERENCES halls(id) ON DELETE CASCADE ON UPDATE CASCADE,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE ON UPDATE CASCADE
            );
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS halls_services;`);
    await queryRunner.query(`
            ALTER TABLE services DROP COLUMN client_id;
            ALTER TABLE services ADD COLUMN config JSON NOT NULL;
            ALTER TABLE services ADD COLUMN type VARCHAR(255) NOT NULL;
            `);
  }
}
