import { MigrationInterface, QueryRunner } from "typeorm";

export class AddingPurchaseStatus1729360078707 implements MigrationInterface {
    name = 'AddingPurchaseStatus1729360078707'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "purchases" ADD "status" character varying NOT NULL DEFAULT 'Partially Paid'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "status"`);
    }

}
