import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingContract1729945182226 implements MigrationInterface {
  name = 'BookingContract1729945182226';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" ADD "booking_contract" text`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "booking_contract"`);
  }
}
