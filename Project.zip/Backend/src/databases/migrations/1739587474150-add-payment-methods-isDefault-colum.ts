import { MigrationInterface, QueryRunner } from "typeorm";

export class AddPaymentMethodsIsDefaultColum1739587474150 implements MigrationInterface {
    name = 'AddPaymentMethodsIsDefaultColum1739587474150'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payment_method" ADD "isDefault" boolean NOT NULL DEFAULT false`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payment_method" DROP COLUMN "isDefault"`);
    }

}
