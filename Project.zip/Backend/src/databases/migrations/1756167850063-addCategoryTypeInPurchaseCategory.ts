import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddCategoryTypeInPurchaseCategory1756167850063 implements MigrationInterface {
  name = 'AddCategoryTypeInPurchaseCategory1756167850063';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TYPE "public"."purchase_categories_category_type_enum" AS ENUM('assets', 'general', 'inventory')`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_categories" ADD "category_type" "public"."purchase_categories_category_type_enum"`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchase_categories" DROP COLUMN "category_type"`);
    await queryRunner.query(`DROP TYPE "public"."purchase_categories_category_type_enum"`);
  }
}
