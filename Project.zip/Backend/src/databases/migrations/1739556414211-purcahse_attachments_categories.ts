import { MigrationInterface, QueryRunner } from 'typeorm';

export class PurcahseAttachmentsCategories1739556414211 implements MigrationInterface {
  name = 'PurcahseAttachmentsCategories1739556414211';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "attached"`);
    await queryRunner.query(
      `CREATE TABLE "purchase_attachments" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying NOT NULL, "path" text NOT NULL, "type" character varying NOT NULL, "purchase_id" integer NOT NULL, CONSTRAINT "PK_0cfaa642ea7adfc4d880585c68b" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "purchase_categories" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "arName" character varying NOT NULL, "enName" character varying NOT NULL, CONSTRAINT "PK_44593a99136cc4f6ba128e8f018" PRIMARY KEY ("id"))`,
    );

    await queryRunner.query(`ALTER TABLE "purchases" ADD "category_id" integer`);

    await queryRunner.query(
      `ALTER TABLE "purchase_attachments" ADD CONSTRAINT "FK_67b8fab99562f737cad7c3e9a49" FOREIGN KEY ("purchase_id") REFERENCES "purchases"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchases" ADD CONSTRAINT "FK_f9fcf50d684949f62c2cd07296e" FOREIGN KEY ("category_id") REFERENCES "purchase_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchases" DROP CONSTRAINT "FK_f9fcf50d684949f62c2cd07296e"`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_attachments" DROP CONSTRAINT "FK_67b8fab99562f737cad7c3e9a49"`,
    );

    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "category_id"`);
    await queryRunner.query(`ALTER TABLE "purchases" ADD "category_id" character varying`);
    await queryRunner.query(`DROP TABLE "purchase_categories"`);
    await queryRunner.query(`DROP TABLE "purchase_attachments"`);
  }
}
