import { MigrationInterface, QueryRunner } from "typeorm";

export class HallPurchases1729108337099 implements MigrationInterface {
    name = 'HallPurchases1729108337099'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "hall_purchases" ("hall_id" integer NOT NULL, "purchase_id" integer NOT NULL, CONSTRAINT "PK_a098f295447d65651da1865657e" PRIMARY KEY ("hall_id", "purchase_id"))`);
        await queryRunner.query(`ALTER TABLE "hall_purchases" ADD CONSTRAINT "FK_823a29806150ea3bda132d11791" FOREIGN KEY ("purchase_id") REFERENCES "purchases"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "hall_purchases" ADD CONSTRAINT "FK_b33137d9c7d1d0754f23a777172" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_purchases" DROP CONSTRAINT "FK_b33137d9c7d1d0754f23a777172"`);
        await queryRunner.query(`ALTER TABLE "hall_purchases" DROP CONSTRAINT "FK_823a29806150ea3bda132d11791"`);
        await queryRunner.query(`DROP TABLE "hall_purchases"`);
    }

}
