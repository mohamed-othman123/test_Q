import { MigrationInterface, QueryRunner } from "typeorm";

export class DropColumsHallSupplier1729290755680 implements MigrationInterface {
    name = 'DropColumsHallSupplier1729290755680'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_supplier" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "halls_supplier" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "halls_supplier" DROP COLUMN "deleted_at"`);
        await queryRunner.query(`ALTER TABLE "halls_supplier" DROP COLUMN "deleted"`);
        await queryRunner.query(`ALTER TABLE "halls_supplier" DROP COLUMN "deleted_by"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_supplier" ADD "deleted_by" integer`);
        await queryRunner.query(`ALTER TABLE "halls_supplier" ADD "deleted" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "halls_supplier" ADD "deleted_at" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "halls_supplier" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "halls_supplier" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
    }

}
