import { MigrationInterface, QueryRunner } from "typeorm";

export class AddDescriptionRoleTable1744009236645 implements MigrationInterface {
    name = 'AddDescriptionRoleTable1744009236645'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "role" ADD "description" character varying`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "role" DROP COLUMN "description"`);
    }

}
