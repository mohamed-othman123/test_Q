import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateBookingTables1723672783830 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "booking" (
        "id" SERIAL PRIMARY KEY,
        "client_id" INT NOT NULL,
        "user_id" INT NOT NULL,
        "hall_id" INT NOT NULL,
        "booking_date" TIMESTAMP NOT NULL,
        "event_type" INT NOT NULL,
        "attendeesType" VARCHAR NOT NULL,
        "fixedPrice" BOOLEAN NOT NULL,
        "attendeesNo" INT NOT NULL,
        "fixedBookingPrice" INT NOT NULL,
        "pricePerAttendee" INT NOT NULL,
        "subtotal" INT NOT NULL,
        "discountPercent" INT NOT NULL,
        "vat" INT NOT NULL,
        "totalPayable" INT NOT NULL,
        "bookingStatus" VARCHAR NOT NULL,
        "maleCoordinatorsNo" INT NOT NULL,
        "femaleCoordinatorsNo" INT NOT NULL,
        "notes"  VARCHAR,
        "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        "updated_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        "deleted_at" TIMESTAMP DEFAULT NULL,
        "deleted" BOOLEAN DEFAULT FALSE,
        "deleted_by" INT DEFAULT NULL,
        "hijri_date" VARCHAR(20) DEFAULT NULL, 
        FOREIGN KEY ("client_id") REFERENCES "clients"("id"),
        FOREIGN KEY ("user_id") REFERENCES "halls_clients"("id"),
        FOREIGN KEY ("hall_id") REFERENCES "halls"("id"),
        FOREIGN KEY ("event_type") REFERENCES "events"("id")
      );
    `);

    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "booking_services" (
        "id" SERIAL PRIMARY KEY,
        "booking_id" INT NOT NULL REFERENCES "booking"("id"),
        "service_id" INT NOT NULL REFERENCES "services"("id"),
        "servicePrice" INT NOT NULL
      );
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "booking_services";`);
    await queryRunner.query(`DROP TABLE IF EXISTS "booking";`);
  }
}
