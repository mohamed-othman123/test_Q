import { MigrationInterface, QueryRunner } from "typeorm";

export class AddTitleContractTable1742258903907 implements MigrationInterface {
    name = 'AddTitleContractTable1742258903907'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contracts" ADD "title_en" character varying`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "title_ar" character varying`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP CONSTRAINT "FK_9ebe35e249c32fa290b0d344bd1"`);
        await queryRunner.query(`ALTER TABLE "contracts" ALTER COLUMN "event_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD CONSTRAINT "FK_9ebe35e249c32fa290b0d344bd1" FOREIGN KEY ("event_id") REFERENCES "events"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contracts" DROP CONSTRAINT "FK_9ebe35e249c32fa290b0d344bd1"`);
        await queryRunner.query(`ALTER TABLE "contracts" ALTER COLUMN "event_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD CONSTRAINT "FK_9ebe35e249c32fa290b0d344bd1" FOREIGN KEY ("event_id") REFERENCES "events"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "title_ar"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "title_en"`);
    }

}
