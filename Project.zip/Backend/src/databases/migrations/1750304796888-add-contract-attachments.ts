import { MigrationInterface, QueryRunner } from "typeorm";

export class AddContractAttachments1750304796888 implements MigrationInterface {
    name = 'AddContractAttachments1750304796888'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "contract_attachments" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying NOT NULL, "path" text NOT NULL, "type" character varying NOT NULL, "contract_id" integer NOT NULL, CONSTRAINT "PK_8a74e4688f0cb80dcafcef5b351" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "contract_attachments" ADD CONSTRAINT "FK_bc3e07eb0dfb340ca0c70811614" FOREIGN KEY ("contract_id") REFERENCES "contracts"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contract_attachments" DROP CONSTRAINT "FK_bc3e07eb0dfb340ca0c70811614"`);
        await queryRunner.query(`DROP TABLE "contract_attachments"`);
    }

}
