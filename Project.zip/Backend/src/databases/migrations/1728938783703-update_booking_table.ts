import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateBookingTable1728938783703 implements MigrationInterface {
  name = 'UpdateBookingTable1728938783703';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "maleCoordinatorsNo"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "femaleCoordinatorsNo"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "bookingStatus"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
   
    await queryRunner.query(`ALTER TABLE "booking" ADD "bookingStatus" character varying NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "femaleCoordinatorsNo" integer NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "maleCoordinatorsNo" integer NOT NULL`);
  }
}
