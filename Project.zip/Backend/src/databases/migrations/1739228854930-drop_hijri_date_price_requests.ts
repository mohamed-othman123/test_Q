import { MigrationInterface, QueryRunner } from 'typeorm';

export class DropHijriDatePriceRequests1739228854930 implements MigrationInterface {
  name = 'DropHijriDatePriceRequests1739228854930';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking_price_requests" DROP COLUMN "event_hijri_date"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking_price_requests" ADD "event_hijri_date" character varying(20)`,
    );
  }
}
