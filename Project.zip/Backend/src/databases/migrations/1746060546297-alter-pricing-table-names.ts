import { MigrationInterface, QueryRunner } from "typeorm";

export class AlterPricingTableNames1746060546297 implements MigrationInterface {
    name = 'AlterPricingTableNames1746060546297'
    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE hall_pricing RENAME TO regular_pricing;`);
        await queryRunner.query(`ALTER TABLE hall_special_days_pricing RENAME TO special_days_pricing;`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE special_days_pricing RENAME TO hall_special_days_pricing;`);
        await queryRunner.query(`ALTER TABLE regular_pricing RENAME TO hall_pricing;`);
    }

}
