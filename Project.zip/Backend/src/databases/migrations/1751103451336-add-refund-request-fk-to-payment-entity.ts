import { MigrationInterface, QueryRunner } from "typeorm";

export class AddRefundRequestFkToPaymentEntity1751103451336 implements MigrationInterface {
    name = 'AddRefundRequestFkToPaymentEntity1751103451336'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payments" ADD "refund_request_id" integer`);
        await queryRunner.query(`ALTER TABLE "payments" ADD CONSTRAINT "UQ_ad7ca087489ac9e7cbeeac3843b" UNIQUE ("refund_request_id")`);
        await queryRunner.query(`ALTER TABLE "payments" ADD CONSTRAINT "FK_ad7ca087489ac9e7cbeeac3843b" FOREIGN KEY ("refund_request_id") REFERENCES "refund_requests"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "refund_request_id"`);
    }

}
