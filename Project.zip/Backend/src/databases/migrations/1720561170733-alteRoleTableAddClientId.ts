import { MigrationInterface, QueryRunner } from 'typeorm';

export class AlteRoleTableAddClientId1720561170733 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "role" ADD "client_id" integer`);
    await queryRunner.query(
      `ALTER TABLE "role" ADD CONSTRAINT "FK_8e3b9b5b2c2d7b6f3e3e4b3e1b4" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "role" DROP CONSTRAINT "FK_8e3b9b5b2c2d7b6f3e3e4b3e1b4"`);
    await queryRunner.query(`ALTER TABLE "role" DROP COLUMN "client_id"`);
  }
}
