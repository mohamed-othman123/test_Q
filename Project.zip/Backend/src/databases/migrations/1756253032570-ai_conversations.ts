import { MigrationInterface, QueryRunner } from 'typeorm';

export class AiConversations1756253032570 implements MigrationInterface {
  name = 'AiConversations1756253032570';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "ai_conversations" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "topic" text, "last_message_at" TIMESTAMP, "settings" jsonb, "summary" text, "thread_id" character varying, "client_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "PK_60db12765b82858ba00c8aa4ae2" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "ai_messages" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "sql" text, "user" text NOT NULL, "assistant" text NOT NULL, "conversation_id" integer NOT NULL, CONSTRAINT "PK_a390434d4a515ba18a41bc996c2" PRIMARY KEY ("id"))`,
    );

    await queryRunner.query(
      `ALTER TABLE "ai_conversations" ADD CONSTRAINT "FK_bf5d0af1111cf7ab0eb6aa57e81" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "ai_conversations" ADD CONSTRAINT "FK_c37c964b9bfff727665856fbd57" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "ai_messages" ADD CONSTRAINT "FK_de21fcb2d1df7fd6ca70f555b6d" FOREIGN KEY ("conversation_id") REFERENCES "ai_conversations"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
