import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateRoleTable1744356086710 implements MigrationInterface {
    name = 'UpdateRoleTable1744356086710'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "role" RENAME COLUMN "description" TO "notes"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "role" RENAME COLUMN "notes" TO "description"`);
       
    }

}
