import { MigrationInterface, QueryRunner } from 'typeorm';

export class ConvertBookingDatesToTypeDates1748385224796 implements MigrationInterface {
  name = 'ConvertBookingDatesToTypeDates1748385224796';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // First, get all dependent views
    const dependentViews = await queryRunner.query(`
      SELECT DISTINCT dependent_ns.nspname as dependent_schema,
      dependent_view.relname as dependent_view
      FROM pg_depend 
      JOIN pg_rewrite ON pg_depend.objid = pg_rewrite.oid 
      JOIN pg_class as dependent_view ON pg_rewrite.ev_class = dependent_view.oid 
      JOIN pg_class as source_table ON pg_depend.refobjid = source_table.oid 
      JOIN pg_namespace dependent_ns ON dependent_view.relnamespace = dependent_ns.oid 
      JOIN pg_namespace source_ns ON source_table.relnamespace = source_ns.oid 
      WHERE source_table.relname = 'booking' 
      AND pg_depend.refobjsubid = ANY(
        SELECT ordinal_position 
        FROM information_schema.columns 
        WHERE table_name = 'booking' 
        AND column_name IN ('start_date', 'end_date')
      );
    `);

    // Store view definitions
    const viewDefinitions = [];
    for (const view of dependentViews) {
      const definition = await queryRunner.query(`
        SELECT pg_get_viewdef('${view.dependent_schema}.${view.dependent_view}'::regclass) as definition;
      `);
      viewDefinitions.push({
        schema: view.dependent_schema,
        name: view.dependent_view,
        definition: definition[0].definition,
      });
    }

    // Drop dependent views
    for (const view of dependentViews) {
      await queryRunner.query(
        `DROP VIEW IF EXISTS "${view.dependent_schema}"."${view.dependent_view}" CASCADE;`,
      );
    }

    // Alter columns
    await queryRunner.query(
      `ALTER TABLE "booking" ALTER COLUMN "start_date" TYPE date USING start_date::date`,
    );
    await queryRunner.query(
      `ALTER TABLE "booking" ALTER COLUMN "end_date" TYPE date USING end_date::date`,
    );

    // Recreate views with modified definitions
    for (const view of viewDefinitions) {
      let modifiedDefinition = view.definition;

      // Special handling for calender_view
      if (view.name === 'calender_view') {
        modifiedDefinition = `
          WITH RECURSIVE date_range AS (
            SELECT 
              b.hall_id,
              b.start_date::timestamp as start_date,
              b.end_date::timestamp as end_date
            FROM booking b
            WHERE b."bookingProcessStatus"::text <> 'Canceled'::text
            UNION ALL
            SELECT 
              date_range_1.hall_id,
              (date_range_1.start_date + '1 day'::interval)::timestamp,
              date_range_1.end_date
            FROM date_range date_range_1
            WHERE (date_range_1.start_date + '1 day'::interval) <= date_range_1.end_date
          )
          SELECT 
            hall_id,
            start_date,
            end_date,
            EXTRACT(year FROM start_date)::integer AS booking_year,
            EXTRACT(month FROM start_date)::integer AS booking_month,
            EXTRACT(day FROM start_date)::integer AS booking_day
          FROM date_range;
        `;
      }

      await queryRunner.query(
        `CREATE VIEW "${view.schema}"."${view.name}" AS ${modifiedDefinition}`,
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Get all dependent views
    const dependentViews = await queryRunner.query(`
      SELECT DISTINCT dependent_ns.nspname as dependent_schema,
      dependent_view.relname as dependent_view
      FROM pg_depend 
      JOIN pg_rewrite ON pg_depend.objid = pg_rewrite.oid 
      JOIN pg_class as dependent_view ON pg_rewrite.ev_class = dependent_view.oid 
      JOIN pg_class as source_table ON pg_depend.refobjid = source_table.oid 
      JOIN pg_namespace dependent_ns ON dependent_view.relnamespace = dependent_ns.oid 
      JOIN pg_namespace source_ns ON source_table.relnamespace = source_ns.oid 
      WHERE source_table.relname = 'booking' 
      AND pg_depend.refobjsubid = ANY(
        SELECT ordinal_position 
        FROM information_schema.columns 
        WHERE table_name = 'booking' 
        AND column_name IN ('start_date', 'end_date')
      );
    `);

    // Store view definitions
    const viewDefinitions = [];
    for (const view of dependentViews) {
      const definition = await queryRunner.query(`
        SELECT pg_get_viewdef('${view.dependent_schema}.${view.dependent_view}'::regclass) as definition;
      `);
      viewDefinitions.push({
        schema: view.dependent_schema,
        name: view.dependent_view,
        definition: definition[0].definition,
      });
    }

    // Drop dependent views
    for (const view of dependentViews) {
      await queryRunner.query(
        `DROP VIEW IF EXISTS "${view.dependent_schema}"."${view.dependent_view}" CASCADE;`,
      );
    }

    // Revert columns back to timestamp
    await queryRunner.query(
      `ALTER TABLE "booking" ALTER COLUMN "start_date" TYPE timestamp USING start_date::timestamp`,
    );
    await queryRunner.query(
      `ALTER TABLE "booking" ALTER COLUMN "end_date" TYPE timestamp USING end_date::timestamp`,
    );

    // Recreate views with original definitions
    for (const view of viewDefinitions) {
      await queryRunner.query(`CREATE VIEW "${view.schema}"."${view.name}" AS ${view.definition}`);
    }
  }
}
