import { MigrationInterface, QueryRunner } from "typeorm";

export class AddTypeColumPermissionTable1739203567992 implements MigrationInterface {
    name = 'AddTypeColumPermissionTable1739203567992'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."permission_type_enum" AS ENUM('CREATE', 'READ', 'READONE', 'UPDATE', 'DELETE')`);
        await queryRunner.query(`ALTER TABLE "permission" ADD "type" "public"."permission_type_enum"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "permission" DROP COLUMN "type"`);
        await queryRunner.query(`DROP TYPE "public"."permission_type_enum"`);
    }

}
