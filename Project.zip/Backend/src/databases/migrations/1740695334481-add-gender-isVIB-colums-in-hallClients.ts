import { MigrationInterface, QueryRunner } from "typeorm";

export class AddGenderIsVIBColumsInHallClients1740695334481 implements MigrationInterface {
    name = 'AddGenderIsVIBColumsInHallClients1740695334481'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."halls_clients_gender_enum" AS ENUM('male', 'female', 'other')`);
        await queryRunner.query(`ALTER TABLE "halls_clients" ADD "gender" "public"."halls_clients_gender_enum" NOT NULL DEFAULT 'other'`);
        await queryRunner.query(`ALTER TABLE "halls_clients" ADD "isVIB" boolean NOT NULL DEFAULT false`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_clients" DROP COLUMN "isVIB"`);
        await queryRunner.query(`ALTER TABLE "halls_clients" DROP COLUMN "gender"`);
        await queryRunner.query(`DROP TYPE "public"."halls_clients_gender_enum"`);
    }

}
