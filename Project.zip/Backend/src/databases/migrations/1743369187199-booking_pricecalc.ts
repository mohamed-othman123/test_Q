import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingPricecalc1743369187199 implements MigrationInterface {
  name = 'BookingPricecalc1743369187199';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "pricing_type" character varying NOT NULL DEFAULT 'BOOKING_TIME'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" ADD "price_calculation_type" character varying`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "price_calculation_type"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "pricing_type"`);
  }
}
