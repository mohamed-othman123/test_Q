import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeLandingPageHaveSections1740353799438 implements MigrationInterface {
    name = 'MakeLandingPageHaveSections1740353799438'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "landing_popular_questions_section" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "question" text NOT NULL, "answer" text NOT NULL, "order" integer, "section_id" integer, CONSTRAINT "PK_378b5b6c4ea8060195e18f32bab" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "landing_features_section" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "icon" text, "title" character varying NOT NULL, "description" text NOT NULL, "order" integer, "section_id" integer, CONSTRAINT "PK_1723affd0637b38c1166aa85a37" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "landing_banners_section" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "path" text NOT NULL, "order" integer, "mimetype" character varying NOT NULL, "section_id" integer, CONSTRAINT "PK_6a710e7c7389743c28f205f06fe" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "landing_images_section" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "path" text NOT NULL, "mimetype" character varying NOT NULL, "order" integer, "section_id" integer, CONSTRAINT "PK_ec97a05f1d8f58f6abd8a660226" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "landing_social_Links_section" ("section_id" integer NOT NULL, "facebook" character varying, "instagram" character varying, "x" character varying, "snapChat" character varying, "tiktok" character varying, "linkedin" character varying, CONSTRAINT "PK_58cda996e4a7ed16916230c9ea3" PRIMARY KEY ("section_id"))`);
        await queryRunner.query(`CREATE TABLE "landing_customers_section" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying(255) NOT NULL, "imagePath" text NOT NULL, "imageMimeType" character varying NOT NULL, "site_url" character varying, "order" integer, "section_id" integer, CONSTRAINT "PK_2af1aa18437765e24095607f971" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TYPE "public"."hall_landing_page_sections_type_enum" AS ENUM('services', 'features', 'banners', 'images', 'popularQuestions', 'customers', 'socialLinks')`);
        await queryRunner.query(`CREATE TABLE "hall_landing_page_sections" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "title" character varying, "description" text, "order" integer, "type" "public"."hall_landing_page_sections_type_enum" NOT NULL, "services" text, "landingPageId" integer NOT NULL, CONSTRAINT "PK_841b5f99e59bf063107be6c4943" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "hall_landing_page" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "hall_name" character varying NOT NULL, "email" character varying NOT NULL, "phone" character varying NOT NULL, "about" text, "location" character varying, "mapLocation" jsonb, "client_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "REL_87e9d60735b79bd02968ff19fa" UNIQUE ("hall_id"), CONSTRAINT "PK_bd275db45e039354166d2f6f410" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "landing_popular_questions_section" ADD CONSTRAINT "FK_3790c34afd18a0f4a2e36e854c1" FOREIGN KEY ("section_id") REFERENCES "hall_landing_page_sections"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "landing_features_section" ADD CONSTRAINT "FK_6e7a63e31adf655d387a0a14905" FOREIGN KEY ("section_id") REFERENCES "hall_landing_page_sections"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "landing_banners_section" ADD CONSTRAINT "FK_690484883bcf02eb30e89d7a7d0" FOREIGN KEY ("section_id") REFERENCES "hall_landing_page_sections"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "landing_images_section" ADD CONSTRAINT "FK_d693a5305957cc515ccf644942a" FOREIGN KEY ("section_id") REFERENCES "hall_landing_page_sections"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "landing_social_Links_section" ADD CONSTRAINT "FK_58cda996e4a7ed16916230c9ea3" FOREIGN KEY ("section_id") REFERENCES "hall_landing_page_sections"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "landing_customers_section" ADD CONSTRAINT "FK_516510340ffa8410446e4a61388" FOREIGN KEY ("section_id") REFERENCES "hall_landing_page_sections"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" ADD CONSTRAINT "FK_e8a3a5e37c009d4105ddaa0a518" FOREIGN KEY ("landingPageId") REFERENCES "hall_landing_page"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page" ADD CONSTRAINT "FK_b49a14b03165dd5b739f6284ef0" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page" ADD CONSTRAINT "FK_87e9d60735b79bd02968ff19fad" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_landing_page" DROP CONSTRAINT "FK_87e9d60735b79bd02968ff19fad"`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page" DROP CONSTRAINT "FK_b49a14b03165dd5b739f6284ef0"`);
        await queryRunner.query(`ALTER TABLE "hall_landing_page_sections" DROP CONSTRAINT "FK_e8a3a5e37c009d4105ddaa0a518"`);
        await queryRunner.query(`ALTER TABLE "landing_customers_section" DROP CONSTRAINT "FK_516510340ffa8410446e4a61388"`);
        await queryRunner.query(`ALTER TABLE "landing_social_Links_section" DROP CONSTRAINT "FK_58cda996e4a7ed16916230c9ea3"`);
        await queryRunner.query(`ALTER TABLE "landing_images_section" DROP CONSTRAINT "FK_d693a5305957cc515ccf644942a"`);
        await queryRunner.query(`ALTER TABLE "landing_banners_section" DROP CONSTRAINT "FK_690484883bcf02eb30e89d7a7d0"`);
        await queryRunner.query(`ALTER TABLE "landing_features_section" DROP CONSTRAINT "FK_6e7a63e31adf655d387a0a14905"`);
        await queryRunner.query(`ALTER TABLE "landing_popular_questions_section" DROP CONSTRAINT "FK_3790c34afd18a0f4a2e36e854c1"`);
        await queryRunner.query(`DROP TABLE "hall_landing_page"`);
        await queryRunner.query(`DROP TABLE "hall_landing_page_sections"`);
        await queryRunner.query(`DROP TYPE "public"."hall_landing_page_sections_type_enum"`);
        await queryRunner.query(`DROP TABLE "landing_customers_section"`);
        await queryRunner.query(`DROP TABLE "landing_social_Links_section"`);
        await queryRunner.query(`DROP TABLE "landing_images_section"`);
        await queryRunner.query(`DROP TABLE "landing_banners_section"`);
        await queryRunner.query(`DROP TABLE "landing_features_section"`);
        await queryRunner.query(`DROP TABLE "landing_popular_questions_section"`);
    }

}
