import { MigrationInterface, QueryRunner } from "typeorm";

export class RefactoringPricesTable1748464012599 implements MigrationInterface {
    name = 'RefactoringPricesTable1748464012599'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP CONSTRAINT "FK_accd77efa56080c101ca3da72ce"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP CONSTRAINT "FK_d5b4c4ae204aadf15c9c075ba68"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP CONSTRAINT "FK_58d2e16a80a24b7c917a0e079d3"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP CONSTRAINT "FK_6c34b643e669d67f158b0780e29"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP COLUMN "morningPrice"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP COLUMN "eveningPrice"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP COLUMN "fullDayPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "mondayMorningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "mondayEveningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "mondayFullDayPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "tuesdayMorningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "tuesdayEveningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "tuesdayFullDayPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "wednesdayMorningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "wednesdayEveningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "wednesdayFullDayPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "thursdayMorningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "thursdayEveningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "thursdayFullDayPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "fridayMorningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "fridayEveningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "fridayFullDayPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "saturdayMorningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "saturdayEveningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "saturdayFullDayPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "sundayMorningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "sundayEveningPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "sundayFullDayPrice"`);
        await queryRunner.query(`CREATE TYPE "public"."special_days_pricing_timeperiod_enum" AS ENUM('morning', 'evening', 'fullDay')`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD "timePeriod" "public"."special_days_pricing_timeperiod_enum" NOT NULL`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD "fixedPrice" numeric(10,2)`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD "menPrice" numeric(10,2)`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD "womenPrice" numeric(10,2)`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD "isFixed" boolean NOT NULL DEFAULT true`);
        await queryRunner.query(`CREATE TYPE "public"."regular_pricing_dayofweek_enum" AS ENUM('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday')`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "dayOfWeek" "public"."regular_pricing_dayofweek_enum" NOT NULL`);
        await queryRunner.query(`CREATE TYPE "public"."regular_pricing_timeperiod_enum" AS ENUM('morning', 'evening', 'fullDay')`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "timePeriod" "public"."regular_pricing_timeperiod_enum" NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "fixedPrice" numeric(10,2)`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "menPrice" numeric(10,2)`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "womenPrice" numeric(10,2)`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "isFixed" boolean NOT NULL DEFAULT true`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP CONSTRAINT "REL_d9abaf324b0de7f72e796a843b"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP CONSTRAINT "UQ_c10028f4515180d889fab89f165"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD CONSTRAINT "FK_d5b4c4ae204aadf15c9c075ba68" FOREIGN KEY ("hallId") REFERENCES "halls"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD CONSTRAINT "FK_accd77efa56080c101ca3da72ce" FOREIGN KEY ("eventId") REFERENCES "events"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD CONSTRAINT "FK_6c34b643e669d67f158b0780e29" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD CONSTRAINT "FK_58d2e16a80a24b7c917a0e079d3" FOREIGN KEY ("event_id") REFERENCES "events"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP CONSTRAINT "FK_58d2e16a80a24b7c917a0e079d3"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP CONSTRAINT "FK_6c34b643e669d67f158b0780e29"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP CONSTRAINT "FK_accd77efa56080c101ca3da72ce"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP CONSTRAINT "FK_d5b4c4ae204aadf15c9c075ba68"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD CONSTRAINT "UQ_c10028f4515180d889fab89f165" UNIQUE ("event_id")`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD CONSTRAINT "REL_d9abaf324b0de7f72e796a843b" UNIQUE ("hall_id")`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "isFixed"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "womenPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "menPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "fixedPrice"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "timePeriod"`);
        await queryRunner.query(`DROP TYPE "public"."regular_pricing_timeperiod_enum"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP COLUMN "dayOfWeek"`);
        await queryRunner.query(`DROP TYPE "public"."regular_pricing_dayofweek_enum"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP COLUMN "isFixed"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP COLUMN "womenPrice"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP COLUMN "menPrice"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP COLUMN "fixedPrice"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP COLUMN "timePeriod"`);
        await queryRunner.query(`DROP TYPE "public"."special_days_pricing_timeperiod_enum"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "sundayFullDayPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "sundayEveningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "sundayMorningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "saturdayFullDayPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "saturdayEveningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "saturdayMorningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "fridayFullDayPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "fridayEveningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "fridayMorningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "thursdayFullDayPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "thursdayEveningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "thursdayMorningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "wednesdayFullDayPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "wednesdayEveningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "wednesdayMorningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "tuesdayFullDayPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "tuesdayEveningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "tuesdayMorningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "mondayFullDayPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "mondayEveningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD "mondayMorningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD "fullDayPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD "eveningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD "morningPrice" numeric(10,2) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD CONSTRAINT "FK_6c34b643e669d67f158b0780e29" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD CONSTRAINT "FK_58d2e16a80a24b7c917a0e079d3" FOREIGN KEY ("event_id") REFERENCES "events"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD CONSTRAINT "FK_d5b4c4ae204aadf15c9c075ba68" FOREIGN KEY ("hallId") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD CONSTRAINT "FK_accd77efa56080c101ca3da72ce" FOREIGN KEY ("eventId") REFERENCES "events"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

}
