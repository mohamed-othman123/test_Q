import { MigrationInterface, QueryRunner } from "typeorm";

export class RemoveUnitsPurchasesItems1729260485421 implements MigrationInterface {
    name = 'RemoveUnitsPurchasesItems1729260485421'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "purchase_items" DROP COLUMN "unit"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "purchase_items" ADD "unit" character varying`);
    }

}
