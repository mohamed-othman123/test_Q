import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingFoodTime1753122460098 implements MigrationInterface {
  name = 'BookingFoodTime1753122460098';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "set_food_time" boolean NOT NULL DEFAULT false`,
    );
    await queryRunner.query(`ALTER TABLE "booking" ADD "food_time" character varying`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "food_time"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "set_food_time"`);
  }
}
