import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdatePermitionsTable1744533661831 implements MigrationInterface {
    name = 'UpdatePermitionsTable1744533661831'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" RENAME COLUMN "sendingTime" TO "sending_time"`);
        await queryRunner.query(`ALTER TABLE "permission" ADD "key" character varying`);
        await queryRunner.query(`ALTER TABLE "permission" ADD "order" integer`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "sending_time" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "sending_time" SET DEFAULT '8:00 AM'`);
        await queryRunner.query(`ALTER TABLE "permission" ALTER COLUMN "type" SET NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "permission" ALTER COLUMN "type" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "sending_time" SET DEFAULT '12:00 AM'`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "sending_time" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "permission" DROP COLUMN "order"`);
        await queryRunner.query(`ALTER TABLE "permission" DROP COLUMN "key"`);
        await queryRunner.query(`ALTER TABLE "halls" RENAME COLUMN "sending_time" TO "sendingTime"`);
    }

}
