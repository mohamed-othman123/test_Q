import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingSerialNumber1728988395322 implements MigrationInterface {
  name = 'BookingSerialNumber1728988395322';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" ADD "serial_number" int`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "booking_reference" character varying(50)`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD CONSTRAINT "UQ_1b26cef9409d01141c96c86cfa8" UNIQUE ("booking_reference")`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking" DROP CONSTRAINT "UQ_1b26cef9409d01141c96c86cfa8"`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "booking_reference"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "serial_number"`);
  }
}
