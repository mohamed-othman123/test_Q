import { MigrationInterface, QueryRunner } from "typeorm";

export class RemoveBookingDateCalenderView1740285345604 implements MigrationInterface {
    name = 'RemoveBookingDateCalenderView1740285345604'

    public async up(queryRunner: QueryRunner): Promise<void> {
//         await queryRunner.query(`DELETE FROM "typeorm_metadata" WHERE "type" = $1 AND "name" = $2 AND "schema" = $3`, ["VIEW","calender_view","public"]);
//         await queryRunner.query(`DROP VIEW "calender_view"`);
//         await queryRunner.query(`CREATE VIEW "calender_view" AS 
// WITH RECURSIVE date_range AS (
//     SELECT
//         b.hall_id,
//         b.start_date,
//         b.end_date
//     FROM
//         booking b
//     WHERE
//         b."bookingProcessStatus" != 'Canceled'

//     UNION ALL

//     SELECT
//         hall_id,
//         start_date + INTERVAL '1 day',
//         end_date
//     FROM
//         date_range
//     WHERE
//         start_date + INTERVAL '1 day' <= end_date
// )

// SELECT
//     hall_id,
//     start_date,
//     end_date,
//     EXTRACT(YEAR FROM start_date)::INTEGER AS booking_year,
//     EXTRACT(MONTH FROM start_date)::INTEGER AS booking_month,
//     EXTRACT(DAY FROM start_date)::INTEGER AS booking_day
// FROM
//     date_range;
//   `);
//         await queryRunner.query(`INSERT INTO "typeorm_metadata"("database", "schema", "table", "type", "name", "value") VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)`, ["public","VIEW","calender_view","WITH RECURSIVE date_range AS (\n    SELECT\n        b.hall_id,\n        b.start_date,\n        b.end_date\n    FROM\n        booking b\n    WHERE\n        b.\"bookingProcessStatus\" != 'Canceled'\n\n    UNION ALL\n\n    SELECT\n        hall_id,\n        start_date + INTERVAL '1 day',\n        end_date\n    FROM\n        date_range\n    WHERE\n        start_date + INTERVAL '1 day' <= end_date\n)\n\nSELECT\n    hall_id,\n    start_date,\n    end_date,\n    EXTRACT(YEAR FROM start_date)::INTEGER AS booking_year,\n    EXTRACT(MONTH FROM start_date)::INTEGER AS booking_month,\n    EXTRACT(DAY FROM start_date)::INTEGER AS booking_day\nFROM\n    date_range;"]);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
//         await queryRunner.query(`DELETE FROM "typeorm_metadata" WHERE "type" = $1 AND "name" = $2 AND "schema" = $3`, ["VIEW","calender_view","public"]);
//         await queryRunner.query(`DROP VIEW "calender_view"`);
//         await queryRunner.query(`CREATE VIEW "calender_view" AS SELECT
//   b.hall_id,
//   b.start_date,
//   b.end_date,
//   EXTRACT(
//     YEAR
//     FROM
//       b.start_date
//   )::INTEGER AS booking_year,
//   EXTRACT(
//     MONTH
//     FROM
//       b.start_date
//   )::INTEGER AS booking_month,
//    EXTRACT(
//     Day
//     FROM
//       b.start_date
//   )::INTEGER AS booking_day
// FROM
//   booking b
// WHERE
//   b."bookingProcessStatus" != 'Canceled'`);
//         await queryRunner.query(`INSERT INTO "typeorm_metadata"("database", "schema", "table", "type", "name", "value") VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)`, ["public","VIEW","calender_view","SELECT\n  b.hall_id,\n  b.start_date,\n  b.end_date,\n  EXTRACT(\n    YEAR\n    FROM\n      b.start_date\n  )::INTEGER AS booking_year,\n  EXTRACT(\n    MONTH\n    FROM\n      b.start_date\n  )::INTEGER AS booking_month,\n   EXTRACT(\n    Day\n    FROM\n      b.start_date\n  )::INTEGER AS booking_day\nFROM\n  booking b\nWHERE\n  b.\"bookingProcessStatus\" != 'Canceled'"]);
 }

}
