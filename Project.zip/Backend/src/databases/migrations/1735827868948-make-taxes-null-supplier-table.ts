import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeTaxesNullSupplierTable1735827868948 implements MigrationInterface {
    name = 'MakeTaxesNullSupplierTable1735827868948'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "suppliers" ALTER COLUMN "taxRegistrationNumber" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "suppliers" ALTER COLUMN "commercialRegistrationNumber" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "suppliers" ALTER COLUMN "commercialRegistrationNumber" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "suppliers" ALTER COLUMN "taxRegistrationNumber" SET NOT NULL`);
    }

}
