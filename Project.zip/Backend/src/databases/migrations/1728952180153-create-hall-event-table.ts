import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateHallEventTable1728952180153 implements MigrationInterface {
    name = 'CreateHallEventTable1728952180153'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "halls_event" ("id" SERIAL NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "event_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "PK_b2338df163684b5ff811c016dbb" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "halls_event" ADD CONSTRAINT "FK_082a91c20b124a9188322b8e0db" FOREIGN KEY ("event_id") REFERENCES "events"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "halls_event" ADD CONSTRAINT "FK_bc2155e49dce9d0505951fa4c13" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        // await queryRunner.query(`ALTER TABLE "services" ADD CONSTRAINT "FK_458874e221f4ed82fa478b755d8" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "services" DROP CONSTRAINT "FK_458874e221f4ed82fa478b755d8"`);
        await queryRunner.query(`ALTER TABLE "halls_event" DROP CONSTRAINT "FK_bc2155e49dce9d0505951fa4c13"`);
        await queryRunner.query(`ALTER TABLE "halls_event" DROP CONSTRAINT "FK_082a91c20b124a9188322b8e0db"`);
        await queryRunner.query(`DROP TABLE "halls_event"`);
    }

}
