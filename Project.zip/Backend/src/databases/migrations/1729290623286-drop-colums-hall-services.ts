import { MigrationInterface, QueryRunner } from "typeorm";

export class DropColumsHallServices1729290623286 implements MigrationInterface {
    name = 'DropColumsHallServices1729290623286'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "deleted"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "deleted_at"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "deleted_by"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "deleted_by" integer`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "deleted_at" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "deleted" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
    }

}
