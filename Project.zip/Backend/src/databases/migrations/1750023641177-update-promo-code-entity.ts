import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdatePromoCodeEntity1750023641177 implements MigrationInterface {
    name = 'UpdatePromoCodeEntity1750023641177'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "promo_codes" ADD "created_by" integer`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ADD "updated_by" integer`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ADD "client_id" integer NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "created_at" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "created_at" SET DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "updated_at" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "updated_at" SET DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "deleted" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" DROP COLUMN "code"`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ADD "code" character varying NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" DROP COLUMN "type"`);
        await queryRunner.query(`CREATE TYPE "public"."promo_codes_type_enum" AS ENUM('fixed', 'percent')`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ADD "type" "public"."promo_codes_type_enum" NOT NULL DEFAULT 'percent'`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "usage_limit" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "start_date" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "end_date" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" DROP COLUMN "note"`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ADD "note" character varying`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ADD CONSTRAINT "FK_3f529ac301c396a5b926634f289" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "promo_codes" DROP CONSTRAINT "FK_3f529ac301c396a5b926634f289"`);
        await queryRunner.query(`ALTER TABLE "promo_codes" DROP COLUMN "note"`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ADD "note" text`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "end_date" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "start_date" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "usage_limit" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "discount" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "promo_codes" DROP COLUMN "type"`);
        await queryRunner.query(`DROP TYPE "public"."promo_codes_type_enum"`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ADD "type" character varying(255) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" DROP COLUMN "code"`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ADD "code" character varying(255) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "deleted" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "updated_at" SET DEFAULT CURRENT_TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "updated_at" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "created_at" SET DEFAULT CURRENT_TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "promo_codes" ALTER COLUMN "created_at" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "promo_codes" DROP COLUMN "client_id"`);
        await queryRunner.query(`ALTER TABLE "promo_codes" DROP COLUMN "updated_by"`);
        await queryRunner.query(`ALTER TABLE "promo_codes" DROP COLUMN "created_by"`);
    }

}
