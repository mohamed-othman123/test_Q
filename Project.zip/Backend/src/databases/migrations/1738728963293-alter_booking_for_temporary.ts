import { MigrationInterface, QueryRunner } from 'typeorm';

export class AlterBookingForTemporary1738728963293 implements MigrationInterface {
  name = 'AlterBookingForTemporary1738728963293';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" ADD "start_date" TIMESTAMP`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "end_date" TIMESTAMP`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "event_time" character varying NOT NULL DEFAULT 'Full Day'`,
    );
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "isConfirmed" boolean NOT NULL DEFAULT true`,
    );

    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "fixedPrice" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "attendeesNo" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "fixedBookingPrice" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "pricePerAttendee" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "subtotal" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "discount_value" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "discount_type" DROP NOT NULL`);
    await queryRunner.query(
      `ALTER TABLE "booking" ALTER COLUMN "subtotal_after_disc" DROP NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "vat" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "totalPayable" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "insurance_amount" DROP NOT NULL`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "insurance_amount" SET NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "totalPayable" SET NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "vat" SET NOT NULL`);
    await queryRunner.query(
      `ALTER TABLE "booking" ALTER COLUMN "subtotal_after_disc" SET NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "discount_type" SET NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "discount_value" SET NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "subtotal" SET NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "pricePerAttendee" SET NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "fixedBookingPrice" SET NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "attendeesNo" SET NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" ALTER COLUMN "fixedPrice" SET NOT NULL`);

    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "isConfirmed"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "event_time"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "end_date"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "start_date"`);

    await queryRunner.query(`ALTER TABLE "booking" ADD "booking_date" TIMESTAMP NOT NULL`);
  }
}
