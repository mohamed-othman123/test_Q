import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateHallClient1729083250055 implements MigrationInterface {
    name = 'UpdateHallClient1729083250055'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_clients" ADD "notes" text`);
        // await queryRunner.query(`ALTER TABLE "services" ADD CONSTRAINT "FK_458874e221f4ed82fa478b755d8" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "services" DROP CONSTRAINT "FK_458874e221f4ed82fa478b755d8"`);
        await queryRunner.query(`ALTER TABLE "halls_clients" DROP COLUMN "notes"`);
    }

}
