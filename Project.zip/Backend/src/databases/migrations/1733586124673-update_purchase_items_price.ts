import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdatePurchaseItemsPrice1733586124673 implements MigrationInterface {
  name = 'UpdatePurchaseItemsPrice1733586124673';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchase_items" DROP COLUMN "price"`);
    await queryRunner.query(
      `ALTER TABLE "purchase_items" ADD "price" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchase_items" DROP COLUMN "price"`);
    await queryRunner.query(`ALTER TABLE "purchase_items" ADD "price" integer NOT NULL`);
  }
}
