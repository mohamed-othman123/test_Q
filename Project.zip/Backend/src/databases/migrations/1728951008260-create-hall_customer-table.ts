import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateHallCustomerTable1728951008260 implements MigrationInterface {
    name = 'CreateHallCustomerTable1728951008260'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "hall_customer" ("id" SERIAL NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "customer_id" integer NOT NULL, "hall_id" integer NOT NULL, CONSTRAINT "PK_bb24ff62c79a4c0581f7bc51d79" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "hall_customer" ADD CONSTRAINT "FK_e7029cf510d8c8527b2eaa45db2" FOREIGN KEY ("customer_id") REFERENCES "halls_clients"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "hall_customer" ADD CONSTRAINT "FK_4a2662354e2a22d1d6278db69e6" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        // await queryRunner.query(`ALTER TABLE "services" ADD CONSTRAINT "FK_458874e221f4ed82fa478b755d8" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "services" DROP CONSTRAINT "FK_458874e221f4ed82fa478b755d8"`);
        await queryRunner.query(`ALTER TABLE "hall_customer" DROP CONSTRAINT "FK_4a2662354e2a22d1d6278db69e6"`);
        await queryRunner.query(`ALTER TABLE "hall_customer" DROP CONSTRAINT "FK_e7029cf510d8c8527b2eaa45db2"`);
        await queryRunner.query(`DROP TABLE "hall_customer"`);
    }

}
