import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingPricesPerAttendeeTypes1748567305431 implements MigrationInterface {
  name = 'BookingPricesPerAttendeeTypes1748567305431';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" ADD "male_attendees_count" integer`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "female_attendees_count" integer`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "male_price_per_attendee" numeric(10,2) DEFAULT '0'`,
    );
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "female_price_per_attendee" numeric(10,2) DEFAULT '0'`,
    );

    await queryRunner.query(`
      UPDATE "booking"
      SET 
        male_attendees_count = CASE 
          WHEN "attendeesType" = 'Men' THEN "attendeesNo"
          WHEN "attendeesType" = 'Men And Women' THEN "attendeesNo"
          ELSE 0
        END,
        female_attendees_count = CASE 
          WHEN "attendeesType" = 'Women' THEN "attendeesNo"
          WHEN "attendeesType" = 'Men And Women' THEN "attendeesNo"
          ELSE 0
        END,
        male_price_per_attendee = CASE 
          WHEN "attendeesType" = 'Men' THEN "pricePerAttendee"
          WHEN "attendeesType" = 'Men And Women' THEN "pricePerAttendee"
          ELSE 0
        END,
        female_price_per_attendee = CASE 
          WHEN "attendeesType" = 'Women' THEN "pricePerAttendee"
          WHEN "attendeesType" = 'Men And Women' THEN "pricePerAttendee"
          ELSE 0
        END
    `);

    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "attendeesNo"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "pricePerAttendee"`);
    await queryRunner.query(
      `ALTER TABLE "booking" RENAME COLUMN "attendeesType" TO "attendees_type"`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "female_price_per_attendee"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "male_price_per_attendee"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "female_attendees_count"`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "male_attendees_count"`);
    await queryRunner.query(
      `ALTER TABLE "booking" RENAME COLUMN "attendees_type" TO "attendeesType"`,
    );
    await queryRunner.query(`ALTER TABLE "booking" ADD "attendeesNo" integer`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "pricePerAttendee" numeric(10,2)`);

    await queryRunner.query(`
      UPDATE "booking"
      SET 
        "attendeesNo" = CASE 
          WHEN "attendeesType" = 'Men' THEN male_attendees_count
          WHEN "attendeesType" = 'Women' THEN female_attendees_count
          WHEN "attendeesType" = 'Men And Women' THEN male_attendees_count + female_attendees_count
          ELSE 0
        END,
        "pricePerAttendee" = CASE 
          WHEN "attendeesType" = 'Men' THEN male_price_per_attendee
          WHEN "attendeesType" = 'Women' THEN female_price_per_attendee
          WHEN "attendeesType" = 'Men And Women' THEN 
            CASE 
              WHEN male_price_per_attendee = female_price_per_attendee THEN male_price_per_attendee
              ELSE (male_price_per_attendee + female_price_per_attendee) / 2
            END
          ELSE 0
        END
    `);
  }
}
