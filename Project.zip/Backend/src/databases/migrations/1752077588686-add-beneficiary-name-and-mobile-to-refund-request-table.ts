import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddBeneficiaryNameAndMobileToRefundRequestTable1752077588686
  implements MigrationInterface
{
  name = 'AddBeneficiaryNameAndMobileToRefundRequestTable1752077588686';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "refund_requests" ADD "beneficiary_name" character varying`,
    );
    await queryRunner.query(
      `ALTER TABLE "refund_requests" ADD "beneficiary_mobile" character varying`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "refund_requests" DROP COLUMN "beneficiary_mobile"`);
    await queryRunner.query(`ALTER TABLE "refund_requests" DROP COLUMN "beneficiary_name"`);
  }
}
