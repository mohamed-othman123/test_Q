import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateClientTable1742939328424 implements MigrationInterface {
    name = 'UpdateClientTable1742939328424'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "clients" DROP COLUMN "cr_number"`);
        await queryRunner.query(`ALTER TABLE "clients" DROP COLUMN "vat_number"`);
        await queryRunner.query(`ALTER TABLE "clients" DROP COLUMN "note"`);
        await queryRunner.query(`ALTER TABLE "clients" ADD "taxRegistrationNumber" character varying`);
        await queryRunner.query(`ALTER TABLE "clients" ADD "commercialRegistrationNumber" character varying`);
        await queryRunner.query(`ALTER TABLE "clients" ALTER COLUMN "address" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "clients" ALTER COLUMN "address" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "clients" DROP COLUMN "commercialRegistrationNumber"`);
        await queryRunner.query(`ALTER TABLE "clients" DROP COLUMN "taxRegistrationNumber"`);
        await queryRunner.query(`ALTER TABLE "clients" ADD "note" character varying`);
        await queryRunner.query(`ALTER TABLE "clients" ADD "vat_number" character varying NOT NULL`);
        await queryRunner.query(`ALTER TABLE "clients" ADD "cr_number" character varying NOT NULL`);
    }

}
