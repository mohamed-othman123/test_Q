import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddSenderIdAndEmailInHallEntity1755867859272 implements MigrationInterface {
  name = 'AddSenderIdAndEmailInHallEntity1755867859272';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "halls" ADD "sender_email" character varying(255)`);
    await queryRunner.query(`ALTER TABLE "halls" ADD "sms_sender_id" text`);
    await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "primary_color" DROP DEFAULT`);
    await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "secondary_color" DROP DEFAULT`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "halls" ALTER COLUMN "secondary_color" SET DEFAULT '#FCF5EC'`,
    );
    await queryRunner.query(
      `ALTER TABLE "halls" ALTER COLUMN "primary_color" SET DEFAULT '#C09156'`,
    );
    await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "sms_sender_id"`);
    await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "sender_email"`);
  }
}
