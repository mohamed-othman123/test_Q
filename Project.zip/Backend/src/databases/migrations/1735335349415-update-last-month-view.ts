import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateLastMonthView1735335349415 implements MigrationInterface {
    name = 'UpdateLastMonthView1735335349415'

    public async up(queryRunner: QueryRunner): Promise<void> {
//         await queryRunner.query(`DELETE FROM "typeorm_metadata" WHERE "type" = $1 AND "name" = $2 AND "schema" = $3`, ["VIEW","last_Month_payments_view","public"]);
//         await queryRunner.query(`DROP VIEW "last_Month_payments_view"`);
//         await queryRunner.query(`CREATE VIEW "last_Month_payments_view" AS 
//  SELECT
//   p.id AS payment_id,
//   booking.hall_id AS hall_id,
//   p.client_id AS client_id,
//   hallClient.name AS payment_name,
//   p.payment_date AS payment_date,
//   p."paymentType" AS payment_type,
//   p.amount AS payment_amount,
//   'payment' AS source
// FROM
//   payments p
//   LEFT JOIN halls_clients hallClient ON hallClient.id = p.user_id
//   LEFT JOIN booking booking ON booking.id = p.booking_id
// WHERE
//   p.payment_date::date >= (CURRENT_DATE - INTERVAL '1 month')
//   AND p.payment_date::date <= CURRENT_DATE

// UNION ALL

// SELECT
//   pp.id AS payment_id,
//   purchase.hall_id AS hall_id,
//   supplier.client_id AS client_id,
//   supplier.name AS paymentName,
//   pp.created_at AS payment_date,
//   pp."paymentType" AS payment_type,
//   pp.amount AS payment_amount,
//   'purchase_payment' AS source
// FROM
//   purchase_payments pp
//   LEFT JOIN purchases purchase ON purchase.id = pp.purchase_id
//   LEFT JOIN suppliers supplier ON supplier.id = purchase.supplier_id
// WHERE
//   pp.created_at::date >= (CURRENT_DATE - INTERVAL '1 month')
//   AND pp.created_at::date <= CURRENT_DATE

// ORDER BY
//   payment_amount;
//     `);
//         await queryRunner.query(`INSERT INTO "typeorm_metadata"("database", "schema", "table", "type", "name", "value") VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)`, ["public","VIEW","last_Month_payments_view","SELECT\n  p.id AS payment_id,\n  booking.hall_id AS hall_id,\n  p.client_id AS client_id,\n  hallClient.name AS payment_name,\n  p.payment_date AS payment_date,\n  p.\"paymentType\" AS payment_type,\n  p.amount AS payment_amount,\n  'payment' AS source\nFROM\n  payments p\n  LEFT JOIN halls_clients hallClient ON hallClient.id = p.user_id\n  LEFT JOIN booking booking ON booking.id = p.booking_id\nWHERE\n  p.payment_date::date >= (CURRENT_DATE - INTERVAL '1 month')\n  AND p.payment_date::date <= CURRENT_DATE\n\nUNION ALL\n\nSELECT\n  pp.id AS payment_id,\n  purchase.hall_id AS hall_id,\n  supplier.client_id AS client_id,\n  supplier.name AS paymentName,\n  pp.created_at AS payment_date,\n  pp.\"paymentType\" AS payment_type,\n  pp.amount AS payment_amount,\n  'purchase_payment' AS source\nFROM\n  purchase_payments pp\n  LEFT JOIN purchases purchase ON purchase.id = pp.purchase_id\n  LEFT JOIN suppliers supplier ON supplier.id = purchase.supplier_id\nWHERE\n  pp.created_at::date >= (CURRENT_DATE - INTERVAL '1 month')\n  AND pp.created_at::date <= CURRENT_DATE\n\nORDER BY\n  payment_amount;"]);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
//         await queryRunner.query(`DELETE FROM "typeorm_metadata" WHERE "type" = $1 AND "name" = $2 AND "schema" = $3`, ["VIEW","last_Month_payments_view","public"]);
//         await queryRunner.query(`DROP VIEW "last_Month_payments_view"`);
//         await queryRunner.query(`CREATE VIEW "last_Month_payments_view" AS SELECT
//   p.id AS payment_id,
//   booking.hall_id AS hall_id,
//   p.client_id AS client_id,
//   hallClient.name AS payment_name,
//   p.payment_date AS payment_date,
//   p."paymentType" AS payment_type,
//   p.amount AS payment_amount,
//   'payment' AS source
// FROM
//   payments p
//   LEFT JOIN halls_clients hallClient ON hallClient.id = p.user_id
//   LEFT JOIN booking booking ON booking.id = p.booking_id
// WHERE
//   p.payment_date::date >= (CURRENT_DATE - INTERVAL '1 month')
//   AND p.payment_date::date <= CURRENT_DATE

// UNION ALL

// SELECT
//   pp.id AS payment_id,
//   purchase.hall_id AS hall_id,
//   supplier.client_id AS client_id,
//   supplier.name AS paymentName,
//   purchase.purchase_date AS payment_date,
//   pp."paymentType" AS payment_type,
//   pp.amount AS payment_amount,
//   'purchase_payment' AS source
// FROM
//   purchase_payments pp
//   LEFT JOIN purchases purchase ON purchase.id = pp.purchase_id
//   LEFT JOIN suppliers supplier ON supplier.id = purchase.supplier_id
// WHERE
//   purchase.purchase_date::date >= (CURRENT_DATE - INTERVAL '1 month')
//   AND purchase.purchase_date::date <= CURRENT_DATE

// ORDER BY
//   payment_amount;`);
//         await queryRunner.query(`INSERT INTO "typeorm_metadata"("database", "schema", "table", "type", "name", "value") VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)`, ["public","VIEW","last_Month_payments_view","SELECT\n  p.id AS payment_id,\n  booking.hall_id AS hall_id,\n  p.client_id AS client_id,\n  hallClient.name AS payment_name,\n  p.payment_date AS payment_date,\n  p.\"paymentType\" AS payment_type,\n  p.amount AS payment_amount,\n  'payment' AS source\nFROM\n  payments p\n  LEFT JOIN halls_clients hallClient ON hallClient.id = p.user_id\n  LEFT JOIN booking booking ON booking.id = p.booking_id\nWHERE\n  p.payment_date::date >= (CURRENT_DATE - INTERVAL '1 month')\n  AND p.payment_date::date <= CURRENT_DATE\n\nUNION ALL\n\nSELECT\n  pp.id AS payment_id,\n  purchase.hall_id AS hall_id,\n  supplier.client_id AS client_id,\n  supplier.name AS paymentName,\n  purchase.purchase_date AS payment_date,\n  pp.\"paymentType\" AS payment_type,\n  pp.amount AS payment_amount,\n  'purchase_payment' AS source\nFROM\n  purchase_payments pp\n  LEFT JOIN purchases purchase ON purchase.id = pp.purchase_id\n  LEFT JOIN suppliers supplier ON supplier.id = purchase.supplier_id\nWHERE\n  purchase.purchase_date::date >= (CURRENT_DATE - INTERVAL '1 month')\n  AND purchase.purchase_date::date <= CURRENT_DATE\n\nORDER BY\n  payment_amount;"]);
 }

}
