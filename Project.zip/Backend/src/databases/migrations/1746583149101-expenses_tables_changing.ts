import { MigrationInterface, QueryRunner } from 'typeorm';

export class ExpensesTablesChanging1746583149101 implements MigrationInterface {
  name = 'ExpensesTablesChanging1746583149101';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.renameColumn('expenses', 'invoiceReference', 'invoice_reference');
    await queryRunner.renameColumn('expenses', 'invoiceType', 'invoice_type');
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
