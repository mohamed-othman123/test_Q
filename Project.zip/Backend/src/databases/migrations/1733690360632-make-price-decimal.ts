import { MigrationInterface, QueryRunner } from "typeorm";

export class MakePriceDecimal1733690360632 implements MigrationInterface {
    name = 'MakePriceDecimal1733690360632'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "price"`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "price" numeric(10,2) NOT NULL DEFAULT '0'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "price"`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "price" integer NOT NULL DEFAULT '0'`);
    }

}
