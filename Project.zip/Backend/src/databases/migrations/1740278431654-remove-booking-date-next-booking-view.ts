import { MigrationInterface, QueryRunner } from "typeorm";

export class RemoveBookingDateNextBookingView1740278431654 implements MigrationInterface {
    name = 'RemoveBookingDateNextBookingView1740278431654'
    public async up(queryRunner: QueryRunner): Promise<void> {
//         await queryRunner.query(`DELETE FROM "typeorm_metadata" WHERE "type" = $1 AND "name" = $2 AND "schema" = $3`, ["VIEW","next_booking_view","public"]);
//         await queryRunner.query(`DROP VIEW "next_booking_view"`);
//         await queryRunner.query(`CREATE VIEW "next_booking_view" AS 
// WITH
//   NextBookings AS (
//     SELECT
//       b.hall_id,
//       b.id,
//       b."bookingProcessStatus",
//       b.start_date,
//       b.end_date,
//       hallClient.name AS username,
//       hallClient.phone AS userphone,
//       hallClient.email AS useremail,
//       ROW_NUMBER() OVER (
//         PARTITION BY
//           b.hall_id
//         ORDER BY
//           b.start_date
//       ) AS rn
//     FROM
//       booking b
//       LEFT JOIN halls_clients hallClient ON hallClient.id = b.user_id
//       LEFT JOIN halls hall ON hall.id = b.hall_id
//    WHERE
//     b.start_date > NOW()  -- Ensure we only get future bookings
//     AND b."bookingProcessStatus" != 'Canceled' -- Exclude canceled bookings
//   )
// SELECT
//   hall.id AS hall_id,
//   hall.client_id AS client_id,
//   nb.id,
//   nb."bookingProcessStatus",
//   nb.start_date,
//   nb.end_date,
//   nb.username,
//   nb.userphone,
//   nb.useremail
// FROM
//   NextBookings nb
//   LEFT JOIN halls hall ON hall.id = nb.hall_id
// WHERE
//   nb.rn = 1;
//   `);
//         await queryRunner.query(`INSERT INTO "typeorm_metadata"("database", "schema", "table", "type", "name", "value") VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)`, ["public","VIEW","next_booking_view","WITH\n  NextBookings AS (\n    SELECT\n      b.hall_id,\n      b.id,\n      b.\"bookingProcessStatus\",\n      b.start_date,\n      b.end_date,\n      hallClient.name AS username,\n      hallClient.phone AS userphone,\n      hallClient.email AS useremail,\n      ROW_NUMBER() OVER (\n        PARTITION BY\n          b.hall_id\n        ORDER BY\n          b.start_date\n      ) AS rn\n    FROM\n      booking b\n      LEFT JOIN halls_clients hallClient ON hallClient.id = b.user_id\n      LEFT JOIN halls hall ON hall.id = b.hall_id\n   WHERE\n    b.start_date > NOW()  -- Ensure we only get future bookings\n    AND b.\"bookingProcessStatus\" != 'Canceled' -- Exclude canceled bookings\n  )\nSELECT\n  hall.id AS hall_id,\n  hall.client_id AS client_id,\n  nb.id,\n  nb.\"bookingProcessStatus\",\n  nb.start_date,\n  nb.end_date,\n  nb.username,\n  nb.userphone,\n  nb.useremail\nFROM\n  NextBookings nb\n  LEFT JOIN halls hall ON hall.id = nb.hall_id\nWHERE\n  nb.rn = 1;"]);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
//         await queryRunner.query(`DELETE FROM "typeorm_metadata" WHERE "type" = $1 AND "name" = $2 AND "schema" = $3`, ["VIEW","next_booking_view","public"]);
//         await queryRunner.query(`DROP VIEW "next_booking_view"`);
//         await queryRunner.query(`CREATE VIEW "next_booking_view" AS WITH
//   NextBookings AS (
//     SELECT
//       b.hall_id,
//       b.id,
//       b."bookingProcessStatus",
//       b.booking_date,
//       b.hijri_date,
//       b."useGregorian",
//       hallClient.name AS username,
//       hallClient.phone AS userphone,
//       hallClient.email AS useremail,
//       ROW_NUMBER() OVER (
//         PARTITION BY
//           b.hall_id
//         ORDER BY
//           b.booking_date
//       ) AS rn
//     FROM
//       booking b
//       LEFT JOIN halls_clients hallClient ON hallClient.id = b.user_id
//       LEFT JOIN halls hall ON hall.id = b.hall_id
//    WHERE
//     b.booking_date > NOW()  -- Ensure we only get future bookings
//     AND b."bookingProcessStatus" != 'Canceled' -- Exclude canceled bookings
//   )
// SELECT
//   hall.id AS hall_id,
//   hall.client_id AS client_id,
//   nb.id,
//   nb."bookingProcessStatus",
//   nb.booking_date,
//   nb.hijri_date,
//   nb."useGregorian",
//   nb.username,
//   nb.userphone,
//   nb.useremail
// FROM
//   NextBookings nb
//   LEFT JOIN halls hall ON hall.id = nb.hall_id
// WHERE
//   nb.rn = 1;`);
//         await queryRunner.query(`INSERT INTO "typeorm_metadata"("database", "schema", "table", "type", "name", "value") VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)`, ["public","VIEW","next_booking_view","WITH\n  NextBookings AS (\n    SELECT\n      b.hall_id,\n      b.id,\n      b.\"bookingProcessStatus\",\n      b.booking_date,\n      b.hijri_date,\n      b.\"useGregorian\",\n      hallClient.name AS username,\n      hallClient.phone AS userphone,\n      hallClient.email AS useremail,\n      ROW_NUMBER() OVER (\n        PARTITION BY\n          b.hall_id\n        ORDER BY\n          b.booking_date\n      ) AS rn\n    FROM\n      booking b\n      LEFT JOIN halls_clients hallClient ON hallClient.id = b.user_id\n      LEFT JOIN halls hall ON hall.id = b.hall_id\n   WHERE\n    b.booking_date > NOW()  -- Ensure we only get future bookings\n    AND b.\"bookingProcessStatus\" != 'Canceled' -- Exclude canceled bookings\n  )\nSELECT\n  hall.id AS hall_id,\n  hall.client_id AS client_id,\n  nb.id,\n  nb.\"bookingProcessStatus\",\n  nb.booking_date,\n  nb.hijri_date,\n  nb.\"useGregorian\",\n  nb.username,\n  nb.userphone,\n  nb.useremail\nFROM\n  NextBookings nb\n  LEFT JOIN halls hall ON hall.id = nb.hall_id\nWHERE\n  nb.rn = 1;"]);
 }

}
