import { MigrationInterface, QueryRunner } from "typeorm";

export class AddRelationEventPricing1746050610461 implements MigrationInterface {
    name = 'AddRelationEventPricing1746050610461'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ADD "eventId" integer`);
        await queryRunner.query(`ALTER TABLE "hall_pricing" ADD "event_id" integer`);
        await queryRunner.query(`ALTER TABLE "hall_pricing" ADD CONSTRAINT "UQ_c10028f4515180d889fab89f165" UNIQUE ("event_id")`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ADD CONSTRAINT "FK_0b48703162dc00127b9054d20ef" FOREIGN KEY ("eventId") REFERENCES "events"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "hall_pricing" ADD CONSTRAINT "FK_c10028f4515180d889fab89f165" FOREIGN KEY ("event_id") REFERENCES "events"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_pricing" DROP CONSTRAINT "FK_c10028f4515180d889fab89f165"`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" DROP CONSTRAINT "FK_0b48703162dc00127b9054d20ef"`);
        await queryRunner.query(`ALTER TABLE "hall_pricing" DROP CONSTRAINT "UQ_c10028f4515180d889fab89f165"`);
        await queryRunner.query(`ALTER TABLE "hall_pricing" DROP COLUMN "event_id"`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" DROP COLUMN "eventId"`);
    }

}
