import { MigrationInterface, QueryRunner } from "typeorm";

export class AddUniqueBookingRef1738465088396 implements MigrationInterface {
    name = 'AddUniqueBookingRef1738465088396'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "UQ_1b26cef9409d01141c96c86cfa8" UNIQUE ("booking_reference")`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "UQ_1b26cef9409d01141c96c86cfa8"`);
    }

}
