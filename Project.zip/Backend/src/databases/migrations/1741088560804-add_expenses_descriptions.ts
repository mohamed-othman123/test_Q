import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddExpensesDescriptions1741088560804 implements MigrationInterface {
  name = 'AddExpensesDescriptions1741088560804';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchases" ADD "expenses_description" text`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchases" DROP COLUMN "expenses_description"`);
  }
}
