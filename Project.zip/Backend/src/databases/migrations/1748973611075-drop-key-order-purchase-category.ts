import { MigrationInterface, QueryRunner } from "typeorm";

export class DropKeyOrderPurchaseCategory1748973611075 implements MigrationInterface {
    name = 'DropKeyOrderPurchaseCategory1748973611075'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "purchase_categories" ADD "isDefault" boolean NOT NULL DEFAULT false`)
        await queryRunner.query(`ALTER TABLE "purchase_categories" DROP COLUMN "order"`);
        await queryRunner.query(`ALTER TABLE "purchase_categories" DROP COLUMN "key"`);
        await queryRunner.query(`ALTER TABLE "purchase_categories" DROP COLUMN "type"`);
        await queryRunner.query(`CREATE TYPE "public"."purchase_categories_type_enum" AS ENUM('Purchases', 'General')`);
        await queryRunner.query(`ALTER TABLE "purchase_categories" ADD "type" "public"."purchase_categories_type_enum" NOT NULL DEFAULT 'Purchases'`);
        await queryRunner.query(`
            UPDATE "purchase_categories"
            SET "description" = "name"
            WHERE "description" IS NULL
          `);
        await queryRunner.query(`ALTER TABLE "purchase_categories" ALTER COLUMN "description" SET NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "purchase_categories" ALTER COLUMN "description" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "purchase_categories" DROP COLUMN "type"`);
        await queryRunner.query(`DROP TYPE "public"."purchase_categories_type_enum"`);
        await queryRunner.query(`ALTER TABLE "purchase_categories" ADD "type" character varying NOT NULL DEFAULT 'Purchases'`);
        await queryRunner.query(`ALTER TABLE "purchase_categories" ADD "key" character varying`);
        await queryRunner.query(`ALTER TABLE "purchase_categories" ADD "order" integer`);
        await queryRunner.query(`ALTER TABLE "purchase_categories" DROP COLUMN "isDefault"`);
    }

}
