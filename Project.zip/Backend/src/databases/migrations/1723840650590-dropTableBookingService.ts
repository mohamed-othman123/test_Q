import { MigrationInterface, QueryRunner } from 'typeorm';

export class $npmConfigName1723840650590 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "booking_services";`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
