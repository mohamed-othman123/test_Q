import { MigrationInterface, QueryRunner } from "typeorm";

export class AddSignturesContractTable1742097224807 implements MigrationInterface {
    name = 'AddSignturesContractTable1742097224807'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contracts" ADD "firstParty" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "secondParty" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "secondPartyName" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "secondPartySignature" text`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "firstPartySignature" text`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "firstPartySignature"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "secondPartySignature"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "secondPartyName"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "secondParty"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "firstParty"`);
    }

}
