import { MigrationInterface, QueryRunner } from 'typeorm';

export class ExpenseItemTransferAccounts1747771684008 implements MigrationInterface {
  name = 'ExpenseItemTransferAccounts1747771684008';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "expense_item_transfer_accounts" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "account_name" character varying NOT NULL, "account_number" character varying NOT NULL, "description" text, "expense_item_id" integer, CONSTRAINT "PK_7cddf03bfe318c90d91d769c67a" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `ALTER TABLE "expense_item_transfer_accounts" ADD CONSTRAINT "FK_5aedc9464fdd8cd1673bbe7dbf8" FOREIGN KEY ("expense_item_id") REFERENCES "expense_items"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "expense_item_transfer_accounts" DROP CONSTRAINT "FK_5aedc9464fdd8cd1673bbe7dbf8"`,
    );

    await queryRunner.query(`DROP TABLE "expense_item_transfer_accounts"`);
  }
}
