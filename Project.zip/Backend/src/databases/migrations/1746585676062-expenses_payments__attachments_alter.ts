import { MigrationInterface, QueryRunner } from 'typeorm';

export class ExpensesPaymentsAlter1746585676062 implements MigrationInterface {
  name = 'ExpensesPaymentsAlter1746585676062';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP CONSTRAINT "FK_b46b86af4665d6f7a39710b1644"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP CONSTRAINT "FK_add42ca533896795ed320136619"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP CONSTRAINT "FK_b0089820b7452d8e84b5d1fda65"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP CONSTRAINT "FK_fed90c8deca69fde22b4d01a2f1"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_attachments" DROP CONSTRAINT "FK_67b8fab99562f737cad7c3e9a49"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" RENAME COLUMN "purchase_id" TO "expense_id"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_attachments" RENAME COLUMN "purchase_id" TO "expense_id"`,
    );

    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD CONSTRAINT "FK_37972b2b501afd2e474fd0253e9" FOREIGN KEY ("bank_details_id") REFERENCES "payment_bank_details"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD CONSTRAINT "FK_6c8656e9aa582b240f13e1fbfcf" FOREIGN KEY ("paymentMethod_id") REFERENCES "payment_method"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD CONSTRAINT "FK_2f3952498da5d865d41cdda9a58" FOREIGN KEY ("expense_id") REFERENCES "expenses"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD CONSTRAINT "FK_2bfd61954ba0361280c019d973a" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_attachments" ADD CONSTRAINT "FK_134359bce07d2a3563a63e0ccd9" FOREIGN KEY ("expense_id") REFERENCES "expenses"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
