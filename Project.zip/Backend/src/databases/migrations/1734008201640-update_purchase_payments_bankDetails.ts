import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdatePurchasePaymentsBankDetails1734008201640 implements MigrationInterface {
  name = 'UpdatePurchasePaymentsBankDetails1734008201640';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TYPE "public"."payment_bank_details_bank_type_enum" AS ENUM('Normal Bank', 'EBANK')`,
    );
    await queryRunner.query(
      `CREATE TABLE "payment_bank_details" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "bank_type" "public"."payment_bank_details_bank_type_enum" NOT NULL DEFAULT 'Normal Bank', "bank_name" character varying, "IBAN" character varying, "phone_number_for_ebank" character varying, CONSTRAINT "PK_d7fc3226d65e5aec7cee03d6e6c" PRIMARY KEY ("id"))`,
    );

    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "bank_name"`);
    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "bank_account_number"`);
    await queryRunner.query(`ALTER TABLE "purchase_payments" ADD "bank_details_id" integer`);
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD CONSTRAINT "UQ_b46b86af4665d6f7a39710b1644" UNIQUE ("bank_details_id")`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD CONSTRAINT "FK_b46b86af4665d6f7a39710b1644" FOREIGN KEY ("bank_details_id") REFERENCES "payment_bank_details"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" DROP CONSTRAINT "FK_b46b86af4665d6f7a39710b1644"`,
    );
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" DROP CONSTRAINT "UQ_b46b86af4665d6f7a39710b1644"`,
    );
    await queryRunner.query(`ALTER TABLE "purchase_payments" DROP COLUMN "bank_details_id"`);
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ADD "bank_account_number" character varying`,
    );
    await queryRunner.query(`ALTER TABLE "purchase_payments" ADD "bank_name" character varying`);

    await queryRunner.query(`DROP TABLE "payment_bank_details"`);
    await queryRunner.query(`DROP TYPE "public"."payment_bank_details_bank_type_enum"`);
  }
}
