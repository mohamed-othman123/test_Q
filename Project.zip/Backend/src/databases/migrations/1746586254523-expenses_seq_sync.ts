import { MigrationInterface, QueryRunner } from 'typeorm';

export class ExpensesSeqSync1746586254523 implements MigrationInterface {
  name = 'ExpensesSeqSync1746586254523';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE SEQUENCE IF NOT EXISTS "expenses_details_id_seq" OWNED BY "expenses_details"."id"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_details" ALTER COLUMN "id" SET DEFAULT nextval('"expenses_details_id_seq"')`,
    );
    await queryRunner.query(`ALTER TABLE "expenses_details" ALTER COLUMN "id" DROP DEFAULT`);
    await queryRunner.query(
      `CREATE SEQUENCE IF NOT EXISTS "expenses_payments_id_seq" OWNED BY "expenses_payments"."id"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ALTER COLUMN "id" SET DEFAULT nextval('"expenses_payments_id_seq"')`,
    );
    await queryRunner.query(`ALTER TABLE "expenses_payments" ALTER COLUMN "id" DROP DEFAULT`);
    await queryRunner.query(
      `CREATE SEQUENCE IF NOT EXISTS "expenses_attachments_id_seq" OWNED BY "expenses_attachments"."id"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_attachments" ALTER COLUMN "id" SET DEFAULT nextval('"expenses_attachments_id_seq"')`,
    );
    await queryRunner.query(`ALTER TABLE "expenses_attachments" ALTER COLUMN "id" DROP DEFAULT`);
    await queryRunner.query(
      `ALTER TABLE "expenses_details" DROP CONSTRAINT "FK_9cc4e7aef02642c631b9340bd8e"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP CONSTRAINT "FK_2f3952498da5d865d41cdda9a58"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_attachments" DROP CONSTRAINT "FK_134359bce07d2a3563a63e0ccd9"`,
    );
    await queryRunner.query(
      `CREATE SEQUENCE IF NOT EXISTS "expenses_id_seq" OWNED BY "expenses"."id"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses" ALTER COLUMN "id" SET DEFAULT nextval('"expenses_id_seq"')`,
    );
    await queryRunner.query(`ALTER TABLE "expenses" ALTER COLUMN "id" DROP DEFAULT`);
    await queryRunner.query(
      `ALTER TABLE "expenses_details" ADD CONSTRAINT "FK_9cc4e7aef02642c631b9340bd8e" FOREIGN KEY ("expense_id") REFERENCES "expenses"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD CONSTRAINT "FK_2f3952498da5d865d41cdda9a58" FOREIGN KEY ("expense_id") REFERENCES "expenses"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_attachments" ADD CONSTRAINT "FK_134359bce07d2a3563a63e0ccd9" FOREIGN KEY ("expense_id") REFERENCES "expenses"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
