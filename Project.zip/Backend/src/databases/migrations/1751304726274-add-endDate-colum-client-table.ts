import { MigrationInterface, QueryRunner } from "typeorm";

export class AddEndDateColumClientTable1751304726274 implements MigrationInterface {
    name = 'AddEndDateColumClientTable1751304726274'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "clients" ADD "end_date" TIMESTAMP`);
        await queryRunner.query(`
            UPDATE "clients"
            SET "end_date" = COALESCE("end_date", "created_at" + INTERVAL '1 MONTH')
            WHERE "end_date" IS NULL;
        `);
        await queryRunner.query(`ALTER TABLE "clients" ALTER COLUMN "end_date" SET NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "clients" DROP COLUMN "end_date"`);
    }

}
