import { MigrationInterface, QueryRunner } from "typeorm";

export class AddInsuranceAmountHallTable1742394968896 implements MigrationInterface {
    name = 'AddInsuranceAmountHallTable1742394968896'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" ADD "insurance_amount" numeric(10,2) DEFAULT '0'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "insurance_amount"`);
    }

}
