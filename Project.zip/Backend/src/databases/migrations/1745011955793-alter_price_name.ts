import { MigrationInterface, QueryRunner } from 'typeorm';

export class AlterPriceName1745011955793 implements MigrationInterface {
  name = 'AlterPriceName1745011955793';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking_services" RENAME COLUMN "servicePrice" to price`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
