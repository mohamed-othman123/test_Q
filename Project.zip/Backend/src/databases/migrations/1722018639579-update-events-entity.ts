import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateEventsEntity1722018639579 implements MigrationInterface {
  name = 'UpdateEventsEntity1722018639579';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" DROP CONSTRAINT "FK_0d609124dfcd918e8b9dd08ec9a"`,
    );
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "date"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "start_time"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "end_time"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "hall_id"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "note"`);
    await queryRunner.query(`ALTER TABLE "events" ADD "description" character varying(255)`);
    await queryRunner.query(`ALTER TABLE "events" ADD "client_id" integer`);
    await queryRunner.query(
      `ALTER TABLE "events" ADD CONSTRAINT "FK_b4ea5a78d656e3c29835bf644e6" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE CASCADE ON UPDATE CASCADE`,
    );
    await queryRunner.query(`DROP TABLE "event_histories"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "events" DROP CONSTRAINT "FK_b4ea5a78d656e3c29835bf644e6"`,
    );

    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "client_id"`);
    await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "description"`);
    await queryRunner.query(`ALTER TABLE "events" ADD "note" text`);
    await queryRunner.query(`ALTER TABLE "events" ADD "hall_id" integer`);
    await queryRunner.query(`ALTER TABLE "events" ADD "end_time" TIME NOT NULL`);
    await queryRunner.query(`ALTER TABLE "events" ADD "start_time" TIME NOT NULL`);
    await queryRunner.query(`ALTER TABLE "events" ADD "date" date NOT NULL`);

    await queryRunner.query(
      `ALTER TABLE "events" ADD CONSTRAINT "FK_0d609124dfcd918e8b9dd08ec9a" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }
}
