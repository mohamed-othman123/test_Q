import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateBookingNumricColumns1734710733005 implements MigrationInterface {
  name = 'UpdateBookingNumricColumns1734710733005';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "amount"`);
    await queryRunner.query(
      `ALTER TABLE "payments" ADD "amount" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "fixedBookingPrice"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "fixedBookingPrice" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "pricePerAttendee"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "pricePerAttendee" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "subtotal"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "subtotal" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "discount_value"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "discount_value" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "subtotal_after_disc"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "subtotal_after_disc" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "vat"`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "vat" numeric(10,2) NOT NULL DEFAULT '0'`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "totalPayable"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "totalPayable" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "insurance_amount"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "insurance_amount" numeric(10,2) NOT NULL DEFAULT '0'`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "insurance_amount"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "insurance_amount" integer NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "totalPayable"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "totalPayable" double precision NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "vat"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "vat" double precision NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "subtotal_after_disc"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "subtotal_after_disc" double precision NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "discount_value"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "discount_value" double precision NOT NULL DEFAULT '0'`,
    );
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "subtotal"`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "subtotal" integer NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "pricePerAttendee"`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "pricePerAttendee" integer NOT NULL`);
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "fixedBookingPrice"`);
    await queryRunner.query(`ALTER TABLE "booking" ADD "fixedBookingPrice" integer NOT NULL`);
    await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "amount"`);
    await queryRunner.query(`ALTER TABLE "payments" ADD "amount" integer NOT NULL`);
  }
}
