import { MigrationInterface, QueryRunner } from "typeorm";

export class AddNameArEvemtTable1735836936994 implements MigrationInterface {
    name = 'AddNameArEvemtTable1735836936994'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "events" ADD "name_ar" character varying(255) NOT NULL DEFAULT ''`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "events" DROP COLUMN "name_ar"`);
    }

}
