import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingDatePrefrence1727067663551 implements MigrationInterface {
  name = 'BookingDatePrefrence1727067663551';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking" ADD "useGregorian" boolean NOT NULL DEFAULT true`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "useGregorian"`);
  }
}
