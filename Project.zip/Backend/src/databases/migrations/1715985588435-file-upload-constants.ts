import { MigrationInterface, QueryRunner, Table } from 'typeorm';

/**
 * Migration to create the "file_upload_constants" table with key, value, and timestamps in PostgreSQL.
 */
export class FileUploadConstants1715985588435 implements MigrationInterface {
  /**
   * Runs when the migration is applied.
   * Creates the "file_upload_constants" table if it does not already exist with columns for key, value, and timestamps.
   */
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'file_upload_constants',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'key',
            type: 'varchar',
            isUnique: true,
          },
          {
            name: 'value',
            type: 'varchar',
          },
          {
            name: 'createdAt',
            type: 'timestamp',
            default: 'now()',
          },
          {
            name: 'updatedAt',
            type: 'timestamp',
            default: 'now()',
            onUpdate: 'now()',
          },
        ],
      }),
    );
    // Insert the default values for the file upload constants
    await queryRunner.query(
      `
            INSERT INTO file_upload_constants (key, value)
            VALUES ('MAX_IMAGE_SIZE', '5242880'),
                   ('MAX_VIDEO_SIZE', '52428800'),
                   ('MAX_AUDIO_SIZE', '10485760'),
                   ('MAX_FILE_SIZE', '52428800'),
                   ('MAX_FILE_COUNT', '10'),
                   ('FILE_UPLOAD_DESTINATION', 'uploads'),
                   ('FILE_UPLOAD_PATH', 'uploads'),
                   ('FILE_UPLOAD_FIELD_NAME', 'file'),
                   ('FILE_UPLOAD_FIELD_NAME_MULTIPLE', 'files'),
                   ('FILE_UPLOAD_FIELD_NAME_ARRAY', 'files'),
                   ('FILE_UPLOAD_FIELD_NAME_ANY', 'files')
        `,
    );
  }

  /**
   * Reverts the changes made in the "up" method.
   * Drops the "file_upload_constants" table.
   */
  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('DROP TABLE IF EXISTS file_upload_constants');
  }
}
