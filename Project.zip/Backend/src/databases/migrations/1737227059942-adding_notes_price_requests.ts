import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddingNotesPriceRequests1737227059942 implements MigrationInterface {
  name = 'AddingNotesPriceRequests1737227059942';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking_price_requests" ADD "notes" text`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking_price_requests" DROP COLUMN "notes"`);
  }
}
