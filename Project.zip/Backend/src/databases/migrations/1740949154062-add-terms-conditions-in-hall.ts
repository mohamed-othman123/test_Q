import { MigrationInterface, QueryRunner } from "typeorm";

export class AddTermsConditionsInHall1740949154062 implements MigrationInterface {
    name = 'AddTermsConditionsInHall1740949154062'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" ADD "terms_and_conditions_en" text`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "terms_and_conditions_ar" text`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "terms_and_conditions_ar"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "terms_and_conditions_en"`);
    }

}
