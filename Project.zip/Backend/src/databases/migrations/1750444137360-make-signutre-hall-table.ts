import { MigrationInterface, QueryRunner } from "typeorm";

export class MakeSignutreHallTable1750444137360 implements MigrationInterface {
    name = 'MakeSignutreHallTable1750444137360'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "firstParty"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "secondParty"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "firstPartySignature"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "firstPartyName"`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "first_party_signature" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "first_party_stamp" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "second_party_signature" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "signature_url" text`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "signature_name" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "stamp_url" text`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "stamp_url"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "signature_name"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "signature_url"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "second_party_signature"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "first_party_stamp"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "first_party_signature"`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "firstPartyName" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "firstPartySignature" text`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "secondParty" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "firstParty" boolean NOT NULL DEFAULT false`);
    }

}
