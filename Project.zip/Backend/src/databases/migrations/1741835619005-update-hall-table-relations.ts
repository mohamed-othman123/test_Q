import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateHallTableRelations1741835619005 implements MigrationInterface {
    name = 'UpdateHallTableRelations1741835619005'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "hall_team_members" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying(255) NOT NULL, "email" character varying(255) NOT NULL, "hallId" integer, CONSTRAINT "PK_55144d81f8cfc119f40687734e7" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "name"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "terms_and_conditions"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "privacy_policy"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "active"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "terms_and_conditions_en"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "terms_and_conditions_ar"`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "terms_and_conditions_en" text`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "terms_and_conditions_ar" text`);
        await queryRunner.query(`CREATE TYPE "public"."contracts_customertype_enum" AS ENUM('Individual', 'Facility', 'Governmental Facility')`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "customerType" "public"."contracts_customertype_enum" NOT NULL DEFAULT 'Individual'`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "event_id" integer`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "daily_temp_bookings" integer NOT NULL DEFAULT '1'`);
        await queryRunner.query(`ALTER TABLE "hall_sections" ALTER COLUMN "capacity" SET DEFAULT '0'`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "primary_color" SET DEFAULT '#C09156'`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "secondary_color" SET DEFAULT '#FCF5EC'`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD CONSTRAINT "FK_9ebe35e249c32fa290b0d344bd1" FOREIGN KEY ("event_id") REFERENCES "events"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "hall_team_members" ADD CONSTRAINT "FK_0510cf164bd7bce6d6998166227" FOREIGN KEY ("hallId") REFERENCES "halls"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_team_members" DROP CONSTRAINT "FK_0510cf164bd7bce6d6998166227"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP CONSTRAINT "FK_9ebe35e249c32fa290b0d344bd1"`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "secondary_color" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "primary_color" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "hall_sections" ALTER COLUMN "capacity" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "daily_temp_bookings"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "event_id"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "customerType"`);
        await queryRunner.query(`DROP TYPE "public"."contracts_customertype_enum"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "terms_and_conditions_ar"`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "terms_and_conditions_en"`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "terms_and_conditions_ar" text`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "terms_and_conditions_en" text`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "active" boolean NOT NULL DEFAULT true`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "privacy_policy" text NOT NULL`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "terms_and_conditions" text NOT NULL`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD "name" character varying(255) NOT NULL`);
        await queryRunner.query(`DROP TABLE "hall_team_members"`);
    }

}
