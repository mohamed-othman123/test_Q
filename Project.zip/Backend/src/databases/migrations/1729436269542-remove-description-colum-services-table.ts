import { MigrationInterface, QueryRunner } from "typeorm";

export class RemoveDescriptionColumServicesTable1729436269542 implements MigrationInterface {
    name = 'RemoveDescriptionColumServicesTable1729436269542'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "services" DROP COLUMN "description"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "services" ADD "description" text`);
    }

}
