import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateCompanyDetalsTable1728946933024 implements MigrationInterface {
    name = 'CreateCompanyDetalsTable1728946933024'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "suppliers" DROP CONSTRAINT "FK_1eac3ac38b455af8345adf400c4"`);
        await queryRunner.query(`CREATE TABLE "company_details" ("id" SERIAL NOT NULL, "taxRegistrationNumber" character varying NOT NULL, "commercialRegistrationNumber" character varying NOT NULL, "bankName" character varying, "IBAN" character varying, CONSTRAINT "PK_36b605d66617cf62e4b3a0161dc" PRIMARY KEY ("id"))`);
        // await queryRunner.query(`ALTER TABLE "halls_clients" DROP COLUMN "company"`);
        // await queryRunner.query(`ALTER TABLE "halls_clients" ADD "Iscompany" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "halls_clients" ADD "companyDetailsId" integer`);
        await queryRunner.query(`ALTER TABLE "halls_clients" ADD CONSTRAINT "UQ_2d8beaafb9c4a66cd707177b9df" UNIQUE ("companyDetailsId")`);
        await queryRunner.query(`ALTER TABLE "halls_clients" DROP CONSTRAINT "FK_76153951135b488e28df283c0ee"`);
        await queryRunner.query(`ALTER TABLE "halls_clients" ALTER COLUMN "client_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "suppliers" ALTER COLUMN "client_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls_clients" ADD CONSTRAINT "FK_76153951135b488e28df283c0ee" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "halls_clients" ADD CONSTRAINT "FK_2d8beaafb9c4a66cd707177b9df" FOREIGN KEY ("companyDetailsId") REFERENCES "company_details"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        // await queryRunner.query(`ALTER TABLE "services" ADD CONSTRAINT "FK_458874e221f4ed82fa478b755d8" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD CONSTRAINT "FK_1eac3ac38b455af8345adf400c4" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "suppliers" DROP CONSTRAINT "FK_1eac3ac38b455af8345adf400c4"`);
        await queryRunner.query(`ALTER TABLE "services" DROP CONSTRAINT "FK_458874e221f4ed82fa478b755d8"`);
        await queryRunner.query(`ALTER TABLE "halls_clients" DROP CONSTRAINT "FK_2d8beaafb9c4a66cd707177b9df"`);
        await queryRunner.query(`ALTER TABLE "halls_clients" DROP CONSTRAINT "FK_76153951135b488e28df283c0ee"`);
        await queryRunner.query(`ALTER TABLE "suppliers" ALTER COLUMN "client_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls_clients" ALTER COLUMN "client_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls_clients" ADD CONSTRAINT "FK_76153951135b488e28df283c0ee" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "halls_clients" DROP CONSTRAINT "UQ_2d8beaafb9c4a66cd707177b9df"`);
        await queryRunner.query(`ALTER TABLE "halls_clients" DROP COLUMN "companyDetailsId"`);
        await queryRunner.query(`ALTER TABLE "halls_clients" DROP COLUMN "Iscompany"`);
        await queryRunner.query(`ALTER TABLE "halls_clients" ADD "company" character varying(255)`);
        await queryRunner.query(`DROP TABLE "company_details"`);
        await queryRunner.query(`ALTER TABLE "suppliers" ADD CONSTRAINT "FK_1eac3ac38b455af8345adf400c4" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}
