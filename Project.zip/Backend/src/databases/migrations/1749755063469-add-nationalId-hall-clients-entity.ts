import { MigrationInterface, QueryRunner } from "typeorm";

export class AddNationalIdHallClientsEntity1749755063469 implements MigrationInterface {
    name = 'AddNationalIdHallClientsEntity1749755063469'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_clients" ADD "national_or_residency_id" character varying`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_clients" DROP COLUMN "national_or_residency_id"`);
    }

}
