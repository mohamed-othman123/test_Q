import { MigrationInterface, QueryRunner } from 'typeorm';

export class DropFixedPriceColumn1743817874809 implements MigrationInterface {
  name = 'DropFixedPriceColumn1743817874809';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "fixedPrice"`);
    await queryRunner.query(
      `ALTER TABLE "booking" ALTER COLUMN "price_calculation_type" SET NOT NULL`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "booking" ALTER COLUMN "price_calculation_type" DROP NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "booking" ADD "fixedPrice" boolean`);
  }
}
