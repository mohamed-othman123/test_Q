import { MigrationInterface, QueryRunner } from "typeorm";

export class AddHallRelationPricisTable1746593453064 implements MigrationInterface {
    name = 'AddHallRelationPricisTable1746593453064'
    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP CONSTRAINT "FK_8902a66d56af2e5266dfc55f656"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP CONSTRAINT "FK_0b48703162dc00127b9054d20ef"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP CONSTRAINT "FK_d9abaf324b0de7f72e796a843b6"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP CONSTRAINT "FK_c10028f4515180d889fab89f165"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD CONSTRAINT "FK_d5b4c4ae204aadf15c9c075ba68" FOREIGN KEY ("hallId") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD CONSTRAINT "FK_accd77efa56080c101ca3da72ce" FOREIGN KEY ("eventId") REFERENCES "events"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD CONSTRAINT "FK_6c34b643e669d67f158b0780e29" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD CONSTRAINT "FK_58d2e16a80a24b7c917a0e079d3" FOREIGN KEY ("event_id") REFERENCES "events"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP CONSTRAINT "FK_58d2e16a80a24b7c917a0e079d3"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" DROP CONSTRAINT "FK_6c34b643e669d67f158b0780e29"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP CONSTRAINT "FK_accd77efa56080c101ca3da72ce"`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" DROP CONSTRAINT "FK_d5b4c4ae204aadf15c9c075ba68"`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD CONSTRAINT "FK_c10028f4515180d889fab89f165" FOREIGN KEY ("event_id") REFERENCES "events"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "regular_pricing" ADD CONSTRAINT "FK_d9abaf324b0de7f72e796a843b6" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD CONSTRAINT "FK_0b48703162dc00127b9054d20ef" FOREIGN KEY ("eventId") REFERENCES "events"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "special_days_pricing" ADD CONSTRAINT "FK_8902a66d56af2e5266dfc55f656" FOREIGN KEY ("hallId") REFERENCES "halls"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}
