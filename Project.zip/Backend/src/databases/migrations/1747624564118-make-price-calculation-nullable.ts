import { MigrationInterface, QueryRunner } from "typeorm";

export class MakePriceCalculationNullable1747624564118 implements MigrationInterface {
    name = 'MakePriceCalculationNullable1747624564118'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "priceCalculationType" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "priceCalculationType" SET NOT NULL`);
    }

}
