import { MigrationInterface, QueryRunner } from "typeorm";

export class RemovePaymentMethodsType1739586187094 implements MigrationInterface {
    name = 'RemovePaymentMethodsType1739586187094'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payment_method" DROP COLUMN "type"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payment_method" ADD "type" character varying NOT NULL`);
    }

}
