import { MigrationInterface, QueryRunner } from "typeorm";

export class CascadeHallservicesDelete1728738207231 implements MigrationInterface {
    name = 'CascadeHallservicesDelete1728738207231'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" DROP CONSTRAINT "FK_ae436a243d71f744b8acb6c8e0f"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP CONSTRAINT "FK_8bd1e59c6d787c231d6ad7ff2bc"`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD CONSTRAINT "FK_8bd1e59c6d787c231d6ad7ff2bc" FOREIGN KEY ("service_id") REFERENCES "services"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD CONSTRAINT "FK_ae436a243d71f744b8acb6c8e0f" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" DROP CONSTRAINT "FK_ae436a243d71f744b8acb6c8e0f"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP CONSTRAINT "FK_8bd1e59c6d787c231d6ad7ff2bc"`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD CONSTRAINT "FK_8bd1e59c6d787c231d6ad7ff2bc" FOREIGN KEY ("service_id") REFERENCES "services"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD CONSTRAINT "FK_ae436a243d71f744b8acb6c8e0f" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}
