import { MigrationInterface, QueryRunner } from "typeorm";

export class AddLandingPageCustomerTable1738618117296 implements MigrationInterface {
    name = 'AddLandingPageCustomerTable1738618117296'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "landing_customers" ("id" SERIAL NOT NULL, "created_by" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_by" integer, "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP, "deleted" boolean NOT NULL DEFAULT false, "deleted_by" integer, "name" character varying(255) NOT NULL, "imagePath" text NOT NULL, "imageMimeType" character varying NOT NULL, "site_url" character varying, "order" integer, "landing_page_id" integer NOT NULL, CONSTRAINT "PK_365c09f48f720224c55b20caef9" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ALTER COLUMN "startDate" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ALTER COLUMN "endDate" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ALTER COLUMN "morningPrice" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ALTER COLUMN "eveningPrice" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ALTER COLUMN "fullDayPrice" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "landing_customers" ADD CONSTRAINT "FK_6d8c3b63fb842732dc6d2cba3eb" FOREIGN KEY ("landing_page_id") REFERENCES "hall_landing_pages"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "landing_customers" DROP CONSTRAINT "FK_6d8c3b63fb842732dc6d2cba3eb"`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ALTER COLUMN "fullDayPrice" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ALTER COLUMN "eveningPrice" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ALTER COLUMN "morningPrice" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ALTER COLUMN "endDate" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ALTER COLUMN "startDate" DROP NOT NULL`);
        await queryRunner.query(`DROP TABLE "landing_customers"`);
    }

}
