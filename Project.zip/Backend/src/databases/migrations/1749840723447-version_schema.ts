import { MigrationInterface, QueryRunner } from 'typeorm';

export class VersionSchema1749840723447 implements MigrationInterface {
  name = 'VersionSchema1749840723447';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "version_history" (
        "id" SERIAL NOT NULL,
        "version_number" character varying NOT NULL,
        "whats_new_en" text NOT NULL,
        "whats_new_ar" text NOT NULL,
        "feature" character varying,
        "stack" character varying NOT NULL,
        "released_date" TIMESTAMP NOT NULL DEFAULT now(),
        "created_by" integer,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        "updated_by" integer,
        "updated_at" TIMESTAMP NOT NULL DEFAULT now(),
        "deleted_at" TIMESTAMP,
        "deleted" boolean NOT NULL DEFAULT false,
        "deleted_by" integer,
        CONSTRAINT "PK_5db259cbb09ce82c0d13cfd1b23" PRIMARY KEY ("id")
      )
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "version_history"`);
  }
}
