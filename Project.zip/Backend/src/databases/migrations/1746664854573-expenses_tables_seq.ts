import { MigrationInterface, QueryRunner } from 'typeorm';

export class ExpensesTablesSeq1746664854573 implements MigrationInterface {
  name = 'ExpensesTablesSeq1746664854573';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            SELECT setval('expenses_details_id_seq', COALESCE((SELECT MAX(id) FROM expenses_details), 0) + 1, false);
          `);
    await queryRunner.query(`
            SELECT setval('expenses_payments_id_seq', COALESCE((SELECT MAX(id) FROM expenses_payments), 0) + 1, false);
          `);
    await queryRunner.query(`
            SELECT setval('expenses_attachments_id_seq', COALESCE((SELECT MAX(id) FROM expenses_attachments), 0) + 1, false);
          `);
    await queryRunner.query(`
            SELECT setval('expenses_id_seq', COALESCE((SELECT MAX(id) FROM expenses), 0) + 1, false);
          `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> { }
}
