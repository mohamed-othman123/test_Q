import { MigrationInterface, QueryRunner } from "typeorm";

export class EditHallServicesTable1728949881907 implements MigrationInterface {
    name = 'EditHallServicesTable1728949881907'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "maleCoordinatorsNo" integer`);
        await queryRunner.query(`ALTER TABLE "halls_services" ADD "femaleCoordinatorsNo" integer`);
        await queryRunner.query(`ALTER TABLE "events" DROP CONSTRAINT "FK_b4ea5a78d656e3c29835bf644e6"`);
        await queryRunner.query(`ALTER TABLE "events" ALTER COLUMN "client_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls" DROP CONSTRAINT "FK_84efe33150872aa4dbb7af31b3b"`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "client_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "contracts" DROP CONSTRAINT "FK_9945462ca96b2c7d0a97e012cdc"`);
        await queryRunner.query(`ALTER TABLE "contracts" ALTER COLUMN "client_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "events" ADD CONSTRAINT "FK_b4ea5a78d656e3c29835bf644e6" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        // await queryRunner.query(`ALTER TABLE "services" ADD CONSTRAINT "FK_458874e221f4ed82fa478b755d8" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "halls" ADD CONSTRAINT "FK_84efe33150872aa4dbb7af31b3b" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD CONSTRAINT "FK_9945462ca96b2c7d0a97e012cdc" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contracts" DROP CONSTRAINT "FK_9945462ca96b2c7d0a97e012cdc"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP CONSTRAINT "FK_84efe33150872aa4dbb7af31b3b"`);
        await queryRunner.query(`ALTER TABLE "services" DROP CONSTRAINT "FK_458874e221f4ed82fa478b755d8"`);
        await queryRunner.query(`ALTER TABLE "events" DROP CONSTRAINT "FK_b4ea5a78d656e3c29835bf644e6"`);
        await queryRunner.query(`ALTER TABLE "contracts" ALTER COLUMN "client_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "contracts" ADD CONSTRAINT "FK_9945462ca96b2c7d0a97e012cdc" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "halls" ALTER COLUMN "client_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "halls" ADD CONSTRAINT "FK_84efe33150872aa4dbb7af31b3b" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "events" ALTER COLUMN "client_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "events" ADD CONSTRAINT "FK_b4ea5a78d656e3c29835bf644e6" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "femaleCoordinatorsNo"`);
        await queryRunner.query(`ALTER TABLE "halls_services" DROP COLUMN "maleCoordinatorsNo"`);
    }

}
