import { MigrationInterface, QueryRunner } from "typeorm";

export class DropUnusedViewsTable1748692656273 implements MigrationInterface {
    name = 'DropUnusedViewsTable1748692656273'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP VIEW IF EXISTS "calender_view" CASCADE`);
        await queryRunner.query(`DROP VIEW IF EXISTS "chart_view" CASCADE`);
        await queryRunner.query(`DROP VIEW IF EXISTS "last_Month_payments_view" CASCADE`);
        await queryRunner.query(`DROP VIEW IF EXISTS "last_Week_payments_view" CASCADE`);
        await queryRunner.query(`DROP VIEW IF EXISTS "next_booking_view" CASCADE`);
        await queryRunner.query(`DROP VIEW IF EXISTS "statistics_view" CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {}
}
       