import { MigrationInterface, QueryRunner } from 'typeorm';

export class ContractHall1732307294772 implements MigrationInterface {
  name = 'ContractHall1732307294772';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "contracts" ADD "hall_id" integer`);
    await queryRunner.query(
      `ALTER TABLE "contracts" ADD CONSTRAINT "FK_7c1ddf7c55fbac55f18f67249a7" FOREIGN KEY ("hall_id") REFERENCES "halls"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contracts" DROP CONSTRAINT "FK_7c1ddf7c55fbac55f18f67249a7"`,
    );
    await queryRunner.query(`ALTER TABLE "contracts" DROP COLUMN "hall_id"`);
  }
}
