import { MigrationInterface, QueryRunner } from 'typeorm';

export class AlterPurchaseCategoriesAddClientId1746019049065 implements MigrationInterface {
  name = 'AlterPurchaseCategoriesAddClientId1746019049065';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "purchase_categories" ADD "client_id" integer`);

    await queryRunner.query(
      `ALTER TABLE "purchase_categories" ADD CONSTRAINT "FK_321091a5147997e6e15a4bd3a60" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchase_categories" DROP CONSTRAINT "FK_321091a5147997e6e15a4bd3a60"`,
    );

    await queryRunner.query(`ALTER TABLE "purchase_categories" DROP COLUMN "client_id"`);
  }
}
