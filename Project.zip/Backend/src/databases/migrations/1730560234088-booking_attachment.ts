import { MigrationInterface, QueryRunner } from 'typeorm';

export class BookingAttachment1730560234088 implements MigrationInterface {
  name = 'BookingAttachment1730560234088';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" ADD "attachment" text`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "attachment"`);
  }
}
