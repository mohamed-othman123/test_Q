import { MigrationInterface, QueryRunner } from "typeorm";

export class AddTitleColumHallSpcialDaysPricingTable1741900818341 implements MigrationInterface {
    name = 'AddTitleColumHallSpcialDaysPricingTable1741900818341'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" ADD "title" character varying`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "hall_special_days_pricing" DROP COLUMN "title"`);
    }

}
