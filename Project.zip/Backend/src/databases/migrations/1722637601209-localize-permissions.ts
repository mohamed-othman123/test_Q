import { MigrationInterface, QueryRunner } from 'typeorm';

export class LocalizePermissions1722637601209 implements MigrationInterface {
  name = 'LocalizePermissions1722637601209';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "permission" DROP COLUMN "module"`);
    await queryRunner.query(`ALTER TABLE "permission" DROP COLUMN "name"`);
    await queryRunner.query(`ALTER TABLE "permission" ADD "ar_name" character varying`);
    await queryRunner.query(`ALTER TABLE "permission" ADD "en_name" character varying`);
    await queryRunner.query(`ALTER TABLE "permission" ADD "ar_module" character varying`);
    await queryRunner.query(`ALTER TABLE "permission" ADD "en_module" character varying`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "permission" DROP COLUMN "en_module"`);
    await queryRunner.query(`ALTER TABLE "permission" DROP COLUMN "ar_module"`);
    await queryRunner.query(`ALTER TABLE "permission" DROP COLUMN "en_name"`);
    await queryRunner.query(`ALTER TABLE "permission" DROP COLUMN "ar_name"`);
    await queryRunner.query(`ALTER TABLE "permission" ADD "name" character varying NOT NULL`);
    await queryRunner.query(`ALTER TABLE "permission" ADD "module" character varying NOT NULL`);
  }
}
