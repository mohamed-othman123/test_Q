import { MigrationInterface, QueryRunner } from 'typeorm';

export class Suppliers1725391526310 implements MigrationInterface {
  name = 'Suppliers1725391526310';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "suppliers" ("id" SERIAL NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted" boolean NOT NULL DEFAULT false, "deleted_at" TIMESTAMP, "deleted_by" integer, "name" character varying NOT NULL, "taxRegistrationNumber" character varying NOT NULL, "commercialRegistrationNumber" character varying NOT NULL, "email" character varying, "phone" character varying NOT NULL, "type" character varying NOT NULL, "address" character varying, "note" text, "client_id" integer, CONSTRAINT "PK_b70ac51766a9e3144f778cfe81e" PRIMARY KEY ("id"))`,
    );

    await queryRunner.query(
      `ALTER TABLE "suppliers" ADD CONSTRAINT "FK_1eac3ac38b455af8345adf400c4" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "suppliers" DROP CONSTRAINT "FK_1eac3ac38b455af8345adf400c4"`,
    );

    await queryRunner.query(`DROP TABLE "suppliers"`);
  }
}
