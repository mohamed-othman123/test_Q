import { MigrationInterface, QueryRunner } from "typeorm";

export class BookingPdfs1743972081616 implements MigrationInterface {
    name = 'BookingPdfs1743972081616'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "booking" ADD "contract_pdf_id" integer`);
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "UQ_d3da56f4894f0841b0e7c6e9882" UNIQUE ("contract_pdf_id")`);
        await queryRunner.query(`ALTER TABLE "booking" ADD "invoice_pdf_id" integer`);
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "UQ_3e993005638a308dfe7686d54d6" UNIQUE ("invoice_pdf_id")`);
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "FK_d3da56f4894f0841b0e7c6e9882" FOREIGN KEY ("contract_pdf_id") REFERENCES "document_pdf"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "booking" ADD CONSTRAINT "FK_3e993005638a308dfe7686d54d6" FOREIGN KEY ("invoice_pdf_id") REFERENCES "document_pdf"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "FK_3e993005638a308dfe7686d54d6"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "FK_d3da56f4894f0841b0e7c6e9882"`);
       
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "UQ_3e993005638a308dfe7686d54d6"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "invoice_pdf_id"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP CONSTRAINT "UQ_d3da56f4894f0841b0e7c6e9882"`);
        await queryRunner.query(`ALTER TABLE "booking" DROP COLUMN "contract_pdf_id"`);
    }

}
