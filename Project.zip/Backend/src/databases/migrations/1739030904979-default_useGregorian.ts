import { MigrationInterface, QueryRunner } from 'typeorm';

export class DefaultUseGregorian1739030904979 implements MigrationInterface {
  name = 'DefaultUseGregorian1739030904979';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ALTER COLUMN "useGregorian" SET DEFAULT true`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "purchase_payments" ALTER COLUMN "useGregorian" SET DEFAULT false`,
    );
  }
}
