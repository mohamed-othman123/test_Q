import { MigrationInterface, QueryRunner } from 'typeorm';

export class DropUnusedLandingPagesTables1744302481674 implements MigrationInterface {
  name = 'DropUnusedLandingPagesTables1744302481674';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "landing_customers" DROP CONSTRAINT "FK_6d8c3b63fb842732dc6d2cba3eb"`,
    );

    await queryRunner.query(
      `ALTER TABLE "landing_social_Links" DROP CONSTRAINT "FK_ca36df0526daec4a0706c93e557"`,
    );
    await queryRunner.query(
      `ALTER TABLE "hall_landing_pages" DROP CONSTRAINT "FK_42300935e46a635b87b7be531c1"`,
    );
    await queryRunner.query(
      `ALTER TABLE "hall_landing_pages" DROP CONSTRAINT "FK_f870ba265b1e512263966174466"`,
    );
    await queryRunner.query(
      `ALTER TABLE "landing_images" DROP CONSTRAINT "FK_908a1511da280bd0e7de4933f1a"`,
    );
    await queryRunner.query(
      `ALTER TABLE "landing_banners" DROP CONSTRAINT "FK_b020fb4c4d5424b74fed68f9e4f"`,
    );
    await queryRunner.query(
      `ALTER TABLE "landing_features" DROP CONSTRAINT "FK_180140b4daeba254a869b4d3f7b"`,
    );
    await queryRunner.query(
      `ALTER TABLE "landing_popular_questions" DROP CONSTRAINT "FK_67dd08426f9104167001f37b193"`,
    );
    await queryRunner.query(`DROP TABLE "landing_social_Links"`);
    await queryRunner.query(`DROP TABLE "landing_customers"`);
    await queryRunner.query(`DROP TABLE "hall_landing_pages"`);
    await queryRunner.query(`DROP TABLE "landing_images"`);
    await queryRunner.query(`DROP TABLE "landing_banners"`);
    await queryRunner.query(`DROP TABLE "landing_features"`);
    await queryRunner.query(`DROP TABLE "landing_popular_questions"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
