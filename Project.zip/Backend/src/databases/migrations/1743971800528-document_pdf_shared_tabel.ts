import { MigrationInterface, QueryRunner } from 'typeorm';

export class DocumentPdfSharedTabel1743971800528 implements MigrationInterface {
  name = 'DocumentPdfSharedTabel1743971800528';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "document_pdf" ("id" SERIAL NOT NULL, "ar_version" text, "en_version" text, "hash" character varying, "secret" character varying NOT NULL, "type" character varying, "status" character varying NOT NULL DEFAULT 'PENDING', "access_count" integer NOT NULL DEFAULT '0', "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_999f1ad367f51985a2db2800754" PRIMARY KEY ("id"))`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "document_pdf"`);
  }
}
