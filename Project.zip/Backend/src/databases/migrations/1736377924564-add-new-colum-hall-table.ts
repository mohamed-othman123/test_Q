import { MigrationInterface, QueryRunner } from "typeorm";

export class AddNewColumHallTable1736377924564 implements MigrationInterface {
    name = 'AddNewColumHallTable1736377924564'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "note"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "mensCapacity"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "womensCapacity"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "totalCapacity"`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "pricingOnBooking" boolean NOT NULL DEFAULT true`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "fixedPrice" boolean`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "specialDays" boolean NOT NULL DEFAULT false`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "specialDays"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "fixedPrice"`);
        await queryRunner.query(`ALTER TABLE "halls" DROP COLUMN "pricingOnBooking"`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "totalCapacity" integer`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "womensCapacity" integer`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "mensCapacity" integer`);
        await queryRunner.query(`ALTER TABLE "halls" ADD "note" text`);
    }

}
