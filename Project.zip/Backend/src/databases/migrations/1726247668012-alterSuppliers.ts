import { MigrationInterface, QueryRunner } from 'typeorm';

export class alterSuppliers1726247668012 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('ALTER TABLE "suppliers" DROP COLUMN "type"');
    await queryRunner.query(`
        ALTER TABLE suppliers
        ADD COLUMN "active" boolean DEFAULT true,
        ADD COLUMN "activity" text NULL,
        ADD COLUMN "bankName" varchar NULL,
        ADD COLUMN "IBAN" varchar NULL;
      `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
        ALTER TABLE suppliers
        DROP COLUMN "active",
        DROP COLUMN "activity",
        DROP COLUMN "bankName",
        DROP COLUMN "IBAN";
      `);
  }
}
