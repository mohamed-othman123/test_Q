import { MigrationInterface, QueryRunner } from "typeorm";

export class AddIsAdminColumHallModeratorTable1729950437605 implements MigrationInterface {
    name = 'AddIsAdminColumHallModeratorTable1729950437605'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_event" DROP COLUMN "isAdmin"`);
        await queryRunner.query(`ALTER TABLE "halls_moderator" ADD "isAdmin" boolean NOT NULL DEFAULT false`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "halls_moderator" DROP COLUMN "isAdmin"`);
        await queryRunner.query(`ALTER TABLE "halls_event" ADD "isAdmin" boolean NOT NULL DEFAULT false`);
    }

}
