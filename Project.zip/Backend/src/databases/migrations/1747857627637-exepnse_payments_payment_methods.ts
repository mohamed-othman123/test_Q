import { MigrationInterface, QueryRunner } from 'typeorm';

export class ExepnsePaymentsPaymentMethods1747857627637 implements MigrationInterface {
  name = 'ExepnsePaymentsPaymentMethods1747857627637';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP CONSTRAINT "FK_6c8656e9aa582b240f13e1fbfcf"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP CONSTRAINT "FK_37972b2b501afd2e474fd0253e9"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP CONSTRAINT "UQ_b46b86af4665d6f7a39710b1644"`,
    );
    await queryRunner.query(`ALTER TABLE "expenses_payments" DROP COLUMN "bank_details_id"`);
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" RENAME COLUMN "paymentMethod_id" TO "hall_payment_method_id"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD "supplier_payment_method_id" integer`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD "item_transfer_account_id" integer`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD CONSTRAINT "FK_38bc3fe81b916b2e1228c9baf03" FOREIGN KEY ("hall_payment_method_id") REFERENCES "payment_method"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD CONSTRAINT "FK_4204553fbda9fb1b300dc64da19" FOREIGN KEY ("supplier_payment_method_id") REFERENCES "supplier_payment_methods"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD CONSTRAINT "FK_2a978f52f6f187471ea8de495e9" FOREIGN KEY ("item_transfer_account_id") REFERENCES "expense_item_transfer_accounts"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query('DROP TABLE "payment_bank_details"');
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP CONSTRAINT "FK_2a978f52f6f187471ea8de495e9"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP CONSTRAINT "FK_4204553fbda9fb1b300dc64da19"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP CONSTRAINT "FK_38bc3fe81b916b2e1228c9baf03"`,
    );

    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP COLUMN "item_transfer_account_id"`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" DROP COLUMN "supplier_payment_method_id"`,
    );
    await queryRunner.query(`ALTER TABLE "expenses_payments" DROP COLUMN "hall_payment_method_id"`);
    await queryRunner.query(`ALTER TABLE "expenses_payments" ADD "bank_details_id" integer`);

    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD "paymentMethod_id" integer NOT NULL`,
    );

    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD CONSTRAINT "FK_37972b2b501afd2e474fd0253e9" FOREIGN KEY ("bank_details_id") REFERENCES "payment_bank_details"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
    await queryRunner.query(
      `ALTER TABLE "expenses_payments" ADD CONSTRAINT "FK_6c8656e9aa582b240f13e1fbfcf" FOREIGN KEY ("paymentMethod_id") REFERENCES "payment_method"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }
}
