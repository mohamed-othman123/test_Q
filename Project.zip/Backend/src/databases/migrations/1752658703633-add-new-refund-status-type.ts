import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddNewRefundStatusType1752658703633 implements MigrationInterface {
  name = 'AddNewRefundStatusType1752658703633';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TYPE "public"."refund_requests_type_enum" ADD VALUE 'in_progress';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
