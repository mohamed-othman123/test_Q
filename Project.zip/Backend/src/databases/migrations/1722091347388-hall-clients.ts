import { MigrationInterface, QueryRunner } from 'typeorm';

export class HallClients1722091347388 implements MigrationInterface {
  name = 'HallClients1722091347388';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "halls_clients" ("id" SERIAL NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), "deleted" boolean NOT NULL DEFAULT false, "deleted_at" TIMESTAMP, "deleted_by" integer, "name" character varying(255) NOT NULL, "phone" character varying(255) NOT NULL, "company" character varying(255), "address" character varying(255), "email" character varying(255), "client_id" integer, CONSTRAINT "PK_e98ae0a608f2fec8d457d7f3b9f" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `ALTER TABLE "halls_clients" ADD CONSTRAINT "FK_76153951135b488e28df283c0ee" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE RESTRICT ON UPDATE CASCADE`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "halls_clients" DROP CONSTRAINT "FK_76153951135b488e28df283c0ee"`,
    );
    await queryRunner.query(`DROP TABLE "halls_clients"`);
  }
}
