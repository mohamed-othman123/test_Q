import { MigrationInterface, QueryRunner } from "typeorm";

export class AddNewFieldPayment1728552786675 implements MigrationInterface {
    name = 'AddNewFieldPayment1728552786675'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payments" ADD "payment_date" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "payments" ADD "useGregorian" boolean NOT NULL DEFAULT true`);
        // await queryRunner.query(`ALTER TABLE "services" ADD CONSTRAINT "FK_458874e221f4ed82fa478b755d8" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "services" DROP CONSTRAINT "FK_458874e221f4ed82fa478b755d8"`);
        await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "useGregorian"`);
        // await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "payment_date"`);
    }

}
