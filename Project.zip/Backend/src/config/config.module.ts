import { Module } from '@nestjs/common';
import { ConfigModule as NestConfigModule } from '@nestjs/config';
import configuration from './configuration';
import {join} from 'path';

@Module({
  imports: [
    NestConfigModule.forRoot({
      isGlobal: true,
      envFilePath:join(
        process.cwd(),
        `${process.env.NODE_ENV == 'development' || 'local' ? 'src' : 'dist'}/config/environments/.${process.env.NODE_ENV}.env`,
      ),
      load: [configuration],
    }),
  ],
  exports: [NestConfigModule],
})
export class ConfigModule {}
