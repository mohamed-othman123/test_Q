import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Connection, Repository } from 'typeorm';
import { GetStatistics } from './dtos/getStatistic.dto';
import { HallsService } from '../halls/halls.service';
import { GetAllPaymentsDto } from './dtos/getAllPayments.dto';
import { CreateFilterPayment } from '../../common/enums/createFilterPayments.enum';
import { PaginatorService } from '../../common/paginator/paginator.service';
import { CalendarBookingDto } from './dtos/calender.dto';
import { GroupedBookings } from './interfaces/calender.interface';
import { Booking } from '../booking/entities/booking.entity';
import { NextBookingDto } from './dtos/nextBooking.dto';
import { PaymentEntity } from '../payment/entities/payment.entity';
import { ChartDto } from './dtos/chart.dto';
import moment from 'moment-hijri';
import { ExpensePaymentEntity } from '../expenses-payments/entities/expense_payments.entity';
import { HallClientsGenderEnum } from '../../common/enums/hallClientsGenderEnum.enum';
import { ExpensesEntity } from '../expenses/entities/expense.entity';
import { EventTimeEnum } from '../booking/enums/event-time.enum';

@Injectable()
export class StatisticsService {
  constructor(
    @InjectRepository(Booking)
    private readonly bookingRepository: Repository<Booking>,
    @InjectRepository(ExpensesEntity)
    private readonly expnesesRepository: Repository<ExpensesEntity>,
    @InjectRepository(PaymentEntity)
    private readonly paymentRepository: Repository<PaymentEntity>,
    @InjectRepository(ExpensePaymentEntity)
    private readonly expensePaymentRepository: Repository<ExpensePaymentEntity>,
    @InjectConnection() private readonly connection: Connection,
    private readonly hallsService: HallsService,
    private readonly paginatorService: PaginatorService,
  ) { }

  async getStatistics(
    query: GetStatistics,
    user: { clientId: number; id: number },
  ): Promise<{
    totalBookings: number;
    totalRevenue: number;
    totalExpenses: number;
    totalNet: number;
    totalTax: number;
    occupancyRate: number;
  }> {
    const { clientId } = user;
    let { hallId, months, fromDate, toDate } = query;

    await this.hallsService.findHall(hallId, clientId);
    // Base parameters to avoid repetition
    const baseParams = { clientId, deleted: false, hallId, canceled: 'Canceled', isConfirmed: true };
    // Determine date filtering logic

    const { startDate, endDate } = this.getDates(months, fromDate, toDate)

    // Apply date filters based on provided dates
    const dateFilters = { startDate, endDate };

    // Initialize expense payment query builder
    const expensePaymentBuilder = this.expensePaymentRepository
      .createQueryBuilder('ep')
      .leftJoinAndSelect('ep.expense', 'expense')
      .where('ep.client_id = :clientId', baseParams)
      .andWhere('ep.deleted = :deleted', baseParams)
      .andWhere('expense.hall_id = :hallId', baseParams)
      .andWhere('ep.payment_date::date BETWEEN :startDate AND :endDate', dateFilters)
      .select([
        'SUM(CASE WHEN ep.paymentType = :income THEN ep.amount ELSE 0 END) AS total_income',
        'SUM(CASE WHEN ep.paymentType = :refund THEN ep.amount ELSE 0 END) AS total_refund'
      ])
      .setParameters({ income: 'Income', refund: 'Refund' });

    // Initialize booking payment query builder
    const bookingPaymentBuilder = this.paymentRepository
      .createQueryBuilder('p')
      .leftJoinAndSelect('p.booking', 'booking')
      .where('p.client_id = :clientId', baseParams)
      .andWhere('p.deleted = :deleted', baseParams)
      .andWhere('booking.hall_id = :hallId', baseParams)
      .andWhere('booking.isConfirmed = :isConfirmed',baseParams)
      .andWhere('p.payment_date::date BETWEEN :startDate AND :endDate', dateFilters)
      .select(['SUM(CASE WHEN p.paymentType = :income THEN p.amount ELSE 0 END) AS total_income', 'SUM(CASE WHEN p.paymentType = :refund THEN p.amount ELSE 0 END) AS total_refund'])
      .setParameters({ income: 'Income', refund: 'Refund' })

    const bookingBuilder = this.bookingRepository
      .createQueryBuilder('booking')
      .leftJoinAndSelect('booking.sections', 'section')
      .where('booking.client_id = :clientId', baseParams)
      .andWhere('booking.deleted = :deleted', baseParams)
      .andWhere('booking.hall_id = :hallId', baseParams)
      .andWhere('booking.bookingProcessStatus != :canceled', baseParams)
      .andWhere('booking.isConfirmed = :isConfirmed', baseParams)
      .andWhere('booking.start_date BETWEEN :startDate AND :endDate', dateFilters)
      .select([
        'COUNT(DISTINCT booking.id) AS total_bookings',
        'COUNT(DISTINCT section.id) AS total_sections',
        'SUM((booking.end_date - booking.start_date)) AS total_booked_days',
        'SUM(DISTINCT (CASE WHEN booking.bookingProcessStatus IN (:...statuses) THEN (booking.subtotal_after_disc * (booking.vat / 100)) ELSE 0 END)) AS total_vat'
      ])
      .setParameters({ statuses: ['Fully Paid', 'Completed'] })


    // Initialize expenses query builder
    const expensesBuilder = this.expnesesRepository
      .createQueryBuilder('e')
      .where('e.client_id = :clientId', baseParams)
      .andWhere('e.deleted = :deleted', baseParams)
      .andWhere('e.hall_id = :hallId', baseParams)
      .andWhere('e.status != :canceled', baseParams)
      .andWhere('e.purchase_date::date BETWEEN :startDate AND :endDate', dateFilters)
      .select([
        'SUM(CASE WHEN e.status IN (:...statuses) THEN (e.vat) ELSE 0 END) AS total_vat'
      ]).setParameters({ statuses: ['Fully Paid', 'Completed'] });

    // Execute queries and group results
    const [bookings, bookingPayments, expenses, expensePayments] = await Promise.all([
      bookingBuilder.groupBy('booking.hall_id').getRawOne(),
      bookingPaymentBuilder.groupBy('booking.hall_id').getRawOne(),
      expensesBuilder.groupBy('e.hall_id').getRawOne(),
      expensePaymentBuilder.groupBy('expense.hall_id').getRawOne(),
    ]);

    // Calculate the number of days between fromDate and toDate
    const numberOfDays = Math.floor(
      (new Date(endDate).getTime() - new Date(startDate).getTime()) / (1000 * 60 * 60 * 24)
    );


    const totalBookings = +bookings?.total_bookings || 0;
    const totalSections = +bookings?.total_sections || 0;
    const totalBookedDays = +bookings?.total_booked_days || 0;
    const totalBookingVat = +bookings?.total_vat || 0
    const totalBookingIncome = +bookingPayments?.total_income || 0;
    const totalBookingRefund = +bookingPayments?.total_refund || 0;
    const totalExpensesIncome = +expensePayments?.total_income || 0;
    const totalExpensesRefund = +expensePayments?.total_refund || 0;
    const totalExpensesVat = +expenses?.total_vat || 0




    // Calculate totals
    const totalRevenue = (totalBookingIncome + totalExpensesRefund).toFixed(2);

    const totalExpenses = (totalBookingRefund + totalExpensesIncome).toFixed(2);

    const total_net = (+totalRevenue - +totalExpenses).toFixed(2);

    const total_tax = (totalBookingVat - totalExpensesVat).toFixed(2)

    const occupancy_rate = (
      (totalBookedDays / Math.max(numberOfDays * totalSections, 1)) *
      100
    ).toFixed(2);

    return {
      totalBookings: +totalBookings,
      totalRevenue: +totalRevenue,
      totalExpenses: +totalExpenses,
      totalNet: +total_net,
      totalTax: +total_tax,
      occupancyRate: +occupancy_rate,
    };
  }
  async getNextBooking(
    query: NextBookingDto,
    user: { clientId: number; id: number },
  ): Promise<{
    id: number;
    startDate: Date;
    endDate: Date;
    eventTime: EventTimeEnum;
    bookingProcessStatus: string;
    userName: string;
    userPhone: string;
    userEmail: string | null;
    userType: string;
    userGender: HallClientsGenderEnum;
    isVIB: boolean;
  }[]> {
    const { clientId } = user;
    const { hallId } = query;
    await this.hallsService.findHall(hallId, clientId);
    // Base parameters to avoid repetition
    const baseParams = { clientId, deleted: false, hallId, canceled: 'Canceled', isConfirmed: true, fullDay: EventTimeEnum.fullDay, morning: EventTimeEnum.morning, evening: EventTimeEnum.evening };
    // Subquery to get the next booking date
    const nextBookingDateSubquery = `(SELECT MIN(b.start_date) FROM booking b 
                                    WHERE b.start_date >= CURRENT_DATE 
                                    AND b.client_id = :clientId 
                                    AND b.deleted = :deleted 
                                    AND b.hall_id = :hallId 
                                    AND b."bookingProcessStatus" != :canceled 
                                    AND b."isConfirmed" = :isConfirmed)`;
    const bookings = await this.bookingRepository
      .createQueryBuilder('booking')
      .withDeleted()
      .leftJoinAndSelect('booking.user', 'customer')
      .where('booking.client_id = :clientId', baseParams)
      .andWhere('booking.deleted = :deleted', baseParams)
      .andWhere('booking.hall_id = :hallId', baseParams)
      .andWhere('booking.bookingProcessStatus != :canceled', baseParams)
      .andWhere('booking.isConfirmed = :isConfirmed', baseParams)
      .andWhere('booking.start_date >= CURRENT_DATE')
      .andWhere(`booking.start_date = ${nextBookingDateSubquery}`)
      .orderBy('booking.start_date', 'ASC')
      .addOrderBy('CASE booking.event_time ' +
        'WHEN :fullDay THEN 1 ' +
        'WHEN :morning THEN 2 ' +
        'WHEN :evening THEN 3 ' +
        'ELSE 4 END',
        'ASC')
      .setParameters(baseParams)
      .select([
        'booking.id AS id',
        'booking.start_date',
        'booking.end_date',
        'booking.bookingProcessStatus AS status',
        'booking.event_time',
        'customer.name AS name',
        'customer.type AS type',
        'customer.phone AS phone',
        'customer.email AS email',
        'customer.isVIB AS is_vib',
        'customer.gender AS gender'
      ])
      .getRawMany();
    // Map the results to the desired return format
    return bookings.map(booking => ({
      id: booking.id,
      startDate: booking.start_date,
      endDate: booking.end_date,
      eventTime: booking.event_time,
      bookingProcessStatus: booking.status,
      userName: booking.name,
      userPhone: booking.phone,
      userEmail: booking.email,
      userType: booking.type,
      userGender: booking.gender,
      isVIB: booking.is_vib,
    }));
  }

  async getBookedCalender(
    query: CalendarBookingDto,
    user: { clientId: number; id: number },
  ): Promise<GroupedBookings> {
    const { clientId } = user;
    const { hallId, year, month } = query;
    // Ensure the hall exists
    await this.hallsService.findHall(hallId, clientId);
    const baseParams = { clientId, deleted: false, hallId, canceled: 'Canceled' };

    const queryBuilder = this.bookingRepository
      .createQueryBuilder('booking')
      .where('booking.client_id = :clientId', baseParams)
      .andWhere('booking.deleted = :deleted', baseParams)
      .andWhere('booking.hall_id = :hallId', baseParams)
      .andWhere('booking.bookingProcessStatus != :canceled', baseParams)
      .andWhere('booking.isConfirmed = :isConfirmed', { isConfirmed: true })
      .andWhere(
        `(
          (booking.start_date BETWEEN :startOfMonth AND :endOfMonth)
          OR (booking.end_date BETWEEN :startOfMonth AND :endOfMonth)
          OR (booking.start_date <= :endOfMonth AND booking.end_date >= :startOfMonth)
        )`,
        {
          startOfMonth: moment(`${year}-${String(month).padStart(2, '0')}-01`)
            .locale('en')
            .format('YYYY-MM-DD'),

          endOfMonth: moment(`${year}-${String(month).padStart(2, '0')}-01`)
            .endOf('month')
            .locale('en')
            .format('YYYY-MM-DD'),
        },
      );

    const result = await queryBuilder.getMany();


    // Grouping by booking_day
    const groupedByDay = result
      .flatMap((booking) => {
        const startDate = moment.utc(booking.startDate).locale('en').startOf('day');
        const endDate = moment.utc(booking.endDate).locale('en').startOf('day');

        let currentDate = moment(startDate);

        const groupedBookings: Record<number, any[]> = {};

        while (currentDate.isSameOrBefore(endDate)) {
          if (currentDate.year() === year && currentDate.month() + 1 === month) {
            const day = currentDate.date();

            const transformedBooking = {
              id: booking.id,
              startDate: booking.startDate,
              endDate: booking.endDate,
              bookingProcessStatus: booking.bookingProcessStatus,
              day,
            };

            if (!groupedBookings[day]) {
              groupedBookings[day] = [];
            }
            groupedBookings[day].push(transformedBooking);
          }

          currentDate.add(1, 'day');
        }

        return Object.entries(groupedBookings).map(([day, bookings]) => ({
          day: Number(day),
          bookings,
        }));
      })
      .reduce((acc, { day, bookings }) => {
        if (!acc[day]) {
          acc[day] = [];
        }
        acc[day].push(...bookings);
        return acc;
      }, {});

    return groupedByDay;
  }

  async getAllPayments(
    query: GetAllPaymentsDto,
    user: { clientId: number; id: number },
  ): Promise<{
    items: {
      paymentId: number;
      paymentDate: Date;
      paymentName: string;
      paymentType: string;
      paymentAmount: number;
      source: string;
    }[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    const { clientId } = user;
    let { hallId, months, fromDate, toDate, page, limit, filter } = query;
    const take = +limit || 5;
    const skip = ((+page || 1) - 1) * take;

    await this.hallsService.findHall(hallId, clientId);
    // Base parameters to avoid repetition
    const baseParams = { clientId, deleted: false, hallId, canceled: 'Canceled' };


    const { startDate, endDate } = this.getDates(months, fromDate, toDate)

    // Apply date filters based on provided dates
    const dateFilters = { startDate, endDate };

    // Initialize expense payment query builder
    const expensePaymentBuilder = this.expensePaymentRepository
      .createQueryBuilder('ep')
      .withDeleted()
      .leftJoinAndSelect('ep.expense', 'expense')
      .leftJoinAndSelect('expense.supplier', 'supplier')
      .where('ep.client_id = :clientId', baseParams)
      .andWhere('ep.deleted = :deleted', baseParams)
      .andWhere('expense.hall_id = :hallId', baseParams)
      .andWhere('ep.payment_date::date BETWEEN :startDate AND :endDate', dateFilters)
      .select([
        'ep.id AS payment_id',
        'supplier.name AS payment_name',
        'ep.payment_date AS payment_date',
        'ep.paymentType AS payment_type',
        'ep.amount AS payment_amount',
        `'purchase_payment' AS source`,
      ]);
    const paymentsBuilder = this.paymentRepository
      .createQueryBuilder('p')
      .withDeleted()
      .leftJoinAndSelect('p.booking', 'booking')
      .leftJoinAndSelect('p.user', 'hallClient')
      .where('p.client_id = :clientId', baseParams)
      .andWhere('p.deleted = :deleted', baseParams)
      .andWhere('booking.hall_id = :hallId', baseParams)
      .andWhere('booking.isConfirmed = :isConfirmed', { isConfirmed: true })
      .andWhere('p.payment_date::date BETWEEN :startDate AND :endDate', dateFilters)
      .select([
        'p.id AS payment_id',
        'hallClient.name AS payment_name',
        'hallClient.isVIB AS is_vib',
        'p.payment_date AS payment_date',
        'p.paymentType AS payment_type',
        'p.amount AS payment_amount',
        `'payment' AS source`,
      ]);

    // Apply date filters based on provided filters
    if (filter === CreateFilterPayment.Income) {
      paymentsBuilder.andWhere('p.paymentType = :income', { income: 'Income' });
      expensePaymentBuilder.andWhere('ep.paymentType = :income', { income: 'Refund' });
    } else if (filter === CreateFilterPayment.Expense) {
      paymentsBuilder.andWhere('p.paymentType = :refund', { refund: 'Refund' });
      expensePaymentBuilder.andWhere('ep.paymentType = :refund', { refund: 'Income' });
    }

    // Execute both queries concurrently using Promise.all
    const [paymentsResult, expensePaymentsResult] = await Promise.all([
      paymentsBuilder
        .orderBy('p.amount', 'DESC')
        .addOrderBy('p.payment_date', 'DESC')
        .skip(skip)
        .take(take)
        .getRawMany(),
      expensePaymentBuilder
        .orderBy('ep.amount', 'DESC')
        .addOrderBy('ep.payment_date', 'DESC')
        .skip(skip)
        .take(take)
        .getRawMany(),
    ]);

    // Combine the payment results
    const combinedResults = [...paymentsResult, ...expensePaymentsResult];

    // Sort the combined results by payment_amount in descending order
    combinedResults.sort((a, b) => b.payment_amount - a.payment_amount);

    // Take only the specified amount of results for pagination
    const paginatedResults = combinedResults.slice(skip, skip + take);

    // Get total count for pagination
    const total = paymentsResult.length + expensePaymentsResult.length;

    const itemsFormatted = paginatedResults.map((item) => ({
      paymentId: item.payment_id,
      paymentDate: item.payment_date,
      paymentName: item.payment_name,
      paymentType: item.payment_type,
      paymentAmount: parseFloat((+item.payment_amount).toFixed(2)),
      isVIB: item.source === 'payment' ? item.is_vib : null,
      source: item.source,
    }));

    // Pagination service (if you have one)
    return this.paginatorService.paginate(itemsFormatted, total, +page || 1, take);
  }

  async getChart(query: ChartDto, user: { clientId: number; id: number }): Promise<any> {
    const { clientId } = user;
    let { hallId, months, fromDate, toDate, type } = query;

    await this.hallsService.findHall(hallId, clientId);
    // Base parameters to avoid repetition
    const baseParams = { clientId, deleted: false, hallId, canceled: 'Canceled',isConfirmed: true };


    const { startDate, endDate } = this.getDates(months, fromDate, toDate)

    // Apply date filters based on provided dates
    const dateFilters = { startDate, endDate };

    // Initialize expense payment query builder
    const expensePaymentBuilder = this.expensePaymentRepository
      .createQueryBuilder('ep')
      .leftJoinAndSelect('ep.expense', 'expense')
      .where('ep.client_id = :clientId', baseParams)
      .andWhere('ep.deleted = :deleted', baseParams)
      .andWhere('expense.hall_id = :hallId', baseParams)
      .andWhere('ep.payment_date::date BETWEEN :startDate AND :endDate', dateFilters)
      .select([
        `DATE_TRUNC('${type}', ep.payment_date) AS period`,
        'SUM(CASE WHEN ep.paymentType = :income THEN ep.amount ELSE 0 END) AS total_income',
        'SUM(CASE WHEN ep.paymentType = :refund THEN ep.amount ELSE 0 END) AS total_refund',
      ])
      .setParameters({ income: 'Income', refund: 'Refund' });

    // Initialize payment query builder
    const paymentsBuilder = this.paymentRepository
      .createQueryBuilder('p')
      .leftJoinAndSelect('p.booking', 'booking')
      .where('p.client_id = :clientId', baseParams)
      .andWhere('p.deleted = :deleted', baseParams)
      .andWhere('booking.hall_id = :hallId', baseParams)
      .andWhere('booking.isConfirmed = :isConfirmed', baseParams)
      .andWhere('p.payment_date::date BETWEEN :startDate AND :endDate', dateFilters)
      .select([
        `DATE_TRUNC('${type}', p.payment_date) AS period`,
        'SUM(CASE WHEN p.paymentType = :income THEN p.amount ELSE 0 END) AS total_income',
        'SUM(CASE WHEN p.paymentType = :refund THEN p.amount ELSE 0 END) AS total_refund',
      ])
      .setParameters({ income: 'Income', refund: 'Refund' });

    // Initialize booking query builder
    const bookingBuilder = this.bookingRepository
      .createQueryBuilder('booking')
      .where('booking.client_id = :clientId', baseParams)
      .andWhere('booking.deleted = :deleted', baseParams)
      .andWhere('booking.hall_id = :hallId', baseParams)
      .andWhere('booking.bookingProcessStatus != :canceled',baseParams)
      .andWhere('booking.isConfirmed = :isConfirmed', baseParams)
      .andWhere('booking.start_date BETWEEN :startDate AND :endDate', dateFilters)
      .select([
        `DATE_TRUNC('${type}', booking.start_date) AS period`,
        'COUNT(DISTINCT booking.id) AS number_of_bookings',
      ]);

    // Execute queries and group results
    const [bookings, payments, expensePayments] = await Promise.all([
      bookingBuilder
        .orderBy(`DATE_TRUNC('${type}', booking.start_date)`, 'DESC')
        .groupBy(`DATE_TRUNC('${type}', booking.start_date)`)
        .getRawMany(),
      paymentsBuilder
        .orderBy(`DATE_TRUNC('${type}', p.payment_date)`, 'DESC')
        .groupBy(`DATE_TRUNC('${type}', p.payment_date)`)
        .getRawMany(),
      expensePaymentBuilder
        .orderBy(`DATE_TRUNC('${type}', ep.payment_date)`, 'DESC')
        .groupBy(`DATE_TRUNC('${type}', ep.payment_date)`)
        .getRawMany(),
    ]);

    let totalBookings = 0,
      totalBookingIncome = 0,
      totalBookingRefund = 0,
      totalExpensesIncome = 0,
      totalExpensesRefund = 0
    // Initialize combined results object
    const combinedResults = {};

    // Process expense payments
    expensePayments.forEach((ep) => {
      const dateObject = new Date(ep.period);

      // Extracting the date in YYYY-MM-DD format
      const period = dateObject.toISOString().split('T')[0];
      combinedResults[period] = {
        totalBookings: 0, // Initialize with 0
        totalRevenue: parseFloat((+ep.total_refund).toFixed(2)),
        totalExpenses: parseFloat((+ep.total_income).toFixed(2)), // Use total_expenses from expensePayments
      };
      totalExpensesIncome += parseFloat((+ep.total_income).toFixed(2));
      totalExpensesRefund += parseFloat((+ep.total_refund).toFixed(2));
    });

    // Process payments (assuming this is a different type of payment data)
    payments.forEach((p) => {
      const dateObject = new Date(p.period);

      // Extracting the date in YYYY-MM-DD format
      const period = dateObject.toISOString().split('T')[0];
      if (!combinedResults[period]) {
        combinedResults[period] = {
          totalBookings: 0,
          totalRevenue: 0,
          totalExpenses: 0, // Initialize if not present
        };
      }
      combinedResults[period].totalRevenue += parseFloat(
        (+p.total_income).toFixed(2),
      ); // Accumulate totalRevenue
      combinedResults[period].totalExpenses += parseFloat(
        (+p.total_refund).toFixed(2),
      ); // Accumulate totalRevenue
      totalBookingIncome += parseFloat((+p.total_income).toFixed(2));
      totalBookingRefund += parseFloat((+p.total_refund).toFixed(2));
    });

    // Process bookings
    bookings.forEach((booking) => {
      const dateObject = new Date(booking.period);

      // Extracting the date in YYYY-MM-DD format
      const period = dateObject.toISOString().split('T')[0];
      if (!combinedResults[period]) {
        // Initialize if the period doesn't exist in combinedResults
        combinedResults[period] = {
          totalBookings: 0,
          totalRevenue: 0,
          totalExpenses: 0, // Initialize if not present
        };
      }

      combinedResults[period].totalBookings += Number(booking.number_of_bookings); // Accumulate number_of_bookings
      totalBookings += Number(booking.number_of_bookings);
    });

    // Calculate totals
    const totalRevenue = (totalBookingIncome + totalExpensesRefund).toFixed(2);

    const totalExpenses = (totalBookingRefund + totalExpensesIncome).toFixed(2);

    return { ...combinedResults, totalBookings, totalRevenue: +totalRevenue, totalExpenses: +totalExpenses };
  }
  async refreshStatisticsView(view: string): Promise<void> {
    try {
      await this.connection.query(`REFRESH  VIEW ${view};`);
    } catch (error) {
      console.error('Error refreshing  view:', error);
    }
  }

  private getDates(months: number, fromDate?: string, toDate?: string): { startDate: string, endDate: string } {
    // Validate input dates
    if (fromDate && toDate) {
      return { startDate: fromDate, endDate: toDate };
    }

    // Handle case for 12 months
    if (months === 12) {
      const currentYear = new Date().getFullYear();
      return { startDate: new Date(currentYear, 0, 1).toISOString().split('T')[0], endDate: new Date(currentYear, 11, 31).toISOString().split('T')[0] };
    }

    // Calculate the start date
    const calculatedStartDate = new Date();
    calculatedStartDate.setMonth(calculatedStartDate.getMonth() - (months - 1));
    calculatedStartDate.setDate(1); // Set to the first day of the month

    // Calculate the end date (last day of the current month)
    const endDate = new Date();
    endDate.setMonth(endDate.getMonth() + 1); // Move to next month
    endDate.setDate(0); // Set to the last day of the current month

    return { startDate: calculatedStartDate.toISOString().split('T')[0], endDate: endDate.toISOString().split('T')[0] };
  }
}
