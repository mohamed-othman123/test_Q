import { Controller, Get, Query, UseInterceptors } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { StatisticsService } from './statistic.service';
import { GetStatistics } from './dtos/getStatistic.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { GetAllPaymentsDto } from './dtos/getAllPayments.dto';
import { CalendarBookingDto } from './dtos/calender.dto';
import { statisticsPermissions } from './statistics.permissions';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { GroupedBookings } from './interfaces/calender.interface';
import { NextBookingDto } from './dtos/nextBooking.dto';
import { ChartDto } from './dtos/chart.dto';
import { EmployeeHallsInterceptor } from '../../auth/interceptors/halls-employee.interceptor';
import { HallClientsGenderEnum } from '../../common/enums/hallClientsGenderEnum.enum';
import { EventTimeEnum } from '../booking/enums/event-time.enum';

@ApiTags('statistics')
@Controller('statistics')
@ApiBearerAuth()
export class StatisticsController {
  constructor(private readonly statisticsService: StatisticsService) { }

  @UseInterceptors(EmployeeHallsInterceptor)
  @Get()
  @RequirePermissions(statisticsPermissions.READ_STATISTICS)
  async getStatistics(
    @Query() query: GetStatistics,
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<{
    totalBookings: number;
    totalRevenue: number;
    totalExpenses: number;
    totalNet: number;
    totalTax: number;
    occupancyRate: number;
  }> {
    return this.statisticsService.getStatistics(query, user);
  }
  @UseInterceptors(EmployeeHallsInterceptor)
  @Get('/next-booking')
  @RequirePermissions(statisticsPermissions.READ_STATISTICS)
  async getNextBooking(
    @Query() query: NextBookingDto,
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<{
    id: number;
    startDate: Date;
    endDate: Date;
    eventTime: EventTimeEnum;
    bookingProcessStatus: string;
    userName: string;
    userPhone: string;
    userEmail: string | null;
    userType: string;
    userGender: HallClientsGenderEnum;
    isVIB: boolean;
  }[]> {
    return this.statisticsService.getNextBooking(query, user);
  }


  @UseInterceptors(EmployeeHallsInterceptor)
  @Get('/calender-booked')
  @RequirePermissions(statisticsPermissions.READ_STATISTICS)
  async getBookedCalender(
    @Query() query: CalendarBookingDto,
    @CurrentUser() user,
  ): Promise<GroupedBookings> {
    return this.statisticsService.getBookedCalender(query, user);
  }

  @UseInterceptors(EmployeeHallsInterceptor)
  @Get('/payments')
  @RequirePermissions(statisticsPermissions.READ_STATISTICS)
  async getAllPayments(
    @Query() query: GetAllPaymentsDto,
    @CurrentUser() user,
  ): Promise<{
    items: {
      paymentId: number;
      paymentDate: Date;
      paymentName: string;
      paymentType: string;
      paymentAmount: number;
      source: string;
    }[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return this.statisticsService.getAllPayments(query, user);
  }

  @UseInterceptors(EmployeeHallsInterceptor)
  @Get('/chart')
  @RequirePermissions(statisticsPermissions.READ_STATISTICS)
  async getChart(@Query() query: ChartDto, @CurrentUser() user): Promise<any> {
    return this.statisticsService.getChart(query, user);
  }
}
