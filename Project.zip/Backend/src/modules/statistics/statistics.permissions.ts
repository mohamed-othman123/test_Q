import { PermissionsTypeEnum } from "../../common/enums/permissionType.enum";

export const statisticsPermissions = {
    READ_STATISTICS: {
      ar_name: 'قراءة:الاحصائيات',
      en_name: 'read:statistcs',
      ar_module: 'لوحة التحكم',
      en_module: 'Dashboard',
      order:1,
      key:'Dashboard',
      type:PermissionsTypeEnum.READ,
      route: "GET '/statistics/*'",
    },
  };
  