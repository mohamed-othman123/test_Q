import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { StatisticsService } from './statistic.service';
import { StatisticsController } from './statistic.controller';
import { HallsModule } from '../halls/halls.module';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { Booking } from '../booking/entities/booking.entity';
import { PaymentEntity } from '../payment/entities/payment.entity';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
import { ExpensePaymentEntity } from '../expenses-payments/entities/expense_payments.entity';
import { ExpensesEntity } from '../expenses/entities/expense.entity';

@Module({
  imports: [
    HallsModule,
    PaginatorModule,
    TypeOrmModule.forFeature([Booking,ExpensesEntity, PaymentEntity, ExpensePaymentEntity]),
  ],
  controllers: [StatisticsController],
  providers: [StatisticsService, HallIdExtractor],
  exports: [StatisticsService],
})
export class StatisticsModule {}
