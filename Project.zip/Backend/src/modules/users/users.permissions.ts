import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const usersPermissions = {
  CREATE_USER: {
    ar_name: 'إنشاء:الموظفين',
    en_name: 'create:employees',
    ar_module: 'الموظفين',
    en_module: 'Employees',
    order: 16,
    key: 'Employees',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/users/moderators'",
  },
  READ_USERS: {
    ar_name: 'قراءة:الموظفين',
    en_name: 'read:employees',
    ar_module: 'الموظفين',
    en_module: 'Employees',
    order: 16,
    key: 'Employees',
    type: PermissionsTypeEnum.READ,
    route: "GET '/users/moderators'",
  },
  UPDATE_USER: {
    ar_name: 'تحديث:الموظفين',
    en_name: 'update:employees',
    ar_module: 'الموظفين',
    en_module: 'Employees',
    order: 16,
    key: 'Employees',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/users/moderators/:id'",
  },
  DELETE_USER: {
    ar_name: 'حذف:الموظفين',
    en_name: 'delete:employees',
    ar_module: 'الموظفين',
    en_module: 'Employees',
    order: 16,
    key: 'Employees',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/users/:id'",
  },
};
