import { forwardRef, Module } from '@nestjs/common';
import { UsersService } from './users.service';
import { UsersController } from './users.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './entities/user.entity';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { MailerAppModule } from '../../providers/mailer/mailer.module';
import { RolesModule } from '../../auth/roles/roles.module';
import { UpdateModeratorTransaction } from './utils/update-moderator.transactions';
import { DeleteModeratorTransaction } from './utils/delete-moderator.transactions';
import { HallsModule } from '../halls/halls.module';
@Module({
  imports: [
    TypeOrmModule.forFeature([User]),
    PaginatorModule,
    MailerAppModule,
    RolesModule,
    forwardRef(() => HallsModule),
  ],
  controllers: [UsersController],
  providers: [UsersService,UpdateModeratorTransaction,DeleteModeratorTransaction],
  exports: [UsersService],
})
export class UsersModule {}
