import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { ApiBearerAuth, ApiHeader, ApiTags } from '@nestjs/swagger';
import { FilterModeratorsDto } from './dto/filter-moderators';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { usersPermissions } from './users.permissions';
import { UpdateModeratorDto } from './dto/update-user.dto';
import { Language } from '../../common/decorators/languages-headers.decorator';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { UserDetails } from './interfaces/user.interface';
import { UserTypeGuard } from '../../common/guards/user-types.guard';
import { UserTypes } from 'src/common/decorators/user-types.decorator';
import { UserTypesEnum } from './enums/users-type.enum';
import { UserProfile } from './interfaces/user-profile.interface';

@ApiTags('users')
@UseGuards(UserTypeGuard)
@Controller('users')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
@ApiBearerAuth()
export class UsersController {
  constructor(private readonly usersService: UsersService) {}
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(usersPermissions.CREATE_USER)
  @Post('/moderators')
  async createModerator(
    @Body() createUserDto: CreateUserDto,
    @CurrentUser() user: { clientId: number; id: number; type: UserTypesEnum },
    @Req() req,
    @Language() lang,
  ): Promise<UserDetails> {
    return this.usersService.createModerator(createUserDto, user, req, lang);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(usersPermissions.READ_USERS)
  @Get('/moderators')
  async getSystemModerators(
    @Query() filter: FilterModeratorsDto,
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<{
    items: UserDetails[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return this.usersService.getSystemModerators(filter, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(usersPermissions.READ_USERS)
  @Get('/moderators/:id')
  async getModerator(
    @Param('id') id: number,
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<UserDetails> {
    return this.usersService.getModerator(id, user);
  }

  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner, UserTypesEnum.employee)
  @Get('/profile')
  async getSystemProfile(
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<UserDetails> {
    return this.usersService.getSystemProfile(user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(usersPermissions.UPDATE_USER)
  @Patch('/moderators/:id')
  async updateModerators(
    @Body() updateModeratorDto: UpdateModeratorDto,
    @Param('id') id: number,
    @CurrentUser() user: { clientId: number; id: number; type: UserTypesEnum },
  ): Promise<UserDetails> {
    return this.usersService.updateModerators(updateModeratorDto, id, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner, UserTypesEnum.employee)
  @Patch('/profile')
  async updateProfile(
    @Body() updateUserDto: UpdateProfileDto,
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<UserDetails> {
    return this.usersService.updateProfile(updateUserDto, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(usersPermissions.DELETE_USER)
  @Delete('/moderators/:id')
  async removeModerator(
    @Param('id') id: number,
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<UserDetails> {
    return this.usersService.removeModerator(id, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner, UserTypesEnum.employee)
  @Get('/:id')
  async getUser(
    @Param('id') id: number,
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<UserProfile> {
    return await this.usersService.getUserProfile(id, user.clientId);
  }
}
