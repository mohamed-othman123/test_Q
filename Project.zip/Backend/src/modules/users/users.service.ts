import {
  BadRequestException,
  forwardRef,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { User } from './entities/user.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, EntityManager, Brackets, Not, In } from 'typeorm';
import { Client } from '../clients/entities/client.entity';
import { CreateAuthDto } from '../../auth/dto/create-auth.dto';
import { UserTypesEnum } from './enums/users-type.enum';
import { FilterModeratorsDto, SortByOptions } from './dto/filter-moderators';
import { PaginatorService } from '../../common/paginator/paginator.service';
import { MailService } from '../../providers/mailer/mail.service';
import { RolesService } from '../../auth/roles/roles.service';
import { ForgetPasswordDto, ResetPasswordDto } from 'src/auth/dto/reset-password.dto';
import { randomBytes, createHash } from 'crypto';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { UpdateModeratorDto } from './dto/update-user.dto';
import { LanguagesEnum } from '../../common/enums/lang.enum';
import { Role } from '../../auth/roles/entities/role.entity';
import { UpdateModeratorTransaction } from './utils/update-moderator.transactions';
import { DeleteModeratorTransaction } from './utils/delete-moderator.transactions';
import { UserDetails } from './interfaces/user.interface';
import { hashPassword } from '../../core/helpers/cast.helper';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { HallsService } from '../halls/halls.service';
import { ClientRolesEnum } from '../../auth/roles/enums/default_roles.enums';
import { UserResponseDto } from './dto/user.response.dto';
import { UserProfile } from './interfaces/user-profile.interface';
import { UserDto } from '../../auth/dto/signup.dto';
import { CacheService } from '../../providers/cache/cache.service';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
    private readonly paginatorService: PaginatorService,
    private readonly mailerService: MailService,
    private readonly updateModeratorTransaction: UpdateModeratorTransaction,
    private readonly deleteModeratorTransaction: DeleteModeratorTransaction,
    private readonly cacheService: CacheService,
    @Inject(forwardRef(() => RolesService))
    private readonly rolesService: RolesService,
    @Inject(forwardRef(() => HallsService))
    private readonly hallsService: HallsService,
  ) {}
  private readonly CACHE_EXPIRATION_TIME = 24 * 60 * 60 * 1000;

  async getUserProfile(id: number, clientId: number): Promise<UserProfile> {
    const user = await this.userRepository.findOne({
      where: { id, client: { id: clientId } },
      relations: { role: true },
    });

    if (!user) {
      throw new NotFoundException(ErrorKeys.userNotFound);
    }

    return {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user?.role?.name_ar || user?.role?.name,
    };
  }

  async createModerator(
    createUserDto: CreateUserDto,
    user: { clientId: number; id: number; type: UserTypesEnum },
    req,
    lang: string,
  ): Promise<UserDetails> {
    const { clientId, id: userId } = user;
    let { email, phone, name, halls, type, permissionType, role } = createUserDto;
    let hallModerators = undefined;
    //prevent any duplication for email or phone (in same client)
    const existUser = await this.userRepository.findOne({
      where: [
        {
          name,
          client: { id: clientId },
          deleted: false,
          type: Not(UserTypesEnum.owner),
        },
        {
          email,
          client: { id: clientId },
          deleted: false,
        },
        {
          phone,
          client: { id: clientId },
          deleted: false,
        },
      ],
    });
    if (existUser) {
      throw new BadRequestException(ErrorKeys.moderatorExist);
    }
    if (type === UserTypesEnum.employee) {
      this.hallsService.validateHalls(halls);
      await this.hallsService.validateExistingHalls(clientId, halls);
      await this.rolesService.findOne(createUserDto.role, clientId);
      hallModerators = halls.map((hall) => ({
        hall: { id: hall.id },
      }));
    }
    if (type === UserTypesEnum.admin) {
      const adminRole = await this.rolesService.findRoleByName(ClientRolesEnum.admin, user);
      const adminHalls = await this.hallsService.getClientHalls(user);
      role = adminRole.id;
      hallModerators = adminHalls.map((hall) => ({
        hall: { id: hall.id },
      }));
    }

    const savedUser = await this.userRepository.save({
      ...createUserDto,
      permissionType: type === UserTypesEnum.employee ? permissionType : undefined,
      role: { id: role },
      hallModerators,
      client: { id: clientId },
      created_by: userId,
    });
    this.forgetPassword({ email }, req, lang, true);
    return this.getModerator(savedUser.id, user);
  }

  async getSystemModerators(
    filter: FilterModeratorsDto,
    user: { clientId: number; id: number },
  ): Promise<{
    items: UserDetails[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    let { sortBy, sortOrder, name, role, page, hallId, creationDate, email, phone, active } =
      filter;
    const { clientId } = user;
    const take = +filter.limit || 10;
    const skip = ((+filter.page || 1) - 1) * take;
    sortBy = sortBy || SortByOptions.createdAt;
    sortOrder = sortOrder || SortOrderEnum.DESC;

    const queryBuilder = this.userRepository
      .createQueryBuilder('u')
      .leftJoinAndSelect('u.role', 'r')
      .leftJoinAndSelect('u.hallModerators', 'hallModerator')
      .leftJoinAndSelect('hallModerator.hall', 'hall');
    const hasFilterKeys =
      name || email || role || creationDate || phone || active !== undefined || hallId;
    if (!hasFilterKeys) {
      queryBuilder
        .where('u.type != :ownerType', { ownerType: UserTypesEnum.owner })
        .andWhere('u.client_id = :clientId', { clientId })
        .andWhere('u.deleted = :deleted', { deleted: false });
    }
    if (hasFilterKeys) {
      queryBuilder.where(
        new Brackets((qb) => {
          qb.where('u.type != :ownerType', { ownerType: UserTypesEnum.owner })
            .andWhere('u.client_id = :clientId', { clientId })
            .andWhere('u.deleted = :deleted', { deleted: false });
          if (creationDate) {
            qb.andWhere('DATE(u.created_at) = :creationDate', {
              creationDate,
            });
          }

          if (name) {
            qb.andWhere('u.name ILIKE :nameFilter', { nameFilter: `%${name}%` });
          }
          if (email) {
            qb.andWhere('u.email ILIKE :emailFilter', { emailFilter: `%${email}%` });
          }
          if (phone) {
            qb.andWhere('u.phone ILIKE :phoneFilter', { phoneFilter: `%${phone}%` });
          }
          if (role) {
            qb.andWhere('r.name ILIKE :roleFilter', { roleFilter: `%${role}%` });
          }
          if (active !== undefined) {
            qb.andWhere('u.active = :activeFilter', { activeFilter: active });
          }
          if (hallId) {
            qb.andWhere('hall.id=:hallId', {
              hallId: filter.hallId,
            });
          }
        }),
      );
    }
    if (sortBy === SortByOptions.role) {
      queryBuilder.orderBy(`r.name`, sortOrder);
    } else {
      queryBuilder.orderBy(`u.${sortBy}`, sortOrder);
    }
    queryBuilder.skip(skip).take(take);

    const [result, total] = await queryBuilder.getManyAndCount();
    const formattedItems = result.map((moderator) => ({
      id: moderator.id,
      created_at: moderator.created_at,
      updated_at: moderator.updated_at,
      name: moderator.name,
      email: moderator.email,
      phone: moderator.phone,
      active: moderator.active,
      type: moderator.type,
      permissionType: moderator.permissionType,
      role: { id: moderator.role.id, name: moderator.role.name, name_ar: moderator.role.name_ar },
      halls: moderator?.hallModerators.map((hm) => ({
        id: hm.hall.id,
        name: hm.hall.name,
        name_ar: hm.hall.name_ar,
      })),
    }));
    return this.paginatorService.paginate(formattedItems, total, page || 1, take);
  }

  async getSystemProfile(user: { clientId: number; id: number }): Promise<UserDetails> {
    const { clientId, id: userId } = user;
    const existUser = await this.userRepository.findOne({
      where: { id: userId, verified: true, active: true, client: { id: clientId }, deleted: false },
      select: {
        id: true,
        created_at: true,
        updated_at: true,
        name: true,
        email: true,
        phone: true,
        active: true,
      },
    });
    if (!existUser) {
      throw new BadRequestException(ErrorKeys.userNotFound);
    }
    return existUser;
  }
  async getModerator(id: number, user: { clientId: number; id: number }): Promise<UserDetails> {
    const { clientId } = user;
    const existUser = await this.userRepository.findOne({
      where: { id, client: { id: clientId }, deleted: false, type: Not(UserTypesEnum.owner) },
      relations: { role: true, hallModerators: { hall: true } },
    });
    if (!existUser) {
      throw new BadRequestException(ErrorKeys.userNotFound);
    }
    return {
      id: existUser.id,
      created_at: existUser.created_at,
      updated_at: existUser.updated_at,
      name: existUser.name,
      email: existUser.email,
      phone: existUser.phone,
      active: existUser.active,
      type: existUser.type,
      permissionType: existUser.permissionType,
      role: { id: existUser.role.id, name: existUser.role.name, name_ar: existUser.role.name },
      halls: existUser?.hallModerators.map((hallModerator) => ({
        id: hallModerator.hall.id,
        name: hallModerator.hall.name,
        name_ar: hallModerator.hall.name_ar,
      })),
    };
  }

  async updateProfile(
    updateUserDto: UpdateProfileDto,
    user: { clientId: number; id: number },
  ): Promise<UserDetails> {
    const { clientId, id: userId } = user;
    const { name, email, phone, password, active } = updateUserDto;
    const profile = await this.getSystemProfile(user);
    if (email) {
      const existUser = await this.userRepository.findOne({
        where: {
          email,
          client: { id: clientId },
          deleted: false,
          id: Not(userId),
        },
      });
      if (existUser) {
        throw new BadRequestException(ErrorKeys.moderatorExist);
      }
    }
    if (phone) {
      const existUser = await this.userRepository.findOne({
        where: {
          phone,
          client: { id: clientId },
          deleted: false,
          id: Not(userId),
        },
      });
      if (existUser) {
        throw new BadRequestException(ErrorKeys.moderatorExist);
      }
    }
    if (name) {
      const existUser = await this.userRepository.findOne({
        where: {
          name,
          client: { id: clientId },
          deleted: false,
          id: Not(userId),
          type: Not(UserTypesEnum.owner),
        },
      });
      if (existUser) {
        throw new BadRequestException(ErrorKeys.moderatorExist);
      }
    }
    await this.userRepository.update(userId, {
      name: name ?? undefined,
      email: email ?? undefined,
      phone: phone ?? undefined,
      active: active ?? undefined,
      password: password ? await hashPassword(updateUserDto.password) : undefined,
      isPasswordHashedV2: password ? true : undefined,
      updated_by: userId,
    });
    if (active !== undefined) {
      try {
        if (active) {
          await this.cacheService.del(this.inActiveUserCacheKey(userId));
        } else {
          const expiresAt = new Date(Date.now() + this.CACHE_EXPIRATION_TIME);
          await this.cacheService.set(
            this.inActiveUserCacheKey(userId),
            JSON.stringify({ id: userId }),
            expiresAt,
          );
        }
      } catch (error) {}
    }

    return { ...profile, ...updateUserDto };
  }

  async updateModerators(
    updateModeratorDto: UpdateModeratorDto,
    id: number,
    user: { clientId: number; id: number; type: UserTypesEnum },
  ): Promise<UserDetails> {
    const { clientId, id: userId } = user;
    let { halls, email, phone, name, type, role, active } = updateModeratorDto;
    let hallModerators = undefined;
    const existModerator = await this.userRepository.findOne({
      where: { id, client: { id: clientId }, deleted: false, type: Not(UserTypesEnum.owner) },
      select: { id: true, type: true },
    });
    if (!existModerator) {
      throw new BadRequestException(ErrorKeys.userNotFound);
    }
    if (name) {
      const existUser = await this.userRepository.findOne({
        where: {
          name,
          client: { id: clientId },
          deleted: false,
          id: Not(id),
          type: Not(UserTypesEnum.owner),
        },
      });
      if (existUser) {
        throw new BadRequestException(ErrorKeys.moderatorExist);
      }
    }
    if (email) {
      const existUser = await this.userRepository.findOne({
        where: {
          email,
          client: { id: clientId },
          deleted: false,
          id: Not(id),
        },
      });
      if (existUser) {
        throw new BadRequestException(ErrorKeys.moderatorExist);
      }
    }
    if (phone) {
      const existUser = await this.userRepository.findOne({
        where: {
          phone,
          client: { id: clientId },
          deleted: false,
          id: Not(id),
        },
      });
      if (existUser) {
        throw new BadRequestException(ErrorKeys.moderatorExist);
      }
    }
    if (type === UserTypesEnum.employee) {
      this.hallsService.validateHalls(halls);
      await this.hallsService.validateExistingHalls(clientId, halls);
      await this.rolesService.findOne(updateModeratorDto.role, clientId);
      hallModerators = halls.map((hall) => ({
        hall: { id: hall.id },
        moderator: { id: existModerator.id },
      }));
    }
    if (type === UserTypesEnum.admin && existModerator.type !== UserTypesEnum.admin) {
      const adminRole = await this.rolesService.findRoleByName(ClientRolesEnum.admin, user);
      const adminHalls = await this.hallsService.getClientHalls(user);
      role = adminRole.id;
      hallModerators = adminHalls.map((hall) => ({
        hall: { id: hall.id },
        moderator: { id: existModerator.id },
      }));
    }
    await this.updateModeratorTransaction.run({
      updateModeratorDto,
      role,
      hallModerators,
      moderatorId: id,
      userId,
    });
    if (active !== undefined) {
      try {
        if (active) {
          await this.cacheService.del(this.inActiveUserCacheKey(id));
        } else {
          const expiresAt = new Date(Date.now() + this.CACHE_EXPIRATION_TIME);
          await this.cacheService.set(
            this.inActiveUserCacheKey(id),
            JSON.stringify({ id: userId }),
            expiresAt,
          );
        }
      } catch (error) {}
    }
    return this.getModerator(id, user);
  }
  async removeModerator(id: number, user: { clientId: number; id: number }): Promise<UserDetails> {
    const { id: userId } = user;
    const existUser = await this.getModerator(id, user);
    await this.deleteModeratorTransaction.run({ moderatorId: id, userId });
    try {
      await this.cacheService.del(this.inActiveUserCacheKey(id));
    } catch (error) {}

    return { ...existUser, deleted: true, deleted_at: new Date() };
  }

  async findOneWithPermissionsandHalls(id: number): Promise<UserResponseDto> {
    const user = await this.userRepository.findOne({
      where: { id },
      relations: {
        hallModerators: {
          hall: true,
        },
        role: {
          permissions: true,
        },
        client: true,
      },
      select: {
        id: true,
        name: true,
        email: true,
        type: true,
        verified: true,
        active: true,
        permissionType: true,
        hallModerators: {
          id: true,
          hall: {
            id: true,
          },
        },
        role: {
          id: true,
          created_by: true,
          name: true,
          name_ar: true,
          permissions: {
            id: true,
            ar_name: true,
            en_name: true,
            ar_module: true,
            en_module: true,
            route: true,
            type: true,
          },
        },
        client: {
          id: true,
          created_at: true,
          endDate: true,
          hasAiFeature: true,
        },
      },
    });
    if (!user) {
      throw new BadRequestException(ErrorKeys.userNotFound);
    }
    const halls = user?.hallModerators.map((hm) => ({
      id: hm.hall.id,
    }));

    delete user.hallModerators;
    return { ...user, halls };
  }

  async checkUser(email: string): Promise<User> {
    return await this.userRepository.findOne({
      where: { email, deleted: false, active: true },
      relations: ['client'],
    });
  }

  async checkUserV2(email: string): Promise<User> {
    return await this.userRepository.findOne({
      where: { email, deleted: false },
      relations: ['client'],
    });
  }

  async register(
    createUserDto: CreateAuthDto,
    client: Client,
    manager: EntityManager,
  ): Promise<User> {
    const userIsExist = await this.checkUserV2(createUserDto.email);
    if (userIsExist) {
      throw new BadRequestException(ErrorKeys.emailExists);
    }
    return await manager.save(
      this.userRepository.create({
        ...createUserDto,
        type: UserTypesEnum.owner,
        phone: '',
        notification_token: '',
        client: client,
      }),
    );
  }

  async registerV2(userDto: UserDto, client: Client, manager: EntityManager) {
    const { name, email, password, phone_number } = userDto;
    const record = this.userRepository.create({
      name,
      email,
      password,
      phone: phone_number,
      type: UserTypesEnum.owner,
      client,
    });

    const user = await manager.save(record);

    return user;
  }

  async verifyUser(userId: number, clientId: number): Promise<{ ownerRole: Role }> {
    const ownerRole = await this.rolesService.initRoleWithPermissions({ userId, clientId });
    await this.userRepository.update(
      {
        id: userId,
      },
      {
        verified: true,
        role: { id: ownerRole?.id },
        created_by: userId,
      },
    );
    return { ownerRole };
  }

  async hasPermission(
    userId: number,
    permission: {
      en_name: string;
      ar_name: string;
      en_module: string;
      ar_module: string;
      route: string;
    },
  ) {
    const user = await this.userRepository.findOne({
      where: {
        id: userId,
      },
      relations: ['role', 'role.permissions'],
    });
    if (!user) {
      throw new BadRequestException(ErrorKeys.userNotFound);
    }
    if (!user.role) {
      throw new BadRequestException(ErrorKeys.roleNotFound);
    }
    if (!user.role.permissions) {
      throw new BadRequestException(ErrorKeys.permissionNotFound);
    }
    const hasPermission = user.role.permissions.some(
      (p) =>
        p.en_name === permission.en_name &&
        p.en_module === permission.en_module &&
        p.route === permission.route,
    );
    return hasPermission;
  }

  async forgetPassword(
    forgetPasswordDto: ForgetPasswordDto,
    req,
    lang: string,
    newUser = false,
  ): Promise<boolean> {
    const { email } = forgetPasswordDto;
    const user = await this.userRepository.findOne({
      where: {
        email,
        deleted: false,
        active: true,
      },
      select: { id: true, name: true, email: true },
    });
    if (!user || (user.password && !user.verified)) {
      throw new BadRequestException(ErrorKeys.userNotFound);
    }
    const resetToken = randomBytes(32).toString('hex');
    user.password_reset_token = createHash('sha256').update(resetToken).digest('hex');

    const resetUrl = `${req.protocol}://${req.hostname}/auth/reset-password/${resetToken}`;
    newUser
      ? this.mailerService.sendEmail(
          [user.email],
          lang === LanguagesEnum.Arabic ? 'رابط تسجيل الدخول' : 'Login url',
          `new-user-${lang}`,
          {
            fullName: user.name,
            resetUrl,
          },
        )
      : this.mailerService.sendEmail(
          [user.email],
          lang === LanguagesEnum.Arabic ? 'إعادة تعيين كلمة المرور' : 'Reset password',
          `forget-password-${lang}`,
          {
            fullName: user.name,
            resetUrl,
          },
        );

    await this.userRepository.save(user);
    return true;
  }
  async resetPassword(resetPasswordDto: ResetPasswordDto, token: string): Promise<User> {
    const encryptedToken = createHash('sha256').update(token).digest('hex');

    const user = await this.userRepository.findOne({
      where: { password_reset_token: encryptedToken, active: true, deleted: false },
      relations: { client: true },
      select: {
        id: true,
        email: true,
        type: true,
        name: true,
        password: true,
        verified: true,
        client: { id: true },
      },
    });
    if (!user || (user.password && !user.verified)) {
      throw new BadRequestException(ErrorKeys.invalidResetToken);
    }

    if (resetPasswordDto.password !== resetPasswordDto.confirmedPassword) {
      throw new BadRequestException(ErrorKeys.passwordsMustBeSame);
    }
    const newPassword = resetPasswordDto.password;
    user.password = await hashPassword(newPassword);
    user.isPasswordHashedV2 = true;
    user.verified = true;
    user.password_reset_token = null;
    return await this.userRepository.save(user);
  }
  async updateHashPassword(userId: number, clientId: number, password: string): Promise<void> {
    const user = await this.userRepository.findOne({
      where: { id: userId, verified: true, active: true, deleted: false, client: { id: clientId } },
    });
    if (!user) {
      throw new BadRequestException(ErrorKeys.userNotFound);
    }
    user.password = await hashPassword(password);
    user.isPasswordHashedV2 = true;
    await this.userRepository.save(user);
  }
  async validateExistingModerators(
    clientId: number,
    hallId: number,
    moderatorIds: number[],
  ): Promise<void> {
    const existsmoderatorts = await this.getModeratorsInRange(clientId, hallId, moderatorIds);
    const existModeratorIds = existsmoderatorts.map((moderator) => moderator.id);
    const notExistsModerators = moderatorIds.filter((id) => !existModeratorIds.includes(id));

    if (notExistsModerators.length > 0) {
      throw new BadRequestException(ErrorKeys.employeeNotFound);
    }
  }
  async getModeratorsInRange(clientId: number, hallId: number, moderatorsIds: number[]) {
    const existModerators = await this.userRepository.find({
      where: {
        id: In(moderatorsIds),
        client: { id: clientId },
        deleted: false,
        hallModerators: { hall: { id: hallId } },
      },
      select: { id: true },
    });
    return existModerators;
  }
  async checkInActiveUser(userId: number): Promise<boolean> {
    const cacheKey = this.inActiveUserCacheKey(userId);

    let cachedData: string | null = null;

    try {
      cachedData = await this.cacheService.get(cacheKey);
    } catch (error) {}
    console.log(cachedData);

    if (cachedData) {
      const cachedUser = JSON.parse(cachedData);
      return !!cachedUser;
    }
    return false;
  }

  private inActiveUserCacheKey(userId: number): string {
    return `inActiveUser:hallName:${userId}`;
  }
}
