import { Module,forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PricingService } from './pricing.service';
import { PricingController } from './pricing.controller';
import { HallsModule } from '../halls/halls.module';
import { UpdatePricingTransaction } from './utils/updatePricing.transactions';
import { DeletePricingTransaction } from './utils/deletePricing.transactions';
import { HallEntity } from '../halls/entities/hall.entity';
import { EventsModule } from '../events/events.module';
import { CreatePricingTransaction } from './utils/createPricing.transactions';
import { HallEvent } from '../events/entities/hall-event.entity';

@Module({
  imports: [TypeOrmModule.forFeature([HallEntity,HallEvent]),forwardRef(() => HallsModule),EventsModule],
  controllers: [PricingController],
  providers: [PricingService, UpdatePricingTransaction,DeletePricingTransaction,CreatePricingTransaction],
  exports: [PricingService],
})
export class PricingModule {}
