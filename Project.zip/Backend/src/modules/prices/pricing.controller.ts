import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { ApiBearerAuth, ApiHeader, ApiTags } from '@nestjs/swagger';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { hallsPermissions } from '../halls/halls.permissions';
import { UserTypeGuard } from '../../common/guards/user-types.guard';
import { UserTypes } from '../../common/decorators/user-types.decorator';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { PricingService } from './pricing.service';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { PricingResponse } from './dtos/pricing.response.dto';
import { UpdatePricingDto } from './dtos/update-pricing.dto';
import { GetOnePricingDto } from './dtos/get-pricing.dto';
import { CreatePricingDto } from './dtos/create-pricing.dto';
import { PricesFilterRequest } from './dtos/filter-pricing.dto';

@ApiTags('halls')
@UseGuards(UserTypeGuard)
@ApiBearerAuth()
@Controller('halls')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class PricingController {
  constructor(private readonly pricingService: PricingService) { }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.UPDATE_HALLS)
  @Post(':hallId/pricing')
  async createHallPricing(
    @Param('hallId') hallId: string,
    @Body() createPricingDto: CreatePricingDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<PricingResponse[]> {
    return this.pricingService.createHallPricing(+hallId, createPricingDto, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner, UserTypesEnum.employee)
  @Get(':hallId/pricing')
  async findHallPricings(
    @Param('hallId') hallId: string,
    @Query() filter: PricesFilterRequest,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<PricingResponse[]> {
    return this.pricingService.getAllPricing(+hallId, filter, user);
  }
  // @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  // @RequirePermissions(hallsPermissions.READ_HALL)
  // @Get(':hallId/pricing')
  // async getOnePricing(
  //   @Param('hallId') hallId: string,
  //   @Query() getOnePricingDto: GetOnePricingDto,
  //   @CurrentUser() user: AuthenticatedUser,
  // ): Promise<PricingResponse> {
  //   return this.pricingService.getOnePricing(+hallId, getOnePricingDto, user);
  // }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.UPDATE_HALLS)
  @Patch(':hallId/pricing')
  async updatePricing(
    @Param('hallId') hallId: string,
    @Query() getOnePricingDto: GetOnePricingDto,
    @Body() updatePriceDto: UpdatePricingDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<PricingResponse> {
    return this.pricingService.updatePricing(+hallId, getOnePricingDto, updatePriceDto, user);
  }

  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.UPDATE_HALLS)
  @Delete(':hallId/pricing')
  async deletePricing(
    @Param('hallId') hallId: string,
    @Query() getOnePricingDto: GetOnePricingDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<PricingResponse> {
    return this.pricingService.deleteEventPricing(+hallId, getOnePricingDto, user);
  }
}
