import { BadRequestException, Injectable, forwardRef, Inject } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { HallsService } from '../halls/halls.service';
import { PricingResponse, RegularPricing, SpecialDaysPrices } from './dtos/pricing.response.dto';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { UpdatePricingDto } from './dtos/update-pricing.dto';
import { UpdatePricingTransaction } from './utils/updatePricing.transactions';
import { DeletePricingTransaction } from './utils/deletePricing.transactions';
import { HallEntity } from '../halls/entities/hall.entity';
import { BookingPricingType } from 'src/common/enums/bookingPricingType.enum';
import { GetOnePricingDto } from './dtos/get-pricing.dto';
import { PricingCalculationType } from 'src/common/enums/pricingCalculationType.enum';
import { CreatePricingDto } from './dtos/create-pricing.dto';
import { EventsService } from '../events/events.service';
import { CreatePricingTransaction } from './utils/createPricing.transactions';
import { PricesFilterRequest } from './dtos/filter-pricing.dto';
import { RegularPricingEntity } from './entities/pricing.entity';
import { SpecialDaysPricingEntity } from './entities/specialDays-pricing.entity';
import { CalculatePricingDto } from '../booking/dto/calculate-pricing-response.dto';
import { CalculatePricingFilterDto } from '../booking/dto/calculate-pricing-filter.dto';
import { HallEvent } from '../events/entities/hall-event.entity';
import { EventTimeEnum } from '../booking/enums/event-time.enum';
import { DayOfWeekEnum } from 'src/common/enums/dayOfweek.enum';
@Injectable()
export class PricingService {
  constructor(
    @InjectRepository(HallEntity)
    private hallRepository: Repository<HallEntity>,
    @InjectRepository(HallEvent) private readonly hallEventRepo: Repository<HallEvent>,
    @Inject(forwardRef(() => HallsService))
    private readonly hallServices: HallsService,
    private readonly updatePricingTransaction: UpdatePricingTransaction,
    private readonly deletePricingTransaction: DeletePricingTransaction,
    private readonly eventService: EventsService,
    private readonly createPricingTransaction: CreatePricingTransaction,
  ) { }

  async createHallPricing(
    hallId: number,
    createPricingDto: CreatePricingDto,
    user: AuthenticatedUser,
  ): Promise<PricingResponse[]> {
    const { events, pricingType } = createPricingDto;
    const { clientId, id: userId } = user;
    await this.hallServices.findHall(hallId, clientId);
    if (pricingType === BookingPricingType.EVENT) {
      this.eventService.validateEvents(events);
      const eventIds = events.map((event) => event.eventId);
      await this.eventService.validateExsistingEventPricings(clientId, eventIds, hallId);
    }
    await this.createPricingTransaction.run({
      pricingDto: createPricingDto,
      hallId,
      userId,
    });
    return this.getAllPricing(hallId, { type: pricingType }, user);
  }

  async getAllPricing(hallId: number, filter: PricesFilterRequest, user: AuthenticatedUser): Promise<PricingResponse[]> {
    const { clientId } = user;
    let { type } = filter
    type = type ? type : BookingPricingType.EVENT
    const existHall = await this.hallRepository.findOne({
      where: { id: hallId, client: { id: clientId }, deleted: false },
      relations: { hallEvents: { event: { regularPricing: true, specialDaysPricing: true } }, regularPricing: true, specialDaysPricing: true },
    });
    if (!existHall) {
      throw new BadRequestException(ErrorKeys.hallNotFound);
    }
    if (existHall.pricingType === BookingPricingType.FIXED && type === BookingPricingType.FIXED) {
      return [{
        id: existHall.id,
        name: existHall.name,
        name_ar: existHall.name_ar,
        priceCalculationType: existHall.priceCalculationType,
        insuranceAmount: existHall.insuranceAmount,
        regularPricing: this.regularPricingFormatting(existHall.regularPricing),
        specialDaysPricing: this.specialDaysFormatting(existHall.specialDaysPricing),
      }];
    } else if (existHall.pricingType === BookingPricingType.EVENT && type === BookingPricingType.EVENT) {
      const formattedItems = existHall.hallEvents.filter((he) => he.event.priceCalculationType !== PricingCalculationType.BOOKING_TIME).map((he) => {
        return {
          id: he.event.id,
          name: he.event.name,
          name_ar: he.event.name_ar,
          priceCalculationType: he.event.priceCalculationType,
          insuranceAmount: he.event.insuranceAmount,
          regularPricing: he.event.priceCalculationType !== PricingCalculationType.BOOKING_TIME
            ? this.regularPricingFormatting(he.event.regularPricing)
            : null,
          specialDaysPricing: this.specialDaysFormatting(he.event.specialDaysPricing),
        };
      });
      return formattedItems;
    }
    return []

  }

  async getOnePricing(
    hallId: number,
    getOnePricingDto: GetOnePricingDto,
    user: AuthenticatedUser,
  ): Promise<PricingResponse> {
    const { clientId } = user;
    const { type, eventId } = getOnePricingDto
    const queryConditions = {
      id: hallId, client: { id: clientId }, deleted: false,
      hallEvents: type === BookingPricingType.EVENT ? { event: { id: eventId } } : undefined,
    };
    await this.hallServices.findHall(hallId, user.clientId)
    const existHall = await this.hallRepository.findOne({
      where: queryConditions,
      relations: { hallEvents: { event: { regularPricing: true, specialDaysPricing: true } }, regularPricing: true, specialDaysPricing: true },
    });
    if (!existHall) {
      throw new BadRequestException(ErrorKeys.eventNotFound);
    }
    if (existHall.pricingType === BookingPricingType.BOOKING_TIME) {
      throw new BadRequestException(ErrorKeys.pricingWhileBooking);
    }
    if (existHall.pricingType !== type) {
      throw new BadRequestException(ErrorKeys.typeIncorrect);
    }
    if (type === BookingPricingType.EVENT) {
      return {
        id: existHall.hallEvents[0].event.id,
        name: existHall.hallEvents[0].event.name,
        name_ar: existHall.hallEvents[0].event.name_ar,
        priceCalculationType: existHall.hallEvents[0].event.priceCalculationType,
        insuranceAmount: existHall.hallEvents[0].event.insuranceAmount,
        regularPricing: existHall.hallEvents[0].event.priceCalculationType !== PricingCalculationType.BOOKING_TIME
          ? this.regularPricingFormatting(existHall.hallEvents[0].event.regularPricing)
          : null,
        specialDaysPricing: this.specialDaysFormatting(existHall.hallEvents[0].event.specialDaysPricing),
      };
    }

    return {
      id: existHall.id,
      name: existHall.name,
      name_ar: existHall.name_ar,
      priceCalculationType: existHall.priceCalculationType,
      insuranceAmount: existHall.insuranceAmount,
      regularPricing: this.regularPricingFormatting(existHall.regularPricing),
      specialDaysPricing: this.specialDaysFormatting(existHall.specialDaysPricing),
    };
  }
  async updatePricing(
    hallId: number,
    getOnePricingDto: GetOnePricingDto,
    updatePriceDto: UpdatePricingDto,
    user: AuthenticatedUser,
  ): Promise<PricingResponse> {
    const { id: userId } = user;
    const { type, eventId } = getOnePricingDto
    await this.getOnePricing(hallId, getOnePricingDto, user)
    await this.updatePricingTransaction.run({
      pricingDto: updatePriceDto,
      pricingType: type,
      hallId,
      eventId,
      userId,
    });
    return this.getOnePricing(hallId, getOnePricingDto, user);
  }

  async deleteEventPricing(
    hallId: number,
    getOnePricingDto: GetOnePricingDto,
    user: AuthenticatedUser,
  ): Promise<PricingResponse> {
    const { id: userId } = user;
    const { eventId, type } = getOnePricingDto
    await this.getOnePricing(hallId, getOnePricingDto, user)
    await this.deletePricingTransaction.run({
      pricingType: type,
      hallId,
      eventId,
      userId,
    });
    return this.getOnePricing(hallId, getOnePricingDto, user)
  }


  //for booking calculations
  async calculatePricing(
    calculatePricingFilter: CalculatePricingFilterDto,
  ): Promise<CalculatePricingDto> {
    const { hallId, eventId, startDate, endDate, eventTime } = calculatePricingFilter;
    const hallEvent = await this.hallEventRepo
      .createQueryBuilder('he')
      .leftJoinAndSelect('he.event', 'event')
      .leftJoinAndSelect('he.hall', 'hall')
      .leftJoinAndSelect('hall.regularPricing', 'hallRegularPricing')
      .leftJoinAndSelect('hall.specialDaysPricing', 'hallSpecialDaysPricing')
      .leftJoinAndSelect('event.regularPricing', 'eventRegularPricing')
      .leftJoinAndSelect('event.specialDaysPricing', 'eventSpecialDaysPricing')
      .where('event.id = :eventId', { eventId })
      .andWhere('hall.id = :hallId', { hallId })
      .getOne();

    if (!hallEvent) {
      throw new BadRequestException(ErrorKeys.eventNotFound);
    }

    const start = new Date(startDate);
    const end = new Date(endDate);
    let totalAmount = 0;
    let totalAmountMen = 0;
    let totalAmountWomen = 0;



    if (hallEvent.hall.pricingType === BookingPricingType.FIXED) {
      const hallRegularPricingFormation = this.regularPricingFormatting(hallEvent.hall.regularPricing)
      const hallSpcialDaysFormating = this.specialDaysFormatting(hallEvent.hall.specialDaysPricing)
      const specialDays = hallSpcialDaysFormating.filter(
        (p) => start <= new Date(p.endDate) && end >= new Date(p.startDate),
      );
      const currentDate = new Date(start);
      while (currentDate <= end) {
        const specialDay = specialDays.find(
          (p) => currentDate >= new Date(p.startDate) && currentDate <= new Date(p.endDate),
        );

        if (specialDay) {
          if (hallEvent.hall.priceCalculationType === PricingCalculationType.FIXED_PRICE) {
            totalAmount += this.getPriceByEventTime(
              specialDay.pricing.morning.fixedPrice,
              specialDay.pricing.evening.fixedPrice,
              specialDay.pricing.fullDay.fixedPrice,
              eventTime,
            );
          } else if (hallEvent.hall.priceCalculationType === PricingCalculationType.PER_PERSON) {
            totalAmountMen += this.getPriceByEventTime(
              specialDay.pricing.morning.menPrice,
              specialDay.pricing.evening.menPrice,
              specialDay.pricing.fullDay.menPrice,
              eventTime,
            );
            totalAmountWomen += this.getPriceByEventTime(
              specialDay.pricing.morning.womenPrice,
              specialDay.pricing.evening.womenPrice,
              specialDay.pricing.fullDay.womenPrice,
              eventTime,
            );

          }


        } else {
          const dayOfWeek = currentDate.getDay();
          const dayPrice = this.getRegularDayPrice(
            hallRegularPricingFormation,
            hallEvent.hall.priceCalculationType,
            dayOfWeek,
            eventTime,
          );
          totalAmount += dayPrice.totalAmount;
          totalAmountMen += dayPrice.totalAmountMen;
          totalAmountWomen += dayPrice.totalAmountWomen;
        }

        currentDate.setDate(currentDate.getDate() + 1);
      }
    } else if (
      hallEvent.hall.pricingType === BookingPricingType.EVENT &&
      hallEvent.event.priceCalculationType !== PricingCalculationType.BOOKING_TIME
    ) {
      const eventRegularPricingFormation = this.regularPricingFormatting(hallEvent.event.regularPricing)
      const eventSpcialDaysFormating = this.specialDaysFormatting(hallEvent.event.specialDaysPricing)
      const specialDays = eventSpcialDaysFormating.filter(
        (p) => start <= new Date(p.endDate) && end >= new Date(p.startDate),
      );
      const currentDate = new Date(start);
      while (currentDate <= end) {
        const specialDay = specialDays.find(
          (p) => currentDate >= new Date(p.startDate) && currentDate <= new Date(p.endDate),
        );

        if (specialDay) {
          if (hallEvent.event.priceCalculationType === PricingCalculationType.FIXED_PRICE) {
            totalAmount += this.getPriceByEventTime(
              specialDay.pricing.morning.fixedPrice,
              specialDay.pricing.evening.fixedPrice,
              specialDay.pricing.fullDay.fixedPrice,
              eventTime,
            );
          } else if (hallEvent.event.priceCalculationType === PricingCalculationType.PER_PERSON) {
            totalAmountMen += this.getPriceByEventTime(
              specialDay.pricing.morning.menPrice,
              specialDay.pricing.evening.menPrice,
              specialDay.pricing.fullDay.menPrice,
              eventTime,
            );
            totalAmountWomen += this.getPriceByEventTime(
              specialDay.pricing.morning.womenPrice,
              specialDay.pricing.evening.womenPrice,
              specialDay.pricing.fullDay.womenPrice,
              eventTime,
            );

          }
        } else {
          const dayOfWeek = currentDate.getDay();
          const dayPrice = this.getRegularDayPrice(
            eventRegularPricingFormation,
            hallEvent.event.priceCalculationType,
            dayOfWeek,
            eventTime,
          );
          totalAmount += dayPrice.totalAmount;
          totalAmountMen += dayPrice.totalAmountMen;
          totalAmountWomen += dayPrice.totalAmountWomen;
        }

        currentDate.setDate(currentDate.getDate() + 1);
      }
    }

    return {
      pricingType: hallEvent.hall.pricingType,
      priceCalculationType:
        hallEvent.hall.pricingType === BookingPricingType.FIXED
          ? hallEvent.hall.priceCalculationType
          : hallEvent.event.priceCalculationType,
      totalAmount,
      totalAmountMen,
      totalAmountWomen,
      insuranceAmount:
        hallEvent.hall.pricingType === BookingPricingType.FIXED
          ? hallEvent.hall.insuranceAmount
          : hallEvent.event.insuranceAmount,
    };
  }

  private getRegularDayPrice(
    regularPricing: RegularPricing,
    priceCalculationType: PricingCalculationType,
    dayOfWeek: number,
    eventTime: EventTimeEnum,
  ): { totalAmount: number, totalAmountMen: number, totalAmountWomen: number } {
    const days = Object.values(DayOfWeekEnum);

    if (dayOfWeek < 0 || dayOfWeek > 6) {
      return { totalAmount: 0, totalAmountMen: 0, totalAmountWomen: 0 };
    }

    const dayPricing = regularPricing[days[dayOfWeek]];

    if (priceCalculationType === PricingCalculationType.FIXED_PRICE) {
      return {
        totalAmount: this.getPriceByEventTime(
          dayPricing.morning.fixedPrice,
          dayPricing.evening.fixedPrice,
          dayPricing.fullDay.fixedPrice,
          eventTime,
        ),
        totalAmountMen: 0,
        totalAmountWomen: 0
      };
    } else if (priceCalculationType === PricingCalculationType.PER_PERSON) {
      return {
        totalAmount: 0,
        totalAmountMen: this.getPriceByEventTime(
          dayPricing.morning.menPrice,
          dayPricing.evening.menPrice,
          dayPricing.fullDay.menPrice,
          eventTime,
        ),
        totalAmountWomen: this.getPriceByEventTime(
          dayPricing.morning.womenPrice,
          dayPricing.evening.womenPrice,
          dayPricing.fullDay.womenPrice,
          eventTime,
        ),
      };
    }

    return { totalAmount: 0, totalAmountMen: 0, totalAmountWomen: 0 };
  }

  private getPriceByEventTime(
    morningPrice: number,
    eveningPrice: number,
    fullDayPrice: number,
    eventTime: EventTimeEnum,
  ): number {
    switch (eventTime) {
      case EventTimeEnum.morning:
        return morningPrice;
      case EventTimeEnum.evening:
        return eveningPrice;
      case EventTimeEnum.fullDay:
        return fullDayPrice;
      default:
        return 0;
    }
  }

  private regularPricingFormatting(regularPricing: RegularPricingEntity[]): RegularPricing {
    const formattedPricing: RegularPricing = {
      monday: { morning: {}, evening: {}, fullDay: {} },
      tuesday: { morning: {}, evening: {}, fullDay: {} },
      wednesday: { morning: {}, evening: {}, fullDay: {} },
      thursday: { morning: {}, evening: {}, fullDay: {} },
      friday: { morning: {}, evening: {}, fullDay: {} },
      saturday: { morning: {}, evening: {}, fullDay: {} },
      sunday: { morning: {}, evening: {}, fullDay: {} },
    };

    regularPricing.forEach(pricing => {
      const day = pricing.dayOfWeek.toLowerCase();
      const timePeriod = pricing.timePeriod;

      if (formattedPricing[day]) {
        formattedPricing[day][timePeriod] = {
          fixedPrice: pricing.fixedPrice || undefined,
          menPrice: pricing.menPrice || undefined,
          womenPrice: pricing.womenPrice || undefined,
        };
      }
    });

    return formattedPricing;
  }

  private specialDaysFormatting(specialDays: SpecialDaysPricingEntity[]): SpecialDaysPrices[] {
    const grouped = {};

    specialDays.forEach(pricing => {
      const key = `${pricing.startDate}-${pricing.endDate}`;
      if (!grouped[key]) {
        grouped[key] = {
          startDate: pricing.startDate,
          endDate: pricing.endDate,
          title: pricing.title,
          pricing: {},
        };
      }

      const timePeriod = pricing.timePeriod;

      if (!grouped[key].pricing[timePeriod]) {
        grouped[key].pricing[timePeriod] = {
          fixedPrice: pricing.fixedPrice || undefined,
          menPrice: pricing.menPrice || undefined,
          womenPrice: pricing.womenPrice || undefined
        };
      }
    });

    return Object.values(grouped);
  }
}
