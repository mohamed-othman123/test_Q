import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { ApiBearerAuth, ApiHeader, ApiTags } from '@nestjs/swagger';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { HallSectionsService } from './hall-sections.service';
import { hallsPermissions } from '../halls/halls.permissions';
import { FilterHallSectionsDto } from './dtos/filter-hall-sections.dto';
import { UpdateSectionDto } from './dtos/update-hall-section';
import { UserTypeGuard } from '../../common/guards/user-types.guard';
import { UserTypes } from '../../common/decorators/user-types.decorator';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { CreateSectionDto } from './dtos/create-hall-section.dto';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { SectionResponseDto } from './dtos/hall-section.response.dto';

@ApiTags('halls')
@UseGuards(UserTypeGuard)
@ApiBearerAuth()
@Controller('halls')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class HallSectionsController {
  constructor(private readonly hallSectionsService: HallSectionsService) {}
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.CREATE_HALLS)
  @Post(':hallId/sections')
  async addSection(
    @Param('hallId') hallId: string,
    @Body() createSectionDto: CreateSectionDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<SectionResponseDto> {
    return this.hallSectionsService.addSection(+hallId, createSectionDto, user);
  }

  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner, UserTypesEnum.employee)
  @Get(':hallId/sections')
  async findHallSections(
    @Param('hallId') hallId: string,
    @Query() filter: FilterHallSectionsDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<{
    items: SectionResponseDto[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return this.hallSectionsService.getHallSections(+hallId, filter, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.READ_HALLS)
  @Get(':hallId/sections/:sectionId')
  async getSection(
    @Param('hallId') hallId: string,
    @Param('sectionId') sectionId: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<SectionResponseDto> {
    return this.hallSectionsService.getSection(+hallId, +sectionId, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.UPDATE_HALLS)
  @Patch(':hallId/sections/:sectionId')
  async updateSection(
    @Param('hallId') hallId: string,
    @Param('sectionId') sectionId: string,
    @Body() updateSectionDto: UpdateSectionDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<SectionResponseDto> {
    return this.hallSectionsService.updateSection(+hallId, +sectionId, updateSectionDto, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.DELETE_HALLS)
  @Delete(':hallId/sections/:sectionId')
  async deleteSection(
    @Param('hallId') hallId: string,
    @Param('sectionId') sectionId: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<SectionResponseDto> {
    return this.hallSectionsService.deleteSection(+hallId, +sectionId, user);
  }
}
