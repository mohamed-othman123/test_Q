export const defaultSections = {
  men: {
    ar: {
      name: 'رجال',
    },
    en: {
      name: 'men',
    },
  },
  women: {
    ar: {
      name: 'نساء',
    },
    en: {
      name: 'women',
    },
  },
};
