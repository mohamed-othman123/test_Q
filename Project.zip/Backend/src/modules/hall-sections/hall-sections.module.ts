import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HallSectionsEntity } from './entities/hall-sections.entity';
import { HallSectionsService } from './hall-sections.service';
import { HallSectionsController } from './hall-sections.controller';
import { HallsModule } from '../halls/halls.module';
import { PaginatorModule } from '../../common/paginator/paginator.module';

@Module({
  imports: [TypeOrmModule.forFeature([HallSectionsEntity]),forwardRef(() => HallsModule),PaginatorModule],
  controllers: [HallSectionsController],
  providers: [HallSectionsService],
  exports: [HallSectionsService],
})
export class HallSectionsModule {}
