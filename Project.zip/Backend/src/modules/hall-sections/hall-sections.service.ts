import { BadRequestException, forwardRef, Inject, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, In, Not, Repository } from 'typeorm';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { HallSectionsEntity } from './entities/hall-sections.entity';
import { UpdateSectionDto } from './dtos/update-hall-section';
import { FilterHallSectionsDto, SortByOptions } from './dtos/filter-hall-sections.dto';
import { HallsService } from '../halls/halls.service';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { PaginatorService } from '../../common/paginator/paginator.service';
import { SectionDto } from './dtos/section.dto';
import { HandelTwoName } from '../../core/helpers/cast.helper';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { CreateSectionDto } from './dtos/create-hall-section.dto';
import { SectionResponseDto } from './dtos/hall-section.response.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';

@Injectable()
export class HallSectionsService {
  constructor(
    @InjectRepository(HallSectionsEntity)
    private sectionRepository: Repository<HallSectionsEntity>,
    @Inject(forwardRef(() => HallsService))
    private readonly hallServices: HallsService,
    private readonly paginatorService: PaginatorService,
    private readonly eventEmitter: EventEmitter2,
  ) { }

  async addSection(
    hallId: number,
    createSectionDto: CreateSectionDto,
    user: AuthenticatedUser,
  ): Promise<SectionResponseDto> {
    let { name, name_ar } = createSectionDto;
    const { clientId, id: userId } = user
    if (!name && !name_ar) {
      throw new BadRequestException(ErrorKeys.nameIsRequired);
    }
    [name, name_ar] = HandelTwoName(name, name_ar);
    await this.hallServices.findHall(hallId, clientId)
    const existSection = await this.sectionRepository.findOne({
      where: [{ name, deleted: false, hall: { id: hallId, client: { id: clientId } } }, { name: name_ar, deleted: false, hall: { id: hallId, client: { id: clientId } } }, { name_ar, deleted: false, hall: { id: hallId, client: { id: clientId } } }, { name_ar: name, deleted: false, hall: { id: hallId, client: { id: clientId } } }],
    });
    if (existSection) {
      throw new BadRequestException(ErrorKeys.sectionExisting);
    }
    const savedSection = await this.sectionRepository.save({
      ...createSectionDto,
      name,
      name_ar,
      hall: { id: hallId },
      created_by: userId,
    });
    await this.emitSectionEmitterAfterChange(savedSection.id, clientId);
    return {
      id: savedSection.id,
      created_at: savedSection.created_at,
      updated_at: savedSection.updated_at,
      name: savedSection.name,
      name_ar: savedSection.name_ar,
      capacity: savedSection.capacity,
    };
  }
  async getHallSections(
    hallId: number,
    filter: FilterHallSectionsDto,
    user: AuthenticatedUser,
  ): Promise<{
    items: SectionResponseDto[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    let { name, capacity, sortBy, sortOrder, creationDate, page, limit } = filter;
    const { clientId } = user;
    sortBy = sortBy || SortByOptions.createdAt;
    sortOrder = sortOrder || SortOrderEnum.DESC;
    await this.hallServices.findHall(hallId, clientId);
    const queryBuilder = this.sectionRepository.createQueryBuilder('s');
    const hasFilterKeys = name || capacity !== undefined || creationDate;

    if (!hasFilterKeys) {
      queryBuilder
        .where('s.hallId = :hallId', { hallId })
        .andWhere('s.deleted = :deleted', { deleted: false });
    }

    if (hasFilterKeys) {
      queryBuilder.where(
        new Brackets((qb) => {
          qb.where('s.hallId = :hallId', { hallId }).andWhere('s.deleted = :deleted', {
            deleted: false,
          });

          if (name) {
            qb.andWhere(
              new Brackets((nameQb) => {
                nameQb
                  .where('s.name ILIKE :nameFilter', {
                    nameFilter: `%${name}%`,
                  })
                  .orWhere('s.name_ar ILIKE :nameFilter', {
                    nameFilter: `%${name}%`,
                  });
              }),
            );
          }

          if (capacity !== undefined) {
            qb.andWhere('s.capacity = :capacityFilter', {
              capacityFilter: capacity,
            });
          }
          if (creationDate) {
            qb.andWhere('DATE(s.created_at) = :creationDate', {
              creationDate,
            });
          }
        }),
      );
    }

    if (sortBy === SortByOptions.name) {
      queryBuilder.orderBy(`s.name`, sortOrder).addOrderBy(`s.name_ar`, sortOrder);
    } else {
      queryBuilder.orderBy(`s.${sortBy}`, sortOrder);
    }
    if (page && limit) {
      const take = limit || 10;
      const skip = ((page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }
    const [result, total] = await queryBuilder.getManyAndCount();
    const formattedItems = result.map((section) => {
      return {
        id: section.id,
        created_at: section.created_at,
        updated_at: section.updated_at,
        name: section.name,
        name_ar: section.name_ar,
        capacity: section.capacity,
      };
    });
    return this.paginatorService.paginate(formattedItems, total, page || 1, limit || total);
  }
  async getSection(
    hallId: number,
    sectionId: number,
    user: AuthenticatedUser,
  ): Promise<SectionResponseDto> {
    const { clientId } = user;
    await this.hallServices.findHall(hallId, clientId)
    const section = await this.sectionRepository.findOne({
      where: { id: sectionId, deleted: false, hall: { id: hallId, client: { id: clientId } } },
      select: {
        id: true,
        created_at: true,
        updated_at: true,
        name: true,
        name_ar: true,
        capacity: true,
      },
    });
    if (!section) {
      throw new BadRequestException(ErrorKeys.sectionNotFound);
    }

    return section;
  }
  async updateSection(
    hallId: number,
    sectionId: number,
    updateSectionDto: UpdateSectionDto,
    user: AuthenticatedUser,
  ): Promise<SectionResponseDto> {
    const { name, capacity, name_ar } = updateSectionDto;
    const { clientId, id: userId } = user
    await this.getSection(hallId, sectionId, user)
    if (name && name_ar) {
      await this.findSectionByName(sectionId, name, name_ar, clientId, hallId);
    } else if (name) {
      await this.findSectionByName(sectionId, name, null, clientId, hallId);
    } else if (name_ar) {
      await this.findSectionByName(sectionId, null, name_ar, clientId, hallId);
    }

    await this.sectionRepository.update(sectionId, {
      name: name ?? undefined,
      name_ar: name_ar ?? undefined,
      capacity: capacity ?? undefined,
      updated_by: userId
    });
    await this.emitSectionEmitterAfterChange(sectionId, clientId);
    return this.getSection(hallId, sectionId, user);
  }
  async deleteSection(
    hallId: number,
    sectionId: number,
    user: AuthenticatedUser,
  ): Promise<SectionResponseDto> {
    const section = await this.getSection(hallId, sectionId, user);
    const { id: userId } = user;
    await this.sectionRepository.update(sectionId, {
      deleted: true,
      deleted_by: userId,
      deleted_at: new Date(),
    });
    return { ...section, deleted: true, deleted_at: new Date() };
  }
  // Validate that section IDs are unique
  validateSections(sections: SectionDto[]): void {
    const sectionIds = sections.map((section) => section.id).filter(Boolean);

    if (new Set(sectionIds).size !== sectionIds.length) {
      throw new BadRequestException(ErrorKeys.sectionsMustBeUnique);
    }
  }

  // Validate that section names are unique
  validateSectionsName(sections: SectionDto[]): void {
    // Set default values for missing names
    sections.forEach((section) => {
      if (!section.name && !section.name_ar) {
        throw new BadRequestException(ErrorKeys.sectionNameIsRequired)
      }
      const [name, name_ar] = HandelTwoName(section.name, section.name_ar)
      section.name = name
      section.name_ar = name_ar
    });
    const names = new Set();
    const namesAr = new Set();
    // Get all names (including defaults)
    for (const section of sections) {
      const { name, name_ar } = section;
      if (names.has(name) || namesAr.has(name_ar) || names.has(name_ar) || namesAr.has(name)) {
        throw new BadRequestException(ErrorKeys.sectionsMustBeUnique);
      }
      // Add names to sets
      names.add(name);
      namesAr.add(name_ar);
    }
  }

  private async findSectionByName(
    id: number,
    name: string,
    name_ar: string,
    clientId: number,
    hallId: number,
  ): Promise<void> {
    let existSection = undefined;

    if (name && name_ar) {
      existSection = await this.sectionRepository.findOne({
        where: [
          {
            name,
            deleted: false,
            hall: { id: hallId, client: { id: clientId } },
            id: Not(id),
          },
          {
            name: name_ar,
            deleted: false,
            hall: { id: hallId, client: { id: clientId } },
            id: Not(id),
          },
          {
            name_ar,
            deleted: false,
            hall: { id: hallId, client: { id: clientId } },
            id: Not(id),
          },
          {
            name_ar: name,
            deleted: false,
            hall: { id: hallId, client: { id: clientId } },
            id: Not(id),
          },
        ],
      });
    } else if (name) {
      existSection = await this.sectionRepository.findOne({
        where: [
          {
            name,
            deleted: false,
            hall: { id: hallId, client: { id: clientId } },
            id: Not(id),
          },
          {
            name_ar: name,
            deleted: false,
            hall: { id: hallId, client: { id: clientId } },
            id: Not(id),
          },
        ],
      });
    } else {
      existSection = await this.sectionRepository.findOne({
        where: [
          {
            name: name_ar,
            deleted: false,
            hall: { id: hallId, client: { id: clientId } },
            id: Not(id),
          },
          {
            name_ar,
            deleted: false,
            hall: { id: hallId, client: { id: clientId } },
            id: Not(id),
          },
        ],
      });
    }
    if (existSection) {
      throw new BadRequestException(ErrorKeys.sectionExisting);
    }
  }

  // Validate that the hall sections exist for a given hall
  async validateExistingSections(hallId: number, sections: SectionDto[], clientId: number): Promise<void> {
    const sectionIds = sections.map((section) => section.id).filter(Boolean);

    if (sectionIds.length === 0) return; // No existing sections to validate

    const existingSections = await this.getSectionsInRange(sectionIds, hallId, clientId);
    const existingSectionIds = existingSections.map((section) => section.id);

    // Check for sections that do not exist
    const notExistsSections = sectionIds.filter((id) => !existingSectionIds.includes(id));

    if (notExistsSections.length > 0) {
      throw new BadRequestException(ErrorKeys.sectionNotFound);
    }
  }

  // Retrieve sections based on their IDs and section ID
  async getSectionsInRange(sectionIds: number[], hallId: number, clientId: number): Promise<HallSectionsEntity[]> {
    return await this.sectionRepository.find({
      where: {
        id: In(sectionIds),
        deleted: false, // Assuming you have a soft delete field
        hall: { id: hallId, client: { id: clientId } }, // Assuming a relation with the hall

      },
      select: ['id', 'name', 'name_ar'], // Select only necessary fields
    });
  }

  private async emitSectionEmitterAfterChange(sectionId: number, clientId: number): Promise<void> {
    const section = await this.sectionRepository.findOne({
      where: { id: sectionId, hall: { client: { id: clientId } }, deleted: false },
      relations: { hall: { landingPage: true } },
    });
    const landingHallNames: string[] = []; // Initialize an empty array
    if (section) {
      if (section?.hall?.landingPage)
        landingHallNames.push(section.hall.landingPage.hallName);
    }

    // Emit the event with the array of hall names
    if (landingHallNames.length > 0) {
      this.eventEmitter.emit('hall.updated', {
        landingHallNames,
      });
    }
  }
}
