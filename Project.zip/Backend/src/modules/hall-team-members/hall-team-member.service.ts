import {
  BadRequestException,
  ForbiddenException,
  forwardRef,
  Inject,
  Injectable,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, In, Not, Repository } from 'typeorm';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { HallsService } from '../halls/halls.service';
import { UsersService } from '../users/users.service';
import { HallTeamMembersEntity } from './entities/hall-team-member.entity';
import { PaginatorService } from '../../common/paginator/paginator.service';
import { UpdateTeamMemberDto } from './dtos/update-hall-team-member.dto';
import { TeamMemberDto } from './dtos/teamMembers.dto';
import { FilterHallTeamMembersDto } from './dtos/filter-hall-team-member.dto';
import { TeamMembersTypeEnum } from '../../common/enums/TeamMembersType.enum';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { TeamMemberResponseDto } from './dtos/hall-team-member.response.dto';
import { CreateTeamMemberDto } from './dtos/create-hall-team-member.dto';
@Injectable()
export class HallTeamMembersService {
  constructor(
    @InjectRepository(HallTeamMembersEntity)
    private teamMembersRepository: Repository<HallTeamMembersEntity>,
    @Inject(forwardRef(() => HallsService))
    private readonly hallServices: HallsService,
    private readonly userService: UsersService,
    private readonly paginatorService: PaginatorService,
  ) {}
  async addTeamMember(
    hallId: number,
    createTeamMemberDto: CreateTeamMemberDto,
    user: AuthenticatedUser,
  ): Promise<TeamMemberResponseDto> {
    const { name, email, phone, memberType, moderatorId } = createTeamMemberDto;
    const { clientId, id: userId } = user;
    await this.hallServices.findHall(hallId, clientId);
    if (memberType === TeamMembersTypeEnum.thirdParty) {
      const existTeamMember = await this.teamMembersRepository.findOne({
        where: [
          { email, deleted: false, hall: { id: hallId, client: { id: user.clientId } } },
          { phone, deleted: false, hall: { id: hallId, client: { id: user.clientId } } },
        ],
        relations: { hall: true, moderator: true },
      });
      if (existTeamMember) {
        throw new BadRequestException(ErrorKeys.teamMemberExist);
      }
    } else {
      await this.userService.validateExistingModerators(clientId, hallId, [moderatorId]);
    }
    const teamMemberEntity =
      memberType === TeamMembersTypeEnum.thirdParty
        ? {
            name,
            email,
            phone,
            memberType,
            created_by: userId,
            hall: { id: hallId },
          }
        : {
            moderator: { id: moderatorId },
            memberType,
            created_by: userId,
            hall: { id: hallId },
          };
    const savedTeamMember = await this.teamMembersRepository.save(teamMemberEntity);
    return this.getTeamMember(hallId, savedTeamMember.id, user);
  }
  async getHallTeamMembers(
    hallId: number,
    filter: FilterHallTeamMembersDto,
    user: AuthenticatedUser,
  ): Promise<{
    items: TeamMemberResponseDto[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    let { page, limit } = filter;
    const { clientId } = user;
    await this.hallServices.findHall(hallId, clientId);

    let queryBuilder = this.teamMembersRepository
      .createQueryBuilder('t')
      .leftJoinAndSelect('t.moderator', 'moderator')
      .where('t.hallId = :hallId', { hallId })
      .andWhere('t.deleted = :deleted', { deleted: false })
      .orderBy('t.created_at', 'DESC');
    if (page && limit) {
      const take = limit || 10;
      const skip = ((page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }
    const [result, total] = await queryBuilder.getManyAndCount();
    const formattedItems = result.map((teamMember) => {
      return this.mapTeamMember(teamMember);
    });
    return this.paginatorService.paginate(formattedItems, total, page || 1, limit || total);
  }
  async getTeamMember(
    hallId: number,
    memberId: number,
    user: AuthenticatedUser,
  ): Promise<TeamMemberResponseDto> {
    const { clientId } = user;
    await this.hallServices.findHall(hallId, clientId);
    const teamMember = await this.teamMembersRepository.findOne({
      where: { id: memberId, deleted: false, hall: { id: hallId, client: { id: clientId } } },
      relations: { hall: true, moderator: true },
    });
    if (!teamMember) {
      throw new BadRequestException(ErrorKeys.teamMemberNotFound);
    }
    return this.mapTeamMember(teamMember);
  }
  async updateTeamMember(
    hallId: number,
    memberId: number,
    updateTeamMemberDto: UpdateTeamMemberDto,
    user: AuthenticatedUser,
  ): Promise<TeamMemberResponseDto> {
    const { name, email, phone } = updateTeamMemberDto;
    const { clientId, id: userId } = user;
    const teamMember = await this.getTeamMember(hallId, memberId, user);
    if (teamMember.memberType === TeamMembersTypeEnum.employee) {
      throw new ForbiddenException(ErrorKeys.forbidden);
    }
    if (email) {
      const existTeamMemberBySameEmail = await this.teamMembersRepository.findOne({
        where: [
          {
            id: Not(memberId),
            email,
            deleted: false,
            hall: { id: hallId, client: { id: user.clientId } },
          },
          {
            id: Not(memberId),
            moderator: { email },
            deleted: false,
            hall: { id: hallId, client: { id: user.clientId } },
          },
        ],
      });
      if (existTeamMemberBySameEmail) {
        throw new BadRequestException(ErrorKeys.teamMemberExist);
      }
    }

    if (phone) {
      const existTeamMemberBySamePhone = await this.teamMembersRepository.findOne({
        where: [
          {
            id: Not(memberId),
            phone,
            deleted: false,
            hall: { id: hallId, client: { id: clientId } },
          },
          {
            id: Not(memberId),
            moderator: { phone },
            deleted: false,
            hall: { id: hallId, client: { id: clientId } },
          },
        ],
      });
      if (existTeamMemberBySamePhone) {
        throw new BadRequestException(ErrorKeys.teamMemberExist);
      }
    }
    await this.teamMembersRepository.update(memberId, {
      name: name ?? undefined,
      email: email ?? undefined,
      phone: phone ?? undefined,
      updated_by: userId,
    });
    return this.getTeamMember(hallId, memberId, user);
  }
  async deleteTeamMember(
    hallId: number,
    memberId: number,
    user: AuthenticatedUser,
  ): Promise<TeamMemberResponseDto> {
    const teamMember = await this.getTeamMember(hallId, memberId, user);
    const { id: userId } = user;
    await this.teamMembersRepository.update(memberId, {
      deleted: true,
      deleted_by: userId,
      deleted_at: new Date(),
    });
    return { ...teamMember, deleted: true, deleted_at: new Date() };
  }

  // Validate that team member email are unique
  validateteamMembers(teamMembers: TeamMemberDto[]): void {
    const memberEmails = teamMembers
      .map((member) => member.email) // Map to get the emails
      .filter(Boolean); // Filter out undefined or null values

    const memberPhones = teamMembers
      .map((member) => member.phone) // Map to get the phones
      .filter(Boolean); // Filter out undefined or null values

    const memberModeratorIds = teamMembers
      .map((member) => member.moderatorId) // Map to get the moderator ids
      .filter(Boolean); // Filter out undefined or null values

    if (
      new Set(memberEmails).size !== memberEmails.length ||
      new Set(memberPhones).size !== memberPhones.length ||
      new Set(memberModeratorIds).size !== memberModeratorIds.length
    ) {
      throw new BadRequestException(ErrorKeys.teamMembersMustBeUnique);
    }
  }

  mapTeamMember(teamMember: HallTeamMembersEntity): TeamMemberResponseDto {
    return teamMember.memberType === TeamMembersTypeEnum.thirdParty
      ? {
          id: teamMember.id,
          created_at: teamMember.created_at,
          updated_at: teamMember.updated_at,
          name: teamMember.name,
          email: teamMember.email,
          phone: teamMember.phone,
          memberType: teamMember.memberType,
          moderator: null,
        }
      : {
          id: teamMember.id,
          created_at: teamMember.created_at,
          updated_at: teamMember.updated_at,
          name: teamMember.moderator.name,
          email: teamMember.moderator.email,
          phone: teamMember.moderator.phone,
          memberType: teamMember.memberType,
          moderator: { id: teamMember.moderator.id },
        };
  }

  async getHallTeamMemberEmails(hallId: number): Promise<string[]> {
    const teamMembers = await this.teamMembersRepository.find({
      where: {
        hall: { id: hallId },
      },
      relations: { moderator: true },
      select: {
        id: true,
        email: true,
        memberType: true,
        moderator: { id: true, email: true },
      },
    });

    return teamMembers
      .map((m) => {
        if (m.memberType === TeamMembersTypeEnum.employee) return m?.moderator?.email;
        return m?.email;
      })
      .filter((e) => e);
  }
}
