import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Query,
  UseGuards,
  Post,
} from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { ApiBearerAuth, ApiHeader, ApiTags } from '@nestjs/swagger';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { hallsPermissions } from '../halls/halls.permissions';
import { FilterHallTeamMembersDto } from './dtos/filter-hall-team-member.dto';
import { UpdateTeamMemberDto } from './dtos/update-hall-team-member.dto';
import { HallTeamMembersService } from './hall-team-member.service';
import { UserTypeGuard } from '../../common/guards/user-types.guard';
import { UserTypes } from '../../common/decorators/user-types.decorator';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { TeamMemberResponseDto } from './dtos/hall-team-member.response.dto';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { CreateTeamMemberDto } from './dtos/create-hall-team-member.dto';

@ApiTags('halls')
@UseGuards(UserTypeGuard)
@ApiBearerAuth()
@Controller('halls')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class HallTeamMembersController {
  constructor(private readonly hallTeamMembersService: HallTeamMembersService) {}
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.CREATE_HALLS)
  @Post(':hallId/members')
  async addTeamMember(
    @Param('hallId') hallId: string,
    @Body() createTeamMemberDto: CreateTeamMemberDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<TeamMemberResponseDto> {
    return this.hallTeamMembersService.addTeamMember(+hallId, createTeamMemberDto, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.READ_HALLS)
  @Get(':hallId/members')
  async findHallTeamMembers(
    @Param('hallId') hallId: string,
    @Query() filter: FilterHallTeamMembersDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<{
    items: TeamMemberResponseDto[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return this.hallTeamMembersService.getHallTeamMembers(+hallId, filter, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.READ_HALLS)
  @Get(':hallId/members/:memberId')
  async getTeamMember(
    @Param('hallId') hallId: string,
    @Param('memberId') memberId: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<TeamMemberResponseDto> {
    return this.hallTeamMembersService.getTeamMember(+hallId, +memberId, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.UPDATE_HALLS)
  @Patch(':hallId/members/:memberId')
  async updateTeamMember(
    @Param('hallId') hallId: string,
    @Param('memberId') memberId: string,
    @Body() updateTeamMemberDto: UpdateTeamMemberDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<TeamMemberResponseDto> {
    return this.hallTeamMembersService.updateTeamMember(
      +hallId,
      +memberId,
      updateTeamMemberDto,
      user,
    );
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.DELETE_HALLS)
  @Delete(':hallId/members/:memberId')
  async deleteTeamMember(
    @Param('hallId') hallId: string,
    @Param('memberId') memberId: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<TeamMemberResponseDto> {
    return this.hallTeamMembersService.deleteTeamMember(+hallId, +memberId, user);
  }
}
