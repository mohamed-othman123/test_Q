import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HallsModule } from '../halls/halls.module';
import { UsersModule } from '../users/users.module';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { HallTeamMembersEntity } from './entities/hall-team-member.entity';
import { HallTeamMembersController } from './hall-team-member.controller';
import { HallTeamMembersService } from './hall-team-member.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([HallTeamMembersEntity]),
    forwardRef(() => HallsModule),
    UsersModule,
    PaginatorModule,
  ],
  controllers: [HallTeamMembersController],
  providers: [HallTeamMembersService],
  exports: [HallTeamMembersService],
})
export class HallTeamMembersModule {}
