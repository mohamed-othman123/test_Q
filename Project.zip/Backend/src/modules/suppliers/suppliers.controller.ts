import { SuppliersService } from './suppliers.service';
import { ApiBearerAuth, ApiHeader, ApiQuery, ApiTags } from '@nestjs/swagger';
import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { CreateSupplierDto } from './dtos/create-supplier.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { suppliersPermissions } from './suppliers.permissions';
import { FilterSuppliersDto } from './dtos/filter-suppliers.dto';
import { UpdateSupplierDto } from './dtos/update-supplier.dto';
import { EmployeeHallsInterceptor } from '../../auth/interceptors/halls-employee.interceptor';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { SupplierResponseDto } from './dtos/supplier.response.dto';
import { purchasesPermissions } from '../expenses/expenses.permissions';
import { servicesPermissions } from '../services/services.permissions';

@ApiBearerAuth()
@ApiTags('suppliers')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
@Controller('suppliers')
export class SuppliersController {
  constructor(private readonly suppliersService: SuppliersService) { }

  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(suppliersPermissions.CREATE_SUPPLIERS)
  @Post()
  async createSupplier(
    @Body() createSupplierDto: CreateSupplierDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<SupplierResponseDto> {
    return this.suppliersService.createSupplier(createSupplierDto, user);
  }

  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(suppliersPermissions.READ_SUPPLIERS, purchasesPermissions.CREATE_PURCHASE,purchasesPermissions.UPDATE_PURCHASE, servicesPermissions.CREATE_SERVICE,servicesPermissions.UPDATE_SERVICE)
  @Get()
  async listSuppliers(
    @Query() filter: FilterSuppliersDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<{
    items: SupplierResponseDto[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return this.suppliersService.listSuppliers(filter, user);
  }

  @RequirePermissions(suppliersPermissions.READ_SUPPLIERS,purchasesPermissions.CREATE_PURCHASE,purchasesPermissions.UPDATE_PURCHASE)
  @Get('/:id')
  async getSupplier(
    @Param('id') id: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<SupplierResponseDto> {
    return this.suppliersService.getSupplier(+id, user);
  }
  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(suppliersPermissions.UPDATE_SUPPLIERS)
  @Patch('/:id')
  async updateSupplier(
    @Param('id') id: string,
    @Body() updateSupplierDto: UpdateSupplierDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<SupplierResponseDto> {
    return this.suppliersService.updateSupplier(+id, updateSupplierDto, user);
  }

  @RequirePermissions(suppliersPermissions.DELETE_SUPPLIERS)
  @Delete('/:id')
  async removeSupplier(
    @Param('id') id: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<SupplierResponseDto> {
    return this.suppliersService.removeSupplier(+id, user);
  }
}
