import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const suppliersPermissions = {
  CREATE_SUPPLIERS: {
    ar_name: 'إنشاء:الموردين',
    en_name: 'create:suppliers',
    ar_module: 'بنود الصرف و الموردين',
    en_module: 'Expenses & Suppliers',
    order: 9,
    key: 'Expenses & Suppliers',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/suppliers'",
  },
  READ_SUPPLIERS: {
    ar_name: 'قراءة:الموردين',
    en_name: 'read:suppliers',
    ar_module: 'بنود الصرف و الموردين',
    en_module: 'Expenses & Suppliers',
    order: 9,
    key: 'Expenses & Suppliers',
    type: PermissionsTypeEnum.READ,
    route: "GET '/suppliers'",
  },
  UPDATE_SUPPLIERS: {
    ar_name: 'تحديث:الموردين',
    en_name: 'update:suppliers',
    ar_module: 'بنود الصرف و الموردين',
    en_module: 'Expenses & Suppliers',
    order: 9,
    key: 'Expenses & Suppliers',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/suppliers/:id'",
  },
  DELETE_SUPPLIERS: {
    ar_name: 'حذف:الموردين',
    en_name: 'delete:suppliers',
    ar_module: 'بنود الصرف و الموردين',
    en_module: 'Expenses & Suppliers',
    order: 9,
    key: 'Expenses & Suppliers',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/suppliers/:id'",
  },
};
