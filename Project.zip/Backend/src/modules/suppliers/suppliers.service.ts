import { UpdateSupplierDto } from './dtos/update-supplier.dto';
import { PaginatorService } from './../../common/paginator/paginator.service';
import { SuppliersEntity } from './entities/suppliers.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { CreateSupplierDto, SupplierPaymentMethodsDto } from './dtos/create-supplier.dto';
import { BadRequestException, Injectable, forwardRef, Inject } from '@nestjs/common';
import { Brackets, In, Repository } from 'typeorm';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { FilterSuppliersDto, SortByOptions } from './dtos/filter-suppliers.dto';
import { HallsService } from '../halls/halls.service';
import { UpdateSupplierTransaction } from './utils/update-supplier.transactions';
import { DeleteSupplierTransaction } from './utils/delete-supplier.transactions';
import { CreateSupplierTransaction } from './utils/create-supplier.transaction';
import { SupplierProductService } from '../supplier-products/supplier-products.service';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { checkUserPermissionType } from 'src/core/helpers/cast.helper';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { HallSupplier } from './entities/hall_supplier.entity';
import { PaymentMethodsEnum } from '../../common/enums/payment-methods.enum';
import {
  SupplierPaymentDetailsResponseDto,
  SupplierResponseDto,
} from './dtos/supplier.response.dto';
import { SupplierPaymentMethodsEntity } from './entities/supplier_payment_methods.entity';

@Injectable()
export class SuppliersService {
  constructor(
    @InjectRepository(SuppliersEntity) private readonly suppliersRepo: Repository<SuppliersEntity>,
    @InjectRepository(HallSupplier) private readonly hallSupplierRepo: Repository<HallSupplier>,
    @InjectRepository(SupplierPaymentMethodsEntity)
    private readonly supplierPaymentMethodRepo: Repository<SupplierPaymentMethodsEntity>,
    private readonly paginatorService: PaginatorService,
    private readonly hallsService: HallsService,
    @Inject(forwardRef(() => SupplierProductService))
    private readonly supplierProductsService: SupplierProductService,
    private readonly createSupplierTransaction: CreateSupplierTransaction,
    private readonly updateSupplierTransaction: UpdateSupplierTransaction,
    private readonly deleteSupplierTransaction: DeleteSupplierTransaction,
  ) {}

  async createSupplier(
    createSupplierDto: CreateSupplierDto,
    user: AuthenticatedUser,
  ): Promise<SupplierResponseDto> {
    const { halls, products, paymentMethods } = createSupplierDto;
    const { clientId, id: userId } = user;
    this.validateSupplierPaymentMethods(paymentMethods);
    this.hallsService.validateHalls(halls);
    if (products) {
      this.supplierProductsService.validateProductsName(products);
    }
    const { supplierId, products: savedProducts } = await this.createSupplierTransaction.run({
      supplier: createSupplierDto,
      clientId,
      userId,
    });
    const supplier = await this.getSupplier(supplierId, user);
    return { ...supplier, products: savedProducts };
  }

  async listSuppliers(
    filter: FilterSuppliersDto,
    user: AuthenticatedUser,
  ): Promise<{
    items: SupplierResponseDto[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    let { sortBy, sortOrder, page, limit } = filter;
    const { clientId } = user;
    sortBy = sortBy || SortByOptions.createdAt;
    sortOrder = sortOrder || SortOrderEnum.DESC;

    const queryBuilder = this.suppliersRepo
      .createQueryBuilder('s')
      .leftJoinAndSelect('s.hallSuppliers', 'hallSupplier')
      .leftJoinAndSelect('hallSupplier.hall', 'hall');

    const hasFilterKeys =
      filter.name ||
      filter.email ||
      filter.active !== undefined ||
      filter.activity ||
      filter.address ||
      filter.phone ||
      filter.creationDate;
    if (!hasFilterKeys) {
      queryBuilder
        .where('s.client_id = :clientId', { clientId })
        .andWhere('s.deleted = :deleted', { deleted: false })
        .andWhere('hall.id=:hallId', {
          hallId: filter.hallId,
        });
    }
    if (hasFilterKeys) {
      queryBuilder.where(
        new Brackets((qb) => {
          qb.where('s.client_id = :clientId', { clientId })
            .andWhere('s.deleted = :deleted', {
              deleted: false,
            })
            .andWhere('hall.id=:hallId', {
              hallId: filter.hallId,
            });
          if (filter.creationDate) {
            qb.andWhere('DATE(s.created_at) = :creationDate', {
              creationDate: filter.creationDate,
            });
          }

          if (filter.name) {
            qb.andWhere('s.name ILIKE :nameFilter', { nameFilter: `%${filter.name}%` });
          }
          if (filter.email) {
            qb.andWhere('s.email ILIKE :emailFilter', { emailFilter: `%${filter.email}%` });
          }
          if (filter.phone) {
            qb.andWhere('s.phone ILIKE :phoneFilter', { phoneFilter: `%${filter.phone}%` });
          }
          if (filter.activity) {
            qb.andWhere('s.activity ILIKE :activityFilter', {
              activityFilter: `%${filter.activity}%`,
            });
          }

          if (filter.active !== undefined) {
            qb.andWhere('s.active = :activeFilter', {
              activeFilter: filter.active,
            });
          }
          if (filter.address) {
            qb.andWhere('s.address ILIKE :addressFilter', { addressFilter: `%${filter.address}%` });
          }
        }),
      );
    }
    queryBuilder.orderBy(`s.${sortBy}`, sortOrder);
    if (page && limit) {
      const take = limit || 10;
      const skip = ((page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }
    const [result, total] = await queryBuilder.getManyAndCount();
    const formattedItems = result.map((supplier) => ({
      id: supplier.id,
      created_at: supplier.created_at,
      updated_at: supplier.updated_at,
      created_by: supplier.created_by,
      name: supplier.name,
      phone: supplier.phone,
      email: supplier.email,
      taxRegistrationNumber: supplier.taxRegistrationNumber,
      commercialRegistrationNumber: supplier.commercialRegistrationNumber,
      active: supplier.active,
      address: supplier.address,
      activity: supplier.activity,
      note: supplier.note,
      halls: supplier?.hallSuppliers.map((hs) => ({
        id: hs.hall.id,
        name: hs.hall.name,
        name_ar: hs.hall.name_ar,
      })),
    }));

    return this.paginatorService.paginate(formattedItems, total, page || 1, limit || total);
  }

  async findSupplier(id: number, user: AuthenticatedUser, select = {}): Promise<SuppliersEntity> {
    const { clientId, type, halls } = user;
    const queryConditions = {
      id,
      client: { id: clientId },
      deleted: false,
      hallSuppliers: type === UserTypesEnum.employee ? { hall: In(halls) } : undefined,
    };
    const existSupplier = await this.suppliersRepo.findOne({
      where: queryConditions,
      select,
      relations: {},
    });
    if (!existSupplier) {
      throw new BadRequestException(ErrorKeys.supplierNotFound);
    }
    return existSupplier;
  }

  async getSupplier(id: number, user: AuthenticatedUser): Promise<SupplierResponseDto> {
    const { clientId, type, halls } = user;
    const queryConditions = {
      id,
      client: { id: clientId },
      deleted: false,
      hallSuppliers: type === UserTypesEnum.employee ? { hall: In(halls) } : undefined,
    };
    const existSupplier = await this.suppliersRepo.findOne({
      where: queryConditions,
      relations: {
        hallSuppliers: { hall: true },
        paymentMethods: true,
        hallServices: { service: true },
      },
    });
    if (!existSupplier) {
      throw new BadRequestException(ErrorKeys.supplierNotFound);
    }

    return {
      id: existSupplier.id,
      created_at: existSupplier.created_at,
      updated_at: existSupplier.updated_at,
      deleted_at: existSupplier.deleted_at,
      created_by: existSupplier.created_by,
      updated_by: existSupplier.updated_by,
      deleted_by: existSupplier.deleted_by,
      name: existSupplier.name,
      phone: existSupplier.phone,
      taxRegistrationNumber: existSupplier.taxRegistrationNumber,
      commercialRegistrationNumber: existSupplier.commercialRegistrationNumber,
      email: existSupplier.email,
      address: existSupplier.address,
      active: existSupplier.active,
      activity: existSupplier.activity,
      note: existSupplier.note,
      paymentMethods: existSupplier?.paymentMethods.map((paymentMethod) => ({
        ...this.handelSupplierPaymentDetails(paymentMethod),
      })),
      halls: existSupplier?.hallSuppliers.map((hallSupplier) => ({
        id: hallSupplier.hall.id,
        name: hallSupplier.hall.name,
        name_ar: hallSupplier.hall.name_ar,
      })),
    };
  }
  async updateSupplier(
    id: number,
    updateSupplierDto: UpdateSupplierDto,
    user: AuthenticatedUser,
  ): Promise<SupplierResponseDto> {
    const { clientId, id: userId } = user;
    const existSupplier = await this.findSupplier(id, user);
    checkUserPermissionType(user, existSupplier.created_by);
    const { halls, paymentMethods } = updateSupplierDto;
    if (halls) {
      this.hallsService.validateHalls(halls);
    }
    if (paymentMethods) {
      this.validateSupplierPaymentMethods(paymentMethods);
      const paymentMethodIds = paymentMethods.map((payment) => payment.id).filter(Boolean);
      await this.validateExistingPaymentMethods(id, paymentMethodIds, user);
    }
    await this.updateSupplierTransaction.run({
      supplier: updateSupplierDto,
      supplierId: id,
      clientId,
      userId,
    });
    return await this.getSupplier(id, user);
  }

  async removeSupplier(id: number, user: AuthenticatedUser): Promise<SupplierResponseDto> {
    const existSupplier = await this.getSupplier(id, user);
    checkUserPermissionType(user, existSupplier.created_by);

    await this.deleteSupplierTransaction.run({
      supplierId: id,
      userId: user.id,
    });
    return { ...existSupplier, deleted: true, deleted_at: new Date() };
  }

  async validateSuppliersInHalls(
    supplierHallPairs: { supplierId: number; hallId: number }[],
    user: AuthenticatedUser,
  ): Promise<HallSupplier[]> {
    // Build query conditions dynamically
    const queryConditions = supplierHallPairs.map((pair) => ({
      supplier: { id: pair.supplierId, client: { id: user.clientId } },
      hall: { id: pair.hallId, client: { id: user.clientId } },
    }));
    // Fetch all existing hall-supplier pairs in one query
    const existingPairs = await this.hallSupplierRepo.find({
      where: queryConditions,
      relations: { supplier: true },
    });

    if (existingPairs.length !== supplierHallPairs.length) {
      throw new BadRequestException(ErrorKeys.supplierNotFound);
    }

    return existingPairs;
  }

  async checkSupplierHalls(supplierId: number, clientId: number): Promise<SuppliersEntity> {
    return await this.suppliersRepo.findOne({
      where: { id: supplierId, client: { id: clientId }, deleted: false },
      relations: { hallSuppliers: { hall: true } },
      select: { id: true, created_by: true, hallSuppliers: { id: true, hall: { id: true } } },
    });
  }

  // Validate that the supplier payment methods exist for a given supplier
  async validateExistingPaymentMethods(
    supplierId: number,
    paymentMethodIds: number[],
    user: AuthenticatedUser,
  ): Promise<void> {
    const existingPaymenMethods = await this.getPaymentMethodsInRange(
      paymentMethodIds,
      supplierId,
      user,
    );
    const existingPaymenMethodnIds = existingPaymenMethods.map((payment) => payment.id);

    // Check for payment methods that do not exist
    const notExistsPaymenMethods = paymentMethodIds.filter(
      (id) => !existingPaymenMethodnIds.includes(id),
    );

    if (notExistsPaymenMethods.length > 0) {
      throw new BadRequestException(ErrorKeys.supplierPaymentMethodNotFound);
    }
  }

  // Retrieve payment methods based on their IDs and section ID
  async getPaymentMethodsInRange(
    paymentMethodIds: number[],
    supplierId: number,
    user: AuthenticatedUser,
  ): Promise<SupplierPaymentMethodsEntity[]> {
    return await this.supplierPaymentMethodRepo.find({
      where: {
        id: In(paymentMethodIds),
        deleted: false,
        supplier: { id: supplierId, client: { id: user.clientId } },
      },
      select: ['id'],
    });
  }
  private validateSupplierPaymentMethods(paymentMethods: SupplierPaymentMethodsDto[]): void {
    const paymentMethodIds = paymentMethods.map((payment) => payment.id).filter(Boolean);
    if (new Set(paymentMethodIds).size !== paymentMethodIds.length) {
      throw new BadRequestException(ErrorKeys.paymentMethodsMustBeUnique);
    }
    // Validate specific payment methods
    paymentMethods.forEach((paymentMethod) => {
      if (
        paymentMethod.paymentMethodType === PaymentMethodsEnum.BANK_ACCOUNT &&
        !paymentMethod.IBAN &&
        !paymentMethod.accountNumber
      ) {
        throw new BadRequestException(ErrorKeys.accountNumberOrIbanIsRequired);
      }
    });
  }
  private handelSupplierPaymentDetails(
    paymentMethod: SupplierPaymentMethodsEntity,
  ): SupplierPaymentDetailsResponseDto {
    const {
      id,
      name,
      paymentMethodType,
      bankName,
      IBAN,
      accountNumber,
      eWalletName,
      eWalletPhone,
      paymentMethodNotes,
    } = paymentMethod;

    const isBankAccount = paymentMethodType === PaymentMethodsEnum.BANK_ACCOUNT;
    const isEWallet = paymentMethodType === PaymentMethodsEnum.E_WALLET;

    const paymentDetails = {
      id,
      name,
      paymentMethodType,
      bankName: isBankAccount ? bankName : undefined,
      IBAN: isBankAccount ? IBAN : undefined,
      accountNumber: isBankAccount ? accountNumber : undefined,
      eWalletName: isEWallet ? eWalletName : undefined,
      eWalletPhone: isEWallet ? eWalletPhone : undefined,
      paymentMethodNotes,
    };

    return paymentDetails;
  }
}
