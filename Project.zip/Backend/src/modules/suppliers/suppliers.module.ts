import { Module, forwardRef } from '@nestjs/common';
import { SuppliersController } from './suppliers.controller';
import { SuppliersService } from './suppliers.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SuppliersEntity } from './entities/suppliers.entity';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { HallsModule } from '../halls/halls.module';
import { UpdateSupplierTransaction } from './utils/update-supplier.transactions';
import { DeleteSupplierTransaction } from './utils/delete-supplier.transactions';
import { CreateSupplierTransaction } from './utils/create-supplier.transaction';
import { SupplierProductModule } from '../supplier-products/supplier-products.module';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
import { HallSupplier } from './entities/hall_supplier.entity';
import { SupplierPaymentMethodsEntity } from './entities/supplier_payment_methods.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([SuppliersEntity, HallSupplier, SupplierPaymentMethodsEntity]),
    PaginatorModule,
    HallsModule,
    forwardRef(() => SupplierProductModule),
  ],
  controllers: [SuppliersController],
  providers: [
    SuppliersService,
    CreateSupplierTransaction,
    UpdateSupplierTransaction,
    DeleteSupplierTransaction,
    HallIdExtractor,
  ],
  exports: [SuppliersService],
})
export class SuppliersModule {}
