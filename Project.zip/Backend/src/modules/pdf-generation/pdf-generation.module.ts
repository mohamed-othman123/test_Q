import { Module, forwardRef, OnModuleInit } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DocumentPdfEntity } from './entities/document-pdf.entity';
import { DocumentService } from './services/document.service';
import { PdfConverterService } from './services/pdf-converter.service';
import { QrCodeModule } from '../qr-code/qr-code.module';
import { BookingContractPreparer } from './services/preparers/booking/contract.preparer';
import { PaymentReceiptPreparer } from './services/preparers/payment/receipt.preparer';
import { PurchaseSettlementPreparer } from './services/preparers/purchase/settlement.preparer';
import { PreparerFactory } from './services/preparers/preparer.factory';
import { ConverterMethod } from './enums/converter-strategies.enum';
import { PuppeteerPdfGenerationStrategy } from './strategies/pdf/puppeteer.strategy';
import { GotenbergPdfGenerationStrategy } from './strategies/pdf/gotenberg.strategy';
import { TemplatePathResolver } from './services/template-path.resolver';
import { FileUploadModule } from '../../common/utilities/file-upload/file-upload.module';
import { PdfGenerationController } from './pdf-generation.controller';
import { MailerAppModule } from '../../providers/mailer/mailer.module';
import { SmsModule } from '../../providers/sms/sms.module';
import { NotificationFactory } from './services/notifications/notification.factory';
import { BookingModule } from '../booking/booking.module';
import { PaymentModule } from '../payment/payment.module';
import { ServicesModule } from '../services/services.module';
import { ExpensesModule } from '../expenses/expenses.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([DocumentPdfEntity]),
    QrCodeModule,
    FileUploadModule,
    MailerAppModule,
    SmsModule,
    forwardRef(() => BookingModule),
    forwardRef(() => PaymentModule),
    forwardRef(() => ExpensesModule),
    ServicesModule,
  ],
  controllers: [PdfGenerationController],
  providers: [
    DocumentService,
    PdfConverterService,
    PreparerFactory,
    BookingContractPreparer,
    PaymentReceiptPreparer,
    PurchaseSettlementPreparer,
    PuppeteerPdfGenerationStrategy,
    GotenbergPdfGenerationStrategy,
    TemplatePathResolver,
    NotificationFactory,

    {
      provide: 'PDF_STRATEGIES',
      useFactory: (
        puppeteer: PuppeteerPdfGenerationStrategy,
        gotenberg: GotenbergPdfGenerationStrategy,
      ) => {
        const strategies = new Map();
        strategies.set(ConverterMethod.Puppeteer, puppeteer);
        strategies.set(ConverterMethod.GOTENBERG, gotenberg);
        return strategies;
      },
      inject: [PuppeteerPdfGenerationStrategy, GotenbergPdfGenerationStrategy],
    },
  ],
  exports: [DocumentService],
})
export class PdfGenerationModule implements OnModuleInit {
  async onModuleInit() {}
}
