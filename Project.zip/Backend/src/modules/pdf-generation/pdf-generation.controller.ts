import { Controller, Get, Param, Query, Res } from '@nestjs/common';
import { FastifyReply } from 'fastify';
import { Public } from 'src/auth/decorator/public.decorator';
import { PdfParamDto } from './dtos/pdf-param.dto';
import { PdfQueryDto } from './dtos/pdf-query.dto';
import { DocumentService } from './services/document.service';

@Controller(':template')
export class PdfGenerationController {
  constructor(private readonly documentService: DocumentService) {}

  @Public()
  @Get('preview/:id')
  async preview(
    @Param() param: PdfParamDto,
    @Query() query: PdfQueryDto,
    @Res() res: FastifyReply,
  ) {
    const result: string | Buffer = await this.documentService.fetchDocument(
      param.id,
      param.template,
      query,
    );

    res.raw.writeHead(200, {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `inline; filename="${param.template}.pdf"`,
    });

    if (typeof result === 'string') {
      const response = await import('axios').then((ax) =>
        ax.default.get(result, { responseType: 'stream' }),
      );
      response.data.pipe(res.raw);
      response.data.on('end', () => res.raw.end());
    } else if (Buffer.isBuffer(result)) {
      res.raw.end(result);
    } else {
      res.status(500).send({ message: 'Invalid PDF response' });
    }
  }

  @Public()
  @Get(':id')
  async templateData(@Param() param: PdfParamDto, @Query() query: PdfQueryDto) {
    return await this.documentService.templateData(param, query);
  }
}
