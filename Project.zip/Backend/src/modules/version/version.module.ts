import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VersionController } from './version.controller';
import { VersionService } from './version.service';
import { VersionHistory } from './entities/version.entity';

@Module({
  imports: [TypeOrmModule.forFeature([VersionHistory])],
  controllers: [VersionController],
  providers: [VersionService],
  exports: [VersionService],
})
export class VersionModule {}
