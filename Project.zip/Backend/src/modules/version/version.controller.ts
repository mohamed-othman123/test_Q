import { Controller, Get, Post, Body, Patch, Param, Delete, Query } from '@nestjs/common';
import { VersionService } from './version.service';
import { CreateVersionDto } from './dto/create-version.dto';
import { UpdateVersionDto } from './dto/update-version.dto';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { FilterVersionsDto } from './dto/filter-vesrions.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';

@ApiBearerAuth()
@ApiTags('version')
@Controller('version')
export class VersionController {
  constructor(private readonly versionService: VersionService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new version' })
  @ApiResponse({ status: 201, description: 'Version created successfully' })
  create(@Body() createVersionDto: CreateVersionDto, @CurrentUser() user: AuthenticatedUser) {
    return this.versionService.create(createVersionDto, user);
  }

  @Get()
  @ApiOperation({ summary: 'Get version history with pagination' })
  @ApiResponse({ status: 200, description: 'Returns version history with pagination' })
  findAll(@Query() filter: FilterVersionsDto, @CurrentUser() user: AuthenticatedUser) {
    return this.versionService.findAll(filter);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a version by ID' })
  @ApiResponse({ status: 200, description: 'Returns the version with the specified ID' })
  findOne(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.versionService.findOne(+id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update a version' })
  @ApiResponse({ status: 200, description: 'Version updated successfully' })
  update(
    @Param('id') id: string,
    @Body() updateVersionDto: UpdateVersionDto,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.versionService.update(+id, updateVersionDto, user);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a version' })
  @ApiResponse({ status: 200, description: 'Version deleted successfully' })
  remove(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.versionService.remove(+id, user);
  }
}
