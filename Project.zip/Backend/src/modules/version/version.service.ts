import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateVersionDto } from './dto/create-version.dto';
import { UpdateVersionDto } from './dto/update-version.dto';
import { FilterVersionsDto } from './dto/filter-vesrions.dto';
import { PaginatorService } from '../../common/paginator/paginator.service';
import { VersionHistory } from './entities/version.entity';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';

@Injectable()
export class VersionService {
  constructor(
    @InjectRepository(VersionHistory)
    private versionRepository: Repository<VersionHistory>,
    private readonly paginatorService: PaginatorService,
  ) {}

  async create(
    createVersionDto: CreateVersionDto,
    user: AuthenticatedUser,
  ): Promise<VersionHistory> {
    const existingVersion = await this.versionRepository.findOne({
      where: {
        versionNumber: createVersionDto.versionNumber,
        stack: createVersionDto.stack,
        deleted: false,
      },
    });

    if (existingVersion) {
      throw new BadRequestException(`Version ${createVersionDto.versionNumber} already exists`);
    }

    const version = this.versionRepository.create({ ...createVersionDto, created_by: user.id });
    return this.versionRepository.save(version);
  }

  async findAll(filter: FilterVersionsDto) {
    const { page, limit, versionNumber, feature, stack } = filter;

    const take = limit ?? 10;
    const skip = ((page ?? 1) - 1) * take;

    const queryBuilder = this.versionRepository
      .createQueryBuilder('v')
      .andWhere('v.deleted = false');
    if (versionNumber) queryBuilder.andWhere('v.versionNumber = :versionNumber', { versionNumber });

    if (feature) queryBuilder.andWhere('v.feature ILIKE :feature', { feature: `%${feature}%` });

    if (stack) queryBuilder.andWhere('v.stack = :stack', { stack });

    queryBuilder.orderBy('v.releasedDate', 'DESC').take(take).skip(skip);
    const [result, total] = await queryBuilder.getManyAndCount();

    return this.paginatorService.paginate(result, total, page || 1, take);
  }

  async findOne(id: number): Promise<VersionHistory> {
    const version = await this.versionRepository.findOne({ where: { id } });
    if (!version) {
      throw new NotFoundException(`Version with ID ${id} not found`);
    }
    return version;
  }

  async update(
    id: number,
    updateVersionDto: UpdateVersionDto,
    user: AuthenticatedUser,
  ): Promise<VersionHistory> {
    const version = await this.findOne(id);

    if (
      updateVersionDto.versionNumber &&
      updateVersionDto.versionNumber !== version.versionNumber
    ) {
      const existingVersion = await this.versionRepository.findOne({
        where: { versionNumber: updateVersionDto.versionNumber, stack: updateVersionDto.stack },
      });

      if (existingVersion) {
        throw new BadRequestException(`Version ${updateVersionDto.versionNumber} already exists`);
      }
    }

    Object.assign(version, updateVersionDto);
    version.updated_by = user.id;
    return this.versionRepository.save(version);
  }

  async remove(id: number, user: AuthenticatedUser): Promise<void> {
    await this.findOne(id);
    await this.versionRepository.update(id, {
      deleted: true,
      deleted_at: new Date(),
      deleted_by: user.id,
    });
  }
}
