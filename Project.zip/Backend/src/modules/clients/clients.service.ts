import { BadRequestException, Injectable } from '@nestjs/common';
import { CreateClientDto } from './dto/create-client.dto';
import { UpdateClientDto } from './dto/update-client.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Client } from './entities/client.entity';
import { EntityManager, Repository } from 'typeorm';
import { ErrorKeys } from 'src/common/enums/errorKeys.enums';
import { ClientInfo } from './interfaces/clientInfo.interface';
import { OrganizationDto } from '../../auth/dto/signup.dto';

@Injectable()
export class ClientsService {
  constructor(
    @InjectRepository(Client)
    private clientRepository: Repository<Client>,
  ) {}
  async create(createClientDto: CreateClientDto, manager: EntityManager): Promise<Client> {
    // Create a new Client instance from the DTO
    const client = this.clientRepository.create(createClientDto);

    // Save the client using the EntityManager
    const savedClient = await manager.save(client);

    return savedClient;
  }

  async createV2(clientDto: OrganizationDto, email: string, manager: EntityManager) {
    const { name } = clientDto;
    const record = this.clientRepository.create({
      name,
      email,
    });

    const client = await manager.save(record);

    return client;
  }

  async getClient(user: { clientId: number; id: number }): Promise<ClientInfo> {
    const { clientId } = user;
    const client = await this.clientRepository.findOne({ where: { id: clientId, deleted: false } });
    if (!client) {
      throw new BadRequestException(ErrorKeys.clientNotFound);
    }
    return {
      id: client.id,
      name: client.name,
      phone: client.phone,
      taxRegistrationNumber: client.taxRegistrationNumber,
      commercialRegistrationNumber: client.commercialRegistrationNumber,
      address: client.address,
    };
  }

  async updateClient(
    user: { clientId: number; id: number },
    updateClientDto: UpdateClientDto,
  ): Promise<ClientInfo> {
    const { clientId, id: userId } = user;
    const client = await this.getClient(user);
    const { name, phone, address, taxRegistrationNumber, commercialRegistrationNumber } =
      updateClientDto;
    await this.clientRepository.update(clientId, {
      name: name ?? undefined,
      phone: phone ?? undefined,
      address: address ?? undefined,
      taxRegistrationNumber: taxRegistrationNumber ?? undefined,
      commercialRegistrationNumber: commercialRegistrationNumber ?? undefined,
      updated_by: userId,
    });
    return this.getClient(user);
  }
}
