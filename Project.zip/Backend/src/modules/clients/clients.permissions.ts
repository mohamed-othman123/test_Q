import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const clientsPermissions = {
  // CREATE_CLIENT: {
  //   ar_name: 'إنشاء:العملاء',
  //   en_name: 'create:clients',
  //   ar_module: 'العملاء',
  //   en_module: 'clients',
  //   route: "POST '/clients'",
  // },
  // READ_CLIENTS: {
  //   ar_name: 'قراءة:العملاء',
  //   en_name: 'read:clients',
  //   ar_module: 'العملاء',
  //   en_module: 'clients',
  //   route: "GET '/clients'",
  // },
  // READ_CLIENT: {
  //   ar_name: 'قراءة:العميل',
  //   en_name: 'read:client',
  //   ar_module: 'العملاء',
  //   en_module: 'clients',
  //   route: "GET '/clients/:id'",
  // },
  READ_ORGANIZATION: {
    ar_name: 'قراءة:المنشأة',
    en_name: 'read:organization',
    ar_module: 'المنشأة',
    en_module: 'Organization',
    order: 17,
    key: 'Organizations',
    type: PermissionsTypeEnum.READ,
    route: "GET '/clients/organization'",
  },
  // UPDATE_CLIENT: {
  //   ar_name: 'تحديث:العملاء',
  //   en_name: 'update:clients',
  //   ar_module: 'العملاء',
  //   en_module: 'clients',
  //   route: "PUT '/clients/:CLIENTId'",
  // },
  UPDATE_ORGANIZATION: {
    ar_name: 'تحديث:المنشأة',
    en_name: 'update:organization',
    ar_module: 'المنشأت',
    en_module: 'Organizations',
    order: 17,
    key: 'Organizations',
    type: PermissionsTypeEnum.UPDATE,
    route: "PUT '/clients/organization'",
  },
  // DELETE_CLIENT: {
  //   ar_name: 'حذف:العملاء',
  //   en_name: 'delete:clients',
  //   ar_module: 'العملاء',
  //   en_module: 'clients',
  //   route: "DELETE '/clients/:CLIENTId'",
  // },
};
