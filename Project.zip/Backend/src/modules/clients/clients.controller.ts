import { Controller, Body, Patch, Param, Get, UseGuards } from '@nestjs/common';
import { ClientsService } from './clients.service';
import { UpdateClientDto } from './dto/update-client.dto';
import { ApiBearerAuth, ApiHeader, ApiTags } from '@nestjs/swagger';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { clientsPermissions } from './clients.permissions';
import { UserTypeGuard } from '../../common/guards/user-types.guard';
import { UserTypes } from '../../common/decorators/user-types.decorator';
import { UserTypesEnum } from '../users/enums/users-type.enum';
@ApiTags('Clients')
@UseGuards(UserTypeGuard)
@Controller('clients')
@ApiBearerAuth()
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class ClientsController {
  constructor(private readonly clientsService: ClientsService) {}
  @Get('/organization')
  @UserTypes(UserTypesEnum.admin,UserTypesEnum.owner)
  @RequirePermissions(clientsPermissions.READ_ORGANIZATION)
  getClient(@CurrentUser() user: { clientId: number; id: number }) {
    return this.clientsService.getClient(user);
  }

  @Patch('/organization')
  @UserTypes(UserTypesEnum.admin,UserTypesEnum.owner)
  @RequirePermissions(clientsPermissions.UPDATE_ORGANIZATION)
  updateClient(@CurrentUser() user: { clientId: number; id: number },@Body() updateClientDto: UpdateClientDto) {
    return this.clientsService.updateClient(user,updateClientDto);
  }
}
