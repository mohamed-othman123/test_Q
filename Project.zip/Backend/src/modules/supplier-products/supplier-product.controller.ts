import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { ApiBearerAuth, ApiHeader, ApiTags } from '@nestjs/swagger';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { UserTypeGuard } from '../../common/guards/user-types.guard';
import { SupplierProductService } from './supplier-products.service';
import { suppliersPermissions } from '../suppliers/suppliers.permissions';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { FilterSupplierItemsDto } from './dtos/filter-supplier-item.dto';
import { SupplierItemResponseDto } from './dtos/supplier-item.response.dto';
import { CreateProductDto } from './dtos/create-supplier-product.dto';
import { UpdateProductDto } from './dtos/update-product.dto';
import { purchasesPermissions } from '../expenses/expenses.permissions';

@ApiTags('suppliers')
@UseGuards(UserTypeGuard)
@ApiBearerAuth()
@Controller('suppliers')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class SupplierProductController {
  constructor(private readonly supplierProductService: SupplierProductService) {}

  @RequirePermissions(suppliersPermissions.CREATE_SUPPLIERS)
  @Post(':supplierId/products')
  async addProduct(
    @Param('supplierId') supplierId: string,
    @Body() createProductDto: CreateProductDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<SupplierItemResponseDto> {
    return this.supplierProductService.addProduct(+supplierId, createProductDto, user);
  }
  @RequirePermissions(suppliersPermissions.READ_SUPPLIERS,purchasesPermissions.CREATE_PURCHASE,purchasesPermissions.UPDATE_PURCHASE)
  @Get(':supplierId/items')
  async listSupplierItems(
    @Param('supplierId') supplierId: string,
    @Query() filter: FilterSupplierItemsDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<{
    items: SupplierItemResponseDto[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return this.supplierProductService.listSupplierItems(+supplierId, filter, user);
  }

  @RequirePermissions(suppliersPermissions.READ_SUPPLIERS)
  @Get(':supplierId/products/:productId')
  async getProduct(
    @Param('supplierId') supplierId: string,
    @Param('productId') productId: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<SupplierItemResponseDto> {
    return this.supplierProductService.getProduct(+supplierId, +productId, user);
  }

  @RequirePermissions(suppliersPermissions.UPDATE_SUPPLIERS)
  @Patch(':supplierId/products/:productId')
  async updateProduct(
    @Param('supplierId') supplierId: string,
    @Param('productId') productId: string,
    @Body() updateProductDto: UpdateProductDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<SupplierItemResponseDto> {
    return this.supplierProductService.updateProduct(
      +supplierId,
      +productId,
      updateProductDto,
      user,
    );
  }
  @RequirePermissions(suppliersPermissions.DELETE_SUPPLIERS)
  @Delete(':supplierId/products/:productId')
  async deleteProduct(
    @Param('supplierId') supplierId: string,
    @Param('productId') productId: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<SupplierItemResponseDto> {
    return this.supplierProductService.deleteProduct(+supplierId, +productId, user);
  }
}
