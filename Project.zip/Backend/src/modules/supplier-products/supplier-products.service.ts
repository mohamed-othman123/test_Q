import { BadRequestException, Injectable, forwardRef, Inject } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Not, Repository } from 'typeorm';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { SupplierProductEntity } from './entities/supplier-products.entity';
import { UpdateSupplierProductDto } from './dtos/update-supplier-product';
import { CreateProductDto } from './dtos/create-supplier-product.dto';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { FilterSupplierItemsDto } from './dtos/filter-supplier-item.dto';
import { SuppliersService } from '../suppliers/suppliers.service';
import { PaginatorService } from '../../common/paginator/paginator.service';
import { HallServiceEntity } from '../services/entities/halls_services.entity';
import { SupplierItemTypeEnum } from '../expenses/enums/supplier-item-types.enum';
import { SupplierItemResponseDto } from './dtos/supplier-item.response.dto'
import { checkUserPermissionType, HandelTwoName } from '../../core/helpers/cast.helper';
import { UpdateProductDto } from './dtos/update-product.dto';

@Injectable()
export class SupplierProductService {
  constructor(
    @InjectRepository(SupplierProductEntity)
    private supplierProductRepository: Repository<SupplierProductEntity>,
    @InjectRepository(HallServiceEntity)
    private HallServicetRepository: Repository<HallServiceEntity>,
    @Inject(forwardRef(() => SuppliersService))
    private readonly supplierService: SuppliersService,
    private readonly paginatorService: PaginatorService,
  ) { }

  async addProduct(
    supplierId: number,
    createProductDto: CreateProductDto,
    user: AuthenticatedUser,
  ): Promise<SupplierItemResponseDto> {
    let { name, name_ar } = createProductDto;
    const { clientId, id: userId } = user
    if (!name && !name_ar) {
      throw new BadRequestException(ErrorKeys.nameIsRequired);
    }
    [name, name_ar] = HandelTwoName(name, name_ar);
    const existSupplier = await this.supplierService.findSupplier(supplierId, user)
    checkUserPermissionType(user, existSupplier.created_by);
    const existProduct = await this.supplierProductRepository.findOne({
      where: [{ name, deleted: false, supplier: { id: supplierId, client: { id: clientId } } }, { name: name_ar, deleted: false, supplier: { id: supplierId, client: { id: clientId } } }, { name_ar, deleted: false, supplier: { id: supplierId, client: { id: clientId } } }, { name_ar: name, deleted: false, supplier: { id: supplierId, client: { id: clientId } } }],
    });
    if (existProduct) {
      throw new BadRequestException(ErrorKeys.productExisting);
    }
    const savedProduct = await this.supplierProductRepository.save({
      ...createProductDto,
      name,
      name_ar,
      supplier: { id: supplierId },
      created_by: userId,
    });
    return {
      id: savedProduct.id,
      created_at: savedProduct.created_at,
      updated_at: savedProduct.updated_at,
      name: savedProduct.name,
      name_ar: savedProduct.name_ar,
      note: savedProduct.note,
      price: savedProduct.price,
    };
  }

  async listSupplierItems(
    supplierId: number,
    filter: FilterSupplierItemsDto,
    user: AuthenticatedUser,
  ): Promise<{
    items: SupplierItemResponseDto[],
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    const { itemType } = filter
    if (itemType === SupplierItemTypeEnum.product) {
      return this.listSuplierProducts(supplierId, filter, user)
    }
    return this.listSuplierServices(supplierId, filter, user)
  }

  private async listSuplierProducts(supplierId: number,
    filter: FilterSupplierItemsDto,
    user: AuthenticatedUser): Promise<{
      items: SupplierItemResponseDto[],
      totalItems: number;
      currentPage: number;
      totalPages: number;
    }> {
    const { page, limit } = filter
    const { clientId } = user
    await this.supplierService.findSupplier(supplierId, user)
    const queryBuilder = this.supplierProductRepository
      .createQueryBuilder('sp')
      .leftJoinAndSelect('sp.supplier', 's')
      .where('s.id = :supplierId', { supplierId })
      .andWhere('s.client_id = :clientId', { clientId })
      .andWhere('sp.deleted = :deleted', { deleted: false });
    if (page && limit) {
      const take = limit || 10;
      const skip = ((page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }
    const [result, total] = await queryBuilder.getManyAndCount();
    const formattedItems = result.map((product) => ({
      id: product.id,
      created_at: product.created_at,
      updated_at: product.updated_at,
      name: product.name,
      name_ar: product.name_ar,
      price: product.price,
      note: product.note,
    }));
    return this.paginatorService.paginate(formattedItems, total, page || 1, limit || total);
  }

  private async listSuplierServices(supplierId: number,
    filter: FilterSupplierItemsDto,
    user: AuthenticatedUser): Promise<{
      items: SupplierItemResponseDto[],
      totalItems: number;
      currentPage: number;
      totalPages: number;
    }> {
    const { page, limit, hallId } = filter
    const { clientId } = user
    await this.supplierService.findSupplier(supplierId, user)
    await this.supplierService.validateSuppliersInHalls([{ supplierId, hallId }],user);
    const queryBuilder = this.HallServicetRepository
      .createQueryBuilder('hs')
      .leftJoinAndSelect('hs.hall', 'hall')
      .leftJoinAndSelect('hs.service', 'service')
      .leftJoinAndSelect('hs.supplier', 'supplier')
      .where('supplier.id = :supplierId', { supplierId })
      .andWhere('hall.id = :hallId', { hallId })
      .andWhere('service.client_id = :clientId', { clientId })
      .andWhere('service.deleted = :deleted', { deleted: false });
    if (page && limit) {
      const take = limit || 10;
      const skip = ((page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }
    const [result, total] = await queryBuilder.getManyAndCount();
    const formattedItems = result.map((hs) => ({
      id: hs.service.id,
      created_at: hs.service.created_at,
      updated_at: hs.service.updated_at,
      name: hs.service.name,
      name_ar: hs.service.name_ar,
      price: hs.price,
      cost:hs.cost,
      note: hs.service.note,
    }));
    return this.paginatorService.paginate(formattedItems, total, page || 1, limit || total);
  }

  async getProduct(
    supplierId: number,
    productId: number,
    user: AuthenticatedUser,
  ): Promise<SupplierItemResponseDto> {
    const { clientId } = user;
    await this.supplierService.findSupplier(supplierId, user)
    const existProduct = await this.supplierProductRepository.findOne({
      where: { id: productId, deleted: false, supplier: { id: supplierId, client: { id: clientId } } },
      select: {
        id: true,
        created_at: true,
        updated_at: true,
        name: true,
        name_ar: true,
        note: true,
        price: true,
      },
    });
    if (!existProduct) {
      throw new BadRequestException(ErrorKeys.productNotFound);
    }

    return existProduct;
  }

  async updateProduct(
    supplierId: number,
    productId: number,
    updateProductDto: UpdateProductDto,
    user: AuthenticatedUser,
  ): Promise<SupplierItemResponseDto> {
    const { name, price, name_ar, note } = updateProductDto;
    const { clientId, id: userId } = user
    const existSupplier = await this.supplierService.findSupplier(supplierId, user)
    checkUserPermissionType(user, existSupplier.created_by);
    await this.getProduct(supplierId, productId, user)
    if (name && name_ar) {
      await this.findProductByName(productId, name, name_ar, clientId, supplierId);
    } else if (name) {
      await this.findProductByName(productId, name, null, clientId, supplierId);
    } else if (name_ar) {
      await this.findProductByName(productId, null, name_ar, clientId, supplierId);
    }

    await this.supplierProductRepository.update(productId, {
      name: name ?? undefined,
      name_ar: name_ar ?? undefined,
      price: price ?? undefined,
      note,
      updated_by: userId
    });
    return this.getProduct(supplierId, productId, user);
  }
  async deleteProduct(
    supplierId: number,
    productId: number,
    user: AuthenticatedUser,
  ): Promise<SupplierItemResponseDto> {
    const existSupplier = await this.supplierService.findSupplier(supplierId, user)
    checkUserPermissionType(user, existSupplier.created_by);
    const existProduct = await this.getProduct(supplierId, productId, user);
    const { id: userId } = user;
    await this.supplierProductRepository.update(productId, {
      deleted: true,
      deleted_by: userId,
      deleted_at: new Date(),
    });
    return { ...existProduct, deleted: true, deleted_at: new Date() };
  }

  private async findProductByName(
    id: number,
    name: string,
    name_ar: string,
    clientId: number,
    supplierId: number,
  ): Promise<void> {
    let existProduct = undefined;

    if (name && name_ar) {
      existProduct = await this.supplierProductRepository.findOne({
        where: [
          {
            name,
            deleted: false,
            supplier: { id: supplierId, client: { id: clientId } },
            id: Not(id),
          },
          {
            name: name_ar,
            deleted: false,
            supplier: { id: supplierId, client: { id: clientId } },
            id: Not(id),
          },
          {
            name_ar,
            deleted: false,
            supplier: { id: supplierId, client: { id: clientId } },
            id: Not(id),
          },
          {
            name_ar: name,
            deleted: false,
            supplier: { id: supplierId, client: { id: clientId } },
            id: Not(id),
          },
        ],
      });
    } else if (name) {
      existProduct = await this.supplierProductRepository.findOne({
        where: [
          {
            name,
            deleted: false,
            supplier: { id: supplierId, client: { id: clientId } },
            id: Not(id),
          },
          {
            name_ar: name,
            deleted: false,
            supplier: { id: supplierId, client: { id: clientId } },
            id: Not(id),
          },
        ],
      });
    } else {
      existProduct = await this.supplierProductRepository.findOne({
        where: [
          {
            name: name_ar,
            deleted: false,
            supplier: { id: supplierId, client: { id: clientId } },
            id: Not(id),
          },
          {
            name_ar,
            deleted: false,
            supplier: { id: supplierId, client: { id: clientId } },
            id: Not(id),
          },
        ],
      });
    }
    if (existProduct) {
      throw new BadRequestException(ErrorKeys.productExisting);
    }
  }



  // Validate that product IDs are unique
  validateProducts(products: UpdateSupplierProductDto[]): void {
    const productIds = products
      .map((product) => product.id) // Map to get the ids
      .filter(Boolean); // Filter out undefined or null values

    if (new Set(productIds).size !== productIds.length) {
      throw new BadRequestException(ErrorKeys.productsMustBeUnique);
    }
  }

  validateProductsName(products: CreateProductDto[]): void {
    // Set default values for missing names
    products.forEach((product) => {
      if (!product.name && !product.name_ar) {
        throw new BadRequestException(ErrorKeys.productNameIsRequired)
      }
      const [name, name_ar] = HandelTwoName(product.name, product.name_ar)
      product.name = name
      product.name_ar = name_ar
    });
    const names = new Set();
    const namesAr = new Set();

    for (const product of products) {
      const { name, name_ar } = product;
      if (names.has(name) || namesAr.has(name_ar) || names.has(name_ar) || namesAr.has(name)) {
        throw new BadRequestException(ErrorKeys.productsMustBeUnique);
      }
      // Add names to sets
      names.add(name);
      namesAr.add(name_ar);
    }
  }


  // Validate that the supplied products exist for a given supplier
  async validateExistingProducts(supplierId: number, products: UpdateSupplierProductDto[]): Promise<void> {
    const productIds = products.map((product) => product.id).filter(Boolean); // Filter out undefined or null values

    const existingProducts = await this.getProductsInRange(productIds, supplierId);
    const existingProductIds = existingProducts.map((product) => product.id);

    // Check for products that do not exist
    const notExistsProducts = productIds.filter((id) => !existingProductIds.includes(id));

    if (notExistsProducts.length > 0) {
      throw new BadRequestException(ErrorKeys.productNotFound);
    }
  }

  // Retrieve products based on their IDs and supplier ID
  async getProductsInRange(
    productIds: number[],
    supplierId: number,
  ): Promise<SupplierProductEntity[]> {
    return await this.supplierProductRepository.find({
      where: {
        id: In(productIds),
        deleted: false, // Assuming you have a soft delete field
        supplier: { id: supplierId }, // Assuming a relation with the supplier
      },
      select: ['id', 'name', 'price'], // Select only necessary fields
    });
  }
}
