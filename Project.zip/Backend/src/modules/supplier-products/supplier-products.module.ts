import { Module,forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SupplierProductEntity } from './entities/supplier-products.entity';
import { SupplierProductService } from './supplier-products.service';
import { SupplierProductController } from './supplier-product.controller';
import { SuppliersModule } from '../suppliers/suppliers.module';
import { HallServiceEntity } from '../services/entities/halls_services.entity';

@Module({
  imports: [TypeOrmModule.forFeature([SupplierProductEntity,HallServiceEntity]),forwardRef(() =>SuppliersModule)],
  controllers:[SupplierProductController],
  providers: [SupplierProductService],
  exports: [SupplierProductService],
})
export class SupplierProductModule {}
