import { TypeOrmModule } from '@nestjs/typeorm';
import { CommentEntity } from './entities/comment.entity';
import { Module } from '@nestjs/common';
import { CommentsController } from './comments.controller';
import { CommentsService } from './services/comments.service';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
import { UsersModule } from '../users/users.module';

@Module({
  imports: [TypeOrmModule.forFeature([CommentEntity]), UsersModule],
  controllers: [CommentsController],
  providers: [CommentsService, HallIdExtractor],
  exports: [CommentsService],
})
export class CommentsModule {}
