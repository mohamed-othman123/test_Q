import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  UseInterceptors,
  HttpStatus,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiBody,
} from '@nestjs/swagger';
import { CommentsService } from './services/comments.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { EmployeeHallsInterceptor } from '../../auth/interceptors/halls-employee.interceptor';
import { CreateCommentDto } from './dtos/create-comment.dto';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { UpdateCommentDto } from './dtos/update-comment.dto';
import { GetCommentsDto } from './dtos/get-comments.dto';
import { Comment } from './types/comment.type';
import { UserTypes } from 'src/common/decorators/user-types.decorator';
import { UserTypesEnum } from '../users/enums/users-type.enum';

@ApiBearerAuth()
@ApiTags('comments')
@Controller('comments')
export class CommentsController {
  constructor(private readonly commentsService: CommentsService) {}

  @ApiOperation({
    summary: 'Create a new comment',
    description: 'Creates a new comment for the specified entity',
  })
  @ApiBody({ type: CreateCommentDto })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Comment created successfully',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid input data',
  })
  @ApiResponse({
    status: HttpStatus.UNAUTHORIZED,
    description: 'User is not authenticated',
  })
  @UseInterceptors(EmployeeHallsInterceptor)
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner, UserTypesEnum.employee)
  @Post()
  async create(
    @Body() createDto: CreateCommentDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<Comment> {
    return await this.commentsService.createComment(createDto, user);
  }

  @ApiOperation({
    summary: 'Get all comments',
    description: 'Retrieves all comments for a specific entity with pagination',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Comments retrieved successfully',
    schema: {
      properties: {
        items: {
          type: 'array',
          items: { $ref: '#/components/schemas/Comment' },
        },
        totalItems: { type: 'number' },
        currentPage: { type: 'number' },
        totalPages: { type: 'number' },
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid query parameters',
  })
  @UseInterceptors(EmployeeHallsInterceptor)
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner, UserTypesEnum.employee)
  @Get()
  async getAll(
    @Query() params: GetCommentsDto,
  ): Promise<{ items: Comment[]; totalItems: number; currentPage: number; totalPages: number }> {
    return await this.commentsService.getComments(params);
  }

  @ApiOperation({
    summary: 'Update a comment',
    description: 'Updates an existing comment by ID. Only the owner of the comment can update it.',
  })
  @ApiParam({
    name: 'id',
    type: 'number',
    description: 'ID of the comment to update',
    example: 1,
  })
  @ApiBody({ type: UpdateCommentDto })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Comment updated successfully',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid input data',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Comment not found',
  })
  @ApiResponse({
    status: HttpStatus.FORBIDDEN,
    description: 'User is not the owner of the comment',
  })
  @UseInterceptors(EmployeeHallsInterceptor)
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner, UserTypesEnum.employee)
  @Put(':id')
  async updateOne(
    @Param('id') id: number,
    @Body() updateDto: UpdateCommentDto,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<Comment> {
    return await this.commentsService.updateComment(id, updateDto, user);
  }

  @ApiOperation({
    summary: 'Delete a comment',
    description: 'Deletes an existing comment by ID. Only the owner of the comment can delete it.',
  })
  @ApiParam({
    name: 'id',
    type: 'number',
    description: 'ID of the comment to delete',
    example: 1,
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Comment deleted successfully',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Comment not found',
  })
  @ApiResponse({
    status: HttpStatus.FORBIDDEN,
    description: 'User is not the owner of the comment',
  })
  @UseInterceptors(EmployeeHallsInterceptor)
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner, UserTypesEnum.employee)
  @Delete(':id')
  async deleteOne(
    @Param('id') id: number,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<void> {
    return await this.commentsService.deleteComment(id, user.id);
  }
}
