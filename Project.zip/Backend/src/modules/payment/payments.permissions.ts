import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const paymentsPermissions = {
  CREATE_PAYMENT: {
    ar_name: 'إنشاء:المدفوعات',
    en_name: 'create:payments',
    ar_module: 'المدفوعات',
    en_module: 'Payments',
    order: 4,
    key: 'Payments',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/payment'",
  },
  READ_PAYMENTS: {
    ar_name: 'قراءة:المدفوعات',
    en_name: 'read:payments',
    ar_module: 'المدفوعات',
    en_module: 'Payments',
    order: 4,
    key: 'Payments',
    type: PermissionsTypeEnum.READ,
    route: "GET '/payment'",
  },
  // UPDATE_PAYMENT: {
  //   ar_name: 'تحديث:المدفوعات',
  //   en_name: 'update:payments',
  //   ar_module: 'المدفوعات',
  //   en_module: 'Payments',
  //   order: 4,
  //   key: 'Payments',
  //   type: PermissionsTypeEnum.UPDATE,
  //   route: "PATCH '/payment/:id'",
  // },
  // DELETE_PAYMENT: {
  //   ar_name: 'حذف:المدفوعات',
  //   en_name: 'delete:payments',
  //   ar_module: 'المدفوعات',
  //   en_module: 'Payments',
  //   order: 4,
  //   key: 'Payments',
  //   type: PermissionsTypeEnum.DELETE,
  //   route: "DELETE '/payment/:id'",
  // },
};
