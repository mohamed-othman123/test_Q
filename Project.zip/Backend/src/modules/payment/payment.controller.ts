import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { CreatePaymentDto } from './dtos/create-payment.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { ApiBearerAuth, ApiQuery, ApiTags } from '@nestjs/swagger';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { paymentsPermissions } from './payments.permissions';
import { FilterPaymentsDto } from './dtos/filter-payments.dto';
import { PaymentEntity } from './entities/payment.entity';
import { PaymentService } from './services/payment.service';
import { EmployeeHallsInterceptor } from '../../auth/interceptors/halls-employee.interceptor';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { bookingsPermissions } from '../booking/permissions/booking.permissions';
@ApiBearerAuth()
@ApiTags('payment')
@Controller('payment')
export class PaymentController {
  constructor(private readonly paymentService: PaymentService) {}

  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(paymentsPermissions.CREATE_PAYMENT)
  @Post()
  async addPayment(
    @Body() createPaymentDto: CreatePaymentDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<PaymentEntity> {
    return await this.paymentService.addPayment(createPaymentDto, user);
  }

  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(paymentsPermissions.READ_PAYMENTS,bookingsPermissions.READ_BOOKINGS)
  @Get()
  async filterPayments(@Query() filter: FilterPaymentsDto, @CurrentUser() user: AuthenticatedUser) {
    return await this.paymentService.filterPayments(filter, user);
  }

  @RequirePermissions(paymentsPermissions.READ_PAYMENTS)
  @Get('/:id')
  async getPayment(
    @Param('id') id: string,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<PaymentEntity> {
    return await this.paymentService.findPaymentById(+id, user);
  }
  // @RequirePermissions(paymentsPermissions.UPDATE_PAYMENT)
  // @Patch('/:id')
  // async updatePayment(
  //   @Body() updatePaymentDto: UpdatePaymentDto,
  //   @Param('id') id: string,
  //   @CurrentUser()
  //   user: AuthenticatedUser,
  // ): Promise<PaymentEntity> {
  //   return await this.paymentService.updatePayment(+id, updatePaymentDto, user);
  // }

  // @RequirePermissions(paymentsPermissions.DELETE_PAYMENT)
  // @Delete('/:id')
  // async removePayment(
  //   @Param('id') id: string,
  //   @CurrentUser()
  //   user: AuthenticatedUser,
  // ): Promise<PaymentEntity> {
  //   return await this.paymentService.removePayment(+id, user);
  // }
}
