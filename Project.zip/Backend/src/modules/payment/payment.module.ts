import { forwardRef, Module, OnModuleInit } from '@nestjs/common';
import { PaymentController } from './payment.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PaymentEntity } from './entities/payment.entity';
import { BookingModule } from '../booking/booking.module';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { Bank } from '../bank/entities/bank.entity';
import { PaymentService } from './services/payment.service';
import { PdfGenerationModule } from '../pdf-generation/pdf-generation.module';
import { FileUploadModule } from '../../common/utilities/file-upload/file-upload.module';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
import { ClientPaymentMethodEntity } from '../refund-requests/entities/client-payment-method.entity';
import { RefundRequestEntity } from '../refund-requests/entities/refund-request.entity';
import { PaymentMethodModule } from '../payment-method/payment-method.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([PaymentEntity, Bank, ClientPaymentMethodEntity, RefundRequestEntity]),
    forwardRef(() => BookingModule),
    PaginatorModule,
    forwardRef(() => PdfGenerationModule),
    FileUploadModule,
    PaymentMethodModule,
  ],
  controllers: [PaymentController],
  providers: [PaymentService, HallIdExtractor],
  exports: [PaymentService],
})
export class PaymentModule implements OnModuleInit {
  constructor(private readonly paymentService: PaymentService) {}

  async onModuleInit() {}
}
