import { Controller, Get } from '@nestjs/common';
import { Public } from '../../auth/decorator/public.decorator';
import { HealthService } from './health-check.service';
import { CustomHealthCheckResult } from './interfaces/CustomHealthCheckResult.interface';

@Controller('health')
export class HealthController {
  constructor(
    private healthService: HealthService,
  ) {}
  @Get()
  @Public()
  async check(): Promise<CustomHealthCheckResult> {
    return await this.healthService.healthCheck();
  }
}
