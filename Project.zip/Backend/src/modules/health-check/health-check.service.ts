import { Injectable, Logger, Inject } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  HttpHealthIndicator,
  MemoryHealthIndicator,
  DiskHealthIndicator,
  TypeOrmHealthIndicator,
} from '@nestjs/terminus';
import * as nodemailer from 'nodemailer';
import Redis from 'ioredis';
import { HealthCheckItem } from './dto/health-check-item.response.dto';
import { CustomHealthCheckResult } from './interfaces/CustomHealthCheckResult.interface';
import * as v8 from 'v8';
@Injectable()
export class HealthService {
  private readonly logger = new Logger(HealthService.name);

  constructor(
    @Inject('REDIS_CLIENT') private readonly redisClient: Redis,
    private readonly configService: ConfigService,
    private http: HttpHealthIndicator,
    private typeOrmHealth: TypeOrmHealthIndicator,
    private memoryHealth: MemoryHealthIndicator,
    private diskHealth: DiskHealthIndicator,
  ) {}

  async checkDatabase(): Promise<HealthCheckItem> {
    try {
      const response = await this.typeOrmHealth.pingCheck('database');

      // Check the status of the response
      if (response.database.status === 'up') {
        return {
          name: 'database',
          status: 'ok',
          info: { status: 'up' },
          error: {},
        };
      } else {
        this.logger.log('Database response:', response);
        return {
          name: 'database',
          status: 'error',
          info: {},
          error: { status: 'down', message: 'Database is not working fine.' },
        };
      }
    } catch (error) {
      // Handle specific error scenarios
      this.logger.error(`Database health check failed: ${error.message}`);
      return {
        name: 'database',
        status: 'error',
        info: {},
        error: { status: 'down', message: error.message || 'Database is not working fine.' },
      };
    }
  }
  async checkRedis(): Promise<HealthCheckItem> {
    try {
      const response = await this.redisClient.ping();
      // Check the status of the response
      if (response === 'PONG') {
        return {
          name: 'redis',
          status: 'ok',
          info: { status: 'up' },
          error: {},
        };
      } else {
        this.logger.log('Redis response:', response);
        return {
          name: 'redis',
          status: 'error',
          info: {},
          error: { status: 'down', message: 'Redis service is unavailable.' },
        };
      }
    } catch (error) {
      this.logger.error(`redis health check failed: ${error.message}`);
      return {
        name: 'redis',
        status: 'error',
        info: {},
        error: { status: 'down', message: error.message || 'Redis service is unavailable.' },
      };
    }
  }
  async checkMemoryHeap(threshold: number = 0.8): Promise<HealthCheckItem> {
    try {
      const heapUsed = process.memoryUsage().heapUsed;
      const { heap_size_limit } = v8.getHeapStatistics(); // Total heap limit in bytes

      const memoryThreshold = threshold * heap_size_limit;
      const isHealthy = heapUsed < memoryThreshold;

      const status = isHealthy ? 'ok' : 'error';

      if (!isHealthy) {
        this.logger.warn(
          `Heap memory exceeded: ${(heapUsed / 1024 / 1024).toFixed(2)} MB / ${(heap_size_limit / 1024 / 1024).toFixed(2)} MB`,
        );
      }
      return {
        name: 'memory_heap',
        status,
        info: isHealthy ? { status: 'up' } : {},
        error: !isHealthy
          ? {
              status: 'down',
              message: `Used heap exceeded ${threshold * 100}% of the heap size limit.`,
            }
          : {},
      };
    } catch (error) {
      this.logger.error('Error checking memory heap', error);
      return {
        name: 'memory_heap',
        status: 'error',
        info: {},
        error: {
          status: 'down',
          message: 'An error occurred while checking memory heap.',
        },
      };
    }
  }
  async checkDisc(): Promise<HealthCheckItem> {
    try {
      const response = await this.diskHealth.checkStorage('storage', {
        path: '/',
        thresholdPercent: 80,
      });

      // Check the status of the response
      if (response.storage.status === 'up') {
        return {
          name: 'storage',
          status: 'ok',
          info: { status: 'up' },
          error: {},
        };
      } else {
        this.logger.log('Storage response:', response);
        return {
          name: 'storage',
          status: 'error',
          info: {},
          error: { status: 'down', message: 'Storage is greater than 80%' },
        };
      }
    } catch (error) {
      // Handle specific error scenarios
      this.logger.error(`Storage health check failed: ${error.message}`);
      return {
        name: 'storage',
        status: 'error',
        info: {},
        error: { status: 'down', message: error.message || 'Storage is greater than 80%' },
      };
    }
  }

  async checkSMS(): Promise<HealthCheckItem> {
    const smsEndpoint = this.configService.get<string>('MSEGAT_BASE_URL');
    try {
      const response = await this.http.pingCheck('sms', smsEndpoint);
      // Check the status of the response
      if (response.sms.status === 'up') {
        return {
          name: 'sms',
          status: 'ok',
          info: { status: 'up' },
          error: {},
        };
      } else {
        this.logger.log('sms response:', response);
        return {
          name: 'sms',
          status: 'error',
          info: {},
          error: { status: 'down', message: 'SMS service is unavailable.' },
        };
      }
    } catch (error) {
      // Handle specific error scenarios
      this.logger.error(`sms health check failed: ${error.message}`);
      return {
        name: 'sms',
        status: 'error',
        info: {},
        error: { status: 'down', message: error.message || 'SMS service is unavailable.' },
      };
    }
  }

  async checkSMTP(): Promise<HealthCheckItem> {
    const smtpConfig = {
      host: this.configService.get<string>('MAIL_HOST'),
      port: this.configService.get<number>('MAIL_PORT'),
      secure: this.configService.get('MAIL_SECURE') === 'false' ? false : true,
      auth: {
        user: this.configService.get<string>('MAIL_USER'),
        pass: this.configService.get<string>('MAIL_PASS'),
      },
    };
    const transporter = nodemailer.createTransport(smtpConfig);

    try {
      await transporter.verify();
      return {
        name: 'smpt',
        status: 'ok',
        info: { status: 'up' },
        error: {},
      };
    } catch (error) {
      // Handle specific error scenarios
      this.logger.error(`smpt health check failed: ${error.message}`);
      return {
        name: 'smpt',
        status: 'error',
        info: {},
        error: { status: 'down', message: error.message || 'SMTP service is unavailable.' },
      };
    }
  }
  async checkGotenberg(): Promise<HealthCheckItem> {
    const gotenbergEndpoint = this.configService.get<string>('GOTENBERG_ENDPOINT');
    const username = this.configService.get<string>('GOTENBERG_USERNAME');
    const password = this.configService.get<string>('GOTENBERG_PASSWORD');

    if (!gotenbergEndpoint || !username || !password) {
      this.logger.warn('Gotenberg endpoint or credentials are not configured.');
    }

    try {
      const options: { auth?: { username: string; password: string } } = {};

      // Add auth if username is provided
      if (username && password) {
        options.auth = { username, password };
      }

      const response = await this.http.pingCheck('gotenberg', gotenbergEndpoint, options);

      if (response.gotenberg.status === 'up') {
        return {
          name: 'gotenberg',
          status: 'ok',
          info: { status: 'up' },
          error: {},
        };
      } else {
        this.logger.log('Gotenberg response:', response);
        return {
          name: 'gotenberg',
          status: 'error',
          info: {},
          error: { status: 'down', message: 'Gotenberg service is unavailable.' },
        };
      }
    } catch (error) {
      this.logger.error(`Gotenberg health check failed: ${error.message}`);
      return {
        name: 'gotenberg',
        status: 'error',
        info: {},
        error: { status: 'down', message: error.message || 'Gotenberg service is unavailable.' },
      };
    }
  }
  async healthCheck(): Promise<CustomHealthCheckResult> {
    const results = await Promise.all([
      this.checkDatabase(),
      this.checkRedis(),
      this.checkMemoryHeap(),
      this.checkDisc(),
      this.checkSMS(),
      this.checkSMTP(),
      this.checkGotenberg(),
    ]);

    // Initialize objects for the response
    const aggregatedResults: Record<string, any> = {};
    const errorResults: Record<string, any> = {};

    results.forEach((res) => {
      // Aggregate results for healthy services

      // Separate healthy and error results
      if (res.status === 'ok') {
        aggregatedResults[res.name] = res.info;
      } else {
        errorResults[res.name] = res.error;
      }
    });

    // Determine overall health status
    const isHealthy = results.every((result) => result.status === 'ok');

    return {
      status: isHealthy ? 'ok' : 'error',
      info: aggregatedResults,
      error: errorResults,
    };
  }
}
