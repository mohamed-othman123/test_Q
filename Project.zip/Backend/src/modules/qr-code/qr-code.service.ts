import { Injectable } from '@nestjs/common';
import { Buffer } from 'buffer';
import QR from 'qr-code-styling';
import { JSDOM } from 'jsdom';
import nodeCanvas from 'canvas';

@Injectable()
export class QrCodeService {
  generateTLVForValue(tagNum: string, tagValue: string): Buffer {
    const tagBytes = Buffer.from([Number.parseInt(tagNum)]);
    const valueBytes = Buffer.from(tagValue, 'utf-8');
    const valueBytesLength = Buffer.from([valueBytes.length]);
    return Buffer.concat([tagBytes, valueBytesLength, valueBytes]);
  }

  formatDateToArabic(date: Date): string {
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Riyadh',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    });

    const [
      { value: month },
      ,
      { value: day },
      ,
      { value: year },
      ,
      { value: hour },
      ,
      { value: minute },
      ,
      { value: second },
    ] = formatter.formatToParts(date);

    return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
  }

  generateQRValue(tenant: any, invoice: any): string {
    const roundedTotalWithVat = Math.round(invoice.totalWithVat);
    const roundedTotalVat = Math.round(invoice.totalVat);

    const readableDate = this.formatDateToArabic(invoice.createdAt);

    const sellerNameBuf = this.generateTLVForValue('1', tenant.name || 'No name');
    const vatRegistrationNumberBuf = this.generateTLVForValue(
      '2',
      tenant.id ? tenant.id.toString().padStart(15, '3') : '3'.repeat(15),
    );
    const timeStampBuf = this.generateTLVForValue('3', readableDate);
    const invoiceAmountBuf = this.generateTLVForValue('4', roundedTotalWithVat.toString());
    const totalVatBuf = this.generateTLVForValue('5', roundedTotalVat.toString());

    const tagsBufsArray = [
      sellerNameBuf,
      vatRegistrationNumberBuf,
      timeStampBuf,
      invoiceAmountBuf,
      totalVatBuf,
    ];

    return Buffer.concat(tagsBufsArray).toString('base64');
  }

  async generateQRCode(tenant: any, invoice: any, color: string): Promise<string> {
    const qrValue = this.generateQRValue(tenant, invoice);

    const qrImage = new QR({
      jsdom: JSDOM,
      nodeCanvas,
      width: 500,
      height: 500,
      data: qrValue,
      dotsOptions: {
        color: color,
        type: 'extra-rounded',
      },
      cornersSquareOptions: {
        color: '#000000',
        type: 'dot',
      },
    });

    // Draw the QR code to the canvas
    const element = await qrImage.getRawData('png');

    // Convert canvas to Data URL
    return 'data:image/png;base64, ' + element.toString('base64');
  }
}
