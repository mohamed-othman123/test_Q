import { InventoryService } from './services/inventory.service';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PaginatorModule } from 'src/common/paginator/paginator.module';
import { HallsModule } from '../halls/halls.module';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
import { InventoryEntity } from './entities/inventory.entity';
import { UpdateInventoryTransaction } from './utils/update-inventory.trnsaction';
import { DeleteInventoryTransaction } from './utils/delete-inventory.transaction';
import { InventoryController } from './contollers/inventory.controller';
@Module({
  imports: [TypeOrmModule.forFeature([InventoryEntity]), PaginatorModule, HallsModule],
  controllers: [InventoryController],
  providers: [
    InventoryService,
    UpdateInventoryTransaction,
    DeleteInventoryTransaction,
    HallIdExtractor,
  ],
  exports: [InventoryService],
})
export class InventoryModule {}
