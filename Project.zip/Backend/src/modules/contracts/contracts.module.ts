import { Module } from '@nestjs/common';
import { ContractsController } from './controllers/contracts.controller';
import { ContractsService } from './services/contracts.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Contract } from './entities/contracts.entity';
import { FileUploadModule } from '../../common/utilities/file-upload/file-upload.module';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { HallsModule } from '../halls/halls.module';
import { EventsModule } from '../events/events.module';
import {ContractAttachmentsEntity} from './entities/contract_attachments.entity'
import {ContractAttachmentsController} from './controllers/contract_attachments.controller'
import {ContractAttachmentsService} from './services/contract_attachments.service'

@Module({
  imports: [
    TypeOrmModule.forFeature([Contract,ContractAttachmentsEntity]),
    FileUploadModule,
    PaginatorModule,
    HallsModule,
    EventsModule
  ],
  controllers: [ContractsController,ContractAttachmentsController],
  providers: [ContractsService,ContractAttachmentsService],
  exports: [ContractsService],
})
export class ContractsModule {}
