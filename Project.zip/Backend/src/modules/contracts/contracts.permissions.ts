import { PermissionsTypeEnum } from "../../common/enums/permissionType.enum";

export const contractsPermissions = {
  // CREATE_CONTRACT: {
  //   ar_name: 'إنشاء:عقد',
  //   en_name: 'create:contract',
  //   ar_module: 'العقود',
  //   en_module: 'Contracts',
  //   type:PermissionsTypeEnum.CREATE,
  //   route: "POST '/contracts'",
  // },
  // READ_CONTRACTS: {
  //   ar_name: 'قراءة:العقود',
  //   en_name: 'read:contracts',
  //   ar_module: 'العقود',
  //   en_module: 'Contracts',
  //   type:PermissionsTypeEnum.READ,
  //   route: "GET '/contracts'",
  // },
  // READ_CONTRACT: {
  //   ar_name: 'قراءة:عقد',
  //   en_name: 'read:contract',
  //   ar_module: 'العقود',
  //   en_module: 'Contracts',
  //   type:PermissionsTypeEnum.READONE,
  //   route: "GET '/contracts/:id'",
  // },
  // UPDATE_CONTRACT: {
  //   ar_name: 'تحديث:عقد',
  //   en_name: 'update:contract',
  //   ar_module: 'العقود',
  //   en_module: 'Contracts',
  //   type:PermissionsTypeEnum.UPDATE,
  //   route: "PATCH '/contracts/:id'",
  // },
  // DELETE_CONTRACT: {
  //   ar_name: 'حذف:عقد',
  //   en_name: 'delete:contract',
  //   ar_module: 'العقود',
  //   en_module: 'Contracts',
  //   type:PermissionsTypeEnum.DELETE,
  //   route: "DELETE '/contracts/:id'",
  // },
};
