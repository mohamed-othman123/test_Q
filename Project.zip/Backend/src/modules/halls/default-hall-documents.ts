import { DocumentType } from './enums/documentType.enum';
export const defaultHallDocuments = [
  {
    documentType: DocumentType.BOOKING_PAYMENT_RECEIPT,
    name: 'Booking Payment Receipt',
    name_ar: 'إيصال دفع حجز',
    order: 1,
  },
  {
    documentType: DocumentType.BOOKING_REFUND_RECEIPT,
    name: 'Booking Refund Receipt',
    name_ar: 'ايصال استرداد حجز',
    order: 2,
  },
  {
    documentType: DocumentType.GENERAL_EXPENSE_PAYMENT_RECEIPT,
    name: 'General Expense Payment Receipt',
    name_ar: 'إيصال دفع المصروفات العامة',
    order: 3,
  },
  {
    documentType: DocumentType.PURCHASE_EXPENSE_PAYMENT_RECEIPT,
    name: 'Purchase Expense Payment Receipt',
    name_ar: 'إيصال دفع مصروفات المشتريات',
    order: 4,
  },
  {
    documentType: DocumentType.EXPENSE_REFUND_RECEIPT,
    name: 'Expense Refund Receipt',
    name_ar: 'ايصال استرداد مصروفات',
    order: 5,
  },
];
