import { Module, OnModuleInit } from '@nestjs/common';
import { HallsService } from './halls.service';
import { HallsController } from './halls.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HallEntity } from './entities/hall.entity';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { DeleteHallTransaction } from './utils/delete-hall.transactions';
import { CreateHallTransaction } from './utils/create-hall.transactions';
import { UpdateHallTransaction } from './utils/update-hall.transactions';
import { FileUploadModule } from '../../common/utilities/file-upload/file-upload.module';
import { HallSectionsModule } from '../hall-sections/hall-sections.module';
import { HallTeamMembersModule } from '../hall-team-members/hall-team-member.module';
import { HallDocumentsEntity } from './entities/hall_documents.entity';
import { UpdateHallSignatureAndStampTransaction } from './utils/update-hall-signatureAndStamp.transactions';

@Module({
  imports: [
    TypeOrmModule.forFeature([HallEntity, HallDocumentsEntity]),
    FileUploadModule,
    PaginatorModule,
    HallSectionsModule,
    HallTeamMembersModule,
  ],
  controllers: [HallsController],
  providers: [
    HallsService,
    DeleteHallTransaction,
    CreateHallTransaction,
    UpdateHallTransaction,
    UpdateHallSignatureAndStampTransaction,
  ],
  exports: [HallsService],
})
export class HallsModule implements OnModuleInit {
  constructor(private readonly hallService: HallsService) {}

  async onModuleInit() {
    // Seed default documents for halls
    await this.hallService.seedDefaultDocumentsForHalls();
  }
}
