import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
  UseInterceptors,
  UseGuards,
} from '@nestjs/common';
import { HallsService } from './halls.service';
import { CreateHallDto } from './dto/create-hall.dto';
import { UpdateHallDto } from './dto/update-hall.dto';
import { CurrentUser } from 'src/common/decorators/current-user.decorator';
import { ApiBearerAuth, ApiHeader, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { FilterHallsDto } from './dto/filter-halls.dto';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { hallsPermissions } from './halls.permissions';
import { HallEntity } from './entities/hall.entity';
import { HallDetails } from './interfaces/hallDetails.interface';
import {
  FileFieldsInterceptor,
  FileInterceptor,
  FilesInterceptor,
  MemoryStorageFile,
  UploadedFile,
  UploadedFiles,
} from '@blazity/nest-file-fastify';
import { UserTypeGuard } from '../../common/guards/user-types.guard';
import { UserTypes } from '../../common/decorators/user-types.decorator';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { UpdateHallSignatureAndStampDto } from './dto/Update-signatureAndStamp.dto';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { BookingPricingType } from '../../common/enums/bookingPricingType.enum';
import { PricingCalculationType } from '../../common/enums/pricingCalculationType.enum';
@ApiTags('halls')
@UseGuards(UserTypeGuard)
@ApiBearerAuth()
@Controller('halls')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class HallsController {
  constructor(private readonly hallsService: HallsService) {}
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.CREATE_HALLS)
  @Post()
  async createHall(
    @Body() createHallDto: CreateHallDto,
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<{
    id: number;
    created_at: Date;
    updated_at: Date;
    name: string;
    name_ar: string;
    description: string;
  }> {
    return this.hallsService.createHall(createHallDto, user.clientId, user.id);
  }

  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner, UserTypesEnum.employee)
  @Get()
  async filterHalls(
    @Query() filter: FilterHallsDto,
    @CurrentUser() user: { clientId: number; id: number; type: UserTypesEnum },
  ): Promise<{
    items: {
      id: number;
      created_at: Date;
      updated_at: Date;
      name: string;
      name_ar: string;
      description: string;
      dailyTempBookings: number;
      autoCancelDaysTempBookings: number | null;
      logo_url: string;
      pricingType: BookingPricingType;
      priceCalculationType: PricingCalculationType;
      insuranceAmount: number;
    }[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return this.hallsService.filterHalls(filter, user);
  }

  @ApiConsumes('multipart/form-data')
  @UseInterceptors(
    FileFieldsInterceptor([
      { name: 'signature', maxCount: 1 },
      { name: 'stamp', maxCount: 1 },
    ]),
  )
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.UPDATE_HALLS)
  @Patch(':hallId/signatures')
  async updateHallSignatureAndStamp(
    @Param('hallId') hallId: string,
    @Body() updateHallSignatureAndStampDto: UpdateHallSignatureAndStampDto,
    @UploadedFiles() files: { signature?: MemoryStorageFile[]; stamp?: MemoryStorageFile[] },
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<HallDetails> {
    return this.hallsService.updateHallSignatureAndStamp(
      +hallId,
      updateHallSignatureAndStampDto,
      files?.signature?.[0],
      files?.stamp?.[0],
      user,
    );
  }

  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('logo'))
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.UPDATE_HALLS)
  @Patch(':id')
  async updateHall(
    @Param('id') id: string,
    @Body() updateHallDto: UpdateHallDto,
    @UploadedFile() logo: MemoryStorageFile,
    @CurrentUser() user: { clientId: number; id: number },
  ): Promise<HallDetails> {
    return this.hallsService.updateHall(+id, updateHallDto, logo, user.clientId, user.id);
  }

  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.READ_HALLS)
  @Get(':id')
  async findHall(@Param('id') id: string, @CurrentUser() user): Promise<HallDetails> {
    const { clientId } = user;
    return this.hallsService.getHall(+id, clientId);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.DELETE_HALLS)
  @Delete(':id')
  async removeHall(@Param('id') id: string, @CurrentUser() user): Promise<HallEntity> {
    return this.hallsService.removeHall(+id, user);
  }
}
