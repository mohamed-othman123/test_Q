import { PaginatorService } from './../../common/paginator/paginator.service';
import { FilterHallsDto, SortByOptions } from './dto/filter-halls.dto';
import { BadRequestException, Injectable } from '@nestjs/common';
import { CreateHallDto } from './dto/create-hall.dto';
import { UpdateHallDto } from './dto/update-hall.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { HallEntity } from './entities/hall.entity';
import { Brackets, In, Not, Repository } from 'typeorm';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { HallDetails } from './interfaces/hallDetails.interface';
import { DeleteHallTransaction } from './utils/delete-hall.transactions';
import { CreateHallTransaction } from './utils/create-hall.transactions';
import { UpdateHallTransaction } from './utils/update-hall.transactions';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { FileUploadService } from '../../common/utilities/file-upload/file-upload.service';
import { MemoryStorageFile } from '@blazity/nest-file-fastify';
import { HandelTwoName } from '../../core/helpers/cast.helper';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { HallDocumentsEntity } from './entities/hall_documents.entity';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { defaultHallDocuments } from './default-hall-documents';
import { UpdateHallSignatureAndStampDto } from './dto/Update-signatureAndStamp.dto';
import { UpdateHallSignatureAndStampTransaction } from './utils/update-hall-signatureAndStamp.transactions';
import { HallDocumentDto } from './dto/hall-document.dto';
import { UsersService } from '../users/users.service';
import { PricingCalculationType } from '../../common/enums/pricingCalculationType.enum';
import { BookingPricingType } from '../../common/enums/bookingPricingType.enum';

@Injectable()
export class HallsService {
  constructor(
    @InjectRepository(HallEntity) private readonly hallsRepo: Repository<HallEntity>,
    @InjectRepository(HallDocumentsEntity)
    private readonly hallDocumentRepo: Repository<HallDocumentsEntity>,
    private readonly paginatorService: PaginatorService,
    private readonly createHallTransaction: CreateHallTransaction,
    private readonly updateHallTransaction: UpdateHallTransaction,
    private readonly deleteHallTransactions: DeleteHallTransaction,
    private readonly updateHallSignatureAndStampTransaction: UpdateHallSignatureAndStampTransaction,
    private readonly fileUploadService: FileUploadService,
    private readonly eventEmitter: EventEmitter2,
  ) {}
  async createHall(
    createHallDto: CreateHallDto,
    clientId: number,
    userId: number,
  ): Promise<{
    id: number;
    created_at: Date;
    updated_at: Date;
    name: string;
    name_ar: string;
    description: string;
  }> {
    let { name, name_ar } = createHallDto;
    if (!name && !name_ar) {
      throw new BadRequestException(ErrorKeys.nameIsRequired);
    }
    [name, name_ar] = HandelTwoName(name, name_ar);
    const existHall = await this.hallsRepo.findOne({
      where: [
        { name, client: { id: clientId }, deleted: false },
        { name: name_ar, client: { id: clientId }, deleted: false },
        { name_ar, client: { id: clientId }, deleted: false },
        { name_ar: name, client: { id: clientId }, deleted: false },
      ],
    });
    if (existHall) {
      throw new BadRequestException(ErrorKeys.hallExists);
    }
    const savedHall = await this.createHallTransaction.run({
      hall: { ...createHallDto, name, name_ar },
      clientId,
      userId,
    });
    return {
      id: savedHall.id,
      created_at: savedHall.created_at,
      updated_at: savedHall.updated_at,
      name: savedHall.name,
      name_ar: savedHall.name_ar,
      description: savedHall.description,
    };
  }

  async filterHalls(
    filter: FilterHallsDto,
    user: { clientId: number; id: number; type: UserTypesEnum },
  ): Promise<{
    items: {
      id: number;
      created_at: Date;
      updated_at: Date;
      name: string;
      name_ar: string;
      description: string;
      dailyTempBookings: number;
      autoCancelDaysTempBookings: number | null;
      logo_url: string;
      pricingType: BookingPricingType;
      priceCalculationType: PricingCalculationType;
      insuranceAmount: number;
    }[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    let { sortBy, sortOrder, page, limit, name, description, creationDate } = filter;
    sortBy = sortBy || SortByOptions.createdAt;
    sortOrder = sortOrder || SortOrderEnum.DESC;
    const { clientId, id: userId, type } = user;

    const queryBuilder = this.hallsRepo
      .createQueryBuilder('h')
      .leftJoinAndSelect('h.hallModerators', 'hm');
    const hasFilterKeys = name || description || creationDate || type === UserTypesEnum.employee;
    if (!hasFilterKeys) {
      queryBuilder
        .where('h.client_id = :clientId', { clientId })
        .andWhere('h.deleted = :deleted', { deleted: false });
    }
    if (hasFilterKeys) {
      queryBuilder.where(
        new Brackets((qb) => {
          qb.where('h.client_id = :clientId', { clientId }).andWhere('h.deleted = :deleted', {
            deleted: false,
          });
          if (type === UserTypesEnum.employee) {
            qb.andWhere('hm.moderator_id = :moderatorId', { moderatorId: userId });
          }
          if (creationDate) {
            qb.andWhere('DATE(h.created_at) = :creationDate', {
              creationDate,
            });
          }
          if (description) {
            qb.andWhere('h.description ILIKE :descriptionFilter', {
              descriptionFilter: `%${description}%`,
            });
          }
          if (name) {
            qb.andWhere(
              new Brackets((nameQb) => {
                nameQb
                  .where('h.name ILIKE :nameFilter', {
                    nameFilter: `%${name}%`,
                  })
                  .orWhere('h.name_ar ILIKE :nameFilter', {
                    nameFilter: `%${name}%`,
                  });
              }),
            );
          }
        }),
      );
    }
    if (sortBy === SortByOptions.name) {
      queryBuilder.orderBy(`h.name`, sortOrder).addOrderBy(`h.name_ar`, sortOrder);
    } else {
      queryBuilder.orderBy(`h.${sortBy}`, sortOrder);
    }
    if (page && limit) {
      const take = limit || 10;
      const skip = ((page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }
    const [result, total] = await queryBuilder.getManyAndCount();

    const formattedItems = result.map((hall) => {
      return {
        id: hall.id,
        created_at: hall.created_at,
        updated_at: hall.updated_at,
        name: hall.name,
        name_ar: hall.name_ar,
        dailyTempBookings: hall.dailyTempBookings,
        autoCancelDaysTempBookings: hall.autoCancelDaysTempBookings,
        description: hall.description,
        logo_url: hall.logo_url,
        pricingType: hall.pricingType,
        priceCalculationType: hall.priceCalculationType,
        insuranceAmount: hall.insuranceAmount,
      };
    });

    return this.paginatorService.paginate(formattedItems, total, page || 1, limit || total);
  }

  async findHall(id: number, clientId: number, select = {}): Promise<HallEntity> {
    const existHall = await this.hallsRepo.findOne({
      where: { id, client: { id: clientId }, deleted: false },
      select,
      relations: { landingPage: true, client: true },
    });
    if (!existHall) {
      throw new BadRequestException(ErrorKeys.hallNotFound);
    }
    return existHall;
  }
  async getHall(id: number, clientId: number): Promise<HallDetails> {
    const existHall = await this.hallsRepo.findOne({
      where: { id, client: { id: clientId }, deleted: false },
      relations: {
        documents: true,
      },
      order: {
        documents: { order: 'ASC' },
      },
    });
    if (!existHall) {
      throw new BadRequestException(ErrorKeys.hallNotFound);
    }
    return {
      id: existHall.id,
      created_at: existHall.created_at,
      updated_at: existHall.updated_at,
      deleted_at: existHall.deleted_at,
      deleted_by: existHall.deleted_by,
      updated_by: existHall.updated_by,
      created_by: existHall.created_by,
      name: existHall.name,
      name_ar: existHall.name_ar,
      description: existHall.description,
      primary_color: existHall.primary_color,
      secondary_color: existHall.secondary_color,
      senderEmail: existHall.senderEmail,
      smsSenderId: existHall.smsSenderId,
      logo_url: existHall.logo_url,
      dailyTempBookings: existHall.dailyTempBookings,
      autoCancelDaysTempBookings: existHall.autoCancelDaysTempBookings,
      pricingType: existHall.pricingType,
      priceCalculationType: existHall.priceCalculationType,
      insuranceAmount: existHall.insuranceAmount,
      sendingTime: existHall.sendingTime,
      scheduleDays: existHall.scheduleDays,
      signatureUrl: existHall.signatureUrl,
      signatureName: existHall.signatureName,
      stampUrl: existHall.stampUrl,
      documents: existHall?.documents.map((document) => ({
        id: document.id,
        name: document.name,
        name_ar: document.name_ar,
        firstPartySignature: document.firstPartySignature,
        firstPartyStamp: document.firstPartyStamp,
        secondPartySignature: document.secondPartySignature,
      })),
    };
  }
  async updateHall(
    id: number,
    updateHallDto: UpdateHallDto,
    logo: MemoryStorageFile,
    clientId: number,
    userId: number,
  ): Promise<HallDetails> {
    const { name, name_ar, removeLogo } = updateHallDto;
    const existHall = await this.findHall(id, clientId, {
      landingPage: { id: true, hallName: true },
    });
    if (name && name_ar) {
      await this.findHallByName(id, name, name_ar, clientId);
    } else if (name) {
      await this.findHallByName(id, name, null, clientId);
    } else if (name_ar) {
      await this.findHallByName(id, null, name_ar, clientId);
    }
    const logo_url =
      logo && !removeLogo
        ? (await this.fileUploadService.uploadImage(logo)).path
        : removeLogo
          ? null
          : undefined;
    await this.updateHallTransaction.run({
      hall: updateHallDto,
      logo_url,
      hallId: id,
      userId,
    });
    if (existHall?.landingPage) {
      this.eventEmitter.emit('hall.updated', {
        landingHallNames: [existHall.landingPage.hallName],
      });
    }
    return this.getHall(id, clientId);
  }
  async removeHall(id: number, user: { clientId: number; id: number }): Promise<HallEntity> {
    const { clientId } = user;
    const existHall = await this.findHall(id, clientId, {
      id: true,
      name: true,
      name_ar: true,
      description: true,
      created_at: true,
    });

    await this.deleteHallTransactions.run({ hallId: existHall.id, userId: user.id });
    delete existHall.landingPage;
    return existHall;
  }

  private async findHallByName(
    id: number,
    name: string,
    name_ar: string,
    clientId: number,
  ): Promise<void> {
    let existHall = undefined;
    if (name && name_ar) {
      existHall = await this.hallsRepo.findOne({
        where: [
          { id: Not(id), name, client: { id: clientId }, deleted: false },
          { id: Not(id), name: name_ar, client: { id: clientId }, deleted: false },
          { id: Not(id), name_ar, client: { id: clientId }, deleted: false },
          { id: Not(id), name_ar: name, client: { id: clientId }, deleted: false },
        ],
      });
    } else if (name) {
      existHall = await this.hallsRepo.findOne({
        where: [
          { id: Not(id), name, client: { id: clientId }, deleted: false },
          { id: Not(id), name_ar: name, client: { id: clientId }, deleted: false },
        ],
      });
    } else {
      existHall = await this.hallsRepo.findOne({
        where: [
          { id: Not(id), name: name_ar, client: { id: clientId }, deleted: false },
          { id: Not(id), name_ar, client: { id: clientId }, deleted: false },
        ],
      });
    }
    if (existHall) {
      throw new BadRequestException(ErrorKeys.hallExists);
    }
  }
  validateHalls(halls: { id: number }[]): void {
    const hallsIds = halls.map((hall) => hall.id);

    if (new Set(hallsIds).size !== hallsIds.length) {
      throw new BadRequestException(ErrorKeys.hallsMustBeUnique);
    }
  }
  async validateExistingHalls(clientId: number, halls: { id: number }[]): Promise<void> {
    const hallsIds = halls.map((hall) => hall.id);
    const existsClientHalls = await this.getHallsInRange(clientId, hallsIds);
    const existHallIds = existsClientHalls.map((hall) => hall.id);
    const notExistsHalls = hallsIds.filter((id) => !existHallIds.includes(id));

    if (notExistsHalls.length > 0) {
      throw new BadRequestException(ErrorKeys.hallNotFound);
    }
  }
  async getHallsInRange(clientId: number, hallsIds: number[]) {
    const existHalls = await this.hallsRepo.find({
      where: { id: In(hallsIds), client: { id: clientId }, deleted: false },
      select: { id: true },
    });
    return existHalls;
  }

  async getClientHalls(user: {
    clientId: number;
    id: number;
    type: UserTypesEnum;
  }): Promise<{ id: number }[]> {
    const { clientId, id: userId, type } = user;
    const queryBuilder = this.hallsRepo
      .createQueryBuilder('h')
      .leftJoinAndSelect('h.hallModerators', 'hm')
      .where('h.client_id = :clientId', { clientId })
      .andWhere('h.deleted = :deleted', { deleted: false })
      .select(['h.id']);

    if (type === UserTypesEnum.employee) {
      queryBuilder.andWhere('hm.moderator_id = :moderatorId', { moderatorId: userId });
    }

    return await queryBuilder.getMany();
  }
  async getSystemHalls() {
    return await this.hallsRepo.find({
      where: { deleted: false },
      relations: { client: true },
      select: {
        id: true,
        sendingTime: true,
        name: true,
        name_ar: true,
        logo_url: true,
        primary_color: true,
        secondary_color: true,
        scheduleDays: true,
        created_at: true,
        client: { id: true, created_at: true },
      },
    });
  }
  async updateHallSignatureAndStamp(
    hallId: number,
    updateHallSignatureAndStampDto: UpdateHallSignatureAndStampDto,
    signature: MemoryStorageFile,
    stamp: MemoryStorageFile,
    user: AuthenticatedUser,
  ): Promise<HallDetails> {
    const { clientId, id: userId } = user;
    const { hallDocuments } = updateHallSignatureAndStampDto;
    await this.findHall(hallId, clientId);
    if (hallDocuments) {
      await this.validateHallSignatureAndStamp(
        updateHallSignatureAndStampDto,
        hallId,
        user,
        signature,
        stamp,
      );
      await this.validateExistingHallDocuments(hallId, hallDocuments, clientId);
    }

    const signatureUrl = signature
      ? (await this.fileUploadService.uploadImage(signature)).path
      : undefined;
    const stampUrl = stamp ? (await this.fileUploadService.uploadImage(stamp)).path : undefined;
    await this.updateHallSignatureAndStampTransaction.run({
      dto: updateHallSignatureAndStampDto,
      signatureUrl,
      stampUrl,
      hallId,
      userId,
    });

    return this.getHall(hallId, clientId);
  }

  private async validateHallSignatureAndStamp(
    dto: UpdateHallSignatureAndStampDto,
    hallId: number,
    user: AuthenticatedUser,
    signature: MemoryStorageFile,
    stamp: MemoryStorageFile,
  ): Promise<void> {
    const { clientId } = user;
    const { hallDocuments, signatureName } = dto;
    const documentIds = hallDocuments.map((document) => document.id).filter(Boolean);

    if (new Set(documentIds).size !== documentIds.length) {
      throw new BadRequestException(ErrorKeys.documentsMustBeUnique);
    }
    const existHall = await this.findHall(hallId, clientId);
    const firstPartySignature = hallDocuments.find((doc) => doc.firstPartySignature === true);
    if (
      firstPartySignature &&
      (!existHall.signatureName || !existHall.signatureUrl) &&
      (!signature || !signatureName)
    ) {
      throw new BadRequestException(ErrorKeys.hallSignatureIsRequired);
    }

    const firstPartyStamp = hallDocuments.find((doc) => doc.firstPartyStamp === true);
    if (firstPartyStamp && !existHall.stampUrl && !stamp) {
      throw new BadRequestException(ErrorKeys.hallStampIsRequired);
    }
  }

  private async validateExistingHallDocuments(
    hallId: number,
    documents: HallDocumentDto[],
    clientId: number,
  ): Promise<void> {
    const documentIds = documents.map((document) => document.id).filter(Boolean);

    const existingDocuments = await this.hallDocumentRepo.find({
      where: {
        id: In(documentIds),
        deleted: false,
        hall: { id: hallId, client: { id: clientId } },
      },
      select: { id: true },
    });
    const existingDocumentsIds = existingDocuments.map((document) => document.id);

    // Check for documents that do not exist
    const notExistsDocuments = documentIds.filter((id) => !existingDocumentsIds.includes(id));

    if (notExistsDocuments.length > 0) {
      throw new BadRequestException(ErrorKeys.documentNotFound);
    }
  }
  async seedDefaultDocumentsForHalls() {
    try {
      // Fetch halls that do not have any associated documents
      const halls = await this.hallsRepo
        .createQueryBuilder('hall')
        .leftJoinAndSelect('hall.documents', 'document')
        .where('document.id IS NULL') // Check if there are no documents
        .getMany();

      const documentsToAdd = [];

      for (const hall of halls) {
        try {
          // Check if the hall has no documents
          if (hall.documents.length === 0) {
            // Prepare documents to add
            defaultHallDocuments.forEach((doc) => {
              documentsToAdd.push({
                ...doc,
                hall: hall, // Associate document with the current hall
              });
            });
          }

          console.log(`Prepared documents for hall ID: ${hall.id}`);
        } catch (error) {
          console.error(`Failed to prepare documents for hall ID: ${hall.id}`, error);
          continue; // Continue to the next hall
        }
      }

      // Save all documents in one go
      if (documentsToAdd.length > 0) {
        await this.hallDocumentRepo.save(documentsToAdd); // Assuming you have a documentsRepo
        console.log(`Successfully saved ${documentsToAdd.length} documents.`);
      }

      console.log('Completed seeding documents for all halls');
    } catch (error) {
      console.error('Error in seedDefaultDocumentsForHalls:', error);
      throw error; // Rethrow error for upstream handling
    }
  }
}
