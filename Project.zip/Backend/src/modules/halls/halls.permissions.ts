import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const hallsPermissions = {
  CREATE_HALLS: {
    ar_name: 'إنشاء:القاعات',
    en_name: 'create:halls',
    ar_module: 'القاعات',
    en_module: 'Halls',
    order: 14,
    key: 'Halls',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/halls'",
  },
  READ_HALLS: {
    ar_name: 'قراءة:القاعات',
    en_name: 'read:halls',
    ar_module: 'القاعات',
    en_module: 'Halls',
    order: 14,
    key: 'Halls',
    type: PermissionsTypeEnum.READ,
    route: "GET '/halls'",
  },
  UPDATE_HALLS: {
    ar_name: 'تحديث:القاعات',
    en_name: 'update:halls',
    ar_module: 'القاعات',
    en_module: 'Halls',
    order: 14,
    key: 'Halls',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/halls/:id'",
  },
  DELETE_HALLS: {
    ar_name: 'حذف:القاعات',
    en_name: 'delete:halls',
    ar_module: 'القاعات',
    en_module: 'Halls',
    order: 14,
    key: 'Halls',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/halls/:id'",
  },
};
