import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const purchasesPermissions = {
  CREATE_PURCHASE: {
    ar_name: 'إنشاء:عملية المصروفات',
    en_name: 'create:expense',
    ar_module: 'المصروفات',
    en_module: 'Expenses',
    order: 7,
    key: 'Expenses',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/expenses'",
  },
  READ_PURCHASES: {
    ar_name: 'قراءة:المصروفات',
    en_name: 'read:expenses',
    ar_module: 'المصروفات',
    en_module: 'Expenses',
    order: 7,
    key: 'Expenses',
    type: PermissionsTypeEnum.READ,
    route: "GET '/expenses'",
  },
  UPDATE_PURCHASE: {
    ar_name: 'تحديث:عملية المصروفات',
    en_name: 'update:expense',
    ar_module: 'المصروفات',
    en_module: 'Expenses',
    order: 7,
    key: 'Expenses',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/expenses/:id'",
  },
  DELETE_PURCHASE: {
    ar_name: 'حذف:عملية المصروفات',
    en_name: 'delete:expense',
    ar_module: 'المصروفات',
    en_module: 'Expenses',
    order: 7,
    key: 'Expenses',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/expenses/:id'",
  },
};
