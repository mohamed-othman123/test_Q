import { ExpenseAttachmentsService } from './services/expenses-attachment.service';
import { forwardRef, Module } from '@nestjs/common';
import { ExpensesController } from './controllers/expenses.controller';
import { FileUploadModule } from '../../common/utilities/file-upload/file-upload.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SuppliersModule } from '../suppliers/suppliers.module';
import { SupplierProductModule } from '../supplier-products/supplier-products.module';
import { HallsModule } from '../halls/halls.module';
import { ExpensesAttachmentsController } from './controllers/expenses-attachments.controller';
import { ExpensesService } from './services/expenses.service';
import { PdfGenerationModule } from '../pdf-generation/pdf-generation.module';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
import { PurchaseCategoriesModule } from '../purchase-categories/purchase-categories.module';
import { ExpensesEntity } from './entities/expense.entity';
import { ExpenseAttachmentsEntity } from './entities/expense_attachments.entity';
import { ExpensesItemsModule } from '../expenses-items/expenses-items.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([ExpensesEntity, ExpenseAttachmentsEntity]),
    FileUploadModule,
    SuppliersModule,
    SupplierProductModule,
    HallsModule,
    forwardRef(() => PdfGenerationModule),
    PurchaseCategoriesModule,
    ExpensesItemsModule,
  ],
  controllers: [ExpensesController, ExpensesAttachmentsController],
  providers: [ExpensesService, ExpenseAttachmentsService, HallIdExtractor],
  exports: [ExpensesService],
})
export class ExpensesModule {}
