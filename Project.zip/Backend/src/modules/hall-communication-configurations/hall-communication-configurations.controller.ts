import { ApiBearerAuth, ApiConsumes, ApiHeader, ApiTags } from '@nestjs/swagger';
import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { UserTypeGuard } from '../../common/guards/user-types.guard';
import { HallCommunicationConfigurationsService } from './hall-communication-configurations.services';
import { UserTypes } from '../../common/decorators/user-types.decorator';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { hallsPermissions } from '../halls/halls.permissions';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { HallCommunicationConfigurationsResponseDto } from './dtos/hall-communication-configuration.response.dto';
import { UpdateHallCommunicationConfigurationsDto } from './dtos/update-hall-communication-configurations.dto';
import { CreateHallCommunicationConfigurationsDto } from './dtos/create-hall-communication-configurations.dto';
import { FilterHallCommunicationConfigurationsDto } from './dtos/filter-hall-communication-configuration.dto';
import { FileInterceptor, MemoryStorageFile } from '@blazity/nest-file-fastify';

@ApiTags('communication-configurations')
@UseGuards(UserTypeGuard)
@ApiBearerAuth()
@Controller('halls')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class HallCommunicationConfigurationsController {
  constructor(
    private readonly hallCommunicationConfigurationsService: HallCommunicationConfigurationsService,
  ) {}
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('emailLogo'))
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.CREATE_HALLS)
  @Post(':hallId/communication-configurations')
  async addHallCommunicationConfiguration(
    @Param('hallId') hallId: string,
    @Body() createHallCommunicationConfigurations: CreateHallCommunicationConfigurationsDto,
    @UploadedFile() emailLogo: MemoryStorageFile,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.hallCommunicationConfigurationsService.addHallCommunicationConfiguration(
      +hallId,
      createHallCommunicationConfigurations,
      emailLogo,
      user,
    );
  }

  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner, UserTypesEnum.employee)
  @Get(':hallId/communication-configurations')
  async filterHallCommunicationConfiguration(
    @Param('hallId') hallId: string,
    @Query() filter: FilterHallCommunicationConfigurationsDto,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.hallCommunicationConfigurationsService.getHallCommunicationConfigurations(
      +hallId,
      filter,
      user,
    );
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.READ_HALLS)
  @Get(':hallId/communication-configurations/:configurationId')
  async getHallCommunicationConfiguration(
    @Param('hallId') hallId: string,
    @Param('configurationId') configurationId: string,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.hallCommunicationConfigurationsService.getHallCommunicationConfiguration(
      +hallId,
      +configurationId,
      user,
    );
  }
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('emailLogo'))
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.UPDATE_HALLS)
  @Patch(':hallId/communication-configurations/:configurationId')
  async updateHallCommunicationConfiguration(
    @Param('hallId') hallId: string,
    @Param('configurationId') configurationId: string,
    @Body() updateHallCommunicationConfigurationDto: UpdateHallCommunicationConfigurationsDto,
    @UploadedFile() emailLogo: MemoryStorageFile,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.hallCommunicationConfigurationsService.updateHallCommunicationConfiguration(
      +hallId,
      +configurationId,
      updateHallCommunicationConfigurationDto,
      emailLogo,
      user,
    );
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(hallsPermissions.DELETE_HALLS)
  @Delete(':hallId/communication-configurations/:configurationId')
  async deleteHallCommunicationConfiguration(
    @Param('hallId') hallId: string,
    @Param('configurationId') configurationId: string,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.hallCommunicationConfigurationsService.deleteHallCommunicationConfiguration(
      +hallId,
      +configurationId,
      user,
    );
  }
}
