import { Injectable } from '@nestjs/common';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { CreateHallCommunicationConfigurationsDto } from './dtos/create-hall-communication-configurations.dto';
import { UpdateHallCommunicationConfigurationsDto } from './dtos/update-hall-communication-configurations.dto';
import { FilterHallCommunicationConfigurationsDto } from './dtos/filter-hall-communication-configuration.dto';
import { MemoryStorageFile } from '@blazity/nest-file-fastify';

@Injectable()
export class HallCommunicationConfigurationsService {
  constructor() {}
  async addHallCommunicationConfiguration(
    hallId: number,
    createHallCommunicationConfigurationsDto: CreateHallCommunicationConfigurationsDto,
    emailLogo: MemoryStorageFile,
    user: AuthenticatedUser,
  ) {
    return true;
  }
  async getHallCommunicationConfigurations(
    hallId: number,
    filter: FilterHallCommunicationConfigurationsDto,
    user: AuthenticatedUser,
  ) {
    return true;
  }
  async getHallCommunicationConfiguration(
    hallId: number,
    configurationId: number,
    user: AuthenticatedUser,
  ) {
    return true;
  }
  async updateHallCommunicationConfiguration(
    hallId: number,
    configurationId: number,
    updateHallCommunicationConfigurationsDto: UpdateHallCommunicationConfigurationsDto,
    emailLogo: MemoryStorageFile,
    user: AuthenticatedUser,
  ) {
    return this.getHallCommunicationConfiguration(hallId, configurationId, user);
  }
  async deleteHallCommunicationConfiguration(
    hallId: number,
    configurationId: number,
    user: AuthenticatedUser,
  ) {
    return true;
  }
}
