import { PaginatorModule } from '../../common/paginator/paginator.module';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { HallCommunicationConfigurationsController } from './hall-communication-configurations.controller';
import { HallCommunicationConfigurationsService } from './hall-communication-configurations.services';
import { HallsModule } from '../halls/halls.module';
import { FileUploadModule } from '../../common/utilities/file-upload/file-upload.module';

@Module({
  imports: [TypeOrmModule.forFeature([]), HallsModule, PaginatorModule, FileUploadModule],
  controllers: [HallCommunicationConfigurationsController],
  providers: [HallCommunicationConfigurationsService],
  exports: [HallCommunicationConfigurationsService],
})
export class HallCommunicationConfigurationsModule {}
