import { PriceRequestsFilter } from './dtos/filter-requests.dto';
import { PaginatorService } from './../../common/paginator/paginator.service';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { CaptchaService } from './../../common/captcha/captcha.service';
import { BadRequestException, Injectable } from '@nestjs/common';
import { PriceRequestDto } from './dtos/price-request.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { PriceRequestEntity } from './entities/price-requests.entity';
import { Repository, DataSource, Not, In } from 'typeorm';
import { HallEntity } from '../halls/entities/hall.entity';
import { UpdatePriceRequestDto } from './dtos/update-price-request.dto';
import { PriceRequestStatus } from './enums/request.status.enum';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { checkUserPermissionType } from '../../core/helpers/cast.helper';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';

@Injectable()
export class BookingPriceRequestsService {
  constructor(
    private readonly captchaService: CaptchaService,
    @InjectRepository(PriceRequestEntity)
    private readonly priceRequestsRepo: Repository<PriceRequestEntity>,
    private readonly dataSource: DataSource,
    private readonly paginatorService: PaginatorService,
  ) {}

  async sendPriceRequest(priceRequestDto: PriceRequestDto): Promise<PriceRequestEntity> {
    const { captchaId, captchaText, hallId, isFlexibleDate, eventDate } = priceRequestDto;
    const validCaptch = await this.captchaService.validateCaptcha(captchaId, captchaText);
    if (!validCaptch) throw new BadRequestException(ErrorKeys.invalidCaptcha);
    const hallRepo = this.dataSource.getRepository(HallEntity);
    const existHall = await hallRepo.findOne({
      where: { id: hallId, deleted: false },
      relations: { client: true },
      select: { id: true, client: { id: true } },
    });

    if (!existHall) throw new BadRequestException(ErrorKeys.hallNotFound);
    const {
      client: { id: clientId },
    } = existHall;

    if (isFlexibleDate !== undefined && !isFlexibleDate && !eventDate) {
      throw new BadRequestException(ErrorKeys.bookingDateIsRequired);
    }

    const newRequest = this.priceRequestsRepo.create({
      ...priceRequestDto,
      hall: { id: hallId },
      client: { id: clientId },
    });
    const savedRequest = await this.priceRequestsRepo.save(newRequest);
    delete savedRequest.client;
    return savedRequest;
  }

  async list(
    filter: PriceRequestsFilter,
    user: { id: number; clientId: number },
  ): Promise<{
    items: PriceRequestEntity[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    const { clientId } = user;
    let {
      page,
      limit,
      hallId,
      name,
      email,
      phoneNumber,
      eventName,
      eventTime,
      eventDate,
      creationDate,
      isFlexibleDate,
      sortBy,
      sortOrder,
      status,
    } = filter;

    const take = limit ?? 10;
    const skip = ((page ?? 1) - 1) * take;
    sortOrder = sortOrder || SortOrderEnum.DESC;

    const queryBuilder = this.priceRequestsRepo
      .createQueryBuilder('p')
      .withDeleted()
      .leftJoin('p.hall', 'h')
      .addSelect(['h.id', 'h.name', 'h.name_ar']);

    const hasFilterKeys =
      name ||
      email ||
      phoneNumber ||
      eventName ||
      eventDate ||
      creationDate ||
      isFlexibleDate !== undefined ||
      eventTime ||
      status;

    if (!hasFilterKeys) {
      queryBuilder
        .where('p.client_id = :clientId', { clientId })
        .andWhere('p.deleted = :deleted', { deleted: false })
        .andWhere('h.id = :hallFilter', {
          hallFilter: hallId,
        });
    }

    if (hasFilterKeys) {
      queryBuilder
        .where('p.client_id = :clientId', { clientId })
        .andWhere('p.deleted = :deleted', { deleted: false })
        .andWhere('h.id = :hallFilter', {
          hallFilter: hallId,
        });

      if (name) {
        queryBuilder.andWhere('p.name ILIKE :name', {
          name: `%${name}%`,
        });
      }

      if (email) {
        queryBuilder.andWhere('p.email ILIKE :email', {
          email: `%${name}%`,
        });
      }

      if (phoneNumber) {
        queryBuilder.andWhere('p.phoneNumber ILIKE :phoneNumber', {
          phoneNumber: `%${phoneNumber}%`,
        });
      }

      if (eventName) {
        queryBuilder.andWhere('p.eventName ILIKE :eventName', {
          eventName: `%${eventName}%`,
        });
      }

      if (eventTime) {
        queryBuilder.andWhere('p.eventTime = :eventTime', {
          eventTime,
        });
      }

      if (status) {
        queryBuilder.andWhere('p.status = :status', {
          status,
        });
      }

      if (eventDate) {
        const eventStartDate = `${eventDate} 00:00:00`;
        const eventEndDate = `${eventDate} 23:59:59`;

        queryBuilder.andWhere('p.eventDate BETWEEN :eventStartDate AND :eventEndDate', {
          eventStartDate,
          eventEndDate,
        });
      }

      if (creationDate) {
        const creationStartDate = `${creationDate} 00:00:00`;
        const creationEndDate = `${creationDate} 23:59:59`;

        queryBuilder.andWhere('p.created_at BETWEEN :creationStartDate AND :creationEndDate', {
          creationStartDate,
          creationEndDate,
        });
      }

      if (isFlexibleDate !== undefined) {
        queryBuilder.andWhere('p.isFlexibleDate = :isFlexibleDate', {
          isFlexibleDate,
        });
      }
    }

    queryBuilder.orderBy(`p.${sortBy}`, sortOrder, 'NULLS LAST').skip(skip).take(take);

    const [result, total] = await queryBuilder.getManyAndCount();

    return this.paginatorService.paginate(result, total, page, limit);
  }

  async findOne(id: number, user: AuthenticatedUser): Promise<PriceRequestEntity> {
    const { clientId } = user;
    const existingPriceRequest = await this.priceRequestsRepo.findOne({
      withDeleted: true,
      where: {
        id,
        client: { id: clientId },
        deleted: false,
        hall: user.type === UserTypesEnum.employee ? { id: In(user.halls) } : undefined,
      },
      relations: { hall: true },
    });
    if (!existingPriceRequest) throw new BadRequestException(ErrorKeys.priceRequestNotFound);

    return existingPriceRequest;
  }

  async update(
    id: number,
    dto: UpdatePriceRequestDto,
    user: AuthenticatedUser,
  ): Promise<PriceRequestEntity> {
    const { id: userId, clientId } = user;

    const { isFlexibleDate, eventDate } = dto;

    const existingPriceRequest = await this.priceRequestsRepo.findOne({
      withDeleted: true,
      where: {
        id,
        client: { id: clientId },
        deleted: false,
        status: Not(PriceRequestStatus.Canceled),
        hall: user.type === UserTypesEnum.employee ? { id: In(user.halls) } : undefined,
      },
      select: { id: true, created_by: true },
    });
    if (!existingPriceRequest) throw new BadRequestException(ErrorKeys.priceRequestNotFound);

    checkUserPermissionType(user, existingPriceRequest?.created_by);

    if (
      isFlexibleDate !== undefined &&
      !isFlexibleDate &&
      !eventDate &&
      !existingPriceRequest.eventDate
    ) {
      throw new BadRequestException(ErrorKeys.bookingDateIsRequired);
    }

    await this.priceRequestsRepo.update(id, { ...dto, updated_by: userId });
    return await this.findOne(id, user);
  }

  async remove(id: number, user: AuthenticatedUser): Promise<PriceRequestEntity> {
    const { id: userId, clientId } = user;
    const existingPriceRequest = await this.findOne(id, user);

    checkUserPermissionType(user, existingPriceRequest?.created_by);

    await this.priceRequestsRepo.update(id, {
      status: PriceRequestStatus.Canceled,
      updated_by: userId,
    });
    return {
      ...existingPriceRequest,
      status: PriceRequestStatus.Canceled,
      updated_by: userId,
    } as PriceRequestEntity;
  }
}
