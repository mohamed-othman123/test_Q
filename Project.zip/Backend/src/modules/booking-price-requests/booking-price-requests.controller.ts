import { PriceRequestsFilter } from './dtos/filter-requests.dto';
import { BookingPriceRequestsService } from './booking-price-requests.service';
import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { PriceRequestDto } from './dtos/price-request.dto';
import { Public } from '.././../auth/decorator/public.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PriceRequestEntity } from './entities/price-requests.entity';
import { UpdatePriceRequestDto } from './dtos/update-price-request.dto';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { bookingPriceRequestsPermissions } from './price-requests.permisssions';
import { EmployeeHallsInterceptor } from '../../auth/interceptors/halls-employee.interceptor';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';

@ApiBearerAuth()
@ApiTags('booking-price-requests')
@Controller('booking-price-requests')
export class BookingPriceRequestsController {
  constructor(private readonly priceRequestsService: BookingPriceRequestsService) {}

  @Public()
  @Post()
  async sendPriceRequest(@Body() priceRequestDto: PriceRequestDto): Promise<PriceRequestEntity> {
    return await this.priceRequestsService.sendPriceRequest(priceRequestDto);
  }

  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(bookingPriceRequestsPermissions.READ_PRICE_REQUESTS)
  @Get()
  async list(
    @Query() filter: PriceRequestsFilter,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<{
    items: PriceRequestEntity[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return await this.priceRequestsService.list(filter, user);
  }

  @RequirePermissions(bookingPriceRequestsPermissions.READ_PRICE_REQUESTS)
  @Get(':id')
  async findOne(
    @Param('id') id: string,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<PriceRequestEntity> {
    return await this.priceRequestsService.findOne(+id, user);
  }

  @RequirePermissions(bookingPriceRequestsPermissions.UPDATE_PRICE_REQUEST)
  @Patch(':id')
  async Reupdate(
    @Param('id') id: string,
    @Body() updatePriceRequestDto: UpdatePriceRequestDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<PriceRequestEntity> {
    return await this.priceRequestsService.update(+id, updatePriceRequestDto, user);
  }
  @RequirePermissions(bookingPriceRequestsPermissions.DELETE_PRICE_REQUEST)
  @Delete(':id')
  async remove(
    @Param('id') id: string,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<PriceRequestEntity> {
    return await this.priceRequestsService.remove(+id, user);
  }
}
