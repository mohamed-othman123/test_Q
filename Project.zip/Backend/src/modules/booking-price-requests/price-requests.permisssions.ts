import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const bookingPriceRequestsPermissions = {
  READ_PRICE_REQUESTS: {
    ar_name: 'قراءة:طلبات الأسعار',
    en_name: 'read:price-requests',
    ar_module: 'طلبات الأسعار',
    en_module: 'Price Requests',
    order: 12,
    key: 'Price Requests',
    type: PermissionsTypeEnum.READ,
    route: "GET '/booking-price-requests'",
  },
  UPDATE_PRICE_REQUEST: {
    ar_name: 'تحديث:طلبات الأسعار',
    en_name: 'update:price-requests',
    ar_module: 'طلبات الأسعار',
    en_module: 'Price Requests',
    order: 12,
    key: 'Price Requests',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/booking-price-requests/:id'",
  },
  DELETE_PRICE_REQUEST: {
    ar_name: 'حذف:طلبات الأسعار',
    en_name: 'delete:price-requests',
    ar_module: 'طلبات الأسعار',
    en_module: 'Price Requests',
    order: 12,
    key: 'Price Requests',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/booking-price-requests/:id'",
  },
};
