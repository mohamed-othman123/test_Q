import { Module } from '@nestjs/common';
import { BookingPriceRequestsController } from './booking-price-requests.controller';
import { BookingPriceRequestsService } from './booking-price-requests.service';
import { CaptchaModule } from '../../common/captcha/captcha.module';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PriceRequestEntity } from './entities/price-requests.entity';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';

@Module({
  imports: [CaptchaModule, PaginatorModule, TypeOrmModule.forFeature([PriceRequestEntity])],
  controllers: [BookingPriceRequestsController],
  providers: [BookingPriceRequestsService,HallIdExtractor],
})
export class BookingPriceRequestsModule {}
