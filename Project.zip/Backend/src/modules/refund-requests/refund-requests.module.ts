import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RefundRequestsController } from './refund-requests.controller';
import { RefundRequestsService } from './refund-requests.service';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
import { RefundRequestEntity } from './entities/refund-request.entity';
import { BookingModule } from '../booking/booking.module';
import { UpdateRefundRequestTransaction } from './utils/update-refund.transaction';
import { PaymentModule } from '../payment/payment.module';
import { PaymentMethodModule } from '../payment-method/payment-method.module';
import { UpdateRefundRequestStatusTransaction } from './utils/change-refund-request-status.transaction';
import { CreateRefundRequestTransaction } from './utils/create-refund-request.transaction';

@Module({
  imports: [
    TypeOrmModule.forFeature([RefundRequestEntity]),
    PaymentMethodModule,
    BookingModule,
    PaymentModule,
  ],
  controllers: [RefundRequestsController],
  providers: [
    RefundRequestsService,
    HallIdExtractor,
    CreateRefundRequestTransaction,
    UpdateRefundRequestTransaction,
    UpdateRefundRequestStatusTransaction,
  ],
  exports: [RefundRequestsService],
})
export class RefundRequestsModule {}
