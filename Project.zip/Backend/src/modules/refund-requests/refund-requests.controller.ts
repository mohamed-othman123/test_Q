import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RefundRequestsService } from './refund-requests.service';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { CreateRefundRequestDto } from './dtos/create-refund.dto';
import { EmployeeHallsInterceptor } from '../../auth/interceptors/halls-employee.interceptor';
import { GetRefundRequestsDto } from './dtos/get-refunds.dto';
import { UpdateRefundRequestDto } from './dtos/update-refund.dto';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { refundRequestsPermissions } from './refund-requests.permissions';
import { RefundRequestResponseDto } from './dtos/refund-request.response.dto';
import { BeneficiaryType } from '../../common/enums/beneficiary-type.enum';
import { RefundStatus } from './enums/refund-status.enum';
import { HallClientsEntity } from '../hall-clients/entities/halls-clients.entity';
import { bookingsPermissions } from '../booking/permissions/booking.permissions';
import { Booking } from '../booking/entities/booking.entity';
import { UpdateRefundRequestStatusDto } from './dtos/update-status.dto';

@ApiTags('refund-requests')
@ApiBearerAuth()
@Controller('refund-requests')
export class RefundRequestsController {
  constructor(private readonly refundRequestsService: RefundRequestsService) { }

  @Post()
  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(refundRequestsPermissions.CREATE_REFUND_REQUEST)
  @ApiOperation({ summary: 'Create a new refund request' })
  async create(
    @Body() createDto: CreateRefundRequestDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<RefundRequestResponseDto> {
    return this.refundRequestsService.createRefundRequest(createDto, user);
  }

  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(
    refundRequestsPermissions.READ_REFUND_REQUESTS,
    bookingsPermissions.READ_BOOKINGS,
  )
  @Get()
  async getAll(
    @CurrentUser() user: AuthenticatedUser,
    @Query() filter: GetRefundRequestsDto,
  ): Promise<{
    items: {
      id: number;
      created_at: Date;
      updated_at: Date;
      deleted_at: Date;
      created_by: number;
      amount: number;
      request_date: Date;
      notes: string | null;
      beneficiaryType: BeneficiaryType;
      beneficiaryName: string;
      beneficiaryMobile: string;
      status: RefundStatus;
      booking: Booking;
      user: HallClientsEntity;
    }[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return this.refundRequestsService.getRefundRequests(filter, user);
  }

  @RequirePermissions(refundRequestsPermissions.READ_REFUND_REQUESTS)
  @Get(':id')
  async findOne(
    @Param('id') id: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<RefundRequestResponseDto> {
    return this.refundRequestsService.getRefundRequest(+id, user);
  }

  @RequirePermissions(refundRequestsPermissions.UPDATE_REFUND_REQUEST)
  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() updateDto: UpdateRefundRequestDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<RefundRequestResponseDto> {
    return this.refundRequestsService.updateRefundRequest(+id, updateDto, user);
  }

  @RequirePermissions(refundRequestsPermissions.UPDATE_REFUND_REQUEST)
  @Patch(':id/status')
  async updateRefundRequestStatus(
    @Param('id') id: string,
    @Body() updateRefundRequestStatusDto: UpdateRefundRequestStatusDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<RefundRequestResponseDto> {
    return this.refundRequestsService.updateRefundRequestStatus(
      +id,
      updateRefundRequestStatusDto,
      user,
    );
  }

  // @RequirePermissions(refundRequestsPermissions.DELETE_REFUND_REQUEST)
  // @Delete(':id')
  // async delete(
  //   @Param('id') id: string,
  //   @CurrentUser()
  //   user: AuthenticatedUser,
  // ): Promise<RefundRequestResponseDto> {
  //   return this.refundRequestsService.canceledRefundRequest(+id, user);
  // }
}
