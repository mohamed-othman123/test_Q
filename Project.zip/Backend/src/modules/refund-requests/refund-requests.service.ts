import { BadRequestException, Injectable } from '@nestjs/common';
import { RefundRequestEntity } from './entities/refund-request.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, In, Not, Repository } from 'typeorm';
import { ClientPaymentMethodEntity } from './entities/client-payment-method.entity';
import { BookingService } from '../booking/services/booking.service';
import { CreateRefundRequestDto } from './dtos/create-refund.dto';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { RefundStatus } from './enums/refund-status.enum';
import { PaymentTypeEnum } from '../payment/enums/payment-types.enum';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { UpdateRefundRequestDto } from './dtos/update-refund.dto';
import { checkUserPermissionType } from '../../core/helpers/cast.helper';
import { HallsService } from '../halls/halls.service';
import { UpdateRefundRequestTransaction } from './utils/update-refund.transaction';
import { GetRefundRequestsDto, SortByOptions } from './dtos/get-refunds.dto';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { PaginatorService } from '../../common/paginator/paginator.service';
import { PaymentService } from '../payment/services/payment.service';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { RefundRequestResponseDto } from './dtos/refund-request.response.dto';
import { BeneficiaryType } from '../../common/enums/beneficiary-type.enum';
import { HallClientsEntity } from '../hall-clients/entities/halls-clients.entity';
import { PaymentMethodService } from '../payment-method/payment-method.service';
import { Booking } from '../booking/entities/booking.entity';
import { UpdateRefundRequestStatusDto } from './dtos/update-status.dto';
import { UpdateRefundRequestStatusTransaction } from './utils/change-refund-request-status.transaction';
import { CreateRefundRequestTransaction } from './utils/create-refund-request.transaction';

@Injectable()
export class RefundRequestsService {
  constructor(
    @InjectRepository(RefundRequestEntity)
    private refundRequestsRepository: Repository<RefundRequestEntity>,
    private bookingsService: BookingService,
    private paymentMethodService: PaymentMethodService,
    private readonly createRefundRequestTransaction: CreateRefundRequestTransaction,
    private readonly updateRefundRequestTransaction: UpdateRefundRequestTransaction,
    private readonly updateRefundRequestStatusTransaction: UpdateRefundRequestStatusTransaction,
    private readonly paginatorService: PaginatorService,
    private paymentService: PaymentService,
  ) {}
  async createRefundRequest(
    createRefundRequestDto: CreateRefundRequestDto,
    user: AuthenticatedUser,
  ): Promise<RefundRequestResponseDto> {
    const { clientId } = user;
    const booking = await this.bookingsService.getBookingToPayment(
      createRefundRequestDto.bookingId,
      PaymentTypeEnum.Refund,
    );
    if (booking.hall.id !== createRefundRequestDto.hallId) {
      throw new BadRequestException(ErrorKeys.bookingNotFound);
    }
    checkUserPermissionType(user, booking?.created_by);
    await this.paymentMethodService.findOne(createRefundRequestDto.paymentMethodId, user);

    await this.paymentService.validatePayment(
      booking.id,
      clientId,
      PaymentTypeEnum.Refund,
      createRefundRequestDto.amount,
      booking.totalPayable,
    );
    const newRefundRequest = await this.createRefundRequestTransaction.run({
      booking,
      createRefundRequestDto,
      user,
    });

    return this.getRefundRequest(newRefundRequest.id, user);
  }
  async findRefundRequest(
    id: number,
    user: AuthenticatedUser,
    select = {},
  ): Promise<RefundRequestEntity> {
    const { clientId, halls, type } = user;
    const queryConditions = {
      id,
      client: { id: clientId },
      deleted: false,
      hallEvents: type === UserTypesEnum.employee ? { hall: In(halls) } : undefined,
    };
    const existRefundRequest = await this.refundRequestsRepository.findOne({
      where: queryConditions,
      select,
      relations: { booking: true, clientPaymentMethod: true, paymentMethod: true },
    });
    if (!existRefundRequest) {
      throw new BadRequestException(ErrorKeys.refundRequestNotFound);
    }
    return existRefundRequest;
  }

  async getRefundRequest(id: number, user: AuthenticatedUser): Promise<RefundRequestResponseDto> {
    const { clientId, type, halls } = user;

    const refundRequest = await this.refundRequestsRepository.findOne({
      where: {
        id,
        deleted: false,
        client: { id: clientId },
        hall: type === UserTypesEnum.employee ? In(halls) : undefined,
      },
      relations: {
        hall: true,
        clientPaymentMethod: true,
        paymentMethod: true,
        booking: true,
        user: true,
      },
    });

    if (!refundRequest) {
      throw new BadRequestException(ErrorKeys.refundRequestNotFound);
    }

    return {
      id: refundRequest.id,
      amount: refundRequest.amount,
      status: refundRequest.status,
      notes: refundRequest.notes,
      rejectReason:
        refundRequest.status === RefundStatus.REJECTED ? refundRequest.rejectReason : undefined,
      request_date: refundRequest.request_date,
      created_at: refundRequest.created_at,
      updated_at: refundRequest.updated_at,
      deleted_at: refundRequest.deleted_at,
      created_by: refundRequest.created_by,
      updated_by: refundRequest.updated_by,
      deleted_by: refundRequest.deleted_by,
      clientPaymentMethod: refundRequest.clientPaymentMethod,
      paymentMethod: refundRequest.paymentMethod,
      deleted: refundRequest.deleted,
      beneficiaryType: refundRequest.beneficiaryType,
      beneficiaryName: refundRequest.beneficiaryName,
      beneficiaryMobile: refundRequest.beneficiaryMobile,
      booking: {
        id: refundRequest.booking.id,
        bookingReference: refundRequest.booking.bookingReference,
      },
      user: {
        id: refundRequest.user.id,
        name: refundRequest.user.name,
        phone: refundRequest.user.phone,
      },
    };
  }
  async getRefundRequests(
    filter: GetRefundRequestsDto,
    user: AuthenticatedUser,
  ): Promise<{
    items: {
      id: number;
      created_at: Date;
      updated_at: Date;
      deleted_at: Date;
      created_by: number;
      amount: number;
      request_date: Date;
      notes: string | null;
      rejectReason?: string;
      beneficiaryType: BeneficiaryType;
      beneficiaryName: string;
      beneficiaryMobile: string;
      status: RefundStatus;
      booking: Booking;
      user: HallClientsEntity;
    }[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    const { clientId } = user;
    const { page, limit, hallId } = filter;
    let { sortBy, sortOrder } = filter;

    sortBy = sortBy || SortByOptions.createdAt;
    sortOrder = sortOrder || SortOrderEnum.DESC;

    const queryBuilder = this.refundRequestsRepository
      .createQueryBuilder('c')
      .leftJoinAndSelect('c.hall', 'hall')
      .leftJoin('c.booking', 'booking')
      .addSelect(['booking.id', 'booking.bookingReference', 'booking.totalPayable'])
      .leftJoin('c.user', 'user')
      .addSelect(['user.id', 'user.name', 'user.isVIB']);

    const hasFilterKeys =
      filter.creationDate ||
      filter.clientName ||
      filter.beneficiaryName ||
      filter.beneficiaryMobile ||
      filter.status ||
      filter.amount ||
      filter.request_date ||
      filter.bookingReference;

    if (!hasFilterKeys) {
      queryBuilder
        .where('c.client_id = :clientId', { clientId })
        .andWhere('c.deleted = :deleted', { deleted: false })
        .andWhere('hall.id = :hallId', {
          hallId: filter.hallId,
        });
    }

    if (hasFilterKeys) {
      queryBuilder.where(
        new Brackets((qb) => {
          qb.where('c.client_id = :clientId', { clientId })
            .andWhere('c.deleted = :deleted', {
              deleted: false,
            })
            .andWhere('hall.id=:hallId', {
              hallId: filter.hallId,
            });

          if (filter.creationDate) {
            qb.andWhere('c.created_at = :creationDate', {
              creationDate: filter.creationDate,
            });
          }

          if (filter.request_date) {
            qb.andWhere('c.request_date = :request_date', {
              request_date: filter.request_date,
            });
          }

          if (filter.status) {
            qb.andWhere('c.status = :status', {
              status: filter.status,
            });
          }
          if (filter.clientName) {
            qb.andWhere('user.name ILIKE :name', {
              name: `%${filter.clientName}%`,
            });
          }
          if (filter.beneficiaryName) {
            qb.andWhere('c.beneficiaryName ILIKE :beneficiaryName', {
              name: `%${filter.beneficiaryName}%`,
            });
          }

          if (filter.beneficiaryMobile) {
            qb.andWhere('c.beneficiaryMobile ILIKE :beneficiaryMobile', {
              name: `%${filter.beneficiaryMobile}%`,
            });
          }

          if (filter.bookingReference) {
            qb.andWhere('booking.bookingReference ILIKE :bookingReference', {
              bookingReference: `%${filter.bookingReference}%`,
            });
          }
          if (filter.amount) {
            qb.andWhere('c.amount = :amount', {
              amount: filter.amount,
            });
          }
        }),
      );
    }

    if (sortBy === SortByOptions.bookingReference) {
      queryBuilder.orderBy('booking.bookingReference', sortOrder);
    } else if (sortBy === SortByOptions.clientName) {
      queryBuilder.orderBy(`user.name`, sortOrder);
    } else {
      queryBuilder.orderBy(`c.${sortBy}`, sortOrder);
    }

    if (page && limit) {
      const take = filter.limit || 10;
      const skip = ((filter.page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }

    const [result, total] = await queryBuilder.getManyAndCount();

    const formattedItems = result.map((request) => ({
      id: request.id,
      created_at: request.created_at,
      updated_at: request.updated_at,
      deleted_at: request.deleted_at,
      created_by: request.created_by,
      amount: request.amount,
      request_date: request.request_date,
      notes: request.notes,
      rejectReason: request.status === RefundStatus.REJECTED ? request.rejectReason : undefined,
      beneficiaryType: request.beneficiaryType,
      beneficiaryName: request.beneficiaryName,
      beneficiaryMobile: request.beneficiaryMobile,
      status: request.status,
      booking: request.booking,
      user: request.user,
    }));

    return this.paginatorService.paginate(formattedItems, total, page || 1, limit || total);
  }

  async updateRefundRequest(
    id: number,
    updateRefundRequestDto: UpdateRefundRequestDto,
    user: AuthenticatedUser,
  ): Promise<RefundRequestResponseDto> {
    const { clientId, type, halls } = user;
    await this.paymentMethodService.findOne(updateRefundRequestDto.paymentMethodId, user);
    const refundRequest = await this.findRefundRequest(id, user);
    checkUserPermissionType(user, refundRequest.created_by);
    if (
      refundRequest.status === RefundStatus.COMPLETED ||
      refundRequest.status === RefundStatus.REJECTED
    ) {
      throw new BadRequestException(ErrorKeys.refundRequestNotUpdate);
    }
    if (
      updateRefundRequestDto.amount !== refundRequest.amount ||
      updateRefundRequestDto.status === RefundStatus.COMPLETED
    ) {
      await this.paymentService.validatePayment(
        refundRequest.booking.id,
        clientId,
        PaymentTypeEnum.Refund,
        updateRefundRequestDto.amount,
        refundRequest.booking.totalPayable,
      );
    }
    // let hallIds = [];
    // if (halls) {
    //   this.hallService.validateHalls(halls);
    //   await this.hallService.validateExistingHalls(clientId, halls);
    //   hallIds = halls.map((hall) => hall.id).filter(Boolean);
    // }
    await this.updateRefundRequestTransaction.run({
      refundRequest,
      user,
      updateRefundRequestDto,
    });

    return this.getRefundRequest(id, user);
  }

  async updateRefundRequestStatus(
    id: number,
    updateRefundRequestStatusDto: UpdateRefundRequestStatusDto,
    user: AuthenticatedUser,
  ): Promise<RefundRequestResponseDto> {
    const { id: userId } = user;
    const { status } = updateRefundRequestStatusDto;
    const refundRequest = await this.findRefundRequest(id, user, {
      booking: true,
    });
    checkUserPermissionType(user, refundRequest.created_by);
    if (
      refundRequest.status === RefundStatus.COMPLETED ||
      refundRequest.status === RefundStatus.REJECTED
    ) {
      throw new BadRequestException(ErrorKeys.refundRequestNotUpdate);
    }
    if (status === RefundStatus.COMPLETED) {
      await this.paymentService.validatePayment(
        refundRequest.booking.id,
        user.clientId,
        PaymentTypeEnum.Refund,
        refundRequest.amount,
        refundRequest.booking.totalPayable,
      );
    }
    await this.updateRefundRequestStatusTransaction.run({
      refundRequest,
      updateRefundRequestStatusDto,
      user,
    });
    return {
      ...refundRequest,
      rejectReason:
        status === RefundStatus.REJECTED ? updateRefundRequestStatusDto.rejectReason : undefined,
      updated_by: userId,
      status,
    };
  }
  async autoRejectInvalidRefunds(): Promise<void> {
    const refundRequests = await this.refundRequestsRepository.find({
      where: {
        status: Not(In([RefundStatus.COMPLETED, RefundStatus.REJECTED])),
        deleted: false,
      },
      relations: {
        booking: true,
        client: true,
      },
    });

    const rejectedIds: number[] = [];

    for (const refund of refundRequests) {
      let shouldReject = false;
      if (refund.status !== RefundStatus.COMPLETED && refund.status !== RefundStatus.REJECTED) {
        shouldReject = await this.paymentService.shouldAutoRejectRefundPayment(
          refund.booking.id,
          refund.client.id,
          PaymentTypeEnum.Refund,
          refund.amount,
          refund.booking.totalPayable,
        );
      }

      if (shouldReject) {
        rejectedIds.push(refund.id);
      }
    }

    if (rejectedIds.length > 0) {
      await this.refundRequestsRepository
        .createQueryBuilder()
        .update()
        .set({
          status: RefundStatus.REJECTED,
          rejectReason: 'لا يمكن أن يتجاوز مجموع مبالغ الاسترداد المبلغ المدفوع الإجمالي',
        })
        .whereInIds(rejectedIds)
        .execute();
    }
  }
}
