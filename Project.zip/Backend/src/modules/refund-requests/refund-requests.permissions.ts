import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const refundRequestsPermissions = {
  CREATE_REFUND_REQUEST: {
    ar_name: 'إنشاء:طلبات الاسترجاع',
    en_name: 'create:refund request',
    ar_module: 'طلبات الاسترجاع',
    en_module: 'Refund Requests',
    order: 11,
    key: 'Refund Requests',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/refund-requests'",
  },
  READ_REFUND_REQUESTS: {
    ar_name: 'قراءة:طلبات الاسترجاع',
    en_name: 'read:refund requests',
    ar_module: 'طلبات الاسترجاع',
    en_module: 'Refund Requests',
    order: 11,
    key: 'Refund Requests',
    type: PermissionsTypeEnum.READ,
    route: "GET '/refund-requests'",
  },
  UPDATE_REFUND_REQUEST: {
    ar_name: 'تحديث:طلبات الاسترجاع',
    en_name: 'update:refund request',
    ar_module: 'طلبات الاسترجاع',
    en_module: 'Refund Requests',
    order: 11,
    key: 'Refund Requests',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/refund-requests/:id'",
  },
  // DELETE_REFUND_REQUEST: {
  //   ar_name: 'حذف:طلبات الاسترجاع',
  //   en_name: 'delete:refund request',
  //   ar_module: 'طلبات الاسترجاع',
  //   en_module: 'Refund Requests',
  //   order: 11,
  //   key: 'Refund Requests',
  //   type: PermissionsTypeEnum.DELETE,
  //   route: "DELETE '/refund-requests/:id'",
  // },
};
