import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const hallsClientsPermissions = {
  CREATE_HALLS_CLIENTS: {
    ar_name: 'إنشاء:عملاء القاعات',
    en_name: 'create:hallsClients',
    ar_module: 'العملاء',
    en_module: 'Clients',
    order: 5,
    key: 'Clients',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/halls-clients'",
  },
  READ_HALLS_CLIENTS: {
    ar_name: 'قراءة:عملاء القاعات',
    en_name: 'read:hallsClients',
    ar_module: 'العملاء',
    en_module: 'Clients',
    order: 5,
    key: 'Clients',
    type: PermissionsTypeEnum.READ,
    route: "GET '/halls-clients'",
  },
  UPDATE_HALLS_CLIENTS: {
    ar_name: 'تحديث:عملاء القاعات',
    en_name: 'update:hallsClients',
    ar_module: 'العملاء',
    en_module: 'Clients',
    order: 5,
    key: 'Clients',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/halls-clients/:id'",
  },
  DELETE_HALLS_CLIENTS: {
    ar_name: 'حذف:عملاء القاعات',
    en_name: 'delete:hallsClients',
    ar_module: 'العملاء',
    en_module: 'Clients',
    order: 5,
    key: 'Clients',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/halls-clients/:id'",
  },
};
