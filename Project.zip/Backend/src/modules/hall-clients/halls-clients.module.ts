import { HallsModule } from './../halls/halls.module';
import { Module } from '@nestjs/common';
import { HallsClientsController } from './halls-clients.controller';
import { HallsClientsService } from './halls-clients.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HallClientsEntity } from './entities/halls-clients.entity';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { AddCustomerTransaction } from './utils/add_customer.transactions';
import { UpdateCustomerTransaction } from './utils/update_customer.transactions';
import { DeleteCustomerTransaction } from './utils/delete_customer.transaction';
import { HallIdExtractor } from 'src/common/services/hall-id.extractor';

@Module({
  imports: [TypeOrmModule.forFeature([HallClientsEntity]), PaginatorModule,HallsModule],
  controllers: [HallsClientsController],
  providers: [
    HallsClientsService,
    AddCustomerTransaction,
    UpdateCustomerTransaction,
    DeleteCustomerTransaction,
    HallIdExtractor
  ],
  exports: [HallsClientsService],
})
export class HallsClientsModule {}
