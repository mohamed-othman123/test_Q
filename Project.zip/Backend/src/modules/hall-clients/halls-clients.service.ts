import { UpdateHallsClientsDto } from './dtos/update-halls-clients.dto';
import { PaginatorService } from './../../common/paginator/paginator.service';
import { contactDto, CreateHallsClientsDto } from './dtos/create-halls-clients.dto';
import { BadRequestException, forwardRef, Inject, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { HallClientsEntity } from './entities/halls-clients.entity';
import { Brackets, In, Not, Repository } from 'typeorm';
import { FilterClientsDto, SortByOptions } from './dtos/filter-halls-clients.dto';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { AddCustomerTransaction } from './utils/add_customer.transactions';
import { UpdateCustomerTransaction } from './utils/update_customer.transactions';
import { DeleteCustomerTransaction } from './utils/delete_customer.transaction';
import { HallClientsTypeEnum } from '../../common/enums/hallClientsType.enum';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { HallsService } from '../halls/halls.service';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { checkUserPermissionType } from '../../core/helpers/cast.helper';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { HallClientsResponseDto } from './dtos/hall-clients.response.dto';
@Injectable()
export class HallsClientsService {
  constructor(
    @InjectRepository(HallClientsEntity)
    private readonly hallsClientsRepo: Repository<HallClientsEntity>,
    private readonly paginatorService: PaginatorService,
    private readonly addCustomerTransaction: AddCustomerTransaction,
    private readonly updateCustomerTransaction: UpdateCustomerTransaction,
    private readonly deleteCustomerTransaction: DeleteCustomerTransaction,
    @Inject(forwardRef(() => HallsService))
    private readonly hallsService: HallsService,
  ) {}

  async createHallsClient(
    createHallsClientsDto: CreateHallsClientsDto,
    user: AuthenticatedUser,
  ): Promise<HallClientsResponseDto> {
    const { halls, type } = createHallsClientsDto;
    const { clientId, id: userId } = user;
    this.hallsService.validateHalls(halls);
    const hallIds = halls.map((hall) => hall.id).filter(Boolean);
    const existClient = await this.hallsClientsRepo.findOne({
      where: {
        phone: createHallsClientsDto.phone,
        client: { id: clientId },
        deleted: false,
        hallCustomers: { hall: { id: In(hallIds) } },
      },
    });
    if (existClient) {
      throw new BadRequestException(ErrorKeys.anotherClientExistByPhone);
    }
    if (type === HallClientsTypeEnum.FACILITY) {
      const existClientByVat = await this.hallsClientsRepo.findOne({
        where: {
          client: { id: clientId },
          deleted: false,
          company_details: {
            commercialRegistrationNumber: createHallsClientsDto.commercialRegistrationNumber,
          },
          hallCustomers: { hall: { id: In(hallIds) } },
        },
      });
      if (existClientByVat) {
        throw new BadRequestException(ErrorKeys.anotherClientExistByCommercial);
      }
      const existClientBytax = await this.hallsClientsRepo.findOne({
        where: {
          client: { id: clientId },
          deleted: false,
          company_details: {
            taxRegistrationNumber: createHallsClientsDto.taxRegistrationNumber,
          },
          hallCustomers: { hall: { id: In(hallIds) } },
        },
      });
      if (existClientBytax) {
        throw new BadRequestException(ErrorKeys.anotherClientExistByTax);
      }
    }
    if (type === HallClientsTypeEnum.INDIVIDUAL) {
      const existClientByNationalOrResidencyId = await this.hallsClientsRepo.findOne({
        where: {
          client: { id: clientId },
          deleted: false,
          nationalOrResidencyId: createHallsClientsDto.nationalOrResidencyId,
          hallCustomers: { hall: { id: In(hallIds) } },
        },
      });
      if (existClientByNationalOrResidencyId) {
        throw new BadRequestException(ErrorKeys.anotherClientExistByNationalOrResidencyId);
      }
    }
    if (createHallsClientsDto?.email) {
      const existEmail = await this.hallsClientsRepo.findOne({
        where: {
          email: createHallsClientsDto.email,
          client: { id: clientId },
          deleted: false,
          hallCustomers: { hall: { id: In(hallIds) } },
        },
      });
      if (existEmail) {
        throw new BadRequestException(ErrorKeys.anotherClientExistByEmail);
      }
    }
    if (createHallsClientsDto.contacts) {
      this.validateContacts(createHallsClientsDto.contacts);
    }
    const savedClient = await this.addCustomerTransaction.run({
      customer: createHallsClientsDto,
      clientId,
      userId,
      halls,
    });
    return this.getClient(savedClient.id, user);
  }

  async filterClients(
    filter: FilterClientsDto,
    user: AuthenticatedUser,
  ): Promise<{
    items: HallClientsResponseDto[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    const { clientId } = user;
    let { sortBy, sortOrder } = filter;
    sortBy = sortBy || SortByOptions.createdAt;
    sortOrder = sortOrder || SortOrderEnum.DESC;

    const queryBuilder = this.hallsClientsRepo
      .createQueryBuilder('c')
      .leftJoinAndSelect('c.company_details', 'companyDetails')
      .leftJoinAndSelect('c.hallCustomers', 'hallCustomer')
      .leftJoinAndSelect('hallCustomer.hall', 'hall');
    const hasFilterKeys =
      filter.name ||
      filter.email ||
      filter.phone ||
      filter.address ||
      filter.phone ||
      filter.type ||
      filter.gender ||
      filter.nationalOrResidencyId ||
      filter.isVIB !== undefined;
    filter.creationDate;
    if (!hasFilterKeys) {
      queryBuilder
        .where('c.client_id = :clientId', { clientId })
        .andWhere('c.deleted = :deleted', { deleted: false })
        .andWhere('hall.id=:hallId', {
          hallId: filter.hallId,
        });
    }
    if (hasFilterKeys) {
      queryBuilder.where(
        new Brackets((qb) => {
          qb.where('c.client_id = :clientId', { clientId })
            .andWhere('c.deleted = :deleted', {
              deleted: false,
            })
            .andWhere('hall.id=:hallId', {
              hallId: filter.hallId,
            });
          if (filter.creationDate) {
            qb.andWhere('DATE(c.created_at) = :creationDate', {
              creationDate: filter.creationDate,
            });
          }

          if (filter.name) {
            qb.andWhere('c.name ILIKE :nameFilter', { nameFilter: `%${filter.name}%` });
          }
          if (filter.email) {
            qb.andWhere('c.email ILIKE :emailFilter', { emailFilter: `%${filter.email}%` });
          }
          if (filter.phone) {
            qb.andWhere('c.phone ILIKE :phoneFilter', { phoneFilter: `%${filter.phone}%` });
          }
          if (filter.nationalOrResidencyId) {
            qb.andWhere('c.nationalOrResidencyId ILIKE :nationalOrResidencyIdFilter', {
              nationalOrResidencyIdFilter: `%${filter.nationalOrResidencyId}%`,
            });
          }

          if (filter.type) {
            qb.andWhere('c.type = :typeFilter', { typeFilter: filter.type });
          }

          if (filter.gender) {
            qb.andWhere('c.gender = :genderFilter', { genderFilter: filter.gender });
          }

          if (filter.isVIB !== undefined) {
            qb.andWhere('c.isVIB = :isVIBFilter', {
              isVIBFilter: filter.isVIB,
            });
          }
          if (filter.address) {
            qb.andWhere('c.address ILIKE :addressFilter', { addressFilter: `%${filter.address}%` });
          }
        }),
      );
    }
    queryBuilder.orderBy(`c.${sortBy}`, sortOrder);
    if (filter.page && filter.limit) {
      const take = filter.limit || 10;
      const skip = ((filter.page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }
    const [result, total] = await queryBuilder.getManyAndCount();
    const formattedItems = result.map((client) => ({
      id: client.id,
      name: client.name,
      email: client.email,
      phone: client.phone,
      address: client.type === HallClientsTypeEnum.FACILITY ? client.address : undefined,
      notes: client.notes,
      gender: client.type === HallClientsTypeEnum.INDIVIDUAL ? client.gender : undefined,
      nationalOrResidencyId:
        client.type === HallClientsTypeEnum.INDIVIDUAL ? client.nationalOrResidencyId : undefined,
      isVIB: client.isVIB,
      type: client.type,
      created_at: client.created_at,
      updated_at: client.updated_at,
      created_by: client.created_by,
      companyDetails:
        client.type === HallClientsTypeEnum.FACILITY
          ? {
              taxRegistrationNumber: client.company_details.taxRegistrationNumber,
              commercialRegistrationNumber: client.company_details.commercialRegistrationNumber,
            }
          : undefined,
      halls: client?.hallCustomers.map((hallCustomer) => ({
        id: hallCustomer.hall.id,
        name: hallCustomer.hall.name,
        name_ar: hallCustomer.hall.name_ar,
      })),
    }));

    return this.paginatorService.paginate(
      formattedItems,
      total,
      filter.page || 1,
      filter.limit || total,
    );
  }

  async findClient(id: number, user: AuthenticatedUser, select = {}): Promise<HallClientsEntity> {
    const { clientId, halls, type } = user;
    const queryConditions = {
      id,
      client: { id: clientId },
      deleted: false,
      hallCustomers: type === UserTypesEnum.employee ? { hall: In(halls) } : undefined,
    };
    const existClient = await this.hallsClientsRepo.findOne({
      where: queryConditions,
      select,
      relations: { hallCustomers: { hall: true } },
    });
    if (!existClient) {
      throw new BadRequestException(ErrorKeys.clientNotFound);
    }
    return existClient;
  }
  async getClient(id: number, user: AuthenticatedUser): Promise<HallClientsResponseDto> {
    const { clientId, halls, type } = user;
    const queryConditions = {
      id,
      client: { id: clientId },
      deleted: false,
      hallCustomers: type === UserTypesEnum.employee ? { hall: In(halls) } : undefined,
    };
    const existClient = await this.hallsClientsRepo.findOne({
      where: queryConditions,
      relations: { contacts: true, company_details: true, hallCustomers: { hall: true } },
    });
    if (!existClient) {
      throw new BadRequestException(ErrorKeys.clientNotFound);
    }

    return {
      id: existClient.id,
      name: existClient.name,
      email: existClient.email,
      phone: existClient.phone,
      address: existClient.type === HallClientsTypeEnum.FACILITY ? existClient.address : undefined,
      notes: existClient.notes,
      gender: existClient.type === HallClientsTypeEnum.INDIVIDUAL ? existClient.gender : undefined,
      nationalOrResidencyId:
        existClient.type === HallClientsTypeEnum.INDIVIDUAL
          ? existClient.nationalOrResidencyId
          : undefined,
      isVIB: existClient.isVIB,
      type: existClient.type,
      created_at: existClient.created_at,
      updated_at: existClient.updated_at,
      created_by: existClient.created_by,
      companyDetails:
        existClient.type === HallClientsTypeEnum.FACILITY
          ? {
              taxRegistrationNumber: existClient.company_details.taxRegistrationNumber,
              commercialRegistrationNumber:
                existClient.company_details.commercialRegistrationNumber,
            }
          : undefined,
      contacts: existClient?.contacts.map((contact) => ({
        id: contact.id,
        name: contact.name,
        phone: contact.phone,
        email: contact.email,
      })),
      halls: existClient?.hallCustomers.map((hallCustomer) => ({
        id: hallCustomer.hall.id,
        name: hallCustomer.hall.name,
        name_ar: hallCustomer.hall.name_ar,
      })),
    };
  }

  async updateClient(
    id: number,
    updateHallsClientsDto: UpdateHallsClientsDto,
    user: AuthenticatedUser,
  ): Promise<HallClientsResponseDto> {
    const {
      phone,
      email,
      halls,
      taxRegistrationNumber,
      commercialRegistrationNumber,
      nationalOrResidencyId,
    } = updateHallsClientsDto;
    const { clientId, id: userId } = user;
    const existClient = await this.findClient(id, user);
    checkUserPermissionType(user, existClient.created_by);
    let hallIds = existClient?.hallCustomers
      .map((hallCustomer) => hallCustomer.hall.id)
      .filter(Boolean);
    if (halls) {
      this.hallsService.validateHalls(halls);
      hallIds = halls.map((hall) => hall.id).filter(Boolean);
    }
    if (phone) {
      const existClient = await this.hallsClientsRepo.findOne({
        where: [
          {
            phone,
            client: { id: clientId },
            deleted: false,
            hallCustomers: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
        ],
      });
      if (existClient) {
        throw new BadRequestException(ErrorKeys.anotherClientExist);
      }
    }
    if (email) {
      const existEmail = await this.hallsClientsRepo.findOne({
        where: {
          email,
          client: { id: clientId },
          deleted: false,
          hallCustomers: { hall: { id: In(hallIds) } },
          id: Not(id),
        },
      });
      if (existEmail) {
        throw new BadRequestException(ErrorKeys.anotherClientExistByEmail);
      }
    }

    if (existClient.type === HallClientsTypeEnum.FACILITY) {
      if (commercialRegistrationNumber) {
        const existClient = await this.hallsClientsRepo.findOne({
          where: {
            client: { id: clientId },
            deleted: false,
            company_details: {
              commercialRegistrationNumber,
            },
            hallCustomers: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
        });
        if (existClient) {
          throw new BadRequestException(ErrorKeys.anotherClientExistByCommercial);
        }
      }
      if (taxRegistrationNumber) {
        const existClient = await this.hallsClientsRepo.findOne({
          where: {
            client: { id: clientId },
            deleted: false,
            company_details: {
              taxRegistrationNumber,
            },
            hallCustomers: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
        });
        if (existClient) {
          throw new BadRequestException(ErrorKeys.anotherClientExistByTax);
        }
      }
    }
    if (existClient.type === HallClientsTypeEnum.INDIVIDUAL && nationalOrResidencyId) {
      const existClientByNationalOrResidencyId = await this.hallsClientsRepo.findOne({
        where: {
          client: { id: clientId },
          deleted: false,
          nationalOrResidencyId,
          hallCustomers: { hall: { id: In(hallIds) } },
        },
      });
      if (existClientByNationalOrResidencyId) {
        throw new BadRequestException(ErrorKeys.anotherClientExistByNationalOrResidencyId);
      }
    }
    if (existClient.contacts) {
      this.validateContacts(existClient.contacts);
    }

    await this.updateCustomerTransaction.run({
      customer: updateHallsClientsDto,
      customerType: existClient.type,
      customerId: id,
      clientId,
      userId,
      halls,
    });

    return this.getClient(id, user);
  }
  async removeClient(id: number, user: AuthenticatedUser): Promise<HallClientsEntity> {
    const { clientId } = user;
    const existClient = await this.findClient(id, user, {
      id: true,
      name: true,
      email: true,
      phone: true,
      type: true,
      address: true,
      notes: true,
      created_by: true,
    });
    checkUserPermissionType(user, existClient.created_by);
    await this.deleteCustomerTransaction.run({
      customerId: id,
      userId: user.id,
    });
    return existClient;
  }

  async getCustomerForBooking(
    id: number,
    clientId: number,
    hallId: number,
  ): Promise<HallClientsEntity> {
    const existCustomer = await this.hallsClientsRepo.findOne({
      where: {
        id,
        client: { id: clientId },
        deleted: false,
      },
      relations: { company_details: true },
    });
    if (!existCustomer) {
      throw new BadRequestException(ErrorKeys.clientNotFound);
    }
    return existCustomer;
  }

  private validateContacts(contacts: contactDto[]): void {
    const contactEmails = contacts
      .map((contact) => contact.email) // Map to get the email
      .filter(Boolean); // Filter out undefined or null values

    const contactPhones = contacts
      .map((contact) => contact.phone) // Map to get the phone
      .filter(Boolean); // Filter out undefined or null values

    if (
      new Set(contactEmails).size !== contactEmails.length ||
      new Set(contactPhones).size !== contactPhones.length
    ) {
      throw new BadRequestException(ErrorKeys.contactsMustBeUnique);
    }
  }
}
