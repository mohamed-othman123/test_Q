import { UpdateHallsClientsDto } from './dtos/update-halls-clients.dto';
import { CurrentUser } from 'src/common/decorators/current-user.decorator';
import { CreateHallsClientsDto } from './dtos/create-halls-clients.dto';
import { HallsClientsService } from './halls-clients.service';
import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiHeader, ApiTags } from '@nestjs/swagger';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { hallsClientsPermissions } from './halls-clients.permissions';
import { FilterClientsDto } from './dtos/filter-halls-clients.dto';
import { HallClientsEntity } from './entities/halls-clients.entity';
import { EmployeeHallsInterceptor } from '../../auth/interceptors/halls-employee.interceptor';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { HallClientsResponseDto } from './dtos/hall-clients.response.dto';
import { bookingsPermissions } from '../booking/permissions/booking.permissions';

@ApiTags('halls-clients')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
@Controller('halls-clients')
export class HallsClientsController {
  constructor(private readonly hallsClientsService: HallsClientsService) {}
  @ApiBearerAuth()
  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(
    hallsClientsPermissions.CREATE_HALLS_CLIENTS
  )
  @Post()
  async createHallsClient(
    @Body() createHallsClientsDto: CreateHallsClientsDto,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<HallClientsResponseDto> {
    return await this.hallsClientsService.createHallsClient(createHallsClientsDto, user);
  }
  @ApiBearerAuth()
  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(hallsClientsPermissions.READ_HALLS_CLIENTS,bookingsPermissions.CREATE_BOOKING,bookingsPermissions.UPDATE_BOOKING)
  @Get()
  async filterClients(
    @Query() filter: FilterClientsDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<{
    items: HallClientsResponseDto[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return await this.hallsClientsService.filterClients(filter, user);
  }
  @ApiBearerAuth()
  @RequirePermissions(hallsClientsPermissions.READ_HALLS_CLIENTS)
  @Get('/:id')
  async getClient(
    @Param('id') id: number,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<HallClientsResponseDto> {
    return await this.hallsClientsService.getClient(id, user);
  }

  @ApiBearerAuth()
  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(hallsClientsPermissions.UPDATE_HALLS_CLIENTS)
  @Patch('/:id')
  async updateClient(
    @Param('id') id: number,
    @Body() updateHallsClientsDto: UpdateHallsClientsDto,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<HallClientsResponseDto> {
    return await this.hallsClientsService.updateClient(id, updateHallsClientsDto, user);
  }

  @ApiBearerAuth()
  @RequirePermissions(hallsClientsPermissions.DELETE_HALLS_CLIENTS)
  @Delete('/:id')
  async removeClient(
    @Param('id') id: number,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<HallClientsEntity> {
    return await this.hallsClientsService.removeClient(id, user);
  }
}
