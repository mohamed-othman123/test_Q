import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const servicesPermissions = {
  CREATE_SERVICE: {
    ar_name: 'إنشاء:الخدمة',
    en_name: 'create:service',
    ar_module: 'الخدمات',
    en_module: 'Services',
    order: 6,
    key: 'Services',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/services'",
  },
  READ_SERVICES: {
    ar_name: 'قراءة:الخدمات',
    en_name: 'read:services',
    ar_module: 'الخدمات',
    en_module: 'Services',
    order: 6,
    key: 'Services',
    type: PermissionsTypeEnum.READ,
    route: "GET '/services'",
  },
  UPDATE_SERVICE: {
    ar_name: 'تحديث:الخدمة',
    en_name: 'update:service',
    ar_module: 'الخدمات',
    en_module: 'Services',
    order: 6,
    key: 'Services',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/services/:id'",
  },
  DELETE_SERVICE: {
    ar_name: 'حذف:الخدمة',
    en_name: 'delete:service',
    ar_module: 'الخدمات',
    en_module: 'Services',
    order: 6,
    key: 'Services',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/services/:id'",
  },
};
