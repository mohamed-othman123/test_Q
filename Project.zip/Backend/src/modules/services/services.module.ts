import { forwardRef, Module } from '@nestjs/common';
import { ServicesService } from './services.service';
import { ServicesController } from './services.controller';
import { Service } from './entities/service.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HallServiceEntity } from './entities/halls_services.entity';
import { HallsModule } from '../halls/halls.module';
import { CreateServiceTransaction } from './utils/create-service.transactions';
import { UpdateServiceTransaction } from './utils/update-service.transactions';
import { DeleteServiceTransaction } from './utils/delete-service.transactions';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
import { SuppliersModule } from '../suppliers/suppliers.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Service, HallServiceEntity]),
    forwardRef(() => HallsModule),
    SuppliersModule,
  ],
  controllers: [ServicesController],
  providers: [
    ServicesService,
    CreateServiceTransaction,
    UpdateServiceTransaction,
    DeleteServiceTransaction,
    HallIdExtractor,
  ],
  exports: [ServicesService],
})
export class ServicesModule {}
