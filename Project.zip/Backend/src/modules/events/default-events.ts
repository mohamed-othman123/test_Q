export const defaultEvents = {
  wedding: {
    ar: {
      name: 'فرح',
      description: 'حفل زفاف',
    },
    en: {
      name: 'Wedding',
      description: 'Marriage ceremony',
    },
  },
  engagementParty: {
    ar: {
      name: 'ملكه',
      description: 'ملكه',
    },
    en: {
      name: 'Engagement Party',
      description: 'Engagement Party',
    },
  },
  conference: {
    ar: {
      name: 'مؤتمر',
      description: 'اجتماع أو ندوة كبيرة',
    },
    en: {
      name: 'Conference',
      description: 'Large meeting or seminar',
    },
  },
  workshop: {
    ar: {
      name: 'ورشة عمل',
      description: 'ورشة عمل',
    },
    en: {
      name: 'Workshop',
      description: 'Workshop',
    },
  },
  graduationCeremony: {
    ar: {
      name: 'حفل تخرج',
      description: 'حفل تخرج',
    },
    en: {
      name: 'Graduation Ceremony',
      description: 'Graduation Ceremony',
    },
  },
  awardCeremony: {
    ar: {
      name: 'حفل تكريم',
      description: 'حفل تكريم',
    },
    en: {
      name: 'Award Ceremony',
      description: 'Award Ceremony',
    },
  },
  trainingCourse: {
    ar: {
      name: 'دورة تدريبية',
      description: 'دورة تدريبية',
    },
    en: {
      name: 'Training Course',
      description: 'Training Course',
    },
  },
  Auction: {
    ar: {
      name: 'مزاد',
      description: 'مزاد',
    },
    en: {
      name: 'Auction',
      description: 'Auction',
    },
  },
  hosting: {
    ar: {
      name: 'ضيافة',
      description: 'ضيافة',
    },
    en: {
      name: 'Hosting',
      description: 'Hosting',
    },
  },
};
