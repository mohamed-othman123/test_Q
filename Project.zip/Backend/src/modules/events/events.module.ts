import { forwardRef, Module } from '@nestjs/common';
import { EventsService } from './events.service';
import { EventsController } from './events.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EventsEntity } from './entities/event.entity';
import { PaginatorModule } from 'src/common/paginator/paginator.module';
import { UpdateEventTransaction } from './utils/update-event.transactions';
import { DeleteEventTransaction } from './utils/delete-event.transaction';
import { HallsModule } from '../halls/halls.module';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
@Module({
  imports: [
    TypeOrmModule.forFeature([EventsEntity]),
    PaginatorModule,
    forwardRef(() => HallsModule),
  ],
  controllers: [EventsController],
  providers: [EventsService, UpdateEventTransaction, DeleteEventTransaction, HallIdExtractor],
  exports: [EventsService],
})
export class EventsModule {}
