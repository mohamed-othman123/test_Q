import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const eventsPermissions = {
  CREATE_EVENT_TYPE: {
    ar_name: 'إنشاء:المناسبات',
    en_name: 'create:events',
    ar_module: 'المناسبات',
    en_module: 'Events',
    order: 15,
    key: 'Events',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/events'",
  },
  READ_EVENTS_TYPES: {
    ar_name: 'قراءة:المناسبات',
    en_name: 'read:events',
    ar_module: 'المناسبات',
    en_module: 'Events',
    order: 15,
    key: 'Events',
    type: PermissionsTypeEnum.READ,
    route: "GET '/events'",
  },
  UPDATE_EVENT_TYPE: {
    ar_name: 'تحديث:المناسبات',
    en_name: 'update:events',
    ar_module: 'المناسبات',
    en_module: 'Events',
    order: 15,
    key: 'Events',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/events/:id'",
  },
  DELETE_EVENT_TYPE: {
    ar_name: 'حذف:المناسبات',
    en_name: 'delete:events',
    ar_module: 'المناسبات',
    en_module: 'Events',
    order: 15,
    key: 'Events',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/events/:id'",
  },
};
