import { PaginatorService } from './../../common/paginator/paginator.service';
import { BadRequestException, forwardRef, Inject, Injectable } from '@nestjs/common';
import { CreateEventDto } from './dto/create-event.dto';
import { UpdateEventDto } from './dto/update-event.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { EventsEntity } from './entities/event.entity';
import { Brackets, In, Not, Repository } from 'typeorm';
import { FilterEventsDto, SortByOptions } from './dto/filter-events.dto';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { UpdateEventTransaction } from './utils/update-event.transactions';
import { DeleteEventTransaction } from './utils/delete-event.transaction';
import { EventDetails } from './interfaces/eventDetails.interface';
import { checkUserPermissionType, HandelTwoName } from '../../core/helpers/cast.helper';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { HallsService } from '../halls/halls.service';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { PricingCalculationType } from 'src/common/enums/pricingCalculationType.enum';
export class EventsService {
  constructor(
    @InjectRepository(EventsEntity) private readonly eventsRepo: Repository<EventsEntity>,
    private readonly paginatorService: PaginatorService,
    private readonly updateEventTransaction: UpdateEventTransaction,
    private readonly deleteEventTransaction: DeleteEventTransaction,
    private readonly eventEmitter: EventEmitter2,
    @Inject(forwardRef(() => HallsService))
    private readonly hallsService: HallsService,
  ) {}

  async createEvent(
    createEventDto: CreateEventDto,
    user: AuthenticatedUser,
  ): Promise<EventDetails> {
    let { halls, name, name_ar } = createEventDto;
    const { clientId, id: userId } = user;
    if (!name && !name_ar) {
      throw new BadRequestException(ErrorKeys.nameIsRequired);
    }
    this.hallsService.validateHalls(halls);
    const hallIds = halls.map((hall) => hall.id).filter(Boolean);
    [name, name_ar] = HandelTwoName(name, name_ar);
    const existEvent = await this.eventsRepo.findOne({
      where: [
        {
          name,
          client: { id: clientId },
          deleted: false,
          hallEvents: { hall: { id: In(hallIds) } },
        },
        {
          name: name_ar,
          client: { id: clientId },
          deleted: false,
          hallEvents: { hall: { id: In(hallIds) } },
        },
        {
          name_ar,
          client: { id: clientId },
          deleted: false,
          hallEvents: { hall: { id: In(hallIds) } },
        },
        {
          name_ar: name,
          client: { id: clientId },
          deleted: false,
          hallEvents: { hall: { id: In(hallIds) } },
        },
      ],
    });
    if (existEvent) {
      throw new BadRequestException(ErrorKeys.eventExists);
    }
    const savedEvent = await this.eventsRepo.save({
      ...createEventDto,
      name,
      name_ar,
      created_by: userId,
      client: { id: clientId },
      hallEvents: halls.map((hall) => ({ hall: { id: hall.id } })),
    });
    await this.emiteventEmitterAfterChange(savedEvent.id, clientId);
    return await this.getEvent(savedEvent.id, user);
  }

  async updateEvent(
    id: number,
    updateEventDto: UpdateEventDto,
    user: AuthenticatedUser,
  ): Promise<EventDetails> {
    const { halls, name, name_ar } = updateEventDto;
    const { clientId, id: userId } = user;
    const event = await this.findEvent(id, user);
    checkUserPermissionType(user, event.created_by);

    let hallIds = event?.hallEvents.map((hallEvent) => hallEvent.hall.id).filter(Boolean);
    if (halls) {
      this.hallsService.validateHalls(halls);
      hallIds = halls.map((hall) => hall.id).filter(Boolean);
    }
    if (name || name_ar) {
      await this.findEventByName(id, name ?? null, name_ar ?? null, clientId, hallIds);
    }
    await this.updateEventTransaction.run({
      event: updateEventDto,
      eventId: id,
      clientId,
      userId,
    });
    if (halls) {
      await this.emiteventEmitterAfterChange(id, clientId);
    }
    return await this.getEvent(id, user);
  }

  async findEvent(id: number, user: AuthenticatedUser, select = {}): Promise<EventsEntity> {
    const { clientId, halls, type } = user;
    const queryConditions = {
      id,
      client: { id: clientId },
      deleted: false,
      hallEvents: type === UserTypesEnum.employee ? { hall: In(halls) } : undefined,
    };
    const existEvent = await this.eventsRepo.findOne({
      where: queryConditions,
      select,
      relations: { hallEvents: { hall: true } },
    });
    if (!existEvent) {
      throw new BadRequestException(ErrorKeys.eventNotFound);
    }
    return existEvent;
  }

  async getEvent(id: number, user: AuthenticatedUser): Promise<EventDetails> {
    const { clientId, halls, type } = user;
    const queryConditions = {
      id,
      client: { id: clientId },
      deleted: false,
      hallEvents: type === UserTypesEnum.employee ? { hall: In(halls) } : undefined,
    };
    const existEvent = await this.eventsRepo.findOne({
      where: queryConditions,
      relations: { hallEvents: { hall: true } },
    });
    if (!existEvent) {
      throw new BadRequestException(ErrorKeys.eventNotFound);
    }
    return {
      id: existEvent.id,
      created_by: existEvent.created_by,
      created_at: existEvent.created_at,
      updated_at: existEvent.updated_at,
      name: existEvent.name,
      name_ar: existEvent.name_ar,
      priceCalculationType: existEvent.priceCalculationType,
      insuranceAmount: existEvent.insuranceAmount,
      description: existEvent.description,
      halls: existEvent?.hallEvents.map((hallEvent) => ({
        id: hallEvent.hall.id,
        name: hallEvent.hall.name,
        name_ar: hallEvent.hall.name_ar,
      })),
    };
  }

  async listEventsTypes(
    filter: FilterEventsDto,
    user: AuthenticatedUser,
  ): Promise<{
    items: EventDetails[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    const { clientId } = user;
    const { page, limit } = filter;
    let { sortBy, sortOrder } = filter;
    sortBy = sortBy || SortByOptions.createdAt;
    sortOrder = sortOrder || SortOrderEnum.DESC;

    const queryBuilder = this.eventsRepo
      .createQueryBuilder('e')
      .leftJoinAndSelect('e.hallEvents', 'hallEvent')
      .leftJoinAndSelect('hallEvent.hall', 'hall');

    const hasFilterKeys = filter.creationDate || filter.name || filter.description;
    if (!filter.generalSearch && !hasFilterKeys) {
      queryBuilder
        .where('e.client_id = :clientId', { clientId })
        .andWhere('e.deleted = :deleted', { deleted: false })
        .andWhere('hall.id=:hallId', {
          hallId: filter.hallId,
        });
    }
    if (hasFilterKeys) {
      queryBuilder.where(
        new Brackets((qb) => {
          qb.where('e.client_id = :clientId', { clientId })
            .andWhere('e.deleted = :deleted', {
              deleted: false,
            })
            .andWhere('hall.id=:hallId', {
              hallId: filter.hallId,
            });
          if (filter.creationDate) {
            qb.andWhere('DATE(e.created_at) = :creationDate', {
              creationDate: filter.creationDate,
            });
          }
          if (filter.description) {
            qb.andWhere('e.description ILIKE :descriptionFilter', {
              descriptionFilter: `%${filter.description}%`,
            });
          }
          if (filter.name) {
            qb.andWhere('(e.name ILIKE :nameFilter OR e.name_ar ILIKE :nameFilter)', {
              nameFilter: `%${filter.name}%`,
            });
          }
        }),
      );
    }
    if (filter.generalSearch) {
      queryBuilder.orWhere(
        new Brackets((qb) => {
          qb.where('e.client_id = :clientId', { clientId }).andWhere('e.deleted = :deleted', {
            deleted: false,
          });
          qb.andWhere(
            new Brackets((subQb) => {
              subQb
                .where('e.name ILIKE :generalSearch', {
                  generalSearch: `%${filter.generalSearch}%`,
                })
                .orWhere('e.name_ar ILIKE :generalSearch', {
                  generalSearch: `%${filter.generalSearch}%`,
                })
                .orWhere('e.description ILIKE :generalSearch', {
                  generalSearch: `%${filter.generalSearch}%`,
                });
            }),
          );
        }),
      );
    }
    if (sortBy === SortByOptions.name) {
      queryBuilder.orderBy(`e.name`, sortOrder).addOrderBy(`e.name_ar`, sortOrder);
    } else {
      queryBuilder.orderBy(`e.${sortBy}`, sortOrder);
    }
    if (page && limit) {
      const take = limit || 10;
      const skip = ((page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }
    const [result, total] = await queryBuilder.getManyAndCount();

    const formattedItems = result.map((event) => ({
      id: event.id,
      created_by: event.created_by,
      created_at: event.created_at,
      updated_at: event.updated_at,
      name: event.name,
      name_ar: event.name_ar,
      priceCalculationType: event.priceCalculationType,
      insuranceAmount: event.insuranceAmount,
      description: event.description,
      halls: event?.hallEvents.map((he) => ({
        id: he.hall.id,
        name: he.hall.name,
        name_ar: he.hall.name_ar,
      })),
    }));

    return this.paginatorService.paginate(formattedItems, total, page || 1, limit || total);
  }

  async removeEvent(id: number, user: AuthenticatedUser): Promise<EventsEntity> {
    const { clientId } = user;
    const event = await this.findEvent(id, user, {
      id: true,
      name: true,
      name_ar: true,
      description: true,
      created_at: true,
      created_by: true,
    });
    checkUserPermissionType(user, event.created_by);
    await this.deleteEventTransaction.run({
      eventId: id,
      userId: user.id,
    });
    await this.emiteventEmitterAfterChange(id, clientId);
    return { ...event, deleted: true, deleted_at: new Date(), deleted_by: user.id };
  }
  private async findEventByName(
    id: number,
    name: string,
    name_ar: string,
    clientId: number,
    hallIds: number[],
  ): Promise<void> {
    let existEvent = undefined;

    if (name && name_ar) {
      existEvent = await this.eventsRepo.findOne({
        where: [
          {
            name,
            client: { id: clientId },
            deleted: false,
            hallEvents: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name: name_ar,
            client: { id: clientId },
            deleted: false,
            hallEvents: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name_ar,
            client: { id: clientId },
            deleted: false,
            hallEvents: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name_ar: name,
            client: { id: clientId },
            deleted: false,
            hallEvents: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
        ],
      });
    } else if (name) {
      existEvent = await this.eventsRepo.findOne({
        where: [
          {
            name,
            client: { id: clientId },
            deleted: false,
            hallEvents: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name_ar: name,
            client: { id: clientId },
            deleted: false,
            hallEvents: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
        ],
      });
    } else {
      existEvent = await this.eventsRepo.findOne({
        where: [
          {
            name: name_ar,
            client: { id: clientId },
            deleted: false,
            hallEvents: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name_ar,
            client: { id: clientId },
            deleted: false,
            hallEvents: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
        ],
      });
    }
    if (existEvent) {
      throw new BadRequestException(ErrorKeys.eventExists);
    }
  }

  validateEvents(events: { eventId: number }[]): void {
    const eventsIds = events.map((event) => event.eventId);

    if (new Set(eventsIds).size !== eventsIds.length) {
      throw new BadRequestException(ErrorKeys.eventsMustBeUnique);
    }
  }
  // Validate that the events exist for a given hall
  async validateExistingEvents(
    clientId: number,
    eventsIds: number[],
    hallId: number,
  ): Promise<void> {
    const existingevents = await this.getEventsInRange(clientId, eventsIds, hallId);
    const existingEventIds = existingevents.map((event) => event.id);

    // Check for events that do not exist
    const notExistsEvents = eventsIds.filter((id) => !existingEventIds.includes(id));

    if (notExistsEvents.length > 0) {
      throw new BadRequestException(ErrorKeys.eventNotFound);
    }
  }
  // Retrieve events based on their IDs
  async getEventsInRange(
    clientId: number,
    eventIds: number[],
    hallId: number,
  ): Promise<EventsEntity[]> {
    return await this.eventsRepo.find({
      where: {
        id: In(eventIds),
        client: { id: clientId },
        deleted: false,
        hallEvents: { hall: { id: hallId } },
      },
      select: ['id', 'name', 'priceCalculationType'],
    });
  }

  // Validate that the pricing events exist for a given hall
  async validateExsistingEventPricings(
    clientId: number,
    eventsIds: number[],
    hallId: number,
  ): Promise<void> {
    const existingevents = await this.getEventsInRange(clientId, eventsIds, hallId);
    const existingEventIds = existingevents.map((event) => event.id);

    // Check for events that do not exist
    const notExistsEvents = eventsIds.filter((id) => !existingEventIds.includes(id));

    if (notExistsEvents.length > 0) {
      throw new BadRequestException(ErrorKeys.eventNotFound);
    }
    const existingeventPricing = existingevents.filter(
      (event) => event.priceCalculationType !== PricingCalculationType.BOOKING_TIME,
    );
    if (existingeventPricing.length > 0) {
      throw new BadRequestException(ErrorKeys.eventPricingExsist);
    }
  }

  private async emiteventEmitterAfterChange(eventId: number, clientId: number): Promise<void> {
    const event = await this.eventsRepo.findOne({
      where: { id: eventId, client: { id: clientId }, deleted: false },
      relations: { hallEvents: { hall: { landingPage: true } } },
    });
    const landingHallNames: string[] = []; // Initialize an empty array
    if (event && event.hallEvents) {
      event.hallEvents.forEach((hallEvent) => {
        if (hallEvent?.hall?.landingPage)
          landingHallNames.push(hallEvent.hall.landingPage.hallName);
      });
    }

    // Emit the event with the array of hall names
    if (landingHallNames.length > 0) {
      this.eventEmitter.emit('hall.updated', {
        landingHallNames,
      });
    }
  }

  // @OnEvent('client.admin.verified')
  // async seedDefaultsEvent(dto): Promise<void> {
  //   let newEvents = [];
  //   const { clientId, lang,userId } = dto;
  //   const events = Object.values(defaultEvents);
  //   for (const event of events) {
  //     const eventType = this.eventsRepo.create({
  //       name: event['en'].name,
  //       name_ar: event['ar'].name,
  //       isDefault: true,
  //       description: event[lang].description,
  //       client: { id: clientId },
  //       created_by:userId
  //     });
  //     newEvents.push(eventType);
  //   }
  //   await this.eventsRepo.save(newEvents);
  // }
}
