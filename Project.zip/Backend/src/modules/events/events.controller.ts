import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { EventsService } from './events.service';
import { CreateEventDto } from './dto/create-event.dto';
import { UpdateEventDto } from './dto/update-event.dto';
import { CurrentUser } from 'src/common/decorators/current-user.decorator';
import { ApiBearerAuth, ApiHeader, ApiTags } from '@nestjs/swagger';
import { RequirePermissions } from 'src/auth/decorator/require-permissions.decorator';
import { eventsPermissions } from './events.permissions';
import { FilterEventsDto } from './dto/filter-events.dto';
import { EventDetails } from './interfaces/eventDetails.interface';
import { EventsEntity } from './entities/event.entity';
import { EmployeeHallsInterceptor } from '../../auth/interceptors/halls-employee.interceptor';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { bookingsPermissions } from '../booking/permissions/booking.permissions';

@ApiTags('events')
@Controller('events')
@ApiBearerAuth()
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class EventsController {
  constructor(private readonly eventsService: EventsService) {}

  @RequirePermissions(eventsPermissions.CREATE_EVENT_TYPE)
  @UseInterceptors(EmployeeHallsInterceptor)
  @Post()
  async create(
    @Body() createEventDto: CreateEventDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<EventDetails> {
    return this.eventsService.createEvent(createEventDto, user);
  }

  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(eventsPermissions.READ_EVENTS_TYPES, bookingsPermissions.CREATE_BOOKING,bookingsPermissions.UPDATE_BOOKING)
  @Get()
  async listEventsTypes(
    @Query() filter: FilterEventsDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<{
    items: EventDetails[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return this.eventsService.listEventsTypes(filter, user);
  }
  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(eventsPermissions.UPDATE_EVENT_TYPE)
  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() updateEventDto: UpdateEventDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<EventDetails> {
    return this.eventsService.updateEvent(+id, updateEventDto, user);
  }

  @RequirePermissions(eventsPermissions.READ_EVENTS_TYPES)
  @Get(':id')
  async getEvent(
    @Param('id') id: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<EventDetails> {
    return this.eventsService.getEvent(+id, user);
  }

  @RequirePermissions(eventsPermissions.DELETE_EVENT_TYPE)
  @Delete(':id')
  async removeEvent(
    @Param('id') id: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<EventsEntity> {
    return this.eventsService.removeEvent(+id, user);
  }
}
