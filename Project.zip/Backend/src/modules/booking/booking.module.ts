import { forwardRef, Module, OnModuleInit } from '@nestjs/common';
import { BookingService } from './services/booking.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Booking } from './entities/booking.entity';
import { BookingServiceEntity } from './entities/BookingServices.entity';
import { ServicesModule } from '../services/services.module';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { ContractsModule } from '../contracts/contracts.module';
import { HallsModule } from '../halls/halls.module';
import { FileUploadModule } from '../../common/utilities/file-upload/file-upload.module';
import { PdfGenerationModule } from '../pdf-generation/pdf-generation.module';
import { BookingTransactionRepo } from './repos/bookings.repos';
import { HallsClientsModule } from '../hall-clients/halls-clients.module';
import { EventsModule } from '../events/events.module';
import { ClientsModule } from '../clients/clients.module';
//import { BookingContractService } from './services/booking_contract.services';
import { BookingController } from './controllers/booking.controller';
//import { PreviewContractController } from './controllers/contract_pdf.controller';
import { I18nResponse } from 'src/core/helpers/i18.helper';
import { PaymentModule } from '../payment/payment.module';
import { HallSectionsModule } from '../hall-sections/hall-sections.module';
import { BookingAttachmentsController } from './controllers/booking-attachments.controller';
import { BookingAttachmentsService } from './services/booking-attachments.service';
import { BookingAttachmentsEntity } from './entities/booking_attachments.entity';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
import { MailerAppModule } from '../../providers/mailer/mailer.module';
import { HallTeamMembersModule } from '../hall-team-members/hall-team-member.module';
import { PricingModule } from '../prices/pricing.module';
import { DocumentService } from '../pdf-generation/services/document.service';
import { PaymentService } from '../payment/services/payment.service';
import { DiscountsModule } from '../discounts/discount.module';
import { CaptchaModule } from '../../common/captcha/captcha.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Booking, BookingServiceEntity, BookingAttachmentsEntity]),
    ServicesModule,
    PaginatorModule,
    ContractsModule,
    HallsModule,
    FileUploadModule,
    forwardRef(() => PdfGenerationModule),
    HallsClientsModule,
    EventsModule,
    ClientsModule,
    HallSectionsModule,
    forwardRef(() => PaymentModule),
    MailerAppModule,
    HallTeamMembersModule,
    PricingModule,
    DiscountsModule,
    CaptchaModule,
  ],
  controllers: [BookingController, BookingAttachmentsController],
  providers: [
    BookingService,
    BookingAttachmentsService,
    BookingTransactionRepo,
    //BookingContractService,
    I18nResponse,
    HallIdExtractor,
  ],
  exports: [BookingService],
})
export class BookingModule implements OnModuleInit {
  constructor(
    private readonly bookingService: BookingService,
    private readonly documentService: DocumentService,
    private readonly paymentService: PaymentService,
  ) {}

  async onModuleInit() {
    // Seed default PDFs for bookings and payments and hash documents
    await this.bookingService.seedDefaultPdfForBookings();
    await this.paymentService.seedDefaultReceiptPdfs();
    await this.documentService.seedDocumentHashes();
  }
}
