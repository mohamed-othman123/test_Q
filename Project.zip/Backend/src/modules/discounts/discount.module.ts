import { Module } from '@nestjs/common';
import { DiscountsService } from './discount.service';
import { DiscountsController } from './discount.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DiscountEntity } from './entities/discount.entity';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { UpdateDiscountTransaction } from './utils/update-discount.transaction';

@Module({
  imports: [TypeOrmModule.forFeature([DiscountEntity]), PaginatorModule],
  controllers: [DiscountsController],
  providers: [DiscountsService, UpdateDiscountTransaction],
  exports: [DiscountsService],
})
export class DiscountsModule { }
