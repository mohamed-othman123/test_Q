import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
  UseGuards,
} from '@nestjs/common';
import { DiscountsService } from './discount.service';
import { CreateDiscountDto } from './dto/create-discount.dto';
import { UpdateDiscountDto } from './dto/update-discount.dto';
import { ApiBearerAuth, ApiHeader, ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { FilterDiscountsDto } from './dto/filter-discount.dto';
import { UserTypes } from '../../common/decorators/user-types.decorator';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { discountPermissions } from './discount.permissions';
import { DiscountResponseDto } from './dto/discount.response.dto';
import { UserTypeGuard } from '../../common/guards/user-types.guard';
import { bookingsPermissions } from '../booking/permissions/booking.permissions';
@ApiTags('discounts')
@UseGuards(UserTypeGuard)
@Controller('discounts')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
@ApiBearerAuth()
export class DiscountsController {
  constructor(private readonly discountsService: DiscountsService) {}
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(discountPermissions.CREATE_SPECIAL_DISCOUNTS)
  @Post()
  async createDiscount(
    @Body() createDiscountDto: CreateDiscountDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<DiscountResponseDto> {
    return this.discountsService.createDiscount(createDiscountDto, user);
  }
  @RequirePermissions(discountPermissions.READ_SPECIAL_DISCOUNTS,bookingsPermissions.CREATE_BOOKING,bookingsPermissions.UPDATE_BOOKING)
  @Get()
  async filterDiscounts(
    @Query() filter: FilterDiscountsDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<{
    items: DiscountResponseDto[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return this.discountsService.filterDiscounts(filter, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(discountPermissions.READ_SPECIAL_DISCOUNTS)
  @Get(':id')
  async findDiscount(
    @Param('id') id: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<DiscountResponseDto> {
    return this.discountsService.findDiscount(+id, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(discountPermissions.UPDATE_SPECIAL_DISCOUNTS)
  @Patch(':id')
  async updateDiscount(
    @Param('id') id: string,
    @Body() updateDiscountDto: UpdateDiscountDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<DiscountResponseDto> {
    return this.discountsService.updateDiscount(+id, updateDiscountDto, user);
  }
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner)
  @RequirePermissions(discountPermissions.DELETE_SPECIAL_DISCOUNTS)
  @Delete(':id')
  async removeDiscount(
    @Param('id') id: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<DiscountResponseDto> {
    return this.discountsService.removeDiscount(+id, user);
  }
}
