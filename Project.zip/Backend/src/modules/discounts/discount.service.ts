import { BadRequestException, Injectable } from '@nestjs/common';
import { CreateDiscountDto } from './dto/create-discount.dto';
import { UpdateDiscountDto } from './dto/update-discount.dto';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { DiscountResponseDto } from './dto/discount.response.dto';
import { FilterDiscountsDto, SortByOptions } from './dto/filter-discount.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, Not, Repository } from 'typeorm';
import { DiscountEntity } from './entities/discount.entity';
import { PaginatorService } from '../../common/paginator/paginator.service';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { UpdateDiscountTransaction } from './utils/update-discount.transaction';

@Injectable()
export class DiscountsService {
  constructor(
    @InjectRepository(DiscountEntity) private readonly discountRepo: Repository<DiscountEntity>,
    private readonly paginatorService: PaginatorService,
    private readonly updateDiscountTransaction: UpdateDiscountTransaction,
  ) { }

  async createDiscount(createDiscountDto: CreateDiscountDto, user: AuthenticatedUser): Promise<DiscountResponseDto> {
    const { clientId, id: userId } = user
    const { name, type, value, note } = createDiscountDto
    const existDiscountByCode = await this.discountRepo.findOne({ where: { name, deleted: false, client: { id: clientId } } })
    if (existDiscountByCode) {
      throw new BadRequestException(ErrorKeys.discountExist)
    }
    
    const DiscountEntity = this.discountRepo.create({
      name,
      type,
      value,
      note,
      created_by: userId,
      client: { id: clientId }
    })
    const savedDiscount = await this.discountRepo.save(DiscountEntity)

    return this.findDiscount(savedDiscount.id, user)
  }

  async filterDiscounts(filter: FilterDiscountsDto, user: AuthenticatedUser): Promise<{
    items: DiscountResponseDto[], totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    let { sortBy, sortOrder, page, limit, name, type, value, note, creationDate } = filter;
    sortBy = sortBy || SortByOptions.createdAt;
    sortOrder = sortOrder || SortOrderEnum.DESC;
    const { clientId, id: userId } = user;

    const queryBuilder = this.discountRepo
      .createQueryBuilder('discount')
    const hasFilterKeys = name || type || value !== undefined || note || creationDate
    if (!hasFilterKeys) {
      queryBuilder
        .where('discount.client_id = :clientId', { clientId })
        .andWhere('discount.deleted = :deleted', { deleted: false });
    }
    if (hasFilterKeys) {
      queryBuilder.where(
        new Brackets((qb) => {
          qb.where('discount.client_id = :clientId', { clientId }).andWhere('discount.deleted = :deleted', {
            deleted: false,
          });
          if (creationDate) {
            qb.andWhere('DATE(discount.created_at) = :creationDate', {
              creationDate,
            });
          }
          if (name) {
            qb.andWhere('discount.name ILIKE :nameFilter', {
              nameFilter: `%${name}%`,
            });
          }
          if (type) {
            qb.andWhere('discount.type = :typeFilter', { typeFilter: type });
          }
          if (value !== undefined) {
            qb.andWhere('discount.value = :valueFilter', { valueFilter: value });
          }
          if (note) {
            qb.andWhere('discount.note ILIKE :noteFilter', {
              noteFilter: `%${note}%`,
            });
          }
        }),
      );
    }
    queryBuilder.orderBy(`discount.${sortBy}`, sortOrder);
    if (page && limit) {
      const take = limit || 10;
      const skip = ((page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }
    const [result, total] = await queryBuilder.getManyAndCount();

    const formattedItems = result.map((discount) => {
      return {
        id: discount.id,
        created_at: discount.created_at,
        updated_at: discount.updated_at,
        name: discount.name,
        type: discount.type,
        note: discount.note,
        value: discount.value
      };
    });

    return this.paginatorService.paginate(formattedItems, total, page || 1, limit || total);
  }

  async findDiscount(id: number, user: AuthenticatedUser): Promise<DiscountResponseDto> {
    const { clientId } = user
    const existDiscount = await this.discountRepo.findOne({ where: { id, deleted: false, client: { id: clientId } } })
    if (!existDiscount) {
      throw new BadRequestException(ErrorKeys.discountNotFound)
    }
    return {
      id: existDiscount.id,
      created_at: existDiscount.created_at,
      updated_at: existDiscount.updated_at,
      name: existDiscount.name,
      type: existDiscount.type,
      note: existDiscount.note,
      value: existDiscount.value
    };
  }

  async updateDiscount(id: number, updateDiscountDto: UpdateDiscountDto, user: AuthenticatedUser): Promise<DiscountResponseDto> {
    const { clientId, id: userId } = user
    const { name, type, value, note } = updateDiscountDto
    const existDiscount = await this.discountRepo.findOne({ where: { id, deleted: false, client: { id: clientId } } })
    if (!existDiscount) {
      throw new BadRequestException(ErrorKeys.discountNotFound)
    }
    if (name) {
      const existDiscountByname = await this.discountRepo.findOne({ where: { id: Not(id), name, deleted: false, client: { id: clientId } } })
      if (existDiscountByname) {
        throw new BadRequestException(ErrorKeys.discountExist)
      }
    }
    const savedDiscount = await this.updateDiscountTransaction.run({ oldDiscount: existDiscount, discount: updateDiscountDto, discountId: id, clientId, userId });
    return this.findDiscount(savedDiscount.id, user);
  }

  async removeDiscount(id: number, user: AuthenticatedUser): Promise<DiscountResponseDto> {
    const existDiscount = await this.findDiscount(id, user)
    await this.discountRepo.update(id, { deleted: true, deleted_at: new Date() })
    return { ...existDiscount, deleted_at: new Date() };
  }
}
