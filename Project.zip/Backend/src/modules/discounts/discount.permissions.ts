import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const discountPermissions = {
  CREATE_SPECIAL_DISCOUNTS: {
    ar_name: 'إنشاء:الخصومات الخاصة',
    en_name: 'create:specialDiscounts',
    ar_module: 'الخصومات الخاصة',
    en_module: 'Special discounts',
    order: 20,
    key: 'Special discounts',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/discounts'",
  },
  READ_SPECIAL_DISCOUNTS: {
    ar_name: 'قراءة:الخصومات الخاصة',
    en_name: 'read:specialDiscounts',
    ar_module: 'الخصومات الخاصة',
    en_module: 'Special discounts',
    order: 20,
    key: 'Special discounts',
    type: PermissionsTypeEnum.READ,
    route: "GET '/discounts'",
  },
  UPDATE_SPECIAL_DISCOUNTS: {
    ar_name: 'تحديث:الخصومات الخاصة',
    en_name: 'update:specialDiscounts',
    ar_module: 'الخصومات الخاصة',
    en_module: 'Special discounts',
    order: 20,
    key: 'Special discounts',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/discounts/:id'",
  },
  DELETE_SPECIAL_DISCOUNTS: {
    ar_name: 'حذف:الخصومات الخاصة',
    en_name: 'delete:specialDiscounts',
    ar_module: 'الخصومات الخاصة',
    en_module: 'Special discounts',
    order: 20,
    key: 'Special discounts',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/discounts/:id'",
  },
};
