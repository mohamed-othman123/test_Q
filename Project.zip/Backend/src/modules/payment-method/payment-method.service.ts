import { BadRequestException, forwardRef, Inject, Injectable } from '@nestjs/common';
import { CreatePaymentMethodDto } from './dto/create-payment-method.dto';
import { UpdatePaymentMethodDto } from './dto/update-payment-method.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { PaymentMethod } from './entities/payment-method.entity';
import { Brackets, In, Not, Repository } from 'typeorm';
import { PaginatorService } from '../../common/paginator/paginator.service';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { GetPaymentMethods, SortByOptions } from './dto/get-payment-methods.dto';
import { PaymentMethodsDetails } from './interfaces/paymentMethodDetails.interface';
import { UpdatePaymentMethodTransaction } from './utils/update-payment-methods.transactions';
import { DeletePaymentMethodTransaction } from './utils/delete-payment-methods.transaction';
import { checkUserPermissionType, HandelTwoName } from '../../core/helpers/cast.helper';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { HallsService } from '../halls/halls.service';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';

@Injectable()
export class PaymentMethodService {
  constructor(
    @InjectRepository(PaymentMethod)
    private readonly paymentMethodRepository: Repository<PaymentMethod>,
    private readonly updatePaymentMethodTransaction: UpdatePaymentMethodTransaction,
    private readonly deletePaymentMethodTransaction: DeletePaymentMethodTransaction,
    private readonly paginatorService: PaginatorService,
    @Inject(forwardRef(() => HallsService))
    private readonly hallsService: HallsService,
  ) {}

  async create(
    createPaymentMethodDto: CreatePaymentMethodDto,
    user: AuthenticatedUser,
  ): Promise<PaymentMethodsDetails> {
    let { halls, name, name_ar } = createPaymentMethodDto;
    const { clientId, id: userId } = user;
    if (!name && !name_ar) {
      throw new BadRequestException(ErrorKeys.nameIsRequired);
    }
    this.hallsService.validateHalls(halls);
    const hallIds = halls.map((hall) => hall.id).filter(Boolean);
    [name, name_ar] = HandelTwoName(name, name_ar);

    const existPaymentMethod = await this.paymentMethodRepository.findOne({
      where: [
        {
          name,
          client: { id: clientId },
          deleted: false,
          hallPaymentMethods: { hall: { id: In(hallIds) } },
        },
        {
          name: name_ar,
          client: { id: clientId },
          deleted: false,
          hallPaymentMethods: { hall: { id: In(hallIds) } },
        },
        {
          name_ar,
          client: { id: clientId },
          deleted: false,
          hallPaymentMethods: { hall: { id: In(hallIds) } },
        },
        {
          name_ar: name,
          client: { id: clientId },
          deleted: false,
          hallPaymentMethods: { hall: { id: In(hallIds) } },
        },
      ],
    });
    if (existPaymentMethod) {
      throw new BadRequestException(ErrorKeys.paymentMethodExists);
    }

    const paymentMethod = await this.paymentMethodRepository.save({
      ...createPaymentMethodDto,
      name,
      name_ar,
      created_by: userId,
      client: { id: clientId },
      hallPaymentMethods: halls.map((hall) => ({ hall: { id: hall.id } })),
    });

    return this.findOne(paymentMethod.id, user);
  }

  async findAll(
    filter: GetPaymentMethods,
    user: AuthenticatedUser,
  ): Promise<{
    items: PaymentMethodsDetails[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    let { page, limit, name, description, hallId, sortBy, sortOrder } = filter;
    const { clientId } = user;
    sortBy = sortBy || SortByOptions.createdAt;
    sortOrder = sortOrder || SortOrderEnum.DESC;
    const queryBuilder = this.paymentMethodRepository
      .createQueryBuilder('p')
      .leftJoinAndSelect('p.hallPaymentMethods', 'hallPaymentMethod')
      .leftJoinAndSelect('hallPaymentMethod.hall', 'hall');
    const hasFilterKeys = name || description || filter.creationDate;
    if (!hasFilterKeys) {
      queryBuilder
        .where('p.client_id = :clientId', { clientId })
        .andWhere('p.deleted = :deleted', { deleted: false })
        .andWhere('hall.id=:hallId', {
          hallId,
        });
    }
    if (hasFilterKeys) {
      queryBuilder.where(
        new Brackets((qb) => {
          qb.where('p.client_id = :clientId', { clientId })
            .andWhere('p.deleted = :deleted', {
              deleted: false,
            })
            .andWhere('hall.id=:hallId', {
              hallId,
            });
          if (filter.creationDate) {
            qb.andWhere('DATE(p.created_at) = :creationDate', {
              creationDate: filter.creationDate,
            });
          }
          if (description) {
            qb.andWhere('p.description ILIKE :descriptionFilter', {
              descriptionFilter: `%${description}%`,
            });
          }
          if (name) {
            qb.andWhere('(p.name ILIKE :nameFilter OR p.name_ar ILIKE :nameFilter)', {
              nameFilter: `%${filter.name}%`,
            });
          }
        }),
      );
    }

    if (sortBy === SortByOptions.name) {
      queryBuilder.orderBy(`p.name`, sortOrder).addOrderBy(`p.name_ar`, sortOrder);
    } else {
      queryBuilder.orderBy(`p.${sortBy}`, sortOrder);
    }
    if (page && limit) {
      const take = limit || 10;
      const skip = ((page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }
    const [result, total] = await queryBuilder.getManyAndCount();
    const formattedItems = result.map((paymentMethod) => ({
      id: paymentMethod.id,
      name: paymentMethod.name,
      name_ar: paymentMethod.name_ar,
      description: paymentMethod.description,
      created_at: paymentMethod.created_at,
      updated_at: paymentMethod.updated_at,
      created_by: paymentMethod.created_by,
      updated_by: paymentMethod.updated_by,
      halls: paymentMethod?.hallPaymentMethods.map((he) => ({
        id: he.hall.id,
        name: he.hall.name,
        name_ar: he.hall.name_ar,
      })),
    }));

    return this.paginatorService.paginate(formattedItems, total, page || 1, limit || total);
  }

  async findOne(id: number, user: AuthenticatedUser): Promise<PaymentMethodsDetails> {
    const { clientId, type, halls } = user;
    const queryConditions = {
      id,
      client: { id: clientId },
      deleted: false,
      hallPaymentMethods: type === UserTypesEnum.employee ? { hall: In(halls) } : undefined,
    };
    const paymentMethod = await this.paymentMethodRepository.findOne({
      where: queryConditions,
      relations: { hallPaymentMethods: { hall: true } },
    });

    if (!paymentMethod) {
      throw new BadRequestException(ErrorKeys.paymentMethodNotFound);
    }

    return {
      id: paymentMethod.id,
      created_by: paymentMethod.created_by,
      name: paymentMethod.name,
      name_ar: paymentMethod.name_ar,
      description: paymentMethod.description,
      halls: paymentMethod?.hallPaymentMethods.map((hallPaymentMethod) => ({
        id: hallPaymentMethod.hall.id,
        name: hallPaymentMethod.hall.name,
        name_ar: hallPaymentMethod.hall.name_ar,
      })),
    };
  }

  async update(
    id: number,
    updatePaymentMethodDto: UpdatePaymentMethodDto,
    user: AuthenticatedUser,
  ): Promise<PaymentMethodsDetails> {
    const { halls, name, name_ar } = updatePaymentMethodDto;
    const { clientId, id: userId } = user;
    const existPaymentMethod = await this.findOne(id, user);
    checkUserPermissionType(user, existPaymentMethod.created_by);
    let hallIds = existPaymentMethod?.halls.map((hall) => hall.id).filter(Boolean);

    if (halls) {
      this.hallsService.validateHalls(halls);
      hallIds = halls.map((hall) => hall.id).filter(Boolean);
    }
    if (name || name_ar) {
      await this.findPaymentMethodsByName(id, name ?? null, name_ar ?? null, clientId, hallIds);
    }

    await this.updatePaymentMethodTransaction.run({
      paymentMethod: updatePaymentMethodDto,
      paymentMethodId: id,
      clientId,
      userId,
    });
    return await this.findOne(id, user);
  }

  async remove(id: number, user: AuthenticatedUser): Promise<PaymentMethodsDetails> {
    const { clientId, id: userId } = user;
    const existPaymentMethod = await this.findOne(id, user);
    checkUserPermissionType(user, existPaymentMethod.created_by);

    await this.deletePaymentMethodTransaction.run({
      paymentMethodId: id,
      userId,
    });
    return { ...existPaymentMethod, deleted: true, deleted_at: new Date() };
  }

  async checkIfPaymentMethodExists(paymentMethodName: string, clientId: number): Promise<boolean> {
    const paymentMethod = await this.paymentMethodRepository.findOne({
      where: { name: paymentMethodName, client: { id: clientId }, deleted: false },
    });

    return !!paymentMethod;
  }

  private async findPaymentMethodsByName(
    id: number,
    name: string,
    name_ar: string,
    clientId: number,
    hallIds: number[],
  ): Promise<void> {
    let paymentMethod = undefined;
    if (name && name_ar) {
      paymentMethod = await this.paymentMethodRepository.findOne({
        where: [
          {
            name,
            client: { id: clientId },
            deleted: false,
            hallPaymentMethods: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name: name_ar,
            client: { id: clientId },
            deleted: false,
            hallPaymentMethods: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name_ar,
            client: { id: clientId },
            deleted: false,
            hallPaymentMethods: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name_ar: name,
            client: { id: clientId },
            deleted: false,
            hallPaymentMethods: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
        ],
      });
    } else if (name) {
      paymentMethod = await this.paymentMethodRepository.findOne({
        where: [
          {
            name,
            client: { id: clientId },
            deleted: false,
            hallPaymentMethods: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name_ar: name,
            client: { id: clientId },
            deleted: false,
            hallPaymentMethods: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
        ],
      });
    } else {
      paymentMethod = await this.paymentMethodRepository.findOne({
        where: [
          {
            name: name_ar,
            client: { id: clientId },
            deleted: false,
            hallPaymentMethods: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name_ar,
            client: { id: clientId },
            deleted: false,
            hallPaymentMethods: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
        ],
      });
    }
    if (paymentMethod) {
      throw new BadRequestException(ErrorKeys.paymentMethodExists);
    }
  }
  // @OnEvent('client.admin.verified')
  // async seedDefaultsPaymentMethod(dto): Promise<void> {
  //   let newMethods = [];
  //   const { clientId, lang,userId } = dto;
  //   const paymentMethods = Object.values(defaultPaymentMethods);
  //   for (const method of paymentMethods) {
  //     const paymentMethod = this.paymentMethodRepository.create({
  //       name: method['en'].name,
  //       name_ar: method['ar'].name,
  //       isDefault: true,
  //       description: method[lang].description,
  //       client: { id: clientId },
  //       created_by:userId
  //     });
  //     newMethods.push(paymentMethod);
  //   }
  //   await this.paymentMethodRepository.save(newMethods);
  // }
}
