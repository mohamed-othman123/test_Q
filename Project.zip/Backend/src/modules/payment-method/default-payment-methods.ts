export const defaultPaymentMethods = {
  pointOfSale: {
    ar: {
      name: 'نقطة بيع',
      description: 'نقطة بيع',
    },
    en: {
      name: 'Point of Sale',
      description: 'Point of Sale',
    },
  },
  cash: {
    ar: {
      name: 'كاش',
      description: 'دفع نقدي',
      
    },
    en: {
      name: 'Cash',
      description: 'Cash payment',
      
    },
  },
  bankTransfer: {
    ar: {
      name: 'حساب بنكى',
      description: 'تحويل عبر البنوك',
    },
    en: {
      name: 'Bank Transfer',
      description: 'Transfer through banks',
    },
  },
  eWallet: {
    ar: {
      name: 'محفظة إلكترونية',
      description: 'دفع عبر المحفظة الإلكترونية',
    },
    en: {
      name: 'E-Wallet',
      description: 'Payment via e-wallet',
    },
  },
};
