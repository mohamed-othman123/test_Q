import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const paymentMethodsPermissions = {
  CREATE_PAYMENT_METHOD: {
    ar_name: 'إنشاء:طريقة الدفع',
    en_name: 'create:paymentMethod',
    ar_module: 'طرق الدفع',
    en_module: 'Payment Methods',
    order: 17,
    key: 'Payment Methods',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/payment-method'",
  },
  READ_PAYMENT_METHODS: {
    ar_name: 'قراءة:طرق الدفع',
    en_name: 'read:paymentMethods',
    ar_module: 'طرق الدفع',
    en_module: 'Payment Methods',
    order: 17,
    key: 'Payment Methods',
    type: PermissionsTypeEnum.READ,
    route: "GET '/payment-method'",
  },
  // UPDATE_PAYMENT_METHOD: {
  //   ar_name: 'تحديث:طريقة الدفع',
  //   en_name: 'update:paymentMethod',
  //   ar_module: 'طرق الدفع',
  //   en_module: 'Payment Methods',
  //   order: 17,
  //   key: 'Payment Methods',
  //   type: PermissionsTypeEnum.UPDATE,
  //   route: "PATCH '/payment-method/:id'",
  // },
  DELETE_PAYMENT_METHOD: {
    ar_name: 'حذف:طريقة الدفع',
    en_name: 'delete:paymentMethod',
    ar_module: 'طرق الدفع',
    en_module: 'Payment Methods',
    order: 17,
    key: 'Payment Methods',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/payment-method/:id'",
  },
};
