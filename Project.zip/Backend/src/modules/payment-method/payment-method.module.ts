import { Module } from '@nestjs/common';
import { PaymentMethodService } from './payment-method.service';
import { PaymentMethodController } from './payment-method.controller';
import { PaymentMethod } from './entities/payment-method.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UpdatePaymentMethodTransaction } from './utils/update-payment-methods.transactions';
import { DeletePaymentMethodTransaction } from './utils/delete-payment-methods.transaction';
import { HallsModule } from '../halls/halls.module';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';

@Module({
  imports: [TypeOrmModule.forFeature([PaymentMethod]), HallsModule],
  controllers: [PaymentMethodController],
  providers: [
    PaymentMethodService,
    UpdatePaymentMethodTransaction,
    DeletePaymentMethodTransaction,
    HallIdExtractor,
  ],
  exports: [PaymentMethodService],
})
export class PaymentMethodModule {}
