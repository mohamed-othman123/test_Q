import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Delete,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { PaymentMethodService } from './payment-method.service';
import { CreatePaymentMethodDto } from './dto/create-payment-method.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { paymentMethodsPermissions } from './payment-method.permissions';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiBody,
  ApiBearerAuth,
  ApiHeader,
} from '@nestjs/swagger';
import { GetPaymentMethods } from './dto/get-payment-methods.dto';
import { PaymentMethodsDetails } from './interfaces/paymentMethodDetails.interface';
import { EmployeeHallsInterceptor } from '../../auth/interceptors/halls-employee.interceptor';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { bookingsPermissions } from '../booking/permissions/booking.permissions';
import { paymentsPermissions } from '../payment/payments.permissions';
import { expensePaymentsPermissions } from '../expenses-payments/permissions/expense_payments.permissions';
import { purchasesPermissions } from '../expenses/expenses.permissions';
import { refundRequestsPermissions } from '../refund-requests/refund-requests.permissions';

@ApiTags('payment-method')
@ApiBearerAuth()
@Controller('payment-method')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class PaymentMethodController {
  constructor(private readonly paymentMethodService: PaymentMethodService) {}

  @UseInterceptors(EmployeeHallsInterceptor)
  @ApiOperation({ summary: 'Create a new payment method' })
  @ApiBody({ type: CreatePaymentMethodDto })
  @ApiResponse({ status: 201, description: 'Payment method created successfully.' })
  @ApiResponse({
    status: 400,
    description:
      'Bad Request. \n\nPossible reasons:\n- Payment method already exists\n- Invalid input data',
  })
  @ApiResponse({ status: 404, description: 'Client not found.' })
  @RequirePermissions(paymentMethodsPermissions.CREATE_PAYMENT_METHOD)
  @Post()
  async create(
    @Body() createPaymentMethodDto: CreatePaymentMethodDto,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<PaymentMethodsDetails> {
    return await this.paymentMethodService.create(createPaymentMethodDto, user);
  }

  @UseInterceptors(EmployeeHallsInterceptor)
  @ApiOperation({ summary: 'Get all payment methods' })
  @ApiResponse({
    status: 200,
    description: 'List of payment methods retrieved successfully.',
  })
  @ApiResponse({ status: 404, description: 'Client not found.' })
  @RequirePermissions(
    paymentMethodsPermissions.READ_PAYMENT_METHODS,
    bookingsPermissions.CREATE_BOOKING,
    bookingsPermissions.UPDATE_BOOKING,
    paymentsPermissions.CREATE_PAYMENT,
    expensePaymentsPermissions.CREATE_EXPENSE_PAYMENT,
    expensePaymentsPermissions.UPDATE_EXPENSE_PAYMENT,
    purchasesPermissions.CREATE_PURCHASE,
    purchasesPermissions.UPDATE_PURCHASE,
    refundRequestsPermissions.CREATE_REFUND_REQUEST,
    refundRequestsPermissions.UPDATE_REFUND_REQUEST
  )
  @Get()
  async findAll(
    @CurrentUser() user: AuthenticatedUser,
    @Query() filter: GetPaymentMethods,
  ): Promise<{
    items: PaymentMethodsDetails[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return await this.paymentMethodService.findAll(filter, user);
  }

  @ApiOperation({ summary: 'Get a payment method by ID' })
  @ApiParam({ name: 'id', description: 'The ID of the payment method' })
  @ApiResponse({
    status: 200,
    description: 'Payment method details retrieved successfully.',
  })
  @ApiResponse({ status: 404, description: 'Payment method not found.' })
  @RequirePermissions(paymentMethodsPermissions.READ_PAYMENT_METHODS)
  @Get(':id')
  async findOne(
    @Param('id') id: string,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<PaymentMethodsDetails> {
    return await this.paymentMethodService.findOne(+id, user);
  }

  // @ApiOperation({ summary: 'Update a payment method' })
  // @ApiParam({ name: 'id', description: 'The ID of the payment method' })
  // @ApiBody({ type: UpdatePaymentMethodDto })
  // @ApiResponse({ status: 200, description: 'Payment method updated successfully.' })
  // @ApiResponse({
  //   status: 400,
  //   description:
  //     'Bad Request. \n\nPossible reasons:\n- Payment method already exists with this name\n- Invalid input data',
  // })
  // @ApiResponse({ status: 404, description: 'Client or Payment method not found.' })
  // @UseInterceptors(EmployeeHallsInterceptor)
  // @RequirePermissions(paymentMethodsPermissions.UPDATE_PAYMENT_METHOD)
  // @Patch(':id')
  // async update(
  //   @Param('id') id: string,
  //   @Body() updatePaymentMethodDto: UpdatePaymentMethodDto,
  //   @CurrentUser()
  //   user: AuthenticatedUser,
  // ): Promise<PaymentMethodsDetails> {
  //   return await this.paymentMethodService.update(+id, updatePaymentMethodDto, user);
  // }

  @ApiOperation({ summary: 'Delete a payment method' })
  @ApiParam({ name: 'id', description: 'The ID of the payment method' })
  @ApiResponse({ status: 200, description: 'Payment method deleted successfully.' })
  @ApiResponse({ status: 404, description: 'Payment method not found.' })
  @RequirePermissions(paymentMethodsPermissions.DELETE_PAYMENT_METHOD)
  @Delete(':id')
  async remove(
    @Param('id') id: string,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<PaymentMethodsDetails> {
    return await this.paymentMethodService.remove(+id, user);
  }
}
