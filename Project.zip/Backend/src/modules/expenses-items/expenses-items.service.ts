import { BadRequestException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ExpenseItemEntity } from './entities/items.entity';
import { Brackets, DataSource, In, Not, QueryRunner, Repository } from 'typeorm';
import { CreateExpenseElementDto, CreateExpenseItemsDto } from './dto/create-expenses-items.dto';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { FilterExpensesItemsDto, SortExpenseItemsOptions } from './dto/filter-items.dto';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { PaginatorService } from '../../common/paginator/paginator.service';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { PurchaseCategoriesService } from '../purchase-categories/purchase-categories.service';
import { UpdateExpenseItemsDto, UpdateTransferAccountDto } from './dto/update-expense-item.dto';
import { checkUserPermissionType, HandelTwoName } from 'src/core/helpers/cast.helper';
import { ExpenseElementEntity } from './entities/element.entity';
import { FilterExpensesElementsDto, SortExpenseElementsOptions } from './dto/filter-elements.dto';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { TransferAccountEntity } from './entities/transfer-account.entity';

@Injectable()
export class ExpensesItemsService {
  constructor(
    @InjectRepository(ExpenseItemEntity) private readonly itemsRepo: Repository<ExpenseItemEntity>,
    @InjectRepository(ExpenseElementEntity)
    private readonly elementsRepo: Repository<ExpenseElementEntity>,
    @InjectRepository(TransferAccountEntity)
    private readonly transferAccountsRepo: Repository<TransferAccountEntity>,
    private readonly paginatorService: PaginatorService,
    private readonly catService: PurchaseCategoriesService,
    private readonly dataSource: DataSource,
  ) {}

  async create(
    expenseItemsDto: CreateExpenseItemsDto,
    user: AuthenticatedUser,
  ): Promise<ExpenseItemEntity> {
    const { clientId } = user;
    const { name, nameAr, categoryId, hallId, transferAccounts } = expenseItemsDto;

    await this.catService.checkGeneralExpenseCategory(categoryId, hallId, user);

    await this.checkItemNameDuplication(name || nameAr, nameAr || name, categoryId);

    const elementsToSave = this.checkInputElementsNames(expenseItemsDto.elements);

    const newItem = this.itemsRepo.create({
      ...expenseItemsDto,
      name: name || nameAr,
      nameAr: nameAr || name,
      category: { id: categoryId },
      client: { id: clientId },
      hall: { id: hallId },
      transferAccounts:
        transferAccounts && transferAccounts.length
          ? transferAccounts.map((a) => ({ ...a, created_by: user.id }))
          : undefined,
      elements: elementsToSave.map((el) => ({ ...el, created_by: user.id })),
      created_by: user.id,
    });

    const savedItem = await this.itemsRepo.save(newItem);

    return await this.findOne(savedItem.id, user);
  }
  async list(
    dto: FilterExpensesItemsDto,
    user: AuthenticatedUser,
  ): Promise<{
    items: ExpenseItemEntity[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    let { page, limit, hallId, category, categoryId, item, sortOrder, creationDate, sortBy } = dto;

    sortOrder = dto.sortOrder || SortOrderEnum.DESC;

    const { clientId } = user;

    const queryBuilder = this.itemsRepo
      .createQueryBuilder('items')
      .withDeleted()
      .leftJoin('items.category', 'category')
      .addSelect(['category.id', 'category.name', 'category.name_ar', 'category.type'])
      .where('items.client_id = :clientId', { clientId })
      .andWhere('items.deleted = :deleted', { deleted: false })
      .andWhere('items.hall_id = :hallFilter', {
        hallFilter: hallId,
      });

    if (categoryId) queryBuilder.andWhere('category.id = :categoryId', { categoryId });

    if (category) {
      queryBuilder.andWhere(
        new Brackets((cateQb) => {
          cateQb
            .where('category.name ILIKE :categoryName', {
              categoryName: `%${category}%`,
            })
            .orWhere('category.name_ar ILIKE :categoryName', {
              categoryName: `%${category}%`,
            });
        }),
      );
    }
    if (item) {
      queryBuilder.andWhere(
        new Brackets((itemQb) => {
          itemQb
            .where('items.name ILIKE :itemName', {
              itemName: `%${item}%`,
            })
            .orWhere('items.name_ar ILIKE :itemName', {
              itemName: `%${item}%`,
            });
        }),
      );
    }

    if (creationDate) {
      const creationStartDate = `${creationDate} 00:00:00`;
      const creationEndDate = `${creationDate} 23:59:59`;
      queryBuilder.andWhere('items.created_at BETWEEN :creationStartDate AND :creationEndDate', {
        creationStartDate,
        creationEndDate,
      });
    }

    if (sortBy === SortExpenseItemsOptions.category) {
      queryBuilder
        .orderBy(`category.name`, sortOrder, 'NULLS LAST')
        .addOrderBy(`category.name_ar`, sortOrder, 'NULLS LAST');
    } else if (sortBy === SortExpenseItemsOptions.item) {
      queryBuilder
        .orderBy(`items.name`, sortOrder, 'NULLS LAST')
        .addOrderBy(`items.nameAr`, sortOrder, 'NULLS LAST');
    } else {
      queryBuilder.orderBy(`items.${sortBy}`, sortOrder);
    }

    if (page && limit) {
      const take = limit || 10;
      const skip = ((page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }

    const [result, total] = await queryBuilder.getManyAndCount();

    return this.paginatorService.paginate(result, total, page || 1, limit || total);
  }

  async itemElements(
    filter: FilterExpensesElementsDto,
    user: AuthenticatedUser,
  ): Promise<{
    items: ExpenseElementEntity[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    let { page, limit, element, itemId, hallId, value, sortOrder, creationDate, sortBy } = filter;

    sortOrder = filter.sortOrder || SortOrderEnum.DESC;

    const { clientId } = user;

    const queryBuilder = this.elementsRepo
      .createQueryBuilder('el')
      .withDeleted()
      .leftJoin('el.item', 'item')
      .where('item.id = :itemId', { itemId })
      .andWhere('item.client_id = :clientId', { clientId })
      .andWhere('item.deleted = :deleted', { deleted: false })
      .andWhere('el.deleted = :deleted', {
        delete: false,
      });

    if (element) {
      queryBuilder.andWhere(
        new Brackets((nameQb) => {
          nameQb
            .where('el.name ILIKE :name', {
              name: `%${element}%`,
            })
            .orWhere('el.name_ar ILIKE :name', {
              name: `%${element}%`,
            });
        }),
      );
    }
    if (value) {
      queryBuilder.andWhere('el.value = :value', { value });
    }

    if (creationDate) {
      const creationStartDate = `${creationDate} 00:00:00`;
      const creationEndDate = `${creationDate} 23:59:59`;
      queryBuilder.andWhere('el.created_at BETWEEN :creationStartDate AND :creationEndDate', {
        creationStartDate,
        creationEndDate,
      });
    }

    if (sortBy === SortExpenseElementsOptions.element) {
      queryBuilder
        .orderBy(`el.name`, sortOrder, 'NULLS LAST')
        .addOrderBy(`el.nameAr`, sortOrder, 'NULLS LAST');
    } else {
      queryBuilder.orderBy(`el.${sortBy}`, sortOrder, 'NULLS LAST');
    }

    if (page && limit) {
      const take = limit || 10;
      const skip = ((page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }

    const [result, total] = await queryBuilder.getManyAndCount();

    return this.paginatorService.paginate(result, total, page, limit);
  }

  async update(
    id: number,
    updateExpenseItemsDto: UpdateExpenseItemsDto,
    user: AuthenticatedUser,
  ): Promise<ExpenseItemEntity> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      const itemRepo = queryRunner.manager.getRepository(ExpenseItemEntity);

      const { elements, categoryId } = updateExpenseItemsDto;

      const existItem = await this.findOne(id, user);

      checkUserPermissionType(user, existItem.created_by);

      const [name, name_ar] = HandelTwoName(
        updateExpenseItemsDto.name,
        updateExpenseItemsDto.nameAr,
      );
      if (existItem.name !== name || existItem.nameAr !== name_ar)
        await this.checkItemNameDuplication(
          name,
          name_ar,
          existItem?.category?.id || updateExpenseItemsDto.categoryId,
        );

      const elementsToSave = this.checkInputElementsNames(elements) as CreateExpenseElementDto[];

      await this.handleElementsUpdate(id, elementsToSave, queryRunner, user);

      await this.handleTransferAccountsUpdate(
        id,
        updateExpenseItemsDto.transferAccounts,
        existItem.transferAccounts,
        queryRunner,
        user,
      );

      delete updateExpenseItemsDto.categoryId;
      delete updateExpenseItemsDto.elements;
      delete updateExpenseItemsDto.hallId;
      delete updateExpenseItemsDto.transferAccounts;

      await itemRepo.update(id, {
        ...updateExpenseItemsDto,
        category: categoryId ? { id: categoryId } : undefined,
        updated_by: user.id,
      });
      await queryRunner.commitTransaction();

      return await this.findOne(id, user);
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  private async handleTransferAccountsUpdate(
    itemId: number,
    transferAccounts: UpdateTransferAccountDto[],
    existAccounts: TransferAccountEntity[],
    queryRunner: QueryRunner,
    user: AuthenticatedUser,
  ): Promise<void> {
    const transferAccountRepo = queryRunner.manager.getRepository(TransferAccountEntity);

    // Separate new and existing accounts
    const accountsToUpdate = transferAccounts.filter((account) => account.id);
    const accountsToCreate = transferAccounts.filter((account) => !account.id);
    const accountIdsToKeep = accountsToUpdate.map((account) => account.id);

    // Soft delete accounts that are not in the update DTO
    const accountsToDelete = existAccounts.filter(
      (account) => !accountIdsToKeep.includes(account.id),
    );

    if (accountsToDelete.length > 0) {
      await transferAccountRepo.update(
        { id: In(accountsToDelete.map((account) => account.id)), expenseItem: { id: itemId } },
        {
          deleted: true,
          deleted_at: new Date(),
          deleted_by: user.id,
        },
      );
    }

    // Update existing accounts
    for (const account of accountsToUpdate) {
      const existingAccount = existAccounts.find((ea) => ea.id === account.id);
      if (
        existingAccount &&
        (existingAccount.accountName !== account.accountName ||
          existingAccount.accountNumber !== account.accountNumber)
      ) {
        await transferAccountRepo.update(account.id, {
          deleted: true,
          deleted_at: new Date(),
          deleted_by: user.id,
        });
        await transferAccountRepo.save({
          accountName: account?.accountName,
          accountNumber: account?.accountNumber,
          description: account?.description,
          expenseItem: { id: itemId },
          created_by: user.id,
        });
      }
    }

    // Create new accounts
    if (accountsToCreate.length > 0) {
      const newAccounts = accountsToCreate.map((account) => ({
        ...account,
        id: undefined,
        expenseItem: { id: itemId },
        created_by: user.id,
      }));
      await transferAccountRepo.save(newAccounts);
    }
  }

  private async handleElementsUpdate(
    itemId: number,
    elements: CreateExpenseElementDto[],
    queryRunner: QueryRunner,
    user: AuthenticatedUser,
  ): Promise<void> {
    const elementRepo = queryRunner.manager.getRepository(ExpenseElementEntity);

    const existingElements = await elementRepo.find({
      where: { item: { id: itemId }, deleted: false },
      select: { id: true, name: true, nameAr: true, value: true },
    });
    const existingElementsMap = new Map(existingElements.map((el) => [el.id, el]));

    const newElements = elements.filter((el) => !el?.id);
    const inputExistingElements = elements.filter((el) => el?.id);
    const inputExistingIdsSet = new Set(inputExistingElements.map((el) => el.id));
    const elementsRemovedFromInput = existingElements.filter(
      (el) => !inputExistingIdsSet.has(el.id),
    );

    if (elementsRemovedFromInput.length > 0) {
      await elementRepo.update(
        { id: In(elementsRemovedFromInput.map((el) => el.id)) },
        { deleted: true, deleted_at: new Date(), deleted_by: user.id },
      );
    }

    if (newElements.length > 0) {
      await elementRepo.save(
        newElements.map((el) => ({
          ...el,
          item: { id: itemId },
          created_by: user.id,
        })),
      );
    }

    for (const el of inputExistingElements) {
      const dbElement = existingElementsMap.get(el.id);
      if (
        dbElement &&
        (dbElement.name !== el.name ||
          dbElement.nameAr !== el.nameAr ||
          dbElement.value !== el.value)
      ) {
        await elementRepo.update(el.id, {
          name: el.name,
          nameAr: el.nameAr,
          value: el.value,
          updated_by: user.id,
        });
      }
    }
  }

  async remove(id: number, user: AuthenticatedUser): Promise<ExpenseItemEntity> {
    const existItem = await this.findOne(id, user);
    checkUserPermissionType(user, existItem.created_by);

    await this.itemsRepo.update(id, { deleted: true, deleted_at: new Date(), deleted_by: user.id });
    await this.elementsRepo.update(
      { item: { id } },
      { deleted: true, deleted_by: user.id, deleted_at: new Date() },
    );
    return { ...existItem, deleted: true, deleted_by: user.id, deleted_at: new Date() };
  }

  private async checkItemNameDuplication(name: string, nameAr: string, categoryId: number) {
    const existItem = await this.itemsRepo.findOne({
      where: [
        { name, deleted: false, category: { id: categoryId } },
        { name: nameAr, deleted: false, category: { id: categoryId } },
        { nameAr, deleted: false, category: { id: categoryId } },
        { nameAr: name, deleted: false, category: { id: categoryId } },
      ],
      select: { id: true },
    });
    if (existItem) throw new BadRequestException(ErrorKeys.expenseItemNameExist);
    return;
  }

  checkInputElementsNames(elements: CreateExpenseElementDto[]) {
    const englishNamesSet = new Set<string>();
    const arabicNamesSet = new Set<string>();

    for (const el of elements) {
      const name = el?.name;
      const nameAr = el?.nameAr;

      if (name) {
        if (englishNamesSet.has(name)) {
          throw new BadRequestException(ErrorKeys.expenseElementNameMustBeUnique);
        }
        englishNamesSet.add(name);
      }

      if (nameAr) {
        if (arabicNamesSet.has(nameAr)) {
          throw new BadRequestException(ErrorKeys.expenseElementNameMustBeUnique);
        }
        arabicNamesSet.add(nameAr);
      }
    }

    return elements.map((el) => ({
      ...el,
      name: el.name || el.nameAr,
      nameAr: el.nameAr || el.name,
      value: el.value,
    }));
  }

  async checkElementNameUnique(
    itemId: number,
    names: string[],
    user: AuthenticatedUser,
  ): Promise<void> {
    const newElementsDublication = await this.elementsRepo.findOne({
      where: [
        { name: In(names), deleted: false, item: { id: itemId, client: { id: user.clientId } } },
        { nameAr: In(names), deleted: false, item: { id: itemId, client: { id: user.clientId } } },
      ],
      select: { id: true },
    });

    if (newElementsDublication)
      throw new BadRequestException(ErrorKeys.expenseElementNameAlreadyExist);
    return;
  }

  async findOne(id: number, user: AuthenticatedUser): Promise<ExpenseItemEntity> {
    const hallCondition = user.type === UserTypesEnum.employee ? { id: In(user.halls) } : undefined;

    const existItem = await this.itemsRepo
      .createQueryBuilder('item')
      .withDeleted()
      .leftJoin('item.category', 'category')
      .leftJoin(
        'item.transferAccounts',
        'transferAccounts',
        'transferAccounts.deleted = :deleted',
        { deleted: false },
      )
      .where('item.id = :id', { id })
      .andWhere('item.client_id = :clientId', { clientId: user.clientId })
      .andWhere(hallCondition ? 'item.hall_id IN (:...halls)' : '1=1', { halls: user.halls })
      .addSelect([
        'category.id',
        'category.name',
        'category.name_ar',
        'category.type',
        'transferAccounts.id',
        'transferAccounts.accountName',
        'transferAccounts.accountNumber',
        'transferAccounts.description',
        'transferAccounts.created_by',
        'transferAccounts.updated_by',
        'transferAccounts.created_at',
        'transferAccounts.updated_at',
      ])
      .getOne();

    if (!existItem) throw new BadRequestException(ErrorKeys.expenseItemNotFound);

    return existItem;
  }

  async getRangeElements(
    elementIds: number[],
    itemId: number,
    user: AuthenticatedUser,
  ): Promise<ExpenseElementEntity[]> {
    const existElements = await this.elementsRepo.find({
      where: {
        id: In(elementIds),
        deleted: false,
        item: { id: itemId, deleted: false, client: { id: user.clientId } },
      },
      select: {
        id: true,
        name: true,
        nameAr: true,
        value: true,
      },
    });
    return existElements;
  }

  async checkTransferAccForItem(accountId: number, itemId: number): Promise<void> {
    const existTransferAccount = await this.transferAccountsRepo.findOne({
      where: { id: accountId, deleted: false, expenseItem: { id: itemId, deleted: false } },
      select: { id: true },
    });
    if (!existTransferAccount) throw new BadRequestException(ErrorKeys.transferAccountNotFound);
  }
}
