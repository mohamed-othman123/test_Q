import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { ExpensesItemsService } from './expenses-items.service';
import { CreateExpenseItemsDto } from './dto/create-expenses-items.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { FilterExpensesItemsDto } from './dto/filter-items.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { expensesItemsPermissions } from './expenses-items.permissions';
import { EmployeeHallsInterceptor } from '../../auth/interceptors/halls-employee.interceptor';
import { UpdateExpenseItemsDto } from './dto/update-expense-item.dto';
import { FilterExpensesElementsDto } from './dto/filter-elements.dto';
import { ExpenseElementEntity } from './entities/element.entity';
import { ExpenseItemEntity } from './entities/items.entity';
import { purchasesPermissions } from '../expenses/expenses.permissions';

@ApiBearerAuth()
@ApiTags('expenses-items')
@Controller('expenses-items')
export class ExpensesItemsController {
  constructor(private readonly expensesItemsService: ExpensesItemsService) { }

  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(expensesItemsPermissions.CREATE_EXPENSE_ITEM)
  @Post()
  async createExpenseItems(
    @Body() createExpenseItemsDto: CreateExpenseItemsDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<ExpenseItemEntity> {
    return await this.expensesItemsService.create(createExpenseItemsDto, user);
  }

  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(
    expensesItemsPermissions.READ_EXPENSE_ITEMS,
    purchasesPermissions.CREATE_PURCHASE,
    purchasesPermissions.UPDATE_PURCHASE
  )
  @Get()
  async list(
    @Query() filter: FilterExpensesItemsDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<{
    items: ExpenseItemEntity[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return await this.expensesItemsService.list(filter, user);
  }

  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(expensesItemsPermissions.READ_EXPENSE_ITEMS, purchasesPermissions.CREATE_PURCHASE, purchasesPermissions.UPDATE_PURCHASE)
  @Get('elements')
  async itemElements(
    @Query() filter: FilterExpensesElementsDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<{
    items: ExpenseElementEntity[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return await this.expensesItemsService.itemElements(filter, user);
  }

  @RequirePermissions(expensesItemsPermissions.READ_EXPENSE_ITEMS, purchasesPermissions.CREATE_PURCHASE, purchasesPermissions.UPDATE_PURCHASE)
  @Get(':id')
  async getItem(
    @Param('id') id: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<ExpenseItemEntity> {
    return await this.expensesItemsService.findOne(+id, user);
  }

  @RequirePermissions(expensesItemsPermissions.UPDATE_EXPENSE_ITEM)
  @Patch(':id')
  async updateExpenseItems(
    @Param('id') id: string,
    @Body() updateExpenseItemsDto: UpdateExpenseItemsDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<ExpenseItemEntity> {
    return await this.expensesItemsService.update(+id, updateExpenseItemsDto, user);
  }

  @RequirePermissions(expensesItemsPermissions.DELETE_EXPENSE_ITEM)
  @Delete(':id')
  async removeItem(
    @Param('id') id: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<ExpenseItemEntity> {
    return await this.expensesItemsService.remove(+id, user);
  }
}
