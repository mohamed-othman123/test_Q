import { Module } from '@nestjs/common';
import { ExpensesItemsController } from './expenses-items.controller';
import { ExpensesItemsService } from './expenses-items.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExpenseItemEntity } from './entities/items.entity';
import { ExpenseElementEntity } from './entities/element.entity';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
import { PurchaseCategoriesModule } from '../purchase-categories/purchase-categories.module';
import { TransferAccountEntity } from './entities/transfer-account.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([ExpenseItemEntity, ExpenseElementEntity, TransferAccountEntity]),
    PaginatorModule,
    PurchaseCategoriesModule,
  ],
  controllers: [ExpensesItemsController],
  providers: [ExpensesItemsService, HallIdExtractor],
  exports: [ExpensesItemsService],
})
export class ExpensesItemsModule {}
