import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const expensesItemsPermissions = {
  CREATE_EXPENSE_ITEM: {
    ar_name: 'إنشاء:بند صرف',
    en_name: 'create:expenseItem',
    ar_module: 'بنود الصرف',
    en_module: 'Expenses Items',
    order: 19,
    key: 'Expenses Items',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/expenses-items'",
  },
  READ_EXPENSE_ITEMS: {
    ar_name: 'قراءة:بنود الصرف',
    en_name: 'read:expenseItems',
    ar_module: 'بنود الصرف',
    en_module: 'Expenses Items',
    order: 19,
    key: 'Expenses Items',
    type: PermissionsTypeEnum.READ,
    route: "GET '/expenses-items'",
  },
  UPDATE_EXPENSE_ITEM: {
    ar_name: 'تحديث:بند صرف',
    en_name: 'update:expenseItem',
    ar_module: 'بنود الصرف',
    en_module: 'Expenses Items',
    order: 19,
    key: 'Expenses Items',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/expenses-items/:id'",
  },
  DELETE_EXPENSE_ITEM: {
    ar_name: 'حذف:بند صرف',
    en_name: 'delete:expenseItem',
    ar_module: 'بنود الصرف',
    en_module: 'Expenses Items',
    order: 19,
    key: 'Expenses Items',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/expenses-items/:id'",
  },
};
