import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PurchaseCategoriesService } from './purchase-categories.service';
import { GetPurchaseCategoriesDto } from './dtos/get-categories.dto';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { CreatePurchaseCategoryDto } from './dtos/create-category.dto';
import { UpdatePurchaseCategoryDto } from './dtos/update-category.dto';
import { PurchaseCategoryResponse } from './dtos/purchase-category.response.dto';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { expenseCategoryPermissions } from './purchase-categories.permissions';
import { EmployeeHallsInterceptor } from '../../auth/interceptors/halls-employee.interceptor';
import { purchasesPermissions } from '../expenses/expenses.permissions';
import { expensesItemsPermissions } from '../expenses-items/expenses-items.permissions';

@ApiTags('purchase-categories')
@ApiBearerAuth()
@Controller('purchase-categories')
export class PurchaseCategoriesController {
  constructor(private readonly purchaseCategoryService: PurchaseCategoriesService) {}
  @RequirePermissions(expenseCategoryPermissions.CREATE_EXEPENSES_CATEGORY)
  @UseInterceptors(EmployeeHallsInterceptor)
  @Post()
  async create(
    @Body() createPurchaseCategoryDto: CreatePurchaseCategoryDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<PurchaseCategoryResponse> {
    return this.purchaseCategoryService.createCategory(createPurchaseCategoryDto, user);
  }
  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(
    expenseCategoryPermissions.READ_EXEPENSES_CATEGORIES,
    purchasesPermissions.CREATE_PURCHASE,
    purchasesPermissions.UPDATE_PURCHASE,
    expensesItemsPermissions.CREATE_EXPENSE_ITEM,
    expensesItemsPermissions.UPDATE_EXPENSE_ITEM
  )
  @Get()
  async getAll(
    @CurrentUser() user: AuthenticatedUser,
    @Query() filter: GetPurchaseCategoriesDto,
  ): Promise<{
    items: PurchaseCategoryResponse[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return this.purchaseCategoryService.getCategories(filter, user);
  }
  @RequirePermissions(expenseCategoryPermissions.READ_EXEPENSES_CATEGORIES)
  @Get(':id')
  async getOne(
    @Param('id') id: string,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<PurchaseCategoryResponse> {
    return this.purchaseCategoryService.getCategory(+id, user);
  }
  @RequirePermissions(expenseCategoryPermissions.UPDATE_EXEPENSES_CATEGORY,expensesItemsPermissions.CREATE_EXPENSE_ITEM,expensesItemsPermissions.UPDATE_EXPENSE_ITEM)
  @UseInterceptors(EmployeeHallsInterceptor)
  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() updatePurchaseCategoryDto: UpdatePurchaseCategoryDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<PurchaseCategoryResponse> {
    return this.purchaseCategoryService.updateCategory(+id, updatePurchaseCategoryDto, user);
  }
  @RequirePermissions(expenseCategoryPermissions.DELETE_EXEPENSES_CATEGORY)
  @Delete(':id')
  async delete(
    @Param('id') id: string,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<PurchaseCategoryResponse> {
    return this.purchaseCategoryService.deleteCategory(+id, user);
  }
}
