import { BadRequestException, Injectable } from '@nestjs/common';
import { Brackets, DataSource, In, Not, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { GetPurchaseCategoriesDto, SortByOptions } from './dtos/get-categories.dto';
import { PurchaseCategoryEntity } from './entities/purchase-category.entity';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { DeletePurchaseCategoryTransaction } from './utils/delete-purchase-category.tranasction';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { CreatePurchaseCategoryDto } from './dtos/create-category.dto';
import { checkUserPermissionType, HandelTwoName } from '../../core/helpers/cast.helper';
import { HallsService } from '../halls/halls.service';
import { UpdatePurchaseCategoryDto } from './dtos/update-category.dto';
import { UpdatePurchaseCategoryTransaction } from './utils/update-purchase-category.transaction';
import { ExpensesTypesEnum } from './enums/expenses-type.enum';
import { PaginatorService } from '../../common/paginator/paginator.service';
import { PurchaseCategoryResponse } from './dtos/purchase-category.response.dto';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { SortOrderEnum } from '../../common/enums/sortOrder.enum';
import { OnEvent } from '@nestjs/event-emitter';
import { defaultExpenseCategories } from './default-purchase-categories';
import { Client } from '../clients/entities/client.entity';
import { HallEntity } from '../halls/entities/hall.entity';
import { HallPurchaseCategoryEntity } from './entities/hall-purchase-category.entity';
import { CategoryTypesEnum } from './enums/category-type.enum';

@Injectable()
export class PurchaseCategoriesService {
  constructor(
    @InjectRepository(PurchaseCategoryEntity)
    private purchaseCategoryRepository: Repository<PurchaseCategoryEntity>,
    private readonly deletePurchaseCategoryTransaction: DeletePurchaseCategoryTransaction,
    private readonly updatePurchaseCategoryTransaction: UpdatePurchaseCategoryTransaction,
    private readonly hallsService: HallsService,
    private readonly paginatorService: PaginatorService,
    private readonly dataSource: DataSource,
  ) {}
  async createCategory(
    createPurchaseCategoryDto: CreatePurchaseCategoryDto,
    user: AuthenticatedUser,
  ): Promise<PurchaseCategoryResponse> {
    let { halls, name, name_ar, description, type, categoryType } = createPurchaseCategoryDto;
    const { clientId, id: userId } = user;
    if (!name && !name_ar) {
      throw new BadRequestException(ErrorKeys.nameIsRequired);
    }
    this.hallsService.validateHalls(halls);
    const hallIds = halls.map((hall) => hall.id).filter(Boolean);
    [name, name_ar] = HandelTwoName(name, name_ar);

    const isPurchaseType = type === ExpensesTypesEnum.Purchases;

    const whereConditions = [
      {
        name,
        type,
        ...(isPurchaseType && { categoryType }),
        client: { id: clientId },
        deleted: false,
        hallPurchaseCategories: { hall: { id: In(hallIds) } },
      },
      {
        name: name_ar,
        type,
        ...(isPurchaseType && { categoryType }),
        client: { id: clientId },
        deleted: false,
        hallPurchaseCategories: { hall: { id: In(hallIds) } },
      },
      {
        name_ar,
        type,
        ...(isPurchaseType && { categoryType }),
        client: { id: clientId },
        deleted: false,
        hallPurchaseCategories: { hall: { id: In(hallIds) } },
      },
      {
        name_ar: name,
        type,
        ...(isPurchaseType && { categoryType }),
        client: { id: clientId },
        deleted: false,
        hallPurchaseCategories: { hall: { id: In(hallIds) } },
      },
    ];

    const existingPurchaseCategory = await this.purchaseCategoryRepository.findOne({
      where: whereConditions,
    });

    if (existingPurchaseCategory) {
      throw new BadRequestException(ErrorKeys.expensesCategoryExists);
    }
    const purchaseCategory = await this.purchaseCategoryRepository.save({
      ...createPurchaseCategoryDto,
      name,
      name_ar,
      description,
      categoryType: isPurchaseType ? categoryType : undefined,
      created_by: userId,
      client: { id: clientId },
      hallPurchaseCategories: halls.map((hall) => ({ hall: { id: hall.id } })),
    });

    return await this.getCategory(purchaseCategory.id, user);
  }

  async getCategories(
    filter: GetPurchaseCategoriesDto,
    user: AuthenticatedUser,
  ): Promise<{
    items: PurchaseCategoryResponse[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    const { clientId } = user;
    const { page, limit } = filter;
    let { sortBy, sortOrder } = filter;
    sortBy = sortBy || SortByOptions.createdAt;
    sortOrder = sortOrder || SortOrderEnum.DESC;
    const queryBuilder = this.purchaseCategoryRepository
      .createQueryBuilder('c')
      .leftJoinAndSelect('c.hallPurchaseCategories', 'hc')
      .leftJoinAndSelect('hc.hall', 'hall');

    const hasFilterKeys =
      filter.creationDate ||
      filter.name ||
      filter.description ||
      filter.type ||
      filter.categoryType;

    if (!hasFilterKeys) {
      queryBuilder
        .where('c.client_id = :clientId', { clientId })
        .andWhere('c.deleted = :deleted', { deleted: false })
        .andWhere('hall.id=:hallId', {
          hallId: filter.hallId,
        });
    }
    if (hasFilterKeys) {
      queryBuilder.where(
        new Brackets((qb) => {
          qb.where('c.client_id = :clientId', { clientId })
            .andWhere('c.deleted = :deleted', {
              deleted: false,
            })
            .andWhere('hall.id=:hallId', {
              hallId: filter.hallId,
            });
          if (filter.creationDate) {
            qb.andWhere('DATE(c.created_at) = :creationDate', {
              creationDate: filter.creationDate,
            });
          }
          if (filter.description) {
            qb.andWhere('c.description ILIKE :descriptionFilter', {
              descriptionFilter: `%${filter.description}%`,
            });
          }
          if (filter.name) {
            qb.andWhere('(c.name ILIKE :nameFilter OR c.name_ar ILIKE :nameFilter)', {
              nameFilter: `%${filter.name}%`,
            });
          }
          if (filter.type) {
            qb.andWhere('c.type = :type', { type: filter.type });
          }
          if (filter.categoryType) {
            qb.andWhere('c.categoryType = :categoryType', { categoryType: filter.categoryType });
          }
        }),
      );
    }

    if (sortBy === SortByOptions.name) {
      queryBuilder.orderBy(`c.name`, sortOrder).addOrderBy(`c.name_ar`, sortOrder);
    } else {
      queryBuilder.orderBy(`c.${sortBy}`, sortOrder);
    }
    if (filter.page && filter.limit) {
      const take = filter.limit || 10;
      const skip = ((filter.page || 1) - 1) * take;
      queryBuilder.skip(skip).take(take);
    }
    const [result, total] = await queryBuilder.getManyAndCount();
    const formattedItems = result.map((category) => ({
      id: category.id,
      created_at: category.created_at,
      updated_at: category.updated_at,
      deleted_at: category.deleted_at,
      created_by: category.created_by,
      name: category.name,
      name_ar: category.name_ar,
      description: category.description,
      isDefault: category?.isDefault,
      type: category.type,
      categoryType:
        category.type === ExpensesTypesEnum.Purchases ? category.categoryType : undefined,
      halls: category?.hallPurchaseCategories.map((hp) => ({
        id: hp.hall.id,
        name: hp.hall.name,
        name_ar: hp.hall.name_ar,
      })),
    }));

    return this.paginatorService.paginate(
      formattedItems,
      total,
      filter.page || 1,
      filter.limit || total,
    );
  }
  async getCategory(id: number, user: AuthenticatedUser): Promise<PurchaseCategoryResponse> {
    const { clientId, type, halls } = user;
    const queryConditions = {
      id,
      client: { id: clientId },
      deleted: false,
      hallPurchaseCategories: type === UserTypesEnum.employee ? { hall: In(halls) } : undefined,
    };
    const purchaseCategory = await this.purchaseCategoryRepository.findOne({
      where: queryConditions,
      relations: { hallPurchaseCategories: { hall: true } },
    });

    if (!purchaseCategory) {
      throw new BadRequestException(ErrorKeys.purchaseCategoryNotFound);
    }

    return {
      id: purchaseCategory.id,
      created_at: purchaseCategory.created_at,
      updated_at: purchaseCategory.updated_at,
      deleted_at: purchaseCategory.deleted_at,
      created_by: purchaseCategory.created_by,
      name: purchaseCategory.name,
      name_ar: purchaseCategory.name_ar,
      description: purchaseCategory.description,
      type: purchaseCategory.type,
      categoryType:
        purchaseCategory.type === ExpensesTypesEnum.Purchases
          ? purchaseCategory.categoryType
          : undefined,
      isDefault: purchaseCategory?.isDefault,
      halls: purchaseCategory?.hallPurchaseCategories.map(({ hall }) => ({
        id: hall.id,
        name: hall.name,
        name_ar: hall.name_ar,
      })),
    };
  }

  async updateCategory(
    id: number,
    updatePurchaseCategoryDto: UpdatePurchaseCategoryDto,
    user: AuthenticatedUser,
  ): Promise<PurchaseCategoryResponse> {
    const { halls, name, name_ar, type, categoryType } = updatePurchaseCategoryDto;
    const { clientId, id: userId } = user;
    const category = await this.getCategory(id, user);
    checkUserPermissionType(user, category.created_by);
    let hallIds = category?.halls.map((hall) => hall.id).filter(Boolean);
    if (halls) {
      this.hallsService.validateHalls(halls);
      hallIds = halls.map((hall) => hall.id).filter(Boolean);
    }
    if (name || name_ar) {
      await this.findCategoryByName(
        id,
        name ?? null,
        name_ar ?? null,
        type,
        categoryType,
        clientId,
        hallIds,
      );
    }

    await this.updatePurchaseCategoryTransaction.run({
      purchaseCategory: updatePurchaseCategoryDto,
      purchaseCategoryId: id,
      clientId,
      userId,
    });
    return await this.getCategory(id, user);
  }

  async deleteCategory(id: number, user: AuthenticatedUser): Promise<PurchaseCategoryResponse> {
    const { id: userId } = user;
    const purchaseCategory = await this.getCategory(id, user);
    checkUserPermissionType(user, purchaseCategory.created_by);

    await this.deletePurchaseCategoryTransaction.run({
      purchaseCategoryId: id,
      userId,
    });

    return { ...purchaseCategory, deleted_at: new Date() };
  }

  async checkGeneralExpenseCategory(
    id: number,
    hallId: number,
    user: AuthenticatedUser,
  ): Promise<void> {
    const existExpenseCategory = await this.purchaseCategoryRepository.findOne({
      where: {
        id,
        type: ExpensesTypesEnum.General,
        client: { id: user.clientId },
        hallPurchaseCategories: { hall: { id: hallId } },
      },
      select: { id: true },
    });
    if (!existExpenseCategory) throw new BadRequestException(ErrorKeys.purchaseCategoryNotFound);
    return;
  }

  private async findCategoryByName(
    id: number,
    name: string,
    name_ar: string,
    type: ExpensesTypesEnum,
    categoryType: CategoryTypesEnum,
    clientId: number,
    hallIds: number[],
  ): Promise<void> {
    let existCategory = undefined;
    const isPurchaseType = type === ExpensesTypesEnum.Purchases;

    if (name && name_ar) {
      existCategory = await this.purchaseCategoryRepository.findOne({
        where: [
          {
            name,
            type,
            ...(isPurchaseType && { categoryType }),
            client: { id: clientId },
            deleted: false,
            hallPurchaseCategories: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name: name_ar,
            type,
            ...(isPurchaseType && { categoryType }),
            client: { id: clientId },
            deleted: false,
            hallPurchaseCategories: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name_ar,
            type,
            ...(isPurchaseType && { categoryType }),
            client: { id: clientId },
            deleted: false,
            hallPurchaseCategories: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name_ar: name,
            type,
            ...(isPurchaseType && { categoryType }),
            client: { id: clientId },
            deleted: false,
            hallPurchaseCategories: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
        ],
      });
    } else if (name) {
      existCategory = await this.purchaseCategoryRepository.findOne({
        where: [
          {
            name,
            type,
            ...(isPurchaseType && { categoryType }),
            client: { id: clientId },
            deleted: false,
            hallPurchaseCategories: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name_ar: name,
            type,
            ...(isPurchaseType && { categoryType }),
            client: { id: clientId },
            deleted: false,
            hallPurchaseCategories: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
        ],
      });
    } else {
      existCategory = await this.purchaseCategoryRepository.findOne({
        where: [
          {
            name: name_ar,
            type,
            ...(isPurchaseType && { categoryType }),
            client: { id: clientId },
            deleted: false,
            hallPurchaseCategories: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
          {
            name_ar,
            type,
            ...(isPurchaseType && { categoryType }),
            client: { id: clientId },
            deleted: false,
            hallPurchaseCategories: { hall: { id: In(hallIds) } },
            id: Not(id),
          },
        ],
      });
    }
    if (existCategory) {
      throw new BadRequestException(ErrorKeys.expensesCategoryExists);
    }
  }

  // @OnEvent('client.admin.verified')
  // async seedDefaultsExpenseCategories(dto): Promise<void> {
  //   let newCategories = [];
  //   const { clientId, lang, userId } = dto;
  //   const categories = Object.values(defaultExpenseCategories);
  //   for (const category of categories) {
  //     const expenseCategory = this.purchaseCategoryRepository.create({
  //       name: category['en'].name,
  //       name_ar: category['ar'].name,
  //       isDefault: true,
  //       description: category[lang].description,
  //       type: category[lang].type,
  //       client: { id: clientId },
  //       created_by: userId,
  //     });
  //     newCategories.push(expenseCategory);
  //   }
  //   await this.purchaseCategoryRepository.save(newCategories);
  // }

  //for old clients with no expenses categories in halls
  async seedDefaultExpensesCategoriesForExistingClients(): Promise<void> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      const clientRepo = queryRunner.manager.getRepository(Client);
      const hallRepo = queryRunner.manager.getRepository(HallEntity);
      const expenseCategoryRepo = queryRunner.manager.getRepository(PurchaseCategoryEntity);
      const hallExpenseCategoryRepo = queryRunner.manager.getRepository(HallPurchaseCategoryEntity);

      const clients = await clientRepo.find({ where: { deleted: false }, select: { id: true } });

      console.log(`Found ${clients.length} clients to process`);

      for (const client of clients) {
        const existingDefaultCategories = await expenseCategoryRepo.count({
          where: {
            client: { id: client.id },
            isDefault: true,
          },
        });

        if (existingDefaultCategories === 0) {
          console.log(`Creating default categories for client ${client.id}`);

          const categories = Object.values(defaultExpenseCategories);

          for (const category of categories) {
            const en = category['en'];
            const isPurchaseType = en.type === ExpensesTypesEnum.Purchases;
            const expenseCategory = expenseCategoryRepo.create({
              name: category['en'].name,
              name_ar: category['ar'].name,
              type: category['en'].type as ExpensesTypesEnum,
              categoryType: isPurchaseType && 'categoryType' in en ? en.categoryType : undefined,
              description: category['en'].description,
              isDefault: true,
              client: { id: client.id },
            });

            const savedCategory = await expenseCategoryRepo.save(expenseCategory);
            const categoryId = savedCategory.id;

            const halls = await hallRepo.find({
              where: { client: { id: client.id }, deleted: false },
              select: ['id'],
            });

            for (const hall of halls) {
              const hallId = hall.id;

              const hallCategoryRelation = hallExpenseCategoryRepo.create({
                hall: { id: hallId },
                purchaseCategory: { id: categoryId },
              });
              await hallExpenseCategoryRepo.save(hallCategoryRelation);
            }
          }

          console.log(
            `Successfully created ${categories.length} default categories for client ${client.id}`,
          );
        } else {
          console.log(`Client ${client.id} already has default categories, skipping...`);
        }
      }

      await queryRunner.commitTransaction();
      console.log('Successfully seeded default expense categories for all existing clients!');
    } catch (err) {
      await queryRunner.rollbackTransaction();
    }
  }
}
