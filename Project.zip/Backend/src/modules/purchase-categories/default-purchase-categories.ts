import { CategoryTypesEnum } from './enums/category-type.enum';

export const defaultExpenseCategories = {
  operatingExpenses: {
    ar: {
      name: 'مصاريف تشغيلية',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.General,
      description: 'الكهرباء، الماء، الاتصالات، والأنظمة التقنية وغيرها',
    },
    en: {
      name: 'Operating Expenses',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.General,
      description: 'Electricity, water, communication, technical systems, and more',
    },
  },
  maintenanceExpenses: {
    ar: {
      name: 'مصاريف الصيانة',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.General,
      description: 'إصلاحات المعدات أو البنية التحتية',
    },
    en: {
      name: 'Maintenance Expenses',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.General,
      description: 'Equipment or infrastructure repair costs',
    },
  },
  officeSupplies: {
    ar: {
      name: 'مستلزمات مكتبية',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.Inventory,
      description: 'القرطاسية والأدوات المكتبية',
    },
    en: {
      name: 'Office Supplies',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.Inventory,
      description: 'Stationery and office tools',
    },
  },
  foodSupplies: {
    ar: {
      name: 'مواد غذائية',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.Inventory,
      description: 'مشتريات السوبرماركت مثل العثيم',
    },
    en: {
      name: 'Food Supplies',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.Inventory,
      description: 'Grocery purchases like Al-Othaim',
    },
  },
  marketingExpenses: {
    ar: {
      name: 'نفقات تسويقية',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.General,
      description: 'الإعلانات والطباعة واللوحات الدعائية',
    },
    en: {
      name: 'Marketing Expenses',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.General,
      description: 'Advertising, printing, and billboards',
    },
  },
  consultancyAndServices: {
    ar: {
      name: 'استشارات وخدمات',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.General,
      description: 'خدمات استشارية أو محاسبية',
    },
    en: {
      name: 'Consultancy and Services',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.General,
      description: 'Consultancy or accounting services',
    },
  },
  rentals: {
    ar: {
      name: 'إيجارات',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.General,
      description: 'إيجارات القاعات أو المعدات',
    },
    en: {
      name: 'Rentals',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.General,
      description: 'Hall or equipment rentals',
    },
  },
  venueSupplies: {
    ar: {
      name: 'مستلزمات القاعة',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.Assets,
      description: 'أثاث أو إنارة أو ديكورات',
    },
    en: {
      name: 'Venue Supplies',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.Assets,
      description: 'Furniture, lighting, or decorations',
    },
  },
  others: {
    ar: {
      name: 'أخرى',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.General,
      description: 'مصاريف متنوعة غير مصنفة',
    },
    en: {
      name: 'Others',
      type: 'Purchases',
      categoryType: CategoryTypesEnum.General,
      description: 'Miscellaneous unclassified expenses',
    },
  },
  salariesAndWages: {
    ar: {
      name: 'رواتب و أجور',
      type: 'General',
      description: 'تسجيل رواتب الموظفين والمكافآت',
    },
    en: {
      name: 'Salaries and Wages',
      type: 'General',
      description: 'Employee salaries and bonuses tracking',
    },
  },
  taxes: {
    ar: {
      name: 'الضرائب',
      type: 'General',
      description: 'قيمة مضافة أو ضرائب مبيعات',
    },
    en: {
      name: 'Taxes',
      type: 'General',
      description: 'VAT or sales taxes',
    },
  },
  governmentExpenses: {
    ar: {
      name: 'مصاريف حكومية',
      type: 'General',
      description: 'رسوم أو تصاريح حكومية',
    },
    en: {
      name: 'Government Expenses',
      type: 'General',
      description: 'Government fees or permits',
    },
  },
  othersGeneral: {
    ar: {
      name: 'أخرى',
      type: 'General',
      description: 'مصاريف متنوعة غير مصنفة',
    },
    en: {
      name: 'Others',
      type: 'General',
      description: 'Miscellaneous unclassified expenses',
    },
  },
};
