import { Module, OnModuleInit } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PurchaseCategoryEntity } from './entities/purchase-category.entity';
import { HallPurchaseCategoryEntity } from './entities/hall-purchase-category.entity';
import { PurchaseCategoriesController } from './purchase-categories.controller';
import { PurchaseCategoriesService } from './purchase-categories.service';
import { DeletePurchaseCategoryTransaction } from './utils/delete-purchase-category.tranasction';
import { HallsModule } from '../halls/halls.module';
import { UpdatePurchaseCategoryTransaction } from './utils/update-purchase-category.transaction';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';

@Module({
  imports: [
    TypeOrmModule.forFeature([PurchaseCategoryEntity, HallPurchaseCategoryEntity]),
    HallsModule,
  ],
  controllers: [PurchaseCategoriesController],
  providers: [
    PurchaseCategoriesService,
    DeletePurchaseCategoryTransaction,
    UpdatePurchaseCategoryTransaction,
    HallIdExtractor,
  ],
  exports: [PurchaseCategoriesService],
})
export class PurchaseCategoriesModule implements OnModuleInit {
  constructor(private readonly catService: PurchaseCategoriesService) {}
  onModuleInit() {
    this.catService.seedDefaultExpensesCategoriesForExistingClients();
  }
}
