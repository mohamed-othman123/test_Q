import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const expenseCategoryPermissions = {
  CREATE_EXEPENSES_CATEGORY: {
    ar_name: 'إنشاء:فئة الصرف',
    en_name: 'create:expense category',
    ar_module: 'فئة الصرف',
    en_module: 'Expense Category',
    order: 18,
    key: 'Expense Category',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/purchase-categories'",
  },
  READ_EXEPENSES_CATEGORIES: {
    ar_name: 'قراءة:فئات الصرف',
    en_name: 'read:expense categories',
    ar_module: 'فئة الصرف',
    en_module: 'Expense Category',
    order: 18,
    key: 'Expense Category',
    type: PermissionsTypeEnum.READ,
    route: "GET '/purchase-categories'",
  },
  UPDATE_EXEPENSES_CATEGORY: {
    ar_name: 'تحديث:فئة الصرف',
    en_name: 'update:expense category',
    ar_module: 'فئة الصرف',
    en_module: 'Expense Category',
    order: 18,
    key: 'Expense Category',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/purchase-categories/:id'",
  },
  DELETE_EXEPENSES_CATEGORY: {
    ar_name: 'حذف:فئة الصرف',
    en_name: 'delete:expense category',
    ar_module: 'فئة الصرف',
    en_module: 'Expense Category',
    order: 18,
    key: 'Expense Category',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/purchase-categories/:id'",
  },
};
