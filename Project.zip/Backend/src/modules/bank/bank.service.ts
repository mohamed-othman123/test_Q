import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { EWalletAr, EWalletEn } from '../../common/enums/ewallets.enum';
import { Bank } from './entities/bank.entity';
@Injectable()
export class BankService {
  constructor(
    @InjectRepository(Bank)
    private readonly bankRepository: Repository<Bank>,
  ) { }
  
  getAllEBanks(): { name: string; name_ar: string }[] {
    const eWallets = [];
    Object.keys(EWalletAr).forEach((key) => {
      if (EWalletEn[key]) {
        eWallets.push({ name: EWalletEn[key], name_ar: EWalletAr[key] });
      }
    });
    return eWallets;
  }

}
