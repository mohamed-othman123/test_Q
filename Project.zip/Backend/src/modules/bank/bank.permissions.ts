import { PermissionsTypeEnum } from "../../common/enums/permissionType.enum";

export const bankPermissions = {
  // CREATE_BANK: {
  //   ar_name: 'إنشاء:البنك',
  //   en_name: 'create:bank',
  //   ar_module: 'البنوك',
  //   en_module: 'Banks',
  //   type:PermissionsTypeEnum.CREATE,
  //   route: "POST '/bank'",
  // },
  // READ_BANKS: {
  //   ar_name: 'قراءة:البنوك',
  //   en_name: 'read:banks',
  //   ar_module: 'البنوك',
  //   en_module: 'Banks',
  //   type:PermissionsTypeEnum.READ,
  //   route: "GET '/bank'",
  // },
  // READ_BANK: {
  //   ar_name: 'قراءة:البنك',
  //   en_name: 'read:bank',
  //   ar_module: 'البنوك',
  //   en_module: 'Banks',
  //   type:PermissionsTypeEnum.READONE,
  //   route: "GET '/bank/:id'",
  // },
  // UPDATE_BANK: {
  //   ar_name: 'تحديث:البنك',
  //   en_name: 'update:bank',
  //   ar_module: 'البنوك',
  //   en_module: 'Banks',
  //   type:PermissionsTypeEnum.UPDATE,
  //   route: "PATCH '/bank/:id'",
  // },
  // DELETE_BANK: {
  //   ar_name: 'حذف:البنك',
  //   en_name: 'delete:bank',
  //   ar_module: 'البنوك',
  //   en_module: 'Banks',
  //   type:PermissionsTypeEnum.DELETE,
  //   route: "DELETE '/bank/:id'",
  // },
};
