import {
  Controller,
  Get,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiHeader,
} from '@nestjs/swagger';
import { BankService } from './bank.service';
import { UserTypeGuard } from '../../common/guards/user-types.guard';
import { UserTypes } from 'src/common/decorators/user-types.decorator';
import { UserTypesEnum } from '../users/enums/users-type.enum';
@ApiTags('Bank')
@UseGuards(UserTypeGuard)
@ApiBearerAuth()
@Controller('bank')
@ApiHeader({
  name: 'Accept-Language',
  required: false,
  description: 'Language header: en, ar',
})
export class BankController {
  constructor(private readonly bankService: BankService) { }


  @Get('/ebanks')
  @UserTypes(UserTypesEnum.admin, UserTypesEnum.owner, UserTypesEnum.employee)
  @ApiOperation({ summary: 'Get all e wallets' })
  @ApiResponse({ status: 200, description: 'List of e wallets' })
  getAllEBanks(): { name: string; name_ar: string }[] {
    return this.bankService.getAllEBanks();
  }
}
