import { expensePaymentsPermissions } from './permissions/expense_payments.permissions';
import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PurchasePaymentDto } from './dtos/create_payment.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { ExpensePaymentEntity } from './entities/expense_payments.entity';
import { FilterPurchasePayments } from './dtos/filter_payments.dto';
import { UpdatePurchasePaymentDto } from './dtos/update_payment.dto';
import { RequirePermissions } from '../../auth/decorator/require-permissions.decorator';
import { EmployeeHallsInterceptor } from '../../auth/interceptors/halls-employee.interceptor';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { ExpensePaymentsService } from './expense-payments.service';
import { purchasesPermissions } from '../expenses/expenses.permissions';

@ApiTags('expense-payments')
@ApiBearerAuth()
@Controller('expense-payments')
export class ExpensePaymentsController {
  constructor(private readonly expensePaymentsService: ExpensePaymentsService) {}

  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(expensePaymentsPermissions.CREATE_EXPENSE_PAYMENT)
  @Post()
  async addPayment(
    @Body() purchasePaymentDto: PurchasePaymentDto,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<ExpensePaymentEntity> {
    return await this.expensePaymentsService.addPayment(purchasePaymentDto, user);
  }

  @RequirePermissions(expensePaymentsPermissions.UPDATE_EXPENSE_PAYMENT)
  @Patch(':id')
  async updatePayment(
    @Param('id') id: number,
    @Body() uppdatePurchasePaymentDto: UpdatePurchasePaymentDto,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<ExpensePaymentEntity> {
    return await this.expensePaymentsService.updatePayment(id, uppdatePurchasePaymentDto, user);
  }

  @UseInterceptors(EmployeeHallsInterceptor)
  @RequirePermissions(expensePaymentsPermissions.READ_EXPENSE_PAYMENTS,purchasesPermissions.READ_PURCHASES)
  @Get()
  async expensePayments(
    @Query() filter: FilterPurchasePayments,
    @CurrentUser() user: AuthenticatedUser,
  ): Promise<{
    items: ExpensePaymentEntity[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    return await this.expensePaymentsService.expensePayments(filter, user);
  }

  @RequirePermissions(expensePaymentsPermissions.READ_EXPENSE_PAYMENTS)
  @Get(':id')
  async expensePayment(
    @Param('id') id: number,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<ExpensePaymentEntity> {
    return await this.expensePaymentsService.getExpensePayment(id, user);
  }

  @RequirePermissions(expensePaymentsPermissions.DELETE_EXPENSE_PAYMENT)
  @Delete(':id')
  async removePayment(
    @Param('id') id: number,
    @CurrentUser()
    user: AuthenticatedUser,
  ): Promise<ExpensePaymentEntity> {
    return await this.expensePaymentsService.removePayment(id, user);
  }
}
