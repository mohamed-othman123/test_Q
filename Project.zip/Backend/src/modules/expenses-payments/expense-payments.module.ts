import { Module } from '@nestjs/common';
import { ExpensePaymentsService } from './expense-payments.service';
import { ExpensePaymentsController } from './expense-payments.controller';
import { ExpensesModule } from '../expenses/expenses.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExpensePaymentEntity } from './entities/expense_payments.entity';
import { PaginatorModule } from '../../common/paginator/paginator.module';
import { PdfGenerationModule } from '../pdf-generation/pdf-generation.module';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';
import { PaymentMethodModule } from '../payment-method/payment-method.module';
import { ExpensesItemsModule } from '../expenses-items/expenses-items.module';
import { SuppliersModule } from '../suppliers/suppliers.module';

@Module({
  imports: [
    ExpensesModule,
    TypeOrmModule.forFeature([ExpensePaymentEntity]),
    PaginatorModule,
    PdfGenerationModule,
    SuppliersModule,
    PaymentMethodModule,
    ExpensesItemsModule,
  ],
  providers: [ExpensePaymentsService, HallIdExtractor],
  controllers: [ExpensePaymentsController],
})
export class ExpensePaymentsModule {}
