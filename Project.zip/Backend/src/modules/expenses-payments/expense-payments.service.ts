import { PaginatorService } from '../../common/paginator/paginator.service';
import { InjectRepository } from '@nestjs/typeorm';
import { PurchasePaymentDto } from './dtos/create_payment.dto';
import { BadRequestException, Injectable } from '@nestjs/common';
import { ExpensePaymentEntity } from './entities/expense_payments.entity';
import { Repository, DataSource, Not, QueryRunner, In } from 'typeorm';
import { PaymentTypeEnum } from './enums/payment-types.enum';
import { ErrorKeys } from '../../common/enums/errorKeys.enums';
import { PurchaseStatusEnum } from '../expenses/enums/expense_status.enum';
import { PaymentValidationData } from './dtos/payment_validation.dto';
import { FilterPurchasePayments } from './dtos/filter_payments.dto';
import { UpdatePurchasePaymentDto } from './dtos/update_payment.dto';
import moment from 'moment-hijri';
import { ExpensesService } from '../expenses/services/expenses.service';
import { UserTypesEnum } from '../users/enums/users-type.enum';
import { checkUserPermissionType } from '../../core/helpers/cast.helper';
import { AuthenticatedUser } from '../../common/interfaces/authenticated-user.interface';
import { ExpensesEntity } from '../expenses/entities/expense.entity';
import { ExpensesTypesEnum } from '../purchase-categories/enums/expenses-type.enum';
import { SuppliersService } from '../suppliers/suppliers.service';
import { PaymentMethodService } from '../payment-method/payment-method.service';
import { ExpensesItemsService } from '../expenses-items/expenses-items.service';
import { ValidateExpensePaymentMethods } from './interfaces/validate-payment-methods.interface';

@Injectable()
export class ExpensePaymentsService {
  constructor(
    @InjectRepository(ExpensePaymentEntity)
    private readonly expensePaymentRepo: Repository<ExpensePaymentEntity>,
    private readonly dataSource: DataSource,
    private readonly expensesService: ExpensesService,
    private readonly paginatorService: PaginatorService,
    private readonly supplierService: SuppliersService,
    private readonly paymentMethodService: PaymentMethodService,
    private readonly expenseItemService: ExpensesItemsService,
  ) {}

  async addPayment(
    purchasePaymentDto: PurchasePaymentDto,
    user: AuthenticatedUser,
  ): Promise<ExpensePaymentEntity> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      const purchaseRepo = queryRunner.manager.getRepository(ExpensesEntity);
      const paymentRepo = queryRunner.manager.getRepository(ExpensePaymentEntity);

      const { id, clientId } = user;
      const {
        purchaseId,
        amount,
        paymentType,
        hallPaymentMethodId,
        supplierPaymentMethodId,
        itemTransferAccountId,
      } = purchasePaymentDto;

      const whereCondition: any = {
        id: purchaseId,
        deleted: false,
        client: { id: clientId },
      };

      if (paymentType !== PaymentTypeEnum.Refund) {
        whereCondition.status = Not(PurchaseStatusEnum.Canceled);
      }

      const existPurchase = await purchaseRepo.findOne({
        where: whereCondition,
        relations: { category: true, supplier: true, expenseItem: true },
        select: {
          id: true,
          created_by: true,
          totalPayable: true,
          dueDate: true,
          category: { id: true, type: true },
          supplier: { id: true },
          expenseItem: { id: true },
          discountType: true,
          discountValue: true,
        },
      });

      if (!existPurchase) throw new BadRequestException(ErrorKeys.purchaseNotFound);
      checkUserPermissionType(user, existPurchase?.created_by);

      await this.validatePaymentMethods({
        expenseCategory: existPurchase.category.type as ExpensesTypesEnum,
        hallPaymentMethodId,
        supplierPaymentMethodId,
        itemTransferAccountId,
        supplierId: existPurchase?.supplier?.id,
        expenseItemId: existPurchase?.expenseItem?.id,
        user,
      });

      const paidAmountCheck = paymentType === PaymentTypeEnum.Income ? amount : 0;

      const [totalIncomes, totalRefunds] = await Promise.all([
        this.checkPurchasePayments(
          {
            purchaseId,
            clientId,
            paidAmount: paidAmountCheck,
            totalPayable: existPurchase.totalPayable,
          },
          queryRunner,
        ),
        this.totalRefunds(purchaseId, clientId, queryRunner),
      ]);

      if (paymentType === PaymentTypeEnum.Income) {
        const purchaseStatus = this.expensesService.purchaseStatus(
          totalIncomes,
          existPurchase.totalPayable,
          existPurchase.dueDate,
          { discountValue: existPurchase.discountValue, discountType: existPurchase.discountType },
        );
        await purchaseRepo.update(purchaseId, { status: purchaseStatus });
      } else if (paymentType === PaymentTypeEnum.Refund && amount + totalRefunds > totalIncomes) {
        throw new BadRequestException(ErrorKeys.refundExceedsTotalIncome);
      }

      const newPayment = paymentRepo.create({
        ...purchasePaymentDto,
        expense: { id: purchaseId },
        hallPaymentMethod: hallPaymentMethodId ? { id: hallPaymentMethodId } : undefined,
        supplierPaymentMethod:
          existPurchase?.category?.type === ExpensesTypesEnum.Purchases && supplierPaymentMethodId
            ? { id: supplierPaymentMethodId }
            : undefined,
        itemTransferAccount:
          existPurchase?.category?.type === ExpensesTypesEnum.General && itemTransferAccountId
            ? { id: itemTransferAccountId }
            : undefined,
        client: { id: clientId },
        created_by: id,
      });
      const savedPayment = await paymentRepo.save(newPayment);
      await queryRunner.commitTransaction();

      if (existPurchase?.category?.type === ExpensesTypesEnum.Purchases)
        void this.expensesService.generateSettlementPdf(purchaseId, clientId);

      return savedPayment;
    } catch (err) {
      console.log('Error', err);
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      queryRunner.release();
    }
  }

  async updatePayment(
    id: number,
    updatePurchasePaymentDto: UpdatePurchasePaymentDto,
    user: AuthenticatedUser,
  ): Promise<ExpensePaymentEntity> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      const {
        amount: newAmount,
        hallPaymentMethodId,
        supplierPaymentMethodId,
        itemTransferAccountId,
        paymentDate,
      } = updatePurchasePaymentDto;
      const { id: userId, clientId } = user;

      const paymentRepo = queryRunner.manager.getRepository(ExpensePaymentEntity);
      const purchaseRepo = queryRunner.manager.getRepository(ExpensesEntity);

      //check exist payment
      const existPayment = await this.getExpensePayment(id, user);

      checkUserPermissionType(user, existPayment?.created_by);

      const {
        amount: oldAmount,
        expense: { id: purchaseId },
      } = existPayment;

      //check if purchase Canceled so rollback
      const existPurchase = await this.validatePurchase(purchaseId, user, queryRunner);

      if (hallPaymentMethodId && hallPaymentMethodId !== existPayment?.hallPaymentMethod?.id)
        await this.paymentMethodService.findOne(hallPaymentMethodId, user);

      if (
        supplierPaymentMethodId &&
        supplierPaymentMethodId !== existPayment?.supplierPaymentMethod?.id
      )
        await this.supplierService.validateExistingPaymentMethods(
          existPurchase?.supplier?.id,
          [supplierPaymentMethodId],
          user,
        );
      if (itemTransferAccountId && itemTransferAccountId !== existPayment?.itemTransferAccount?.id)
        await this.expenseItemService.checkTransferAccForItem(
          itemTransferAccountId,
          existPurchase?.expenseItem?.id,
        );

      if (existPayment.paymentType === PaymentTypeEnum.Income && oldAmount !== newAmount) {
        //update purchase status if amount changed
        const totalPayments = await this.checkPurchasePayments(
          {
            purchaseId,
            clientId,
            paidAmount: newAmount - oldAmount,
            totalPayable: existPurchase.totalPayable,
          },
          queryRunner,
        );

        const purchaseStatus = this.expensesService.purchaseStatus(
          totalPayments,
          existPurchase.totalPayable,
          existPurchase.dueDate,
          {
            discountValue: existPurchase?.discountValue,
            discountType: existPurchase?.discountType,
          },
        );
        await purchaseRepo.update(purchaseId, { status: purchaseStatus });
      }

      delete updatePurchasePaymentDto?.hallPaymentMethodId;
      delete updatePurchasePaymentDto?.supplierPaymentMethodId;
      delete updatePurchasePaymentDto?.itemTransferAccountId;

      await paymentRepo.update(id, {
        ...updatePurchasePaymentDto,
        paymentDate: paymentDate ?? undefined,
        hijriDate: paymentDate ? moment(paymentDate).format('iYYYY/iM/iD') : undefined,
        hallPaymentMethod: hallPaymentMethodId ? { id: hallPaymentMethodId } : undefined,
        supplierPaymentMethod:
          existPurchase?.category?.type === ExpensesTypesEnum.Purchases && supplierPaymentMethodId
            ? { id: supplierPaymentMethodId }
            : undefined,
        itemTransferAccount:
          existPurchase?.category?.type === ExpensesTypesEnum.General && itemTransferAccountId
            ? { id: itemTransferAccountId }
            : undefined,
        updated_by: userId,
      });

      await queryRunner.commitTransaction();

      if (existPurchase?.category?.type === ExpensesTypesEnum.Purchases)
        void this.expensesService.generateSettlementPdf(purchaseId, clientId);

      return await this.getExpensePayment(id, user);
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      queryRunner.release();
    }
  }

  async expensePayments(
    filter: FilterPurchasePayments,
    user: { id: number; clientId: number },
  ): Promise<{
    items: ExpensePaymentEntity[];
    totalItems: number;
    currentPage: number;
    totalPages: number;
  }> {
    const { clientId } = user;

    let { page, limit, purchaseId } = filter;
    page = page ? page : 1;
    limit = limit ? limit : 10;
    const skip = (page - 1) * limit;

    const [result, total] = await this.expensePaymentRepo.findAndCount({
      where: { expense: { id: purchaseId }, client: { id: clientId }, deleted: false },
      withDeleted: true,
      relations: {
        hallPaymentMethod: true,
        supplierPaymentMethod: true,
        itemTransferAccount: true,
      },
      select: {
        hallPaymentMethod: { id: true, name: true, description: true, name_ar: true },
        itemTransferAccount: {
          id: true,
          accountName: true,
          accountNumber: true,
          description: true,
        },
      },
      take: limit,
      skip,
      order: { created_at: 'DESC' },
    });
    return this.paginatorService.paginate(result, total, page, limit);
  }

  async getExpensePayment(id: number, user: AuthenticatedUser): Promise<ExpensePaymentEntity> {
    const { clientId } = user;

    //check if user is employee associate with hall
    const purchaseHallCond =
      user.type === UserTypesEnum.employee ? { hall: { id: In(user.halls) } } : undefined;

    const existPayment = await this.expensePaymentRepo.findOne({
      where: { id, client: { id: clientId }, deleted: false, expense: purchaseHallCond },
      withDeleted: true,
      relations: {
        hallPaymentMethod: true,
        supplierPaymentMethod: true,
        itemTransferAccount: true,
        expense: true,
      },
      select: {
        hallPaymentMethod: { id: true, name: true, description: true, name_ar: true },
        itemTransferAccount: {
          id: true,
          accountName: true,
          accountNumber: true,
          description: true,
        },
        expense: { id: true },
      },
    });
    if (!existPayment) throw new BadRequestException(ErrorKeys.paymentNotFound);

    return existPayment;
  }

  async removePayment(id: number, user: AuthenticatedUser): Promise<ExpensePaymentEntity> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      const { id: userId, clientId } = user;

      const paymentRepo = queryRunner.manager.getRepository(ExpensePaymentEntity);
      const purchaseRepo = queryRunner.manager.getRepository(ExpensesEntity);

      const existPayment = await this.getExpensePayment(id, user);

      checkUserPermissionType(user, existPayment?.created_by);

      const {
        amount,
        expense: { id: purchaseId },
      } = existPayment;

      //check if purchase Canceled so rollback
      const existPurchase = await this.validatePurchase(purchaseId, user, queryRunner);

      //update purchase status after payment deleted
      if (existPayment.paymentType === PaymentTypeEnum.Income) {
        const totalPayments = await this.checkPurchasePayments(
          { purchaseId, clientId, paidAmount: 0, totalPayable: existPurchase.totalPayable },
          queryRunner,
        );

        const purchaseStatus = this.expensesService.purchaseStatus(
          totalPayments - amount,
          existPurchase.totalPayable,
          existPurchase.dueDate,
          {
            discountValue: existPurchase?.discountValue,
            discountType: existPurchase?.discountType,
          },
        );

        await purchaseRepo.update(purchaseId, { status: purchaseStatus });
      }

      await paymentRepo.update(id, {
        deleted: true,
        deleted_at: new Date(),
        deleted_by: userId,
      });

      await queryRunner.commitTransaction();

      if (existPurchase?.category?.type === ExpensesTypesEnum.Purchases)
        void this.expensesService.generateSettlementPdf(purchaseId, clientId);

      return {
        ...existPayment,
        deleted: true,
        deleted_at: new Date(),
        deleted_by: userId,
      } as ExpensePaymentEntity;
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      queryRunner.release();
    }
  }

  private async checkPurchasePayments(
    paymentValidationData: PaymentValidationData,
    queryRunner: QueryRunner,
  ) {
    const { purchaseId, clientId, paidAmount: amount, totalPayable } = paymentValidationData;
    const totalPreviousPayments = await queryRunner.manager
      .getRepository(ExpensePaymentEntity)
      .sum('amount', {
        expense: { id: purchaseId },
        client: { id: clientId },
        paymentType: PaymentTypeEnum.Income,
        deleted: false,
      });

    if (totalPreviousPayments + amount > totalPayable) {
      throw new BadRequestException(ErrorKeys.exceedTotalPayableForPurchase);
    }

    return totalPreviousPayments + amount;
  }

  private async totalRefunds(
    purchaseId: number,
    clientId: number,
    queryRunner: QueryRunner,
  ): Promise<number> {
    const totalRefunds = await queryRunner.manager
      .getRepository(ExpensePaymentEntity)
      .sum('amount', {
        expense: { id: purchaseId },
        client: { id: clientId },
        paymentType: PaymentTypeEnum.Refund,
        deleted: false,
      });
    if (!totalRefunds) return 0;
    return totalRefunds;
  }

  private async validatePurchase(
    purchaseId: number,
    user: AuthenticatedUser,
    queryRunner: QueryRunner,
  ) {
    const purchaseRepo = queryRunner.manager.getRepository(ExpensesEntity);

    const purchase = await purchaseRepo.findOne({
      where: {
        id: purchaseId,
        deleted: false,
        client: { id: user.clientId },
        status: Not(PurchaseStatusEnum.Canceled),
      },
      relations: { category: true, supplier: true, expenseItem: true },
      select: {
        id: true,
        totalPayable: true,
        dueDate: true,
        category: { id: true, type: true },
        supplier: { id: true },
        expenseItem: { id: true },
        discountType: true,
        discountValue: true,
      },
    });
    if (!purchase) throw new BadRequestException(ErrorKeys.purchaseNotFound);
    return purchase;
  }

  private async validatePaymentMethods(validatePaymentMethods: ValidateExpensePaymentMethods) {
    const validationPromises = [];

    const {
      expenseCategory: categoryType,
      hallPaymentMethodId,
      supplierPaymentMethodId,
      itemTransferAccountId,
      supplierId,
      expenseItemId,
      user,
    } = validatePaymentMethods;

    if (hallPaymentMethodId) {
      validationPromises.push(this.paymentMethodService.findOne(hallPaymentMethodId, user));
    }

    if (categoryType === ExpensesTypesEnum.Purchases && supplierPaymentMethodId) {
      validationPromises.push(
        this.supplierService.validateExistingPaymentMethods(
          supplierId,
          [supplierPaymentMethodId],
          user,
        ),
      );
    }

    if (categoryType === ExpensesTypesEnum.General && itemTransferAccountId) {
      validationPromises.push(
        this.expenseItemService.checkTransferAccForItem(itemTransferAccountId, expenseItemId),
      );
    }

    await Promise.all(validationPromises);
  }
}
