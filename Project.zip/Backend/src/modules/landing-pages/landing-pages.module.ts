import { FileUploadModule } from './../../common/utilities/file-upload/file-upload.module';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LandingPageEntity } from './entities/landing-page.entity';
import { BannerEntity } from './entities/banners.entity';
import { SocialMediaEntity } from './entities/socialMedia.entity';
import { HallFeatureEntity } from './entities/features.entity';
import { LandingPagesController } from './controllers/landing-pages.controller';
import { MediaController } from './controllers/media.controller';
import { LandingPagesService } from './services/landing-pages.service';
import { MediaService } from './services/media.services';
import { HallImagesEntity } from './entities/images.entity';
import { FeaturesController } from './controllers/features.controller';
import { LandingPagePopularQuestionsController } from './controllers/popular-questions.controller';
import { FeaturesService } from './services/features.services';
import { QuestionsServices } from './services/questions.service';
import { PopularQuestion } from './entities/popular-question.entity';
import { HallCustomerEntity } from './entities/customer.entity';
import { CustomersController } from './controllers/customer.controller';
import { CustomersService } from './services/customer.services';
import { HallsModule } from '../halls/halls.module';
import { LandingPageSectionsEntity } from './entities/landing-page-sections.entity';
import { LandingSectionsController } from './controllers/section.controller';
import { LandingSectionsService } from './services/section.services';
import { HallIdExtractor } from '../../common/services/hall-id.extractor';

@Module({
  imports: [
    FileUploadModule,
    HallsModule,
    TypeOrmModule.forFeature([
      LandingPageEntity,
      BannerEntity,
      SocialMediaEntity,
      HallFeatureEntity,
      HallCustomerEntity,
      HallImagesEntity,
      PopularQuestion,
      LandingPageSectionsEntity,
    ]),
  ],
  controllers: [
    LandingPagesController,
    MediaController,
    FeaturesController,
    CustomersController,
    LandingPagePopularQuestionsController,
    LandingSectionsController,
  ],
  providers: [
    LandingPagesService,
    MediaService,
    FeaturesService,
    CustomersService,
    QuestionsServices,
    LandingSectionsService,
    HallIdExtractor,
  ],
})
export class LandingPagesModule {}
