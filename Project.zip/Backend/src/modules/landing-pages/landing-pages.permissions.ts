import { PermissionsTypeEnum } from '../../common/enums/permissionType.enum';

export const landingPagePermissions = {
  CREATE_LANDING_PAGE: {
    ar_name: 'إنشاء:صفحات القاعات',
    en_name: 'create:Landing Pages',
    ar_module: 'ويب سايت',
    en_module: 'Website',
    order: 13,
    key: 'Website',
    type: PermissionsTypeEnum.CREATE,
    route: "POST '/landing-pages/*'",
  },

  READ_LANDING_PAGE: {
    ar_name: 'قراءة:صفحة القاعة',
    en_name: 'read:Landing Pages',
    ar_module: 'ويب سايت',
    en_module: 'Website',
    order: 13,
    key: 'Website',
    type: PermissionsTypeEnum.READ,
    route: "GET '/landing-pages/:hallId'",
  },

  UPDATE_LANDING_PAGE: {
    ar_name: 'تحديث:صفحات القاعات',
    en_name: 'update:Landing Pages',
    ar_module: 'ويب سايت',
    en_module: 'Website',
    order: 13,
    key: 'Website',
    type: PermissionsTypeEnum.UPDATE,
    route: "PATCH '/landing-pages/*'",
  },
  DELETE_LANDING_PAGE_DATA: {
    ar_name: 'حذف:بيانات القاعات',
    en_name: 'delete:Landing Pages Data',
    ar_module: 'ويب سايت',
    en_module: 'Website',
    order: 13,
    key: 'Website',
    type: PermissionsTypeEnum.DELETE,
    route: "DELETE '/landing-pages/*'",
  },
};
