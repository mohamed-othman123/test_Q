# Qaatk Online Analytics & AI Integration

This document provides a comprehensive guide for implementing the Metabase dashboard embedding and AI chat integration for Qaatk Online.

## 🎯 Overview

The integration enables users to:

- Embed Metabase dashboards directly in the Angular frontend
- Ask natural-language questions in Arabic or English via ChatGPT
- Receive AI-powered answers based on tenant-specific data
- Preview predefined dashboards with proper tenant isolation

## 🏗️ Architecture

### Backend (NestJS)

- **AnalyticsModule**: Main module coordinating all analytics features
- **MetabaseService**: Handles JWT token generation and dashboard URL creation
- **AiChatService**: Processes natural language queries using OpenAI
- **Tenant Isolation**: Ensures data security through client_id filtering

### Frontend (Angular)

- **AnalyticsDashboardComponent**: Embeds Metabase dashboards via iframe
- **AiChatComponent**: Chat interface with RTL support for Arabic
- **AnalyticsPageComponent**: Main page combining dashboard and chat
- **AnalyticsService**: HTTP service for API communication

## 📋 Prerequisites

### Backend Dependencies

```bash
npm install jsonwebtoken axios
```

### Frontend Dependencies

```bash
npm install @angular/common @angular/forms
```

### Environment Variables

Add these to your `.env` file:

```env
# Metabase Configuration
METABASE_URL=https://your-metabase-instance.com
METABASE_SECRET_KEY=your-metabase-secret-key

# OpenAI Configuration
OPENAI_API_KEY=your-openai-api-key
OPENAI_API_URL=https://api.openai.com/v1

# Database (already configured)
DATABASE_HOST=localhost
DATABASE_PORT=5432
DATABASE_USERNAME=your_username
DATABASE_PASSWORD=your_password
DATABASE_NAME=your_database
```

## 🚀 Backend Setup

### 1. Add Analytics Module to App Module

The `AnalyticsModule` has been automatically added to `src/app.module.ts`.

### 2. Configure Metabase

1. **Enable Embedding in Metabase**:
   - Go to Admin → Settings → Embedding
   - Enable embedding
   - Set your secret key

2. **Create Dashboards**:
   - Create dashboards with `client_id` parameter
   - Ensure all queries filter by `client_id`

3. **Example Dashboard Query**:
   ```sql
   SELECT * FROM bookings
   WHERE client_id = {{client_id}}
   AND booking_date >= CURRENT_DATE - INTERVAL '30 days'
   ```

### 3. Database Views for AI Queries

Create secure views for AI queries:

```sql
-- Create a secure view for AI queries
CREATE VIEW ai_bookings_view AS
SELECT
    id,
    customer_name,
    booking_date,
    total_amount,
    status,
    created_at
FROM bookings
WHERE client_id = CURRENT_SETTING('app.current_client_id')::integer;

-- Set up Row Level Security
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY client_isolation_policy ON bookings
    FOR ALL
    USING (client_id = CURRENT_SETTING('app.current_client_id')::integer);
```

## 🎨 Frontend Setup

### 1. Add Components to Angular Module

```typescript
// app.module.ts
import { AnalyticsDashboardComponent } from './analytics-dashboard.component';
import { AiChatComponent } from './ai-chat.component';
import { AnalyticsPageComponent } from './analytics-page.component';
import { SafeUrlPipe } from './pipes/safe-url.pipe';

@NgModule({
  declarations: [AnalyticsDashboardComponent, AiChatComponent, AnalyticsPageComponent, SafeUrlPipe],
  // ... other configurations
})
export class AppModule {}
```

### 2. Add Route

```typescript
// app-routing.module.ts
const routes: Routes = [
  // ... existing routes
  {
    path: 'analytics',
    component: AnalyticsPageComponent,
    canActivate: [AuthGuard],
  },
];
```

### 3. Add Navigation Link

```html
<!-- Add to your navigation menu -->
<a routerLink="/analytics" class="nav-link">
  <i class="fas fa-chart-line"></i>
  {{ isRTL ? 'التحليلات' : 'Analytics' }}
</a>
```

## 🔧 Configuration

### Metabase Dashboard Configuration

1. **Dashboard Parameters**:
   - Add `client_id` as a required parameter
   - Set default values based on user context

2. **Embedding Settings**:
   - Enable embedding for each dashboard
   - Set appropriate permissions

### OpenAI Configuration

1. **API Key Management**:
   - Store API key securely in environment variables
   - Implement rate limiting for API calls

2. **Prompt Engineering**:
   - Customize system prompts for your domain
   - Add Arabic language support

## 🛡️ Security Considerations

### 1. Tenant Isolation

- All queries must include `client_id` filter
- Database views enforce row-level security
- JWT tokens are scoped to specific tenants

### 2. SQL Injection Prevention

- AI-generated queries are validated
- Only SELECT statements are allowed
- Forbidden commands are blocked

### 3. Rate Limiting

- Implement rate limiting for AI chat
- Monitor API usage and costs

## 📊 Usage Examples

### Dashboard Embedding

```typescript
// Get dashboard URL
const dashboardUrl = await this.analyticsService.getDashboardUrl(1, {
  date_range: 'last_30_days',
});
```

### AI Chat Queries

```typescript
// Send message to AI
const response = await this.analyticsService.sendChatMessage('ما هي الحجوزات لهذا الأسبوع؟', 'ar');
```

## 🧪 Testing

### Backend Tests

```bash
# Test analytics endpoints
npm run test:e2e -- --testNamePattern="analytics"

# Test specific service
npm run test -- --testNamePattern="MetabaseService"
```

### Frontend Tests

```bash
# Test components
ng test --include="**/analytics*.spec.ts"

# E2E tests
ng e2e --specs="analytics.e2e-spec.ts"
```

## 📝 API Endpoints

### GET /analytics/dashboard-url

Get signed Metabase dashboard URL.

**Query Parameters:**

- `dashboardId` (number): Dashboard ID
- `parameters` (object): Optional dashboard parameters

**Response:**

```json
{
  "url": "https://metabase.example.com/embed/dashboard/...",
  "expiresAt": "2024-01-15T10:45:00.000Z"
}
```

### POST /analytics/chat

Send message to AI assistant.

**Request Body:**

```json
{
  "message": "ما هي الحجوزات لهذا الأسبوع؟",
  "language": "ar"
}
```

**Response:**

```json
{
  "message": "تم العثور على 15 حجز لهذا الأسبوع...",
  "data": [...],
  "sqlQuery": "SELECT * FROM bookings WHERE client_id = 1...",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### GET /analytics/available-dashboards

Get available dashboards for the tenant.

**Response:**

```json
[
  {
    "id": 1,
    "name": "Booking Overview",
    "name_ar": "نظرة عامة على الحجوزات",
    "description": "Overview of all bookings and revenue"
  }
]
```

## 🚨 Troubleshooting

### Common Issues

1. **Dashboard Not Loading**:
   - Check Metabase URL and secret key
   - Verify JWT token generation
   - Check iframe security policies

2. **AI Chat Not Working**:
   - Verify OpenAI API key
   - Check rate limits
   - Review error logs

3. **Data Isolation Issues**:
   - Ensure `client_id` is properly set
   - Check database views and policies
   - Verify JWT payload

### Debug Mode

Enable debug logging:

```typescript
// In MetabaseService
this.logger.setLogLevels(['debug']);

// In AiChatService
this.logger.setLogLevels(['debug']);
```

## 📈 Performance Optimization

1. **Dashboard Caching**:
   - Cache dashboard URLs for 10-15 minutes
   - Implement URL refresh logic

2. **AI Response Caching**:
   - Cache common queries
   - Implement response streaming

3. **Database Optimization**:
   - Index on `client_id` columns
   - Use materialized views for complex queries

## 🔄 Deployment

### Production Checklist

- [ ] Set environment variables
- [ ] Configure Metabase production instance
- [ ] Set up OpenAI API key
- [ ] Test tenant isolation
- [ ] Configure rate limiting
- [ ] Set up monitoring and logging
- [ ] Test RTL support
- [ ] Verify security measures

### Docker Configuration

Add to your `docker-compose.yml`:

```yaml
services:
  metabase:
    image: metabase/metabase:latest
    environment:
      MB_ENCRYPTION_SECRET_KEY: your-secret-key
    ports:
      - '3000:3000'
```

## 📞 Support

For issues and questions:

1. Check the troubleshooting section
2. Review error logs
3. Test with minimal configuration
4. Contact the development team

## 🔮 Future Enhancements

- [ ] Advanced dashboard customization
- [ ] Real-time data updates
- [ ] Export functionality
- [ ] Advanced AI features
- [ ] Mobile optimization
- [ ] Offline support
- [ ] Advanced analytics
- [ ] Custom visualizations
