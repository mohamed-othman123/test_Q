# Metabase SQL Injection & Visualization Guide

This guide explains all available options for injecting SQL into Metabase and generating embed URLs for visualization in the Qaatk Online system.

## 🎯 Overview

Metabase provides several ways to inject SQL and create visualizations:

1. **Question Embedding** - Embed individual SQL queries as questions
2. **Dashboard Embedding** - Embed predefined dashboards (current implementation)
3. **Dynamic Question Creation** - Create questions programmatically via API
4. **Direct SQL Visualization** - Generate visualization URLs for any SQL query

## 🚀 Available Options

### 1. Question Embedding (Recommended)

**What it does**: Embeds individual SQL queries as interactive visualizations
**Use case**: Dynamic queries from AI chat or custom user requests

```typescript
// Generate visualization URL for any SQL query
const visualizationUrl = await metabaseService.generateSqlVisualizationUrl(
  clientId,
  'SELECT customer_name, total_amount FROM bookings WHERE client_id = 1',
  'bar',
);
```

**API Endpoint**: `POST /analytics/sql-visualization`

**Request Body**:

```json
{
  "sqlQuery": "SELECT customer_name, total_amount FROM bookings WHERE client_id = 1",
  "visualizationType": "bar",
  "databaseId": 1
}
```

**Response**:

```json
{
  "url": "https://metabase.example.com/embed/question/...",
  "expiresAt": "2024-01-15T10:45:00.000Z",
  "visualizationType": "bar"
}
```

### 2. Dynamic Question Creation

**What it does**: Creates permanent Metabase questions via API
**Use case**: Saving frequently used queries as reusable questions

```typescript
// Create a new Metabase question
const result = await metabaseService.createDynamicQuestion(
  clientId,
  'SELECT * FROM bookings WHERE client_id = 1',
  'My Custom Query',
  'table',
);
```

**API Endpoint**: `POST /analytics/create-question`

**Request Body**:

```json
{
  "sqlQuery": "SELECT * FROM bookings WHERE client_id = 1",
  "questionName": "Monthly Revenue Analysis",
  "visualizationType": "line",
  "databaseId": 1
}
```

**Response**:

```json
{
  "questionId": 123,
  "url": "https://metabase.example.com/embed/question/...",
  "expiresAt": "2024-01-15T10:45:00.000Z",
  "visualizationType": "line"
}
```

### 3. Enhanced AI Chat with Visualization

**What it does**: Automatically generates visualization URLs for AI chat responses
**Use case**: Natural language queries that return visual data

The AI chat service now automatically:

- Generates SQL queries from natural language
- Determines appropriate visualization type
- Returns both data and visualization URL

**Example Chat Response**:

```json
{
  "message": "Found 15 bookings for this week with total revenue of $2,500",
  "data": [...],
  "sqlQuery": "SELECT * FROM bookings WHERE client_id = 1...",
  "visualizationUrl": "https://metabase.example.com/embed/question/...",
  "visualizationType": "bar",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### 4. Dashboard Embedding (Current)

**What it does**: Embeds predefined Metabase dashboards
**Use case**: Standard reports and analytics

```typescript
// Generate dashboard URL
const dashboardUrl = await metabaseService.generateDashboardUrl(clientId, dashboardId, parameters);
```

## 📊 Visualization Types

The system supports these visualization types:

- **`table`** - Tabular data display
- **`line`** - Line charts for trends over time
- **`bar`** - Bar charts for comparisons
- **`pie`** - Pie charts for distributions

### Automatic Visualization Detection

The AI chat service automatically determines the best visualization type based on:

1. **Query keywords**: "trend", "over time", "مقارنة", "توزيع"
2. **Data structure**: Date columns → line chart, numeric comparisons → bar chart
3. **Query intent**: Distribution queries → pie chart

## 🔧 Implementation Details

### Backend Services

#### MetabaseService

```typescript
// New methods added:
- generateQuestionUrl() - Generate question embed URLs
- createDynamicQuestion() - Create questions via API
- generateSqlVisualizationUrl() - Direct SQL visualization
```

#### AiChatService

```typescript
// Enhanced with:
- determineVisualizationType() - Auto-detect chart type
- visualizationUrl generation in responses
```

### Frontend Integration

#### AnalyticsService

```typescript
// New methods:
- generateSqlVisualization() - Generate visualization URLs
- createQuestion() - Create Metabase questions
- getQuestionUrl() - Get existing question URLs
```

## 🛡️ Security Considerations

### SQL Injection Protection

- All queries must include `client_id` filter
- Only SELECT statements allowed
- Query validation and sanitization
- Row-level security policies

### Tenant Isolation

- Automatic `client_id` injection
- JWT token expiration (15 minutes)
- Secure parameter passing

## 📋 API Reference

### SQL Visualization Endpoints

#### POST /analytics/sql-visualization

Generate visualization URL for custom SQL query.

**Request**:

```json
{
  "sqlQuery": "SELECT customer_name, total_amount FROM bookings WHERE client_id = 1",
  "visualizationType": "bar",
  "databaseId": 1
}
```

**Response**:

```json
{
  "url": "https://metabase.example.com/embed/question/...",
  "expiresAt": "2024-01-15T10:45:00.000Z",
  "visualizationType": "bar"
}
```

#### POST /analytics/create-question

Create a new Metabase question with custom SQL.

**Request**:

```json
{
  "sqlQuery": "SELECT * FROM bookings WHERE client_id = 1",
  "questionName": "Monthly Revenue Analysis",
  "visualizationType": "line",
  "databaseId": 1
}
```

**Response**:

```json
{
  "questionId": 123,
  "url": "https://metabase.example.com/embed/question/...",
  "expiresAt": "2024-01-15T10:45:00.000Z",
  "visualizationType": "line"
}
```

#### POST /analytics/chat (Enhanced)

AI chat with automatic visualization generation.

**Request**:

```json
{
  "message": "Show me revenue trends for this month",
  "language": "en"
}
```

**Response**:

```json
{
  "message": "Found revenue data for this month...",
  "data": [...],
  "sqlQuery": "SELECT booking_date, total_amount FROM bookings...",
  "visualizationUrl": "https://metabase.example.com/embed/question/...",
  "visualizationType": "line",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

## 🎨 Frontend Usage Examples

### Basic SQL Visualization

```typescript
// Generate visualization for custom SQL
const response = await analyticsService.generateSqlVisualizationAsync({
  sqlQuery: 'SELECT customer_name, total_amount FROM bookings WHERE client_id = 1',
  visualizationType: 'bar',
});

// Use the URL in an iframe
this.visualizationUrl = response.url;
```

### AI Chat with Visualization

```typescript
// Send chat message and get visualization
const chatResponse = await analyticsService.sendChatMessageAsync(
  'Show me booking trends for this month',
  'en',
);

if (chatResponse.visualizationUrl) {
  this.visualizationUrl = chatResponse.visualizationUrl;
  this.visualizationType = chatResponse.visualizationType;
}
```

### Create Reusable Questions

```typescript
// Create a permanent question
const questionResponse = await analyticsService.createQuestionAsync({
  sqlQuery: 'SELECT * FROM bookings WHERE client_id = 1',
  questionName: 'All Bookings',
  visualizationType: 'table',
});

// Save questionId for future use
this.savedQuestionId = questionResponse.questionId;
```

## 🔄 Workflow Examples

### 1. User asks AI question → Gets visualization

```
User: "What are my revenue trends?"
AI: Generates SQL → Executes query → Creates visualization → Returns URL
Frontend: Displays both text response and interactive chart
```

### 2. Developer creates custom query → Embeds visualization

```
Developer: Writes SQL query
API: Validates query → Generates embed URL → Returns visualization
Frontend: Embeds chart in dashboard
```

### 3. System creates reusable questions

```
System: Identifies common queries
API: Creates Metabase questions → Stores question IDs
Users: Access saved questions via dashboard
```

## 🚨 Limitations & Considerations

### Metabase API Authentication

- The `createDynamicQuestion` method requires Metabase API authentication
- You'll need to implement proper session management
- Consider using API keys or service accounts

### Performance

- Question creation via API is slower than direct embedding
- Consider caching frequently used visualizations
- Monitor Metabase API rate limits

### Security

- All SQL queries are validated and sanitized
- Client isolation is enforced at multiple levels
- JWT tokens expire after 15 minutes

## 🎯 Best Practices

1. **Use Question Embedding** for dynamic queries from AI chat
2. **Use Dashboard Embedding** for standard reports
3. **Create Questions** for frequently used queries
4. **Cache visualization URLs** for better performance
5. **Monitor API usage** and implement rate limiting
6. **Validate all SQL queries** before execution
7. **Use appropriate visualization types** based on data structure

## 🔧 Configuration

### Environment Variables

```env
METABASE_URL=https://your-metabase-instance.com
METABASE_SECRET_KEY=your-metabase-secret-key
METABASE_API_USERNAME=your-api-username
METABASE_API_PASSWORD=your-api-password
```

### Metabase Setup

1. Enable embedding in Metabase admin
2. Configure database connections
3. Set up proper permissions
4. Test API authentication

This comprehensive system provides multiple ways to inject SQL into Metabase and generate visualization URLs, giving you maximum flexibility for different use cases while maintaining security and performance.
