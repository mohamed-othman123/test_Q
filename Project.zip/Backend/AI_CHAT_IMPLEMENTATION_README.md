# AI Chat Implementation with OpenAI Function Calling

## Overview

This implementation uses a **clean separation of concerns** architecture where:

- **OpenAI Module**: Only handles client initialization and configuration
- **AI Services**: Use the OpenAI client directly for their specific needs
- **Better Flexibility**: Each service controls its own AI logic
- **Easier Testing**: Simple to mock and test individual services

## Architecture

### 1. Global OpenAiModule (`src/providers/openai/`) 🔧 **Client Initialization Only**

- **Purpose**: Centralized OpenAI client initialization and configuration
- **Features**:
  - Global module accessible by any service
  - OpenAI client initialization with retry logic
  - Configuration management with environment variables
  - **NO business logic** - just client management

### 2. AiChatOpenAiService (`src/modules/analytics/services/ai-chat-openai.service.ts`) 🤖 **AI Logic Service**

- **Purpose**: Handles all OpenAI-specific AI chat logic
- **Features**:
  - SQL query generation via function calling
  - Natural language response generation
  - Uses OpenAI client from global module
  - Fallback to mock responses when needed

### 3. AiChatService (`src/modules/analytics/services/ai-chat.service.ts`) 📊 **Business Logic**

- **Purpose**: Main business logic for AI chat processing
- **Features**:
  - Orchestrates the entire AI chat flow
  - SQL execution and security validation
  - Visualization URL generation
  - Uses AiChatOpenAiService for AI operations

### 4. Analytics Controller (`src/modules/analytics/analytics.controller.ts`) 🌐 **API Endpoint**

- **Endpoint**: `POST /analytics/ai-chat`
- **Input**: `{ message: string, language?: string }`
- **Output**: Structured response with SQL, data, visualization, and explanation

## Module Structure

```
src/
├── providers/
│   └── openai/                    # 🔧 OpenAI Client Management
│       ├── index.ts               # Clean exports
│       ├── openai.module.ts       # Global module
│       ├── openai.service.ts      # Client initialization only
│       └── openai.config.ts       # Configuration
└── modules/
    └── analytics/
        ├── analytics.module.ts     # Analytics module
        ├── analytics.controller.ts # API endpoints
        └── services/
            ├── ai-chat.service.ts           # Main business logic
            ├── ai-chat-openai.service.ts    # AI-specific logic
            └── example-openai-usage.service.ts # Example usage
```

## Why This Architecture is Better

### ✅ **Clean Separation of Concerns**

- **OpenAI Module**: Only client management
- **AI Services**: Handle their specific AI logic
- **Business Services**: Focus on business rules

### ✅ **Flexibility**

- Each service can use OpenAI differently
- Easy to add new AI capabilities
- No "god object" in OpenAI module

### ✅ **Testability**

- Easy to mock OpenAI module
- Test AI logic separately from business logic
- Better unit test coverage

### ✅ **Reusability**

- Any service can inject OpenAI module
- Consistent client configuration
- Shared connection management

## Current Implementation Status

### ✅ Completed

- Global OpenAI module with client initialization
- AI chat service using OpenAI client
- Function calling for structured SQL output
- Mock fallback when OpenAI unavailable
- Module configuration and API endpoint

### 🔄 Next Steps

1. Install OpenAI package: `npm install openai`
2. Set environment variables
3. Test with real OpenAI API

## Configuration

### Environment Variables

```bash
# Required
OPENAI_API_KEY=your_openai_api_key_here

# Optional (with defaults)
OPENAI_API_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-4
OPENAI_MAX_RETRIES=3
OPENAI_TIMEOUT=30000
OPENAI_MAX_TOKENS=1000
OPENAI_TEMPERATURE=0.1
```

## Usage Examples

### 1. **AI Chat Service** (Current Implementation)

```typescript
// Uses AiChatOpenAiService for OpenAI operations
const result = await this.aiChatOpenAiService.generateSqlQueryWithFunctionCall(messages, functions);
```

### 2. **Other Services** (Example Usage)

```typescript
// Any service can use OpenAI directly
export class TranslationService {
  constructor(private readonly openAiService: OpenAiService) {}

  async translate(text: string, language: string) {
    const client = this.openAiService.getClient();
    const response = await client.chat.completions.create({
      model: this.openAiService.getModel(),
      messages: [...],
      // ... other params
    });
    return response.choices[0]?.message?.content;
  }
}
```

### 3. **API Call**

```bash
POST /analytics/ai-chat
Authorization: Bearer <token>
Content-Type: application/json

{
  "message": "Show me bookings from last week",
  "language": "en"
}
```

### 4. **Response Structure**

```json
{
  "message": "I found 15 bookings from the last 7 days...",
  "data": [...],
  "sqlQuery": "SELECT * FROM bookings WHERE client_id = 1 AND booking_date >= CURRENT_DATE - INTERVAL '7 days'",
  "visualizationUrl": "https://metabase.example.com/embed/...",
  "visualizationType": "table",
  "explanation": "This query retrieves all bookings from the last 7 days..."
}
```

## Function Calling Benefits

### Before (Free Text)

```typescript
// Had to parse OpenAI response manually
const response = await axios.post('/chat/completions', {...});
const sqlQuery = response.data.choices[0]?.message?.content?.trim();
// Risk of malformed SQL, no visualization type, no explanation
```

### After (Function Calling)

```typescript
// Structured, validated output
const result = await this.aiChatOpenAiService.generateSqlQueryWithFunctionCall(messages, functions);
// Guaranteed: sqlQuery, visualizationType, explanation
```

## Security Features

1. **Client ID Filtering**: All queries automatically include `WHERE client_id = ${clientId}`
2. **SQL Validation**: Only SELECT statements allowed
3. **Forbidden Commands**: Blocks DROP, DELETE, UPDATE, INSERT, ALTER, CREATE
4. **Result Limiting**: Maximum 100 rows per query

## Switching from Mock to Real OpenAI

1. **Install Package**:

   ```bash
   npm install openai
   ```

2. **Set Environment Variable**:

   ```bash
   OPENAI_API_KEY=sk-...
   ```

3. **Test Endpoint**:
   ```bash
   curl -X POST /analytics/ai-chat \
     -H "Authorization: Bearer <token>" \
     -H "Content-Type: application/json" \
     -d '{"message": "Show me this month revenue"}'
   ```

## Visualization Type Logic

The AI automatically determines the best visualization type:

- **Table**: Detailed listings, multiple field comparisons
- **Line**: Time-series data, trends over time
- **Bar**: Category comparisons, aggregated data
- **Pie**: Distribution analysis, percentage breakdowns

## Error Handling

- **OpenAI API Errors**: Logged and handled gracefully
- **SQL Validation Errors**: Security violations blocked
- **Database Errors**: Logged with user-friendly messages
- **Fallback Responses**: Mock responses when OpenAI unavailable
- **Configuration Errors**: Graceful fallback to mock mode

## Testing

The architecture makes testing much easier:

- **Mock OpenAI Module**: Test without API calls
- **Test AI Logic**: Test AiChatOpenAiService separately
- **Test Business Logic**: Test AiChatService with mocked AI service
- **Integration Tests**: Test with real OpenAI API

## Future Enhancements

1. **Streaming Responses**: Real-time chat experience
2. **Query History**: Save and reuse common queries
3. **Custom Functions**: Additional AI capabilities
4. **Multi-language Support**: Enhanced Arabic/English handling
5. **Query Optimization**: AI-suggested query improvements
6. **Multiple AI Providers**: Support for different AI services
7. **Rate Limiting**: Built-in rate limiting and quota management
8. **Caching**: Cache common AI responses
9. **Analytics**: Track AI usage and performance
