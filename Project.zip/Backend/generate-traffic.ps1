# Generate traffic for HyperDX testing
Write-Host "Generating traffic for HyperDX testing..."

for ($i = 1; $i -le 10; $i++) {
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:3001/v1/test-telemetry" -Method GET
        Write-Host "Request $i - Status: $($response.StatusCode)"
        
        # Add a small delay between requests
        Start-Sleep -Milliseconds 500
    } catch {
        Write-Host "Request $i - Error: $($_.Exception.Message)"
    }
}

Write-Host "Traffic generation complete!" 