# Metabase Embedding: Dashboard vs Card vs Question

## 📊 **Metabase Terminology**

### 1. **Question** (Also called "Card")

- **Definition**: A single query with visualization
- **Contains**: SQL query + chart type + display settings
- **Use case**: Individual data analysis
- **Example**: "Monthly Revenue Chart", "Customer List"
- **ID**: Positive integer (e.g., 123)

### 2. **Card**

- **Definition**: Same as Question (interchangeable terms)
- **Contains**: Same as Question
- **Use case**: Same as Question
- **Note**: "Card" is the older term, "Question" is newer

### 3. **Dashboard**

- **Definition**: Collection of multiple Questions/Cards
- **Contains**: Multiple questions arranged in a layout
- **Use case**: Comprehensive reports with multiple views
- **Example**: "Business Overview Dashboard" with revenue, customers, trends
- **ID**: Positive integer (e.g., 456)

## 🔗 **Embedding Options**

### **Current Implementation Issues**

The error you encountered:

```
Card id should be a positive integer.
```

This happens because Metabase's embedding system has **two different approaches**:

1. **Question Embedding with ID** (requires existing question ID)
2. **Question Embedding with Query** (requires different payload structure)

## ✅ **Available Solutions**

### **Option 1: Create Question First, Then Embed** (Recommended)

```typescript
// 1. Create a question via Metabase API
const questionResponse = await metabaseService.createQuestionViaApi(
  'My Custom Query',
  'SELECT customer_name, total_amount FROM bookings WHERE client_id = 1',
  'bar',
);

// 2. Generate embed URL using the question ID
const embedUrl = await metabaseService.generateQuestionUrl(
  clientId,
  questionResponse.id, // Use the question ID
);
```

**API Endpoint**: `POST /analytics/create-question`

### **Option 2: Simple SQL Visualization** (No API Auth Required)

```typescript
// Generate URL that opens Metabase question builder with SQL pre-filled
const visualizationUrl = await metabaseService.generateSimpleSqlVisualizationUrl(
  clientId,
  'SELECT customer_name, total_amount FROM bookings WHERE client_id = 1',
  'bar',
);
```

**API Endpoint**: `POST /analytics/simple-sql-visualization`

### **Option 3: Public Question Embedding**

```typescript
// Embed existing public questions
const publicUrl = await metabaseService.generatePublicQuestionUrl(
  questionId, // Must be a public question in Metabase
  clientId,
);
```

**API Endpoint**: `GET /analytics/public-question-url`

### **Option 4: Dashboard Embedding** (Current Working)

```typescript
// Embed predefined dashboards
const dashboardUrl = await metabaseService.generateDashboardUrl(clientId, dashboardId, parameters);
```

**API Endpoint**: `GET /analytics/dashboard-url`

## 🎯 **When to Use Each Option**

| Option              | Use Case          | Pros                       | Cons                    |
| ------------------- | ----------------- | -------------------------- | ----------------------- |
| **Create Question** | Reusable queries  | Persistent, full embedding | Requires API auth       |
| **Simple SQL**      | One-time queries  | No auth required           | Opens in new tab        |
| **Public Question** | Pre-built reports | Fast, reliable             | Question must be public |
| **Dashboard**       | Standard reports  | Consistent, pre-built      | Limited flexibility     |

## 🚀 **Quick Fix for Your Current Issue**

Instead of using the complex embedding, try the **simple SQL visualization**:

```bash
curl -X POST http://localhost:3000/analytics/simple-sql-visualization \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "sqlQuery": "SELECT customer_name, total_amount FROM bookings WHERE client_id = 1 LIMIT 10",
    "visualizationType": "bar"
  }'
```

This will return:

```json
{
  "url": "http://localhost:3000/question/new?query=SELECT%20customer_name%2C%20total_amount%20FROM%20bookings%20WHERE%20client_id%20%3D%201%20LIMIT%2010&visualization_type=bar&client_id=51",
  "visualizationType": "bar",
  "method": "simple",
  "note": "This URL opens Metabase question builder with your SQL pre-filled"
}
```

## 🔧 **Metabase Configuration Requirements**

### **For Full Embedding (Options 1 & 4)**

1. Enable embedding in Metabase admin
2. Set up API authentication
3. Configure database connections
4. Set proper permissions

### **For Simple SQL (Option 2)**

1. Metabase must be accessible
2. User must have permission to create questions
3. No additional configuration needed

### **For Public Questions (Option 3)**

1. Questions must be marked as public in Metabase
2. No authentication required
3. Limited to pre-created questions

## 📋 **API Reference**

### **POST /analytics/simple-sql-visualization**

Generate simple visualization URL (no API auth required).

**Request**:

```json
{
  "sqlQuery": "SELECT customer_name, total_amount FROM bookings WHERE client_id = 1",
  "visualizationType": "bar"
}
```

**Response**:

```json
{
  "url": "http://localhost:3000/question/new?query=...",
  "visualizationType": "bar",
  "method": "simple",
  "note": "This URL opens Metabase question builder with your SQL pre-filled"
}
```

## 🎯 **Recommendation**

For your use case, I recommend using **Option 2 (Simple SQL Visualization)** because:

1. ✅ **No API authentication required**
2. ✅ **Works immediately**
3. ✅ **Supports any SQL query**
4. ✅ **Easy to implement**
5. ✅ **No complex setup**

The URL will open Metabase's question builder with your SQL pre-filled, allowing users to visualize the data and optionally save it as a permanent question.

## 🔄 **Workflow**

1. **User sends SQL query** → API generates Metabase URL
2. **URL opens Metabase** → Question builder with SQL pre-filled
3. **User can visualize** → See the data in charts/tables
4. **Optional save** → Save as permanent question for reuse

This approach gives you the flexibility of SQL injection while avoiding the complexity of Metabase's embedding API.
