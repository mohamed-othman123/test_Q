# AI Agent Implementation - Database Schema Vector Search

## 🎯 Overview

This implementation provides a **production-ready AI agent** that uses **stable OpenAI APIs** with **custom vector search** for database schema discovery and natural language query processing.

## 🏗️ Architecture

### **Core Components:**

1. **AiSchemaService** - Manages database schemas with embeddings
2. **AiAgentProductionService** - Main AI chat service
3. **Database Storage** - Persistent schema storage with embeddings
4. **Vector Search** - Custom cosine similarity search

### **Flow:**

```
User Question → Vector Search → Find Relevant Tables → Generate SQL → Execute → Natural Response
```

## 📊 **Database Schema Storage**

### **What We Store:**

- **Table Names** (bookings, expenses, payments, etc.)
- **Descriptions** (Human-readable table descriptions)
- **Column Information** (name, type, nullable, comments)
- **Embeddings** (Vector representations for semantic search)
- **Metadata** (version, last updated, custom descriptions)

### **Storage Table: `ai_schemas`**

```sql
CREATE TABLE "ai_schemas" (
  "id" SERIAL PRIMARY KEY,
  "table_name" VARCHAR(100) UNIQUE NOT NULL,
  "description" TEXT NOT NULL,
  "columns" JSONB NOT NULL,
  "embedding" TEXT, -- JSON string of embedding vector
  "is_active" BOOLEAN DEFAULT true,
  "metadata" JSONB,
  -- Standard audit fields
  "created_at", "updated_at", "deleted_at", etc.
);
```

## 🔍 **Vector Search Implementation**

### **How It Works:**

1. **Schema Embedding Creation:**

   ```typescript
   const textToEmbed = `Table: ${tableName}. ${description}. Columns: ${columns}`;
   const embedding = await this.createEmbedding(textToEmbed);
   ```

2. **Question Embedding:**

   ```typescript
   const questionEmbedding = await this.createEmbedding(userQuestion);
   ```

3. **Cosine Similarity Search:**

   ```typescript
   const similarities = schemas.map((schema) => ({
     tableName: schema.tableName,
     similarity: this.cosineSimilarity(questionEmbedding, JSON.parse(schema.embedding)),
   }));
   ```

4. **Top Results:**
   ```typescript
   return similarities
     .sort((a, b) => b.similarity - a.similarity)
     .slice(0, 3)
     .map((item) => item.tableName);
   ```

## 🚀 **API Endpoints**

### **AI Chat:**

```typescript
POST /ai-agent/chat
{
  "message": "Show me bookings from last week",
  "conversationId": "optional",
  "topic": "optional",
  "language": "en"
}
```

### **Conversations:**

```typescript
GET /ai-agent/conversations?page=1&limit=10
GET /ai-agent/conversations/:id/messages?page=1&limit=10
DELETE /ai-agent/conversations/:id
```

### **Schema Management (Admin):**

```typescript
GET /ai-schemas                    // List all schemas
POST /ai-schemas/initialize        // Initialize all schemas
PUT /ai-schemas/:table/description // Update table description
POST /ai-schemas/:table/refresh    // Refresh specific table schema
```

## 🔧 **Setup Instructions**

### **1. Run Migrations:**

```bash
npm run migration:run
```

### **2. Initialize Schemas:**

```bash
POST /ai-schemas/initialize
```

### **3. Test the System:**

```bash
POST /ai-agent/chat
{
  "message": "What are my recent bookings?"
}
```

## 💡 **Usage Examples**

### **Example 1: Booking Queries**

```
User: "Show me bookings from last week"
AI: Finds 'bookings' table → Generates SQL → Returns results
```

### **Example 2: Expense Analysis**

```
User: "What are my total expenses this month?"
AI: Finds 'expenses' table → Generates SQL → Returns summary
```

### **Example 3: Payment Tracking**

```
User: "Show me pending payments"
AI: Finds 'payments' table → Generates SQL → Returns pending payments
```

## 🔒 **Security Features**

### **SQL Safety:**

- ✅ **Only SELECT queries** allowed
- ✅ **No DROP/DELETE/UPDATE/INSERT** operations
- ✅ **Input validation** and sanitization
- ✅ **Client ID filtering** for data isolation

### **Access Control:**

- ✅ **Authentication required** for all endpoints
- ✅ **Permission-based access** for admin functions
- ✅ **User context isolation** (client_id filtering)

## 📈 **Performance Optimizations**

### **Vector Search:**

- ✅ **Database storage** - No memory loss on restart
- ✅ **Efficient embeddings** - text-embedding-3-small model
- ✅ **Fast similarity calculation** - Optimized cosine similarity
- ✅ **Caching** - Embeddings stored in database

### **Query Optimization:**

- ✅ **Relevant table selection** - Only search necessary tables
- ✅ **Result limiting** - Max 100 rows per query
- ✅ **Streaming responses** - Real-time chat experience

## 🛠️ **Customization**

### **Adding New Tables:**

1. Add table name to `tables` array in `AiSchemaService`
2. Add description in `getTableDescription()` method
3. Run schema initialization

### **Custom Descriptions:**

```typescript
PUT /ai-schemas/bookings/description
{
  "description": "Custom description for bookings table"
}
```

### **Schema Refresh:**

```typescript
POST / ai - schemas / bookings / refresh;
```

## 💰 **Cost Analysis**

### **OpenAI API Costs:**

- **Embeddings**: ~$0.00002 per 1K tokens (very cheap)
- **Chat Completions**: ~$0.00015 per 1K tokens (GPT-4o-mini)
- **Total per query**: ~$0.001-0.005 per user question

### **Storage Costs:**

- **Database**: Minimal (embeddings are small)
- **No external vector DB**: Saves significant costs

## 🔄 **Maintenance**

### **Regular Tasks:**

1. **Monitor OpenAI usage** in dashboard
2. **Update table descriptions** as needed
3. **Refresh schemas** when database structure changes
4. **Review and optimize** queries based on usage

### **Troubleshooting:**

- **Schema not found**: Run `/ai-schemas/initialize`
- **Poor results**: Update table descriptions
- **High costs**: Monitor and optimize query patterns

## 🎉 **Benefits**

✅ **Production Ready** - Uses only stable APIs  
✅ **Cost Effective** - No expensive vector databases  
✅ **Persistent Storage** - Schemas survive restarts  
✅ **Customizable** - Easy to add tables and descriptions  
✅ **Secure** - SQL validation and access control  
✅ **Scalable** - Efficient vector search implementation

---

**Ready to use!** The system is now fully implemented with database-backed schema storage and vector search capabilities. 🚀
