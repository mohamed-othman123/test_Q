# Default Expense Categories Seeding

This document explains how to seed default expense categories for existing clients in the Qaatk system.

## Overview

The system automatically creates default expense categories for new clients when they are verified. However, existing clients may not have these default categories. This functionality provides a way to add default expense categories to existing clients and their halls.

## Default Categories

The following default expense categories are created for each client:

### Purchases Type:

1. **Operating Expenses** - Electricity, water, communication, technical systems
2. **Maintenance Expenses** - Equipment or infrastructure repair costs
3. **Office Supplies** - Stationery and office tools
4. **Food Supplies** - Grocery purchases like Al-Othaim
5. **Marketing Expenses** - Advertising, printing, and billboards
6. **Consultancy and Services** - Consultancy or accounting services
7. **Rentals** - Hall or equipment rentals
8. **Venue Supplies** - Furniture, lighting, or decorations
9. **Others** - Miscellaneous unclassified expenses

### General Type:

1. **Salaries and Wages** - Employee salaries and bonuses tracking
2. **Taxes** - VAT or sales taxes
3. **Government Expenses** - Government fees or permits
4. **Others** - Miscellaneous unclassified expenses

## Methods to Seed Default Categories

### 1. Service Method (Recommended)

The service provides two methods for seeding default categories:

#### For All Existing Clients:

```typescript
await purchaseCategoriesService.seedDefaultExpensesCategoriesForExistingClients();
```

#### For a Specific Client:

```typescript
await purchaseCategoriesService.seedDefaultExpensesCategoriesForSpecificClient(clientId);
```

### 2. API Endpoints

#### Seed for All Existing Clients:

```bash
POST /purchase-categories/seed-defaults
```

#### Seed for a Specific Client:

```bash
POST /purchase-categories/seed-defaults/:clientId
```

### 3. Database Migration (Alternative)

The migration file `1725000000000-seed-default-expense-categories.ts` is commented out but can be used as an alternative approach.

### 2. API Endpoint

Make a POST request to seed default categories:

```bash
POST /purchase-categories/seed-defaults
```

This endpoint will:

- Find all existing clients
- Create default categories for clients that don't have them
- Associate categories with all halls of each client
- Return a success message

### 3. Standalone Script

Run the standalone script:

```bash
npx ts-node scripts/seed-default-expense-categories.ts
```

This script will:

- Initialize the application context
- Call the seeding service
- Log the progress and results
- Close the application context

## Service Methods

The `PurchaseCategoriesService` includes two methods for seeding default categories:

### `seedDefaultExpensesCategoriesForExistingClients()`

This method processes all existing clients:

1. **Fetches all clients** that are not deleted
2. **Checks each client** for existing default categories
3. **Creates default categories** for clients that don't have them
4. **Associates categories with halls** by creating relationships in the `halls_purchase_categories` table
5. **Skips clients** that already have default categories
6. **Uses database transactions** for data integrity
7. **Provides detailed logging** for monitoring progress

### `seedDefaultExpensesCategoriesForSpecificClient(clientId: number)`

This method processes a specific client:

1. **Validates the client** exists and is not deleted
2. **Checks for existing default categories**
3. **Creates default categories** if none exist
4. **Associates categories with all halls** belonging to the client
5. **Uses database transactions** for data integrity
6. **Provides detailed logging** for monitoring progress

## Database Tables Involved

- `clients` - Client information
- `purchase_categories` - Expense categories
- `halls` - Hall information
- `halls_purchase_categories` - Many-to-many relationship between halls and categories

## Rollback

To rollback the migration:

```bash
npm run migration:revert
```

This will remove all default categories created by the migration.

## Notes

- The seeding process is idempotent - it won't create duplicate categories
- Categories are marked as `isDefault: true` to distinguish them from custom categories
- The `created_by` field is set to the client ID for default categories
- Each category is available in both English and Arabic
- Categories are automatically associated with all halls belonging to the client
